import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "./db";
import { mindMaps } from "../drizzle/schema";
import { protectedProcedure, router } from "./_core/trpc";
import type { MindMapDoc } from "../shared/mindmap";

const mindMapTypeSchema = z.enum([
  "mindmap",
  "logic",
  "brace",
  "org",
  "tree",
  "timeline",
  "fishbone",
  "treetable",
  "matrix",
  "grid",
]);

const mindMapNodeSchema: z.ZodType<any> = z.lazy(() =>
  z.object({
    id: z.string(),
    title: z.string(),
    notes: z.string().optional(),
    color: z.string().optional(),
    children: z.array(mindMapNodeSchema),
  }),
);

const mindMapDocSchema = z.union([
  z.object({ kind: z.literal("tree"), root: mindMapNodeSchema }),
  z.object({
    kind: z.literal("table"),
    rows: z.array(z.string()),
    cols: z.array(z.string()),
    cells: z.record(z.string(), z.string()),
  }),
]);

export const mindMapsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.select().from(mindMaps).where(eq(mindMaps.userId, ctx.user.id)).orderBy(desc(mindMaps.updatedAt));
  }),

  byId: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const [map] = await db
        .select()
        .from(mindMaps)
        .where(and(eq(mindMaps.id, input.id), eq(mindMaps.userId, ctx.user.id)))
        .limit(1);
      return map ?? null;
    }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1, "Başlık gerekli"),
        type: mindMapTypeSchema,
        data: mindMapDocSchema as unknown as z.ZodType<MindMapDoc>,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [map] = await db
        .insert(mindMaps)
        .values({ ...input, userId: ctx.user.id })
        .returning();
      return map;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        data: (mindMapDocSchema as unknown as z.ZodType<MindMapDoc>).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...changes } = input;
      const [map] = await db
        .update(mindMaps)
        .set({ ...changes, updatedAt: new Date() })
        .where(and(eq(mindMaps.id, id), eq(mindMaps.userId, ctx.user.id)))
        .returning();
      return map ?? null;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await db.delete(mindMaps).where(and(eq(mindMaps.id, input.id), eq(mindMaps.userId, ctx.user.id)));
      return { success: true } as const;
    }),
});
