import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "./db";
import { notes } from "../drizzle/schema";
import { protectedProcedure, router } from "./_core/trpc";

export const notesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.select().from(notes).where(eq(notes.userId, ctx.user.id)).orderBy(desc(notes.updatedAt));
  }),

  byId: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const [note] = await db
        .select()
        .from(notes)
        .where(and(eq(notes.id, input.id), eq(notes.userId, ctx.user.id)))
        .limit(1);
      return note ?? null;
    }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1, "Başlık gerekli"),
        body: z.string().default(""),
        tag: z.string().min(1).default("Kişisel"),
        date: z.string().length(10).nullable().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [note] = await db
        .insert(notes)
        .values({ ...input, userId: ctx.user.id })
        .returning();
      return note;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        body: z.string().optional(),
        tag: z.string().min(1).optional(),
        date: z.string().length(10).nullable().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...changes } = input;
      const [note] = await db
        .update(notes)
        .set({ ...changes, updatedAt: new Date() })
        .where(and(eq(notes.id, id), eq(notes.userId, ctx.user.id)))
        .returning();
      return note ?? null;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await db.delete(notes).where(and(eq(notes.id, input.id), eq(notes.userId, ctx.user.id)));
      return { success: true } as const;
    }),
});
