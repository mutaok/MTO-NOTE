import { Router } from "express";
import { and, eq } from "drizzle-orm";
import { db, rawSql } from "./db";
import { syncStore, users } from "../drizzle/schema";

export const syncApiRouter = Router();

// In-memory fallback if Neon database isn't connected yet
const memoryStore = new Map<string, any>();

let tableEnsured = false;
async function ensureTables() {
  if (tableEnsured || !rawSql) return;
  try {
    await rawSql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        "openId" VARCHAR(64) NOT NULL UNIQUE,
        name TEXT,
        email VARCHAR(320),
        "loginMethod" VARCHAR(64),
        role VARCHAR(16) DEFAULT 'user' NOT NULL,
        "createdAt" TIMESTAMP DEFAULT NOW() NOT NULL,
        "updatedAt" TIMESTAMP DEFAULT NOW() NOT NULL,
        "lastSignedIn" TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `;
    await rawSql`
      CREATE TABLE IF NOT EXISTS sync_store (
        id SERIAL PRIMARY KEY,
        "userId" INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        "storeKey" VARCHAR(64) NOT NULL,
        data JSONB NOT NULL,
        "updatedAt" TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `;
    tableEnsured = true;
  } catch (e) {
    console.warn("[Sync] Ensure tables fallback:", e);
  }
}

async function getSyncUserId(): Promise<number> {
  await ensureTables();
  try {
    const [user] = await db.select().from(users).where(eq(users.openId, "local-default-user")).limit(1);
    if (user?.id) return user.id;

    const [newUser] = await db
      .insert(users)
      .values({
        openId: "local-default-user",
        name: "Senkronize Kullanıcı",
        loginMethod: "local",
      })
      .onConflictDoUpdate({
        target: users.openId,
        set: { updatedAt: new Date() },
      })
      .returning();
    return newUser?.id || 1;
  } catch (err) {
    return 1;
  }
}

// GET all keys or specific key
syncApiRouter.get("/sync/:key?", async (req, res) => {
  const { key } = req.params;
  try {
    const userId = await getSyncUserId();

    if (key) {
      const [item] = await db
        .select()
        .from(syncStore)
        .where(and(eq(syncStore.userId, userId), eq(syncStore.storeKey, key)))
        .limit(1);

      if (item) {
        return res.json({ success: true, data: item.data });
      }
      if (memoryStore.has(key)) {
        return res.json({ success: true, data: memoryStore.get(key) });
      }
      return res.json({ success: true, data: null });
    }

    // Return all keys
    const items = await db
      .select()
      .from(syncStore)
      .where(eq(syncStore.userId, userId));

    const result: Record<string, any> = {};
    for (const [k, v] of memoryStore.entries()) {
      result[k] = v;
    }
    for (const item of items) {
      result[item.storeKey] = item.data;
    }

    res.json({ success: true, data: result });
  } catch (error) {
    // If DB has error, return in-memory
    if (key) {
      return res.json({ success: true, data: memoryStore.get(key) || null });
    }
    const result: Record<string, any> = {};
    for (const [k, v] of memoryStore.entries()) {
      result[k] = v;
    }
    res.json({ success: true, data: result });
  }
});

// POST save a key
syncApiRouter.post("/sync/:key", async (req, res) => {
  const { key } = req.params;
  const { data } = req.body;

  if (data === undefined) {
    return res.status(400).json({ error: "Missing data payload" });
  }

  // Always keep in memory for immediate access
  memoryStore.set(key, data);

  try {
    const userId = await getSyncUserId();

    // Check existing
    const [existing] = await db
      .select()
      .from(syncStore)
      .where(and(eq(syncStore.userId, userId), eq(syncStore.storeKey, key)))
      .limit(1);

    if (existing) {
      await db
        .update(syncStore)
        .set({ data, updatedAt: new Date() })
        .where(eq(syncStore.id, existing.id));
    } else {
      await db.insert(syncStore).values({
        userId,
        storeKey: key,
        data,
      });
    }

    res.json({ success: true, key });
  } catch (error) {
    // Stored in memory as safe fallback
    res.json({ success: true, key, fallback: "memory" });
  }
});
