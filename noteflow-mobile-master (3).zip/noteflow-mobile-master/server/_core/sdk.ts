import { AXIOS_TIMEOUT_MS, COOKIE_NAME, ONE_YEAR_MS } from "../../shared/const.js";
import axios, { type AxiosInstance } from "axios";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";

const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.length > 0;

export type SessionPayload = {
  openId: string;
  appId: string;
  name: string;
};

export type NeonAuthUser = {
  id: string;
  email: string;
  name: string | null;
  emailVerified: boolean;
};

type NeonAuthEmailResponse = {
  token: string;
  user: NeonAuthUser;
};

const createNeonAuthClient = (): AxiosInstance =>
  axios.create({
    baseURL: ENV.neonAuthBaseUrl,
    timeout: AXIOS_TIMEOUT_MS,
  });

/**
 * Thin client for Neon's managed Better Auth REST API. Only used to verify
 * email/password credentials and obtain a canonical user identity — session
 * management for this app is handled locally via `SDKServer.createSessionToken`.
 */
class NeonAuthService {
  constructor(private client: AxiosInstance) {
    if (!ENV.neonAuthBaseUrl) {
      console.error("[NeonAuth] ERROR: NEON_AUTH_BASE_URL is not configured!");
    }
  }

  async signUpWithEmail(email: string, password: string, name: string): Promise<NeonAuthUser> {
    const { data } = await this.client.post<NeonAuthEmailResponse>("/sign-up/email", {
      email,
      password,
      name,
      callbackURL: ENV.neonAuthCallbackUrl,
    });
    return data.user;
  }

  async signInWithEmail(email: string, password: string): Promise<NeonAuthUser> {
    const { data } = await this.client.post<NeonAuthEmailResponse>("/sign-in/email", {
      email,
      password,
      callbackURL: ENV.neonAuthCallbackUrl,
    });
    return data.user;
  }
}

class SDKServer {
  private readonly neonAuth: NeonAuthService;

  constructor(client: AxiosInstance = createNeonAuthClient()) {
    this.neonAuth = new NeonAuthService(client);
  }

  private parseCookies(cookieHeader: string | undefined) {
    if (!cookieHeader) {
      return new Map<string, string>();
    }

    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }

  private getSessionSecret() {
    const secret = ENV.cookieSecret;
    if (!secret) {
      throw new Error(
        "JWT_SECRET is not set. Add a strong random secret to your .env file before signing or verifying sessions.",
      );
    }
    return new TextEncoder().encode(secret);
  }

  /**
   * Verify a new user's email/password with Neon Auth, then persist/refresh
   * the corresponding local user row.
   */
  async signUp(email: string, password: string, name: string): Promise<User> {
    const neonUser = await this.neonAuth.signUpWithEmail(email, password, name);
    return this.syncLocalUser(neonUser);
  }

  /**
   * Verify an existing user's email/password with Neon Auth, then persist/refresh
   * the corresponding local user row.
   */
  async signIn(email: string, password: string): Promise<User> {
    const neonUser = await this.neonAuth.signInWithEmail(email, password);
    return this.syncLocalUser(neonUser);
  }

  private async syncLocalUser(neonUser: NeonAuthUser): Promise<User> {
    await db.upsertUser({
      openId: neonUser.id,
      name: neonUser.name,
      email: neonUser.email,
      loginMethod: "email",
      lastSignedIn: new Date(),
    });
    const user = await db.getUserByOpenId(neonUser.id);
    if (!user) {
      throw new Error("Failed to persist user after Neon Auth sign-in");
    }
    return user;
  }

  /**
   * Create a session token for a local user openId (Neon Auth user id).
   * @example
   * const sessionToken = await sdk.createSessionToken(user.openId, { name: user.name ?? "" });
   */
  async createSessionToken(
    openId: string,
    options: { expiresInMs?: number; name?: string } = {},
  ): Promise<string> {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || "",
      },
      options,
    );
  }

  async signSession(
    payload: SessionPayload,
    options: { expiresInMs?: number } = {},
  ): Promise<string> {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);
    const secretKey = this.getSessionSecret();

    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name,
    })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setExpirationTime(expirationSeconds)
      .sign(secretKey);
  }

  async verifySession(
    cookieValue: string | undefined | null,
  ): Promise<{ openId: string; appId: string; name: string } | null> {
    if (!cookieValue) {
      return null;
    }

    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"],
      });
      const { openId, appId, name } = payload as Record<string, unknown>;

      if (!isNonEmptyString(openId)) {
        console.warn("[Auth] Session payload missing openId");
        return null;
      }

      return {
        openId,
        appId: isNonEmptyString(appId) ? appId : "",
        name: isNonEmptyString(name) ? name : "",
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }

  async authenticateRequest(req: Request): Promise<User> {
    const authHeader = req.headers.authorization || req.headers.Authorization;
    let token: string | undefined;
    if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
      token = authHeader.slice("Bearer ".length).trim();
    }

    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = token || cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);

    // No login screen in this app: a missing/invalid session falls back to a
    // single local user instead of failing the request. A previously issued,
    // still-valid session cookie (from before login was removed) keeps working
    // as that real account.
    if (!session) {
      return db.getOrCreateDefaultUser();
    }

    const user = await db.getUserByOpenId(session.openId);
    if (!user) {
      return db.getOrCreateDefaultUser();
    }

    await db.upsertUser({
      openId: user.openId,
      lastSignedIn: new Date(),
    });

    return user;
  }
}

export const sdk = new SDKServer();
