import { and, asc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "./db";
import { tasks } from "../drizzle/schema";
import { protectedProcedure, router } from "./_core/trpc";

export const tasksRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, ctx.user.id))
      .orderBy(asc(tasks.dueDate), asc(tasks.dueTime));
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1, "Başlık gerekli"),
        list: z.string().min(1).default("Kişisel"),
        dueDate: z.string().nullable().default(null),
        dueTime: z.string().nullable().default(null),
        color: z.string().default("#64B5F6"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [task] = await db
        .insert(tasks)
        .values({ ...input, userId: ctx.user.id })
        .returning();
      return task;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        list: z.string().min(1).optional(),
        dueDate: z.string().nullable().optional(),
        dueTime: z.string().nullable().optional(),
        done: z.boolean().optional(),
        color: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...changes } = input;
      const [task] = await db
        .update(tasks)
        .set({ ...changes, updatedAt: new Date() })
        .where(and(eq(tasks.id, id), eq(tasks.userId, ctx.user.id)))
        .returning();
      return task ?? null;
    }),

  toggleDone: protectedProcedure
    .input(z.object({ id: z.number(), done: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const [task] = await db
        .update(tasks)
        .set({ done: input.done, updatedAt: new Date() })
        .where(and(eq(tasks.id, input.id), eq(tasks.userId, ctx.user.id)))
        .returning();
      return task ?? null;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await db.delete(tasks).where(and(eq(tasks.id, input.id), eq(tasks.userId, ctx.user.id)));
      return { success: true } as const;
    }),
});
