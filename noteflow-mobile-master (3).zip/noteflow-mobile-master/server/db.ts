import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { eq } from 'drizzle-orm';
import * as schema from '../drizzle/schema';
import { users, type InsertUser, type User } from '../drizzle/schema';
import { ENV } from './_core/env';

let db: any;
let rawSql: any = null;

const LOCAL_USER = {
  id: 1,
  openId: 'local-default-user',
  name: 'Yerel Kullanıcı',
  email: null,
  loginMethod: 'local',
  role: 'user',
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

function createMockDb() {
  console.warn('[NoteFlow] DATABASE_URL not set — using in-memory mock (data is lost on restart)');

  const store = new Map<string, any[]>([['users', [{ ...LOCAL_USER }]]]);
  const counters = new Map<string, number>([['users', 2]]);

  const TABLES: Array<[any, string]> = [
    [schema.users, 'users'],
    [schema.notes, 'notes'],
    [schema.tasks, 'tasks'],
    [schema.mindMaps, 'mind_maps'],
    [schema.syncStore, 'sync_store'],
  ];

  function tableName(ref: any): string {
    for (const [obj, name] of TABLES) if (ref === obj) return name;
    return String(ref?.[Symbol.for('drizzle:Name')] ?? 'unknown');
  }

  function rowsOf(name: string): any[] {
    if (!store.has(name)) store.set(name, []);
    return store.get(name)!;
  }

  /** Walk a drizzle SQL condition tree collecting { columnName: value } equality pairs. */
  function conditions(cond: any, out: Record<string, any> = {}): Record<string, any> {
    if (!cond || typeof cond !== 'object' || !Array.isArray(cond.queryChunks)) return out;
    let col: string | null = null;
    for (const ch of cond.queryChunks) {
      if (!ch || typeof ch !== 'object') continue;
      if (Array.isArray(ch.queryChunks)) { conditions(ch, out); continue; }
      if (ch.name && ch.columnType) { col = ch.name; continue; }
      if (ch.constructor?.name === 'Param' && col) { out[col] = ch.value; col = null; }
    }
    return out;
  }

  function matches(row: any, filter: Record<string, any>): boolean {
    return Object.entries(filter).every(([k, v]) => row[k] === v);
  }

  /**
   * Thenable query builder. `then` must resolve with a plain array copy —
   * resolving with an object that is itself thenable deadlocks the await.
   */
  function query(rows: any[]): any {
    const settle = () => Promise.resolve(rows.slice());
    return {
      where: (cond: any) => query(rows.filter((r) => matches(r, conditions(cond)))),
      limit: (n: number) => query(rows.slice(0, n)),
      orderBy: () => query(rows),
      returning: () => query(rows),
      then: (res: any, rej: any) => settle().then(res, rej),
      catch: (fn: any) => settle().catch(fn),
      finally: (fn: any) => settle().finally(fn),
    };
  }

  return new Proxy({}, {
    get: (_t, prop) => {
      if (prop === 'query') {
        return new Proxy({}, {
          get: () => ({ findMany: async () => [], findFirst: async () => null }),
        });
      }

      if (prop === 'select') {
        return () => ({ from: (ref: any) => query(rowsOf(tableName(ref))) });
      }

      if (prop === 'insert') {
        return (ref: any) => {
          const name = tableName(ref);
          return {
            values: (data: any) => {
              const rows = rowsOf(name);
              const insert = () => {
                const id = counters.get(name) ?? 1;
                counters.set(name, id + 1);
                const row = { id, createdAt: new Date(), updatedAt: new Date(), ...data };
                rows.push(row);
                return row;
              };
              return {
                returning: () => query([insert()]),
                onConflictDoUpdate: (cfg: any) => {
                  const targetCol = cfg?.target?.name;
                  const existing = targetCol
                    ? rows.find((r) => r[targetCol] === data[targetCol])
                    : undefined;
                  if (existing) {
                    Object.assign(existing, cfg?.set ?? {}, { updatedAt: new Date() });
                    return { returning: () => query([existing]) };
                  }
                  return { returning: () => query([insert()]) };
                },
              };
            },
          };
        };
      }

      if (prop === 'update') {
        return (ref: any) => {
          const name = tableName(ref);
          return {
            set: (changes: any) => ({
              where: (cond: any) => {
                const hit = rowsOf(name).filter((r) => matches(r, conditions(cond)));
                hit.forEach((r) => Object.assign(r, changes, { updatedAt: new Date() }));
                return query(hit);
              },
            }),
          };
        };
      }

      if (prop === 'delete') {
        return (ref: any) => {
          const name = tableName(ref);
          return {
            where: (cond: any) => {
              const filter = conditions(cond);
              const kept = rowsOf(name).filter((r) => !matches(r, filter));
              store.set(name, kept);
              return query([]);
            },
          };
        };
      }

      return () => query([]);
    },
  });
}

try {
  if (ENV.databaseUrl) {
    rawSql = neon(ENV.databaseUrl);
    db = drizzle(rawSql, { schema });
  } else {
    db = createMockDb();
  }
} catch {
  db = createMockDb();
}

export function getDb() {
  return db;
}

export { db, rawSql };

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const [user] = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return user;
}

export async function upsertUser(data: Partial<InsertUser> & { openId: string }): Promise<User> {
  const { openId, ...rest } = data;
  const [user] = await db
    .insert(users)
    .values({ openId, ...rest })
    .onConflictDoUpdate({
      target: users.openId,
      set: { ...rest, updatedAt: new Date() },
    })
    .returning();
  return user;
}

const DEFAULT_OPEN_ID = 'local-default-user';

/**
 * The app has no login screen - every request that isn't carrying a valid
 * session cookie is treated as this single local user, created on first use.
 */
export async function getOrCreateDefaultUser(): Promise<User> {
  const existing = await getUserByOpenId(DEFAULT_OPEN_ID);
  if (existing) return existing;
  return upsertUser({
    openId: DEFAULT_OPEN_ID,
    name: 'Yerel Kullanıcı',
    loginMethod: 'local',
    lastSignedIn: new Date(),
  });
}