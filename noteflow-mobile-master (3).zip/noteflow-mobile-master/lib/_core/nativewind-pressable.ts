// NoteFlow uses NativeWind classes on Pressable for compact, accessible touch targets.
// Keep the component unpatched so className styles are applied on mobile and web.
export {};
