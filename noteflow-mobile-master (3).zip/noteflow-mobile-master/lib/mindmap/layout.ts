import type { MindMapNode, MindMapType } from "@/shared/mindmap";

export type Point = { x: number; y: number };

export type LayoutNode = {
  id: string;
  node: MindMapNode;
  parentId: string | null;
  depth: number;
  x: number;
  y: number;
};

export type LayoutEdge = { id: string; from: Point; to: Point };

export type LayoutResult = {
  nodes: LayoutNode[];
  edges: LayoutEdge[];
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
};

export const NODE_W = 150;
export const NODE_H = 48;
const GAP_MAIN = 70;
const GAP_CROSS = 20;

function bounds(nodes: LayoutNode[]): Pick<LayoutResult, "minX" | "maxX" | "minY" | "maxY"> {
  if (nodes.length === 0) return { minX: 0, maxX: 0, minY: 0, maxY: 0 };
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const n of nodes) {
    minX = Math.min(minX, n.x - NODE_W / 2);
    maxX = Math.max(maxX, n.x + NODE_W / 2);
    minY = Math.min(minY, n.y - NODE_H / 2);
    maxY = Math.max(maxY, n.y + NODE_H / 2);
  }
  return { minX, maxX, minY, maxY };
}

function edgesFromParentIds(nodes: LayoutNode[]): LayoutEdge[] {
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const edges: LayoutEdge[] = [];
  for (const n of nodes) {
    if (!n.parentId) continue;
    const parent = byId.get(n.parentId);
    if (!parent) continue;
    edges.push({ id: `${parent.id}-${n.id}`, from: { x: parent.x, y: parent.y }, to: { x: n.x, y: n.y } });
  }
  return edges;
}

type Direction = "right" | "left" | "down";

/** Reingold-Tilford-lite: leaves get sequential cross-axis slots, parents center over their children's slot span. */
function layoutDirectional(root: MindMapNode, direction: Direction): LayoutNode[] {
  const nodes: LayoutNode[] = [];
  let nextSlot = 0;
  const mainStep = direction === "down" ? NODE_H + GAP_MAIN : NODE_W + GAP_MAIN;
  const crossStep = direction === "down" ? NODE_W + GAP_CROSS : NODE_H + GAP_CROSS;

  function visit(node: MindMapNode, depth: number, parentId: string | null): number {
    let slot: number;
    if (node.children.length === 0) {
      slot = nextSlot;
      nextSlot += 1;
    } else {
      const childSlots = node.children.map((c) => visit(c, depth + 1, node.id));
      slot = (childSlots[0] + childSlots[childSlots.length - 1]) / 2;
    }
    const main = direction === "left" ? -depth * mainStep : depth * mainStep;
    const cross = slot * crossStep;
    nodes.push({ id: node.id, node, parentId, depth, x: direction === "down" ? cross : main, y: direction === "down" ? main : cross });
    return slot;
  }

  visit(root, 0, null);
  return nodes;
}

/** Classic two-sided mind map: root's children split into a right-growing half and a left-growing half. */
function layoutBidirectional(root: MindMapNode): LayoutNode[] {
  const mainStep = NODE_W + GAP_MAIN;
  const crossStep = NODE_H + GAP_CROSS;
  const rootNode: LayoutNode = { id: root.id, node: root, parentId: null, depth: 0, x: 0, y: 0 };
  const nodes: LayoutNode[] = [rootNode];

  const half = Math.ceil(root.children.length / 2);
  const sides: [MindMapNode[], 1 | -1][] = [
    [root.children.slice(0, half), 1],
    [root.children.slice(half), -1],
  ];

  for (const [children, sign] of sides) {
    if (children.length === 0) continue;
    let nextSlot = 0;
    const side: LayoutNode[] = [];
    function visit(node: MindMapNode, depth: number, parentId: string): number {
      let slot: number;
      if (node.children.length === 0) {
        slot = nextSlot;
        nextSlot += 1;
      } else {
        const childSlots = node.children.map((c) => visit(c, depth + 1, node.id));
        slot = (childSlots[0] + childSlots[childSlots.length - 1]) / 2;
      }
      side.push({ id: node.id, node, parentId, depth, x: sign * depth * mainStep, y: slot * crossStep });
      return slot;
    }
    children.forEach((c) => visit(c, 1, root.id));
    const slots = side.map((n) => n.y / crossStep);
    const center = (Math.min(...slots) + Math.max(...slots)) / 2;
    for (const n of side) n.y -= center * crossStep;
    nodes.push(...side);
  }

  return nodes;
}

function layoutTimeline(root: MindMapNode): LayoutNode[] {
  const step = NODE_W + GAP_MAIN;
  const rootNode: LayoutNode = { id: root.id, node: root, parentId: null, depth: 0, x: 0, y: -(NODE_H + GAP_CROSS) };
  const nodes: LayoutNode[] = [rootNode];
  root.children.forEach((child, i) => {
    nodes.push({ id: child.id, node: child, parentId: root.id, depth: 1, x: i * step, y: 0 });
    // sub-notes under a timeline stop stack downward
    child.children.forEach((sub, j) => {
      nodes.push({ id: sub.id, node: sub, parentId: child.id, depth: 2, x: i * step, y: (j + 1) * (NODE_H + GAP_CROSS) });
    });
  });
  return nodes;
}

function layoutFishbone(root: MindMapNode): LayoutNode[] {
  const spineStep = NODE_W + GAP_MAIN;
  const categories = root.children;
  const n = Math.max(categories.length, 1);
  const rootX = n * spineStep + spineStep / 2;
  const nodes: LayoutNode[] = [{ id: root.id, node: root, parentId: null, depth: 0, x: rootX, y: 0 }];

  categories.forEach((cat, i) => {
    const attachX = (i + 1) * spineStep;
    const side: 1 | -1 = i % 2 === 0 ? -1 : 1;
    const branchLen = 130;
    const catX = attachX - branchLen * 0.55;
    const catY = side * branchLen * 0.85;
    nodes.push({ id: cat.id, node: cat, parentId: root.id, depth: 1, x: catX, y: catY });
    cat.children.forEach((cause, j) => {
      const t = (j + 1) / (cat.children.length + 1);
      nodes.push({
        id: cause.id,
        node: cause,
        parentId: cat.id,
        depth: 2,
        x: catX + (attachX - catX) * t,
        y: catY * (1 - t) - side * 8,
      });
    });
  });

  return nodes;
}

export function layoutMindMap(type: MindMapType, root: MindMapNode): LayoutResult {
  let nodes: LayoutNode[];
  switch (type) {
    case "mindmap":
      nodes = layoutBidirectional(root);
      break;
    case "org":
    case "treetable":
      nodes = layoutDirectional(root, "down");
      break;
    case "timeline":
      nodes = layoutTimeline(root);
      break;
    case "fishbone":
      nodes = layoutFishbone(root);
      break;
    case "logic":
    case "brace":
    case "tree":
    default:
      nodes = layoutDirectional(root, "right");
      break;
  }
  const edges = type === "fishbone" ? buildFishboneEdges(root, nodes) : edgesFromParentIds(nodes);
  return { nodes, edges, ...bounds(nodes) };
}

function buildFishboneEdges(root: MindMapNode, nodes: LayoutNode[]): LayoutEdge[] {
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const rootLN = byId.get(root.id)!;
  const spineStep = NODE_W + GAP_MAIN;
  const edges: LayoutEdge[] = [{ id: "spine", from: { x: 0, y: 0 }, to: { x: rootLN.x, y: 0 } }];
  root.children.forEach((cat, i) => {
    const catLN = byId.get(cat.id)!;
    const attachX = (i + 1) * spineStep;
    edges.push({ id: `spine-${cat.id}`, from: { x: attachX, y: 0 }, to: { x: catLN.x, y: catLN.y } });
    cat.children.forEach((cause) => {
      const causeLN = byId.get(cause.id);
      if (causeLN) edges.push({ id: `${cat.id}-${cause.id}`, from: { x: catLN.x, y: catLN.y }, to: { x: causeLN.x, y: causeLN.y } });
    });
  });
  return edges;
}
