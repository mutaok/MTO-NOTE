import { ReactNode } from 'react';
import { Pressable, Text, View } from 'react-native';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';

type IconName = React.ComponentProps<typeof IconSymbol>['name'];

export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return <View className="mb-3 flex-row items-center justify-between"><Text className="text-[18px] font-semibold text-foreground">{title}</Text>{action && onAction ? <Pressable onPress={onAction} style={({ pressed }) => [{ opacity: pressed ? 0.65 : 1 }]}><Text style={{ color: colors.primary }} className="text-[13px] font-semibold">{action}</Text></Pressable> : null}</View>;
}

export function SurfaceCard({ children, className = '', onPress }: { children: ReactNode; className?: string; onPress?: () => void }) {
  const content = <View className={`rounded-2xl border border-border bg-surface ${className}`}>{children}</View>;
  if (!onPress) return content;
  return <Pressable onPress={onPress} style={({ pressed }) => [{ opacity: pressed ? 0.82 : 1 }]}>{content}</Pressable>;
}

export function IconButton({ name, onPress, label, size = 20 }: { name: IconName; onPress: () => void; label?: string; size?: number }) {
  const colors = useColors();
  return <Pressable accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [{ opacity: pressed ? 0.55 : 1 }]}><IconSymbol name={name} size={size} color={colors.foreground} /></Pressable>;
}

export function PrimaryButton({ label, icon, onPress }: { label: string; icon?: IconName; onPress: () => void }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={({ pressed }) => [{ height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 999, paddingHorizontal: 20, backgroundColor: colors.primary, transform: [{ scale: pressed ? 0.97 : 1 }] }]}><>{icon ? <IconSymbol name={icon} size={19} color="#0F172A" /> : null}<Text className="text-[14px] font-bold text-slate-950">{label}</Text></></Pressable>;
}

export function FilterChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={({ pressed }) => [{ alignSelf: 'flex-start', marginRight: 8, borderWidth: 1, borderRadius: 999, paddingHorizontal: 16, paddingVertical: 8, backgroundColor: active ? colors.primary : colors.surface, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.72 : 1 }]}><Text style={{ color: active ? '#0F172A' : colors.muted }} className="text-[13px] font-semibold">{label}</Text></Pressable>;
}

export function FloatingActionButton({ onPress, label = 'Yeni' }: { onPress: () => void; label?: string }) {
  const colors = useColors();
  return <Pressable accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [{ position: 'absolute', right: 20, bottom: 20, height: 56, flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 28, paddingHorizontal: 20, backgroundColor: colors.primary, transform: [{ scale: pressed ? 0.96 : 1 }] }]}><IconSymbol name="plus" size={23} color="#0F172A" /><Text className="text-[14px] font-bold text-slate-950">{label}</Text></Pressable>;
}

export function EmptyState({ icon, title, description }: { icon: IconName; title: string; description: string }) {
  const colors = useColors();
  return <View className="items-center px-8 py-16"><View className="mb-4 h-16 w-16 items-center justify-center rounded-3xl bg-blue-100 dark:bg-slate-800"><IconSymbol name={icon} size={30} color={colors.primary} /></View><Text className="text-center text-[18px] font-semibold text-foreground">{title}</Text><Text className="mt-2 text-center text-[14px] leading-5 text-muted">{description}</Text></View>;
}
