// Fallback for using MaterialIcons on Android and web.
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { SymbolWeight } from 'expo-symbols';
import { OpaqueColorValue, type StyleProp, type TextStyle } from 'react-native';

type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  'house.fill': 'home', 'note.text': 'description', 'checkmark.circle.fill': 'check-circle', 'calendar': 'calendar-month', 'ellipsis.circle': 'more-horiz', 'magnifyingglass': 'search', 'plus': 'add', 'sparkles': 'auto-awesome', 'checklist': 'checklist', 'event': 'event', 'document.scanner': 'document-scanner', 'arrow.up.right': 'north-east', 'pin.fill': 'push-pin', 'clock': 'schedule', 'chevron.right': 'chevron-right', 'chevron.left': 'chevron-left', 'arrow.left': 'arrow-back', 'more': 'more-vert', 'bookmark': 'bookmark-border', 'tag': 'local-offer', 'folder': 'folder-open', 'close': 'close', 'format.bold': 'format-bold', 'format.italic': 'format-italic', 'format.list.bulleted': 'format-list-bulleted', 'link': 'link', 'code': 'code', 'table': 'table-chart', 'heading': 'title', 'dark.mode': 'dark-mode', 'settings': 'settings', 'help': 'help-outline', 'share': 'ios-share', 'archive': 'archive', 'logout': 'logout', 'delete': 'delete-outline',
  'hub': 'hub', 'device-hub': 'device-hub', 'call-split': 'call-split', 'account-tree': 'account-tree', 'timeline': 'timeline', 'schema': 'schema', 'grid-on': 'grid-on', 'undo': 'undo', 'redo': 'redo', 'add-circle': 'add-circle-outline', 'palette': 'palette', 'edit': 'edit', 'zoom-in': 'zoom-in-map', 'book': 'menu-book', 'book.closed': 'menu-book',
} as const;

export function IconSymbol({ name, size = 24, color, style }: { name: IconSymbolName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: SymbolWeight }) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
