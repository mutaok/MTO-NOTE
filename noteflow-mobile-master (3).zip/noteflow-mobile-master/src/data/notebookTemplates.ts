import {
  Notebook,
  NotebookType,
  MathFormula,
  Flashcard,
  Citation,
  CountdownEvent,
  Milestone,
  FileVersion,
  MoodEntry,
  BookRecord,
  TravelPlan,
  RecipeData,
  FinanceItem,
  BudgetGoal,
  WorkoutEntry,
  StickyNote,
  CodeSnippet,
  BugResolution,
  AutomationRule,
} from '../types';

export interface NotebookTypeMeta {
  type: NotebookType;
  name: string;
  badge: string;
  description: string;
  iconName: string;
  icon?: string;
  accentColor: string;
  color?: string;
  bgGradient: string;
  paperStyle: 'plain' | 'lined' | 'grid' | 'dots';
  defaultViews: string[];
  keyFeatures: string[];
  specialTools?: string[];
  templateSnippet: string;
}

export const NOTEBOOK_TYPES_CONFIG: Record<NotebookType, NotebookTypeMeta> = {
  academic: {
    type: 'academic',
    name: 'Ders / Akademik',
    badge: 'Akademik',
    description: 'Cornell not düzeni, formül kütüphanesi, soru-cevap kartları, kaynakça ve sınav sayacı.',
    iconName: 'GraduationCap',
    accentColor: '#4F46E5', // Indigo
    bgGradient: 'from-indigo-500/10 to-blue-500/10 dark:from-indigo-950/40 dark:to-blue-950/40',
    paperStyle: 'lined',
    defaultViews: ['notes', 'special', 'calendar', 'mindmap'],
    keyFeatures: ['Cornell Düzeni', 'Soru-Cevap Kartları', 'Formül Kütüphanesi', 'Sınav Sayacı', 'Kaynakça'],
    templateSnippet: `## İpuçları & Sorular (Cues)\n- Temel kavramlar nelerdir?\n- Ana çıkarım?\n\n## Notlar (Notes)\n1. Konu özeti ve türetmeler\n2. Örnek uygulama\n\n## Özet (Summary)\nBu dersin ana çıktısı ve sınav için kritik noktalar...`,
  },
  project: {
    type: 'project',
    name: 'Proje',
    badge: 'Proje',
    description: 'Kanban panosu, Gantt zaman çizelgesi, kilometre taşları, dosya sürümleri ve ilerleme takibi.',
    iconName: 'Kanban',
    accentColor: '#0284C7', // Sky Blue
    bgGradient: 'from-sky-500/10 to-indigo-500/10 dark:from-sky-950/40 dark:to-indigo-950/40',
    paperStyle: 'plain',
    defaultViews: ['kanban', 'table', 'calendar', 'notes'],
    keyFeatures: ['Kanban Panosu', 'Gantt Zaman Çizelgesi', 'Kilometre Taşları', 'Dosya Sürümleri', 'İlerleme %'],
    templateSnippet: `### Proje Hedefi\nYeni ürün özelliklerini 3. çeyrekte canlıya almak.\n\n### Görev Dağılımı\n- [ ] UI Tasarımları (Ahmet, 15 Eylül)\n- [ ] API Entegrasyonu (Selin, 20 Eylül)\n- [ ] QA Testleri (Mehmet, 25 Eylül)\n\n### Riskler & Bağımlılıklar\nÜçüncü parti servis API anahtarlarının temini.`,
  },
  journal: {
    type: 'journal',
    name: 'Günlük',
    badge: 'Günlük',
    description: 'Tarih odaklı akış, mood & enerji grafiği, alışkanlıklar, şükran listesi ve PIN defter kilidi.',
    iconName: 'BookHeart',
    accentColor: '#D97706', // Amber
    bgGradient: 'from-amber-500/10 to-orange-500/10 dark:from-amber-950/40 dark:to-orange-950/40',
    paperStyle: 'dots',
    defaultViews: ['special', 'calendar', 'notes', 'analytics'],
    keyFeatures: ['Mood & Enerji Takibi', 'Alışkanlık Matrisi', 'Şükran Listesi', 'PIN Defter Kilidi', 'Tarihsel Akış'],
    templateSnippet: `### Bugünün Ruh Hali & Düşünceleri\nBugün oldukça verimli ve huzurlu geçti.\n\n### Bugün Neye Minnettarım?\n1. Sabah içtiğim sıcak kahve\n2. Dostumla yaptığım samimi sohbet\n3. Tamamlanan önemli bir iş\n\n### Günün Öğretisi\nAcele etmeden odaklanmak her zaman daha hızlı sonuç veriyor.`,
  },
  meeting: {
    type: 'meeting',
    name: 'Toplantı',
    badge: 'Toplantı',
    description: 'Ajanda, katılımcılar, kararlar, aksiyon maddeleri, ses transkripti ve WhatsApp/E-posta gönderimi.',
    iconName: 'Users',
    accentColor: '#0D9488', // Teal
    bgGradient: 'from-teal-500/10 to-emerald-500/10 dark:from-teal-950/40 dark:to-emerald-950/40',
    paperStyle: 'plain',
    defaultViews: ['notes', 'table', 'calendar'],
    keyFeatures: ['Gündem Maddeleri', 'Katılımcı Listesi', 'Karar Kaydı', 'Aksiyonlar -> Görev', 'Hızlı Paylaşım'],
    templateSnippet: `### Gündem Maddeleri\n1. Sprint hedeflerinin gözden geçirilmesi\n2. Müşteri talepleri ve önceliklendirme\n\n### Alınan Kararlar\n- Yeni tasarım sistemi v2 onaylandı.\n- Sunucu bakım penceresi Cumartesi 02:00 olarak belirlendi.\n\n### Aksiyonlar\n- [ ] Raporu hazırla (Ali - 18 Eylül)\n- [ ] Güvenlik taraması yap (Zeynep - 19 Eylül)`,
  },
  reading: {
    type: 'reading',
    name: 'Kitap / Okuma',
    badge: 'Okuma',
    description: 'Raf görünümü, ISBN/Yazar/Sayfa takibi, alıntılar kütüphanesi, karakter haritası ve özet.',
    iconName: 'BookOpen',
    accentColor: '#7C3AED', // Violet
    bgGradient: 'from-violet-500/10 to-purple-500/10 dark:from-violet-950/40 dark:to-purple-950/40',
    paperStyle: 'lined',
    defaultViews: ['gallery', 'notes', 'mindmap', 'special'],
    keyFeatures: ['Raf (Bookshelf) Görünümü', 'Okuma İlerlemesi', 'Alıntılar', 'Karakter Haritası', 'Yıldız Derecelendirme'],
    templateSnippet: `### Kitap İncelemesi & Ana Fikir\nKitabın ana teması insanın anlam arayışı ve irade gücüdür.\n\n### Beğenilen Alıntılar\n> "İnsanı yıkan şey acı çekmesi değil, anlamsız bir acı çekmesidir." (Sayfa 74)\n\n### Karakterler / Konu Akışı\nBaş kahramanın iç çatışması ve çevresiyle olan dinamikleri.`,
  },
  travel: {
    type: 'travel',
    name: 'Seyahat',
    badge: 'Seyahat',
    description: 'Harita kartları, rota, rezervasyonlar, seyahat bütçesi, paket listesi ve döviz çevirici.',
    iconName: 'Plane',
    accentColor: '#059669', // Emerald
    bgGradient: 'from-emerald-500/10 to-cyan-500/10 dark:from-emerald-950/40 dark:to-cyan-950/40',
    paperStyle: 'plain',
    defaultViews: ['special', 'calendar', 'table', 'notes'],
    keyFeatures: ['Harita / Rota Kartları', 'Gün Gün Plan', 'Rezervasyonlar (PNR)', 'Bütçe Takibi', 'Döviz Çevirici'],
    templateSnippet: `### Gün 1: Şehir Turu & Tarihi Mekanlar\n- 09:00: Eski Şehir Meydanı yürüyüşü\n- 13:00: Yerel lezzetler öğle yemeği\n- 16:00: Sanat müzesi ziyareti\n\n### Önemli Rezervasyonlar\n- Uçuş: TK1821 (PNR: X7K2L9)\n- Otel: Grand Central (Giriş: 14:00)\n\n### Paket Hatırlatıcıları\nPasaport, adaptör, rahat yürüyüş ayakkabısı.`,
  },
  recipe: {
    type: 'recipe',
    name: 'Tarif / Yemek',
    badge: 'Mutfak',
    description: 'Malzeme listesi, porsiyon ölçekleme, tek tıkla alışveriş listesine aktarma ve pişirme zamanlayıcısı.',
    iconName: 'UtensilsCrossed',
    accentColor: '#EA580C', // Orange
    bgGradient: 'from-orange-500/10 to-red-500/10 dark:from-orange-950/40 dark:to-red-950/40',
    paperStyle: 'grid',
    defaultViews: ['special', 'gallery', 'notes'],
    keyFeatures: ['Porsiyon Ölçekleme (2x/3x)', 'Alışveriş Listesine Ekle', 'Adım Adım Pişirme Modu', 'Dahili Zamanlayıcı', 'Besin Değerleri'],
    templateSnippet: `### Malzemeler (4 Kişilik)\n- 400g Makarna\n- 2 yemek kaşığı zeytinyağı\n- 3 diş sarımsak\n- 1 kutu krema\n- 100g parmesan\n\n### Hazırlanış Adımları\n1. Makarnayı bol tuzlu suda al dente haşlayın.\n2. Tavada zeytinyağı ile ezilmiş sarımsakları soteleyin.\n3. Kremayı ekleyip kısık ateşte sos kıvamına getirin.\n4. Makarnayı sosla birleştirip peynirle servis yapın.`,
  },
  finance: {
    type: 'finance',
    name: 'Finans / Bütçe',
    badge: 'Finans',
    description: 'Gelir-gider tablosu, kategoriler, grafikler, tekrarlayan abonelikler ve bütçe hedefi.',
    iconName: 'PieChart',
    accentColor: '#16A34A', // Green
    bgGradient: 'from-green-500/10 to-teal-500/10 dark:from-green-950/40 dark:to-teal-950/40',
    paperStyle: 'grid',
    defaultViews: ['special', 'table', 'notes', 'analytics'],
    keyFeatures: ['Gelir / Gider Tablosu', 'Kategori Grafikleri', 'Tekrarlayan Faturalar', 'Bütçe Hedef Barı', 'Net Tasarruf Analizi'],
    templateSnippet: `### Aylık Finansal Hedef\nAylık gelirin %25'ini tasarrufa/yatırıma ayırmak.\n\n### Sabit Giderler\n- Kira: 15.000 TL\n- Aidat & Faturalar: 2.500 TL\n- Abonelikler: 450 TL\n\n### Değerlendirme\nMarket harcamalarında haftalık 3.000 TL bütçe sınırı aşılmadı.`,
  },
  fitness: {
    type: 'fitness',
    name: 'Sağlık / Spor',
    badge: 'Fitness',
    description: 'Antrenman logu, set/tekrar tablosu, vücut ölçümleri, 8 bardak su sayacı ve gelişim grafikleri.',
    iconName: 'Activity',
    accentColor: '#E11D48', // Rose
    bgGradient: 'from-rose-500/10 to-pink-500/10 dark:from-rose-950/40 dark:to-pink-950/40',
    paperStyle: 'lined',
    defaultViews: ['special', 'table', 'calendar', 'notes'],
    keyFeatures: ['Set / Tekrar Logu', 'Günlük 8 Bardak Su', 'Vücut Ölçüm Takibi', 'Gelişim Grafikleri', 'Haftalık Egzersiz Süresi'],
    templateSnippet: `### Antrenman: Üst Vücut İtiş\n- Isınma: 5 dk ip atlama & dinamik esneme\n\n### Set & Tekrarlar\n1. Bench Press: 4 set x 8 tekrar (75 kg)\n2. Omuz Press: 3 set x 10 tekrar (20 kg dumbell)\n3. Triceps Pushdown: 3 set x 12 tekrar\n\n### Günlük Hidrasyon\nBugün 2.5L su tüketimi tamamlandı. Enerji seviyesi yüksek.`,
  },
  brainstorm: {
    type: 'brainstorm',
    name: 'Fikir / Beyin Fırtınası',
    badge: 'Fikir',
    description: 'Renkli yapışkan notlar (Sticky Notes), zihin haritası, rastgele bağlantı ve AI genişletme.',
    iconName: 'Lightbulb',
    accentColor: '#F59E0B', // Amber/Yellow
    bgGradient: 'from-yellow-500/10 to-amber-500/10 dark:from-yellow-950/40 dark:to-amber-950/40',
    paperStyle: 'dots',
    defaultViews: ['special', 'mindmap', 'notes', 'gallery'],
    keyFeatures: ['Sticky Notes Tahtası', 'Zihin Haritası Entegrasyonu', 'Rastgele Bağlantı Motoru', 'AI İle Fikir Genişletme', 'Serbest Fikir Tuvali'],
    templateSnippet: `### Çekirdek Problem\nKullanıcıların günlük notlarını defter türlerine göre özelleştirememesi.\n\n### Çözüm Fikirleri (Beyin Fırtınası)\n1. Her deftere özel araç kutusu ve widgetlar sağlamak\n2. Otomasyon kuralları eklemek (Toplantıdan göreve aktarma)\n3. Çizgili/kareli kağıt ve formül kütüphanesi entegrasyonu`,
  },
  code: {
    type: 'code',
    name: 'Kod / Teknik',
    badge: 'Geliştirici',
    description: 'Sözdizimi vurgulamalı kod blokları, terminal komutları, snippet kütüphanesi ve hata çözümleri.',
    iconName: 'Code2',
    accentColor: '#2563EB', // Blue
    bgGradient: 'from-blue-500/10 to-cyan-500/10 dark:from-blue-950/40 dark:to-cyan-950/40',
    paperStyle: 'grid',
    defaultViews: ['notes', 'special', 'table', 'kanban'],
    keyFeatures: ['Sözdizimi Vurgulu Bloklar', 'Terminal & Hızlı Kopyala', 'Snippet Kütüphanesi', 'Hata & Çözüm Logu', 'GitHub Entegrasyonu'],
    templateSnippet: `### Teknik Mimari & Servis Tasarımı\nREST API yerine tRPC veya WebSocket tabanlı anlık senkronizasyon yapısı.\n\n\`\`\`typescript\n// Örnek TypeScript Interface\ninterface NotebookRecord {\n  id: string;\n  title: string;\n  type: NotebookType;\n  created: Date;\n}\n\`\`\`\n\n### Terminal Komutları\n\`npm run build && npm run preview\``,
  },
};

// Ensure specialTools, color, and icon aliases are present for all types
Object.values(NOTEBOOK_TYPES_CONFIG).forEach((meta) => {
  if (!meta.specialTools) {
    meta.specialTools = meta.keyFeatures || [];
  }
  meta.color = meta.accentColor;
  meta.icon = meta.iconName;
});

// Initial Default Notebooks showcasing all types
export const DEFAULT_NOTEBOOKS: Notebook[] = [
  {
    id: '101',
    title: 'Bilgisayar Mühendisliği & Matematik',
    description: 'Algoritmalar, diferansiyel denklemler ve veri yapıları ders notları.',
    type: 'academic',
    color: '#4F46E5',
    icon: 'GraduationCap',
    paperStyle: 'lined',
    defaultView: 'notes',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Üniversite', 'Algoritmalar', 'Matematik'],
    collaborators: [
      { id: 'c1', name: 'Can Demir', email: 'can@example.com', role: 'owner' },
      { id: 'c2', name: 'Prof. Yılmaz', email: 'yilmaz@univ.edu', role: 'commenter' },
    ],
  },
  {
    id: '102',
    title: 'NoteFlow v2.0 Geliştirme Projesi',
    description: 'Ürün yol haritası, sprint görevleri ve lansman kilometre taşları.',
    type: 'project',
    color: '#0284C7',
    icon: 'Kanban',
    paperStyle: 'plain',
    defaultView: 'kanban',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Yazılım', 'Sprint', 'Lansman'],
    collaborators: [
      { id: 'c1', name: 'Can Demir', email: 'can@example.com', role: 'owner' },
      { id: 'c3', name: 'Selin Kaya (Tasarım)', email: 'selin@team.io', role: 'editor' },
      { id: 'c4', name: 'Mehmet Eren (Backend)', email: 'mehmet@team.io', role: 'editor' },
    ],
  },
  {
    id: '103',
    title: 'Kişisel Günlük & Şükran Notları',
    description: 'Ruh hali takibi, günlük farkındalık ve alışkanlık gözlemleri.',
    type: 'journal',
    color: '#D97706',
    icon: 'BookHeart',
    isLocked: false,
    paperStyle: 'dots',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Kişisel', 'Farkındalık', 'Alışkanlık'],
  },
  {
    id: '104',
    title: 'Strateji & Müşteri Toplantıları',
    description: 'Haftalık liderlik toplantıları, kararlar ve atanmış aksiyonlar.',
    type: 'meeting',
    color: '#0D9488',
    icon: 'Users',
    paperStyle: 'plain',
    defaultView: 'notes',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Yönetim', 'Toplantı', 'Aksiyonlar'],
  },
  {
    id: '105',
    title: '2026 Okuma Listesi & Alıntılar',
    description: 'Okunan kitaplar, sayfa hedefleri ve altı çizilen etkileyici alıntılar.',
    type: 'reading',
    color: '#7C3AED',
    icon: 'BookOpen',
    paperStyle: 'lined',
    defaultView: 'gallery',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Kitaplar', 'Edebiyat', 'Gelişim'],
  },
  {
    id: '106',
    title: 'İtalya & Akdeniz Seyahat Rehberi',
    description: 'Roma - Floransa - Amalfi rotası, rezervasyonlar ve bütçe planı.',
    type: 'travel',
    color: '#059669',
    icon: 'Plane',
    paperStyle: 'plain',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Seyahat', 'Tatil', 'Avrupa'],
  },
  {
    id: '107',
    title: 'Gurme Mutfak & İtalyan Tarifleri',
    description: 'Özel makarna sosları, hamur işleri ve porsiyon ölçekli tarifler.',
    type: 'recipe',
    color: '#EA580C',
    icon: 'UtensilsCrossed',
    paperStyle: 'grid',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Yemek', 'Mutfak', 'Tarif'],
  },
  {
    id: '108',
    title: '2026 Bütçe & Yatırım Defteri',
    description: 'Aylık gelir-gider takibi, sabit faturalar ve portföy hedefleri.',
    type: 'finance',
    color: '#16A34A',
    icon: 'PieChart',
    paperStyle: 'grid',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Finans', 'Bütçe', 'Yatırım'],
  },
  {
    id: '109',
    title: 'Fitness & Güç Antrenman Günlüğü',
    description: 'Haftalık split programı, ağırlık progresyonu ve günlük su tüketimi.',
    type: 'fitness',
    color: '#E11D48',
    icon: 'Activity',
    paperStyle: 'lined',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Spor', 'Sağlık', 'Antrenman'],
  },
  {
    id: '110',
    title: 'Yeni Girişim & Ürün Fikirleri',
    description: 'Yaratıcı problem çözümleri, beyin fırtınası tahtası ve SCAMPER notları.',
    type: 'brainstorm',
    color: '#F59E0B',
    icon: 'Lightbulb',
    paperStyle: 'dots',
    defaultView: 'special',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Girişimcilik', 'Fikir', 'İnovasyon'],
  },
  {
    id: '111',
    title: 'Web Mimarisi & Kod Snippet’ları',
    description: 'TypeScript, Docker, Tailwind ve SQL pratik şablonları.',
    type: 'code',
    color: '#2563EB',
    icon: 'Code2',
    paperStyle: 'grid',
    defaultView: 'notes',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Kod', 'Teknoloji', 'FullStack'],
  },
];

// Sample Formül Kütüphanesi
export const SAMPLE_FORMULAS: MathFormula[] = [
  {
    id: 'f1',
    title: 'Euler Özdeşliği',
    category: 'Matematik',
    latex: 'e^{i\\pi} + 1 = 0',
    description: 'Matematiğin en zarif beş sabitini (e, i, pi, 1, 0) bir araya getirir.',
  },
  {
    id: 'f2',
    title: 'Kütle-Enerji Eşdeğerliği',
    category: 'Fizik',
    latex: 'E = m \\cdot c^2',
    description: 'Özel görelilik teorisinin temel kütle enerji bağıntısı.',
  },
  {
    id: 'f3',
    title: 'İkinci Dereceden Denklem Kökleri',
    category: 'Matematik',
    latex: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
    description: 'ax² + bx + c = 0 denkleminin genel analitik çözüm formülü.',
  },
  {
    id: 'f4',
    title: 'İdeal Gaz Yasası',
    category: 'Kimya',
    latex: 'P \\cdot V = n \\cdot R \\cdot T',
    description: 'Basınç, hacim, mol sayısı ve mutlak sıcaklık ilişkisi.',
  },
  {
    id: 'f5',
    title: 'Shannon Entropi Formülü',
    category: 'Mühendislik',
    latex: 'H(X) = -\\sum_{i} P(x_i) \\log_2 P(x_i)',
    description: 'Bilgi teorisinde veri belirsizliği ve sıkıştırma limiti.',
  },
];

// Sample Soru-Cevap Kartları
export const SAMPLE_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc1',
    question: 'Binary Search (İkili Arama) algoritmasının zaman karmaşıklığı nedir?',
    answer: 'O(log n). Her adımda arama uzayını yarıya indirir, dizi sıralı olmalıdır.',
    deck: 'Algoritmalar',
    difficulty: 'kolay',
    repetitions: 4,
  },
  {
    id: 'fc2',
    question: 'REST ve GraphQL arasındaki temel fark nedir?',
    answer: 'REST sabit endpointler ve over/under-fetching üretirken, GraphQL istemcinin tam istediği veriyi tek sorguda seçmesine izin verir.',
    deck: 'Web Mimarisi',
    difficulty: 'orta',
    repetitions: 2,
  },
  {
    id: 'fc3',
    question: 'CAP Teoremi neleri ifade eder?',
    answer: 'Consistency (Tutarlılık), Availability (Erişilebilirlik) ve Partition Tolerance (Bölünme Toleransı). Dağıtık bir sistem aynı anda en fazla ikisini garanti edebilir.',
    deck: 'Dağıtık Sistemler',
    difficulty: 'zor',
    repetitions: 1,
  },
];

// Sample Kaynakça
export const SAMPLE_CITATIONS: Citation[] = [
  {
    id: 'cit1',
    authors: 'Cormen, T. H., Leiserson, C. E., Rivest, R. L., Stein, C.',
    title: 'Introduction to Algorithms (4th Edition)',
    source: 'MIT Press',
    year: 2022,
    format: 'APA',
  },
  {
    id: 'cit2',
    authors: 'Martin, Robert C.',
    title: 'Clean Architecture: A Craftsman\'s Guide to Software Structure and Design',
    source: 'Prentice Hall',
    year: 2017,
    format: 'IEEE',
  },
];

// Sample Sınav Geri Sayımı
export const SAMPLE_COUNTDOWNS: CountdownEvent[] = [
  {
    id: 'cd1',
    title: 'Veri Yapıları & Algoritmalar Final Sınavı',
    date: '2026-10-24',
    time: '10:00',
    type: 'sınav',
  },
  {
    id: 'cd2',
    title: 'Bitirme Projesi 1. Faz Teslimi',
    date: '2026-11-05',
    time: '23:59',
    type: 'teslim',
  },
];

// Sample Proje Kilometre Taşları
export const SAMPLE_MILESTONES: Milestone[] = [
  {
    id: 'm1',
    title: 'v1.0 Alfa: Temel Not & Zihin Haritası Çekirdeği',
    dueDate: '2026-09-01',
    completed: true,
    description: 'Temel veri modelleri ve UI bileşenleri hazırlandı.',
  },
  {
    id: 'm2',
    title: 'v2.0 Beta: 11 Defter Türü ve Özel Araç Seti',
    dueDate: '2026-09-15',
    completed: false,
    description: 'Cornell, Kanban, Tarif, Finans ve Kod modülleri devreye alınıyor.',
  },
  {
    id: 'm3',
    title: 'v2.5 Genel Kullanıma Açılış (GA)',
    dueDate: '2026-10-01',
    completed: false,
    description: 'AI destekli özet ve çoklu cihaz senkronizasyonu.',
  },
];

// Sample Dosya Sürümleri
export const SAMPLE_FILE_VERSIONS: FileVersion[] = [
  {
    id: 'fv1',
    version: 'v2.1.0',
    name: 'noteflow-core-bundle.ts',
    updatedAt: '2026-09-11 10:30',
    author: 'Can Demir',
    changeLog: 'Defter bazlı işlevsel modüller ve şablon seçici eklendi.',
  },
  {
    id: 'fv2',
    version: 'v2.0.0',
    name: 'noteflow-core-bundle.ts',
    updatedAt: '2026-09-08 14:15',
    author: 'Selin Kaya',
    changeLog: 'Mind Map 10 şablon motoru optimize edildi.',
  },
];

// Sample Günlük Kayıtları
export const SAMPLE_MOOD_ENTRIES: MoodEntry[] = [
  {
    id: 'mood1',
    date: '2026-09-11',
    mood: 'çok_iyi',
    energyLevel: 5,
    habits: { water: true, exercise: true, reading: true, meditation: true },
    gratitude: [
      'Güneşli bir sabah yürüyüşü yapabildiğim için',
      'Yeni defter mimarisini başarıyla kurguladığım için',
      'Sağlıklı ve enerjik hissettiğim için',
    ],
    weather: 'güneşli',
    reflection: 'Bugün odaklanma sürem çok yüksekti. Zorlu problemleri sakinlikle çözebildim.',
  },
  {
    id: 'mood2',
    date: '2026-09-10',
    mood: 'mutlu',
    energyLevel: 4,
    habits: { water: true, exercise: true, reading: false, meditation: true },
    gratitude: [
      'Ekip arkadaşlarımın yapıcı geri bildirimleri',
      'Akşam dinlenirken okuduğum makaleler',
    ],
    weather: 'bulutlu',
    reflection: 'Günün ortasında kısa bir mola vermek öğleden sonraki verimimi ikiye katladı.',
  },
  {
    id: 'mood3',
    date: '2026-09-09',
    mood: 'sakin',
    energyLevel: 4,
    habits: { water: true, exercise: false, reading: true, meditation: true },
    gratitude: ['Sakin ve kesintisiz geçen çalışma saatleri'],
    weather: 'güneşli',
  },
  {
    id: 'mood4',
    date: '2026-09-08',
    mood: 'yorgun',
    energyLevel: 3,
    habits: { water: false, exercise: true, reading: false, meditation: false },
    gratitude: ['Günü tamamlayıp erken uyuma fırsatı'],
    weather: 'yağmurlu',
  },
];

// Günlük Soru Önerileri
export const DAILY_REFLECTION_QUESTIONS: string[] = [
  'Bugün seni en çok ne gülümsetti?',
  'Bugün karşılaştığın bir zorluktan ne öğrendin?',
  'Kendinde bugün takdir ettiğin bir davranış neydi?',
  'Bugün kime küçük bir nezaket gösterdin ya da kimden nezaket gördün?',
  'Yarın için en çok sabırsızlandığın tek şey nedir?',
  'Bugün enerjini en çok tüketen şeyi yarın nasıl sadeleştirebilirsin?',
];

// Sample Kitap Kaydı
export const SAMPLE_BOOKS: BookRecord[] = [
  {
    id: 'b1',
    title: 'Atomik Alışkanlıklar',
    author: 'James Clear',
    isbn: '978-6050689945',
    totalPages: 320,
    readPages: 320,
    status: 'tamamlandı',
    rating: 5,
    startDate: '2026-08-01',
    finishDate: '2026-08-20',
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&auto=format&fit=crop&q=80',
    quotes: [
      { text: 'Her gün %1 daha iyi olmak, bir yıl sonunda 37 kat gelişim sağlar.', page: 25 },
      { text: 'Hedefleriniz seviyesine yükselmezsiniz, sistemleriniz seviyesine düşersiniz.', page: 38 },
    ],
    summary: 'Küçük değişikliklerin bileşik getirisi üzerinden alışkanlık oluşturma psikolojisi.',
  },
  {
    id: 'b2',
    title: 'Kusursuz Yazılımcı (Clean Code)',
    author: 'Robert C. Martin',
    isbn: '978-0132350884',
    totalPages: 464,
    readPages: 290,
    status: 'okunuyor',
    rating: 5,
    startDate: '2026-08-25',
    coverUrl: 'https://images.unsplash.com/photo-1532012164546-f432f2e3777a?w=400&auto=format&fit=crop&q=80',
    quotes: [
      { text: 'Okunabilir kod, yazılmış koddan katbekat daha sık okunur.', page: 14 },
    ],
    summary: 'Fonksiyon boyutu, isimlendirme ve refactoring disiplinleri.',
  },
  {
    id: 'b3',
    title: 'Düşün ve Zengin Ol',
    author: 'Napoleon Hill',
    isbn: '978-9752107472',
    totalPages: 288,
    readPages: 0,
    status: 'okunacak',
    rating: 4,
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&auto=format&fit=crop&q=80',
    quotes: [],
  },
];

// Sample Seyahat Planı
export const SAMPLE_TRAVEL_PLAN: TravelPlan = {
  destination: 'İtalya (Roma - Floransa - Amalfi)',
  startDate: '2026-10-10',
  endDate: '2026-10-18',
  budgetTotal: 65000,
  budgetSpent: 38500,
  currency: 'TRY',
  reservations: [
    { id: 'r1', type: 'Uçuş', title: 'İstanbul (IST) -> Roma (FCO)', code: 'TK1821', date: '2026-10-10 08:30' },
    { id: 'r2', type: 'Otel', title: 'Hotel Colosseum Palace Roma', code: 'BOOK-8823', date: '2026-10-10' },
    { id: 'r3', type: 'Tren', title: 'Frecciarossa Hızlı Tren (Roma - Floransa)', code: 'FR-9412', date: '2026-10-13 11:15' },
    { id: 'r4', type: 'Bilet', title: 'Uffizi Galerisi Müze Giriş Bileti', code: 'UFF-2026', date: '2026-10-14 14:00' },
  ],
  packingList: [
    { id: 'p1', item: 'Pasaport ve Vize Evrakları', packed: true, category: 'Belgeler' },
    { id: 'p2', item: 'Avrupa Tipi Şarj Adaptörü ve Powerbank', packed: true, category: 'Elektronik' },
    { id: 'p3', item: 'Rahat Şehir Yürüyüş Ayakkabısı', packed: true, category: 'Giyim' },
    { id: 'p4', item: 'Hafif Yağmurluk ve Rüzgarlık', packed: false, category: 'Giyim' },
    { id: 'p5', item: 'Güneş Gözlüğü ve Şapka', packed: true, category: 'Aksesuar' },
    { id: 'p6', item: 'Temel Seyahat İlaçları', packed: false, category: 'Sağlık' },
  ],
  itinerary: [
    {
      day: 1,
      title: 'Roma: Kolezyum & Antik Forum',
      activities: ['Otele yerleşme', 'Kolezyum rehberli tur', 'Trastevere bölgesinde akşam yemeği'],
    },
    {
      day: 2,
      title: 'Vatikan & San Pietro Meydanı',
      activities: ['Vatikan Müzeleri & Sistina Şapeli', 'Castel Sant\'Angelo manzarası', 'Akşam espresso molası'],
    },
    {
      day: 3,
      title: 'Floransa\'ya Geçiş & Duomo',
      activities: ['Hızlı trenle Floransa yolculuğu', 'Piazza del Duomo & Ponte Vecchio gün batımı'],
    },
  ],
  placesToVisit: [
    { name: 'Kolezyum (Colosseo)', address: 'Piazza del Colosseo, 1, Roma', visited: true },
    { name: 'Pantheon', address: 'Piazza della Rotonda, Roma', visited: true },
    { name: 'Trevi Çeşmesi', address: 'Piazza di Trevi, Roma', visited: false },
    { name: 'Uffizi Galerisi', address: 'Piazzale degli Uffizi, 6, Floransa', visited: false },
  ],
};

// Sample Tarif
export const SAMPLE_RECIPES: RecipeData[] = [
  {
    title: 'Geleneksel Fettuccine Alfredo',
    servings: 4,
    prepTimeMinutes: 10,
    cookTimeMinutes: 15,
    difficulty: 'Kolay',
    calories: 520,
    ingredients: [
      { id: 'ing1', name: 'Fettuccine Makarna', amount: 400, unit: 'g' },
      { id: 'ing2', name: 'Tereyağı', amount: 60, unit: 'g' },
      { id: 'ing3', name: 'Taze Sıvı Krema', amount: 200, unit: 'ml' },
      { id: 'ing4', name: 'Rendelenmiş Parmesan Peyniri', amount: 100, unit: 'g' },
      { id: 'ing5', name: 'Sarımsak', amount: 2, unit: 'diş' },
      { id: 'ing6', name: 'Taze Çekilmiş Karabiber & Muskat', amount: 1, unit: 'çay kaşığı' },
    ],
    steps: [
      'Geniş bir tencerede bol tuzlu suyu kaynatın ve makarnayı paketteki süreden 1 dakika eksik (al dente) haşlayın.',
      'Geniş bir tavada tereyağını eritin. Ezilmiş sarımsakları kokusu çıkana kadar 30 saniye kavurun.',
      'Kremayı ekleyin ve kısık ateşte hafifçe koyulaşana kadar 2-3 dakika çektirin.',
      'Haşlanan makarnayı ve yarım çay bardağı makarna suyunu sos tavasına aktarın.',
      'Ateşten alıp rendelenmiş parmesan ve taze çekilmiş karabiberi ekleyerek krema kıvamı elde edene kadar karıştırın.',
    ],
    notes: 'Püf noktası: Makarnanın haşlama suyundaki nişasta, sosun makarnaya kusursuz yapışmasını sağlar.',
  },
];

// Sample Finans İşlemleri
export const SAMPLE_FINANCE_ITEMS: FinanceItem[] = [
  { id: 'fi1', title: 'Yazılım Danışmanlık Hakedişi', amount: 45000, type: 'gelir', category: 'Maaş', date: '2026-09-01' },
  { id: 'fi2', title: 'Ev Kirası Ödemesi', amount: 16000, type: 'gider', category: 'Kira', date: '2026-09-02', recurring: true },
  { id: 'fi3', title: 'Haftalık Süpermarket Alışverişi', amount: 2450, type: 'gider', category: 'Market', date: '2026-09-06' },
  { id: 'fi4', title: 'Elektrik & Doğalgaz & İnternet Faturası', amount: 1350, type: 'gider', category: 'Faturalar', date: '2026-09-07' },
  { id: 'fi5', title: 'BES & Borsa Fon Alımı', amount: 8000, type: 'gider', category: 'Yatırım', date: '2026-09-08' },
  { id: 'fi6', title: 'Konser & Sinema Biletleri', amount: 950, type: 'gider', category: 'Eğlence', date: '2026-09-10' },
];

export const SAMPLE_BUDGET_GOALS: BudgetGoal[] = [
  { category: 'Kira', limit: 16000, current: 16000 },
  { category: 'Market', limit: 9000, current: 4800 },
  { category: 'Faturalar', limit: 2500, current: 1350 },
  { category: 'Eğlence', limit: 3000, current: 1850 },
  { category: 'Yatırım', limit: 12000, current: 8000 },
];

// Sample Fitness Log
export const SAMPLE_WORKOUTS: WorkoutEntry[] = [
  {
    id: 'w1',
    date: '2026-09-11',
    activity: 'Göğüs & Triceps Güç',
    durationMinutes: 55,
    waterGlasses: 8,
    weightKg: 76.4,
    sets: [
      { exercise: 'Barbell Bench Press', sets: 4, reps: 8, weightKg: 80 },
      { exercise: 'Incline Dumbbell Press', sets: 3, reps: 10, weightKg: 26 },
      { exercise: 'Dips (Vücut Ağırlığı)', sets: 3, reps: 12, weightKg: 0 },
      { exercise: 'Halat Triceps Pushdown', sets: 4, reps: 12, weightKg: 27 },
    ],
  },
  {
    id: 'w2',
    date: '2026-09-09',
    activity: 'Sırt & Biceps Çekiş',
    durationMinutes: 60,
    waterGlasses: 7,
    weightKg: 76.6,
    sets: [
      { exercise: 'Barfiks (Pull-up)', sets: 4, reps: 8, weightKg: 0 },
      { exercise: 'Barbell Row', sets: 4, reps: 10, weightKg: 65 },
      { exercise: 'Lat Pulldown', sets: 3, reps: 12, weightKg: 55 },
      { exercise: 'Incline Dumbbell Curl', sets: 3, reps: 12, weightKg: 14 },
    ],
  },
];

// Sample Fikir Yapışkan Notları
export const SAMPLE_STICKY_NOTES: StickyNote[] = [
  {
    id: 'sn1',
    content: 'Defter bazlı sesli transkript ve AI quiz özelliği',
    color: 'yellow',
    x: 40,
    y: 30,
    tags: ['Yapay Zeka', 'Özellik'],
  },
  {
    id: 'sn2',
    content: 'Çizgili ve kareli kağıt dokusuyla gerçek defter hissi',
    color: 'cyan',
    x: 280,
    y: 40,
    tags: ['Tasarım', 'UI/UX'],
  },
  {
    id: 'sn3',
    content: 'Tek tıkla tarif malzemelerini alışveriş listesine yollama',
    color: 'green',
    x: 100,
    y: 200,
    tags: ['Otomasyon', 'Tarif'],
  },
  {
    id: 'sn4',
    content: 'Kitap bittiğinde otomatik "Tamamlandı" rafına geçişi',
    color: 'pink',
    x: 340,
    y: 190,
    tags: ['Otomasyon', 'Kitap'],
  },
  {
    id: 'sn5',
    content: 'PIN şifreli defter kilidi (Günlük & Finans)',
    color: 'purple',
    x: 200,
    y: 350,
    tags: ['Güvenlik', 'Gizlilik'],
  },
];

// Sample Kod Snippet'ları & Hata Çözümleri
export const SAMPLE_SNIPPETS: CodeSnippet[] = [
  {
    id: 'cs1',
    title: 'React useDebounce Custom Hook',
    language: 'typescript',
    description: 'Arama ve filtre girdi gecikmelerini yönetmek için hafif debounce hooku.',
    tags: ['React', 'Hooks', 'Performans'],
    code: `import { useState, useEffect } from 'react';

export function useDebounce<T>(value: T, delayMs: number = 300): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delayMs);
    return () => clearTimeout(handler);
  }, [value, delayMs]);

  return debouncedValue;
}`,
  },
  {
    id: 'cs2',
    title: 'Fast Tailwind Responsive Container Pattern',
    language: 'css',
    description: 'Büyük ekranlarda taşmayı engelleyen akıcı container stili.',
    tags: ['CSS', 'Tailwind', 'Responsive'],
    code: `.responsive-container {
  width: 100%;
  max-width: 80rem; /* max-w-7xl */
  margin-left: auto;
  margin-right: auto;
  padding: 1rem 1.5rem;
}`,
  },
];

export const SAMPLE_BUG_RESOLUTIONS: BugResolution[] = [
  {
    id: 'bug1',
    title: 'Hydration Mismatch / LocalStorage İlk Yükleme Hatası',
    errorMessage: 'Text content does not match server-rendered HTML',
    rootCause: 'Sunucu tarafında Date objesi ile istemcideki yerel saat farkından dolayı DOM uyuşmazlığı.',
    solution: 'Tarih formatlama bileşenini useEffect içinde veya istemci render bayrağı (isMounted) ile çalıştırmak.',
    resolvedDate: '2026-09-08',
  },
  {
    id: 'bug2',
    title: 'Vite HMR WebSocket Bağlantı Uyarısı',
    errorMessage: '[vite] failed to connect to websocket',
    rootCause: 'Platform tarafından DISABLE_HMR=true verildiğinde oluşan beklenen benign konsol uyarısı.',
    solution: 'Platform kuralı gereği yoksayılmalıdır, uygulama işleyişini etkilemez.',
    resolvedDate: '2026-09-10',
  },
];

// Sample Otomasyon Kuralları
export const DEFAULT_AUTOMATIONS: AutomationRule[] = [
  {
    id: 'auto1',
    title: 'Toplantı Aksiyonlarını Görev Listesine Ekle',
    trigger: 'meeting_action_added',
    actionDescription: 'Toplantı notuna sorumlu ve tarihli aksiyon eklendiğinde bunu otomatik olarak Görevler ve Takvime ekler.',
    enabled: true,
  },
  {
    id: 'auto2',
    title: 'Kitap %100 Olunca Tamamlandı Rafına Taşı',
    trigger: 'book_finished',
    actionDescription: 'Okunan sayfa sayısı toplam sayfa sayısına ulaştığında durumunu anında "Tamamlandı" olarak günceller.',
    enabled: true,
  },
  {
    id: 'auto3',
    title: 'Tarif Malzemelerini Alışveriş Listesine Aktar',
    trigger: 'recipe_to_shopping_list',
    actionDescription: 'Tek tıkla tarifteki tüm malzemeleri seçilen porsiyona göre hesaplayıp alışveriş listesine iliştirir.',
    enabled: true,
  },
  {
    id: 'auto4',
    title: 'Finans Harcamasından Bütçe Barını Güncelle',
    trigger: 'finance_expense_logged',
    actionDescription: 'Yeni bir harcama kaydedildiğinde ilgili kategorinin harcama limitini ve kalan bakiyesini anında günceller.',
    enabled: true,
  },
];
