import { KanbanBoard, KanbanList, KanbanCard, KanbanLabel, KanbanActivityLog } from '../types/kanban';
import {
  SMMM_SGS_BOARD,
  SMMM_SGS_LISTS,
  SMMM_SGS_CARDS,
  SMMM_SGS_LABELS,
} from './smmmSgsData';

export const DEFAULT_KANBAN_LABELS: KanbanLabel[] = [
  ...SMMM_SGS_LABELS,
  { id: 'lbl-1', name: 'Frontend', color: '#3B82F6' },
  { id: 'lbl-2', name: 'Backend', color: '#10B981' },
  { id: 'lbl-3', name: 'Tasarım', color: '#8B5CF6' },
  { id: 'lbl-4', name: 'Yüksek Öncelik', color: '#EF4444' },
  { id: 'lbl-5', name: 'İnceleme', color: '#F59E0B' },
  { id: 'lbl-6', name: 'Mobil', color: '#06B6D4' },
];

export const DEFAULT_BOARDS: KanbanBoard[] = [
  SMMM_SGS_BOARD,
  {
    id: 'board-main',
    title: '🚀 NoteFlow Ürün Geliştirme',
    description: 'Web ve Mobil platform özellikleri, sprint görevleri ve kullanıcı geri bildirimleri panosu.',
    owner_id: '00000000-0000-4000-8000-000000000001',
    color: '#0d9488',
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'board-marketing',
    title: '📢 Pazarlama & İçerik Takvimi',
    description: 'Sosyal medya duyuruları, blog yazıları ve lansman hazırlıkları.',
    owner_id: '00000000-0000-4000-8000-000000000001',
    color: '#6366f1',
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
  },
];

export const DEFAULT_LISTS: KanbanList[] = [
  ...SMMM_SGS_LISTS,
  {
    id: 'list-todo',
    board_id: 'board-main',
    title: '📋 Yapılacaklar',
    position: 65536,
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-in-progress',
    board_id: 'board-main',
    title: '⚡ Geliştiriliyor (Sprint)',
    position: 131072,
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-review',
    board_id: 'board-main',
    title: '🔍 Test & İnceleme',
    position: 196608,
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-done',
    board_id: 'board-main',
    title: '🎉 Tamamlandı',
    position: 262144,
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  // Marketing lists
  {
    id: 'list-mkt-ideas',
    board_id: 'board-marketing',
    title: '💡 Fikir Havuzu',
    position: 65536,
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-mkt-drafting',
    board_id: 'board-marketing',
    title: '✍️ Yazım Aşamasında',
    position: 131072,
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-mkt-published',
    board_id: 'board-marketing',
    title: '🚀 Yayında',
    position: 196608,
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const today = new Date();
const formatDate = (daysOffset: number) => {
  const d = new Date();
  d.setDate(today.getDate() + daysOffset);
  return d.toISOString().slice(0, 10);
};

export const DEFAULT_CARDS: KanbanCard[] = [
  ...SMMM_SGS_CARDS,
  {
    id: 'card-1',
    list_id: 'list-todo',
    title: 'Dark Mode kontrast oranlarını WCAG AA standartlarına göre optimize et',
    description: 'Koyu temada metin okunabilirliğini artırmak için gri renk tonlarını ve sınır çizgilerini elden geçir.',
    position: 65536,
    due_date: formatDate(3),
    labels: [
      { id: 'lbl-3', name: 'Tasarım', color: '#8B5CF6' },
      { id: 'lbl-1', name: 'Frontend', color: '#3B82F6' },
    ],
    checklist: [
      { id: 'chk-1', card_id: 'card-1', text: 'slate-400 kontrast kontrolü', is_done: true },
      { id: 'chk-2', card_id: 'card-1', text: 'Kart arka plan ayrımı', is_done: false },
      { id: 'chk-3', card_id: 'card-1', text: 'OLED siyah modu testi', is_done: false },
    ],
    comments: [
      {
        id: 'comm-1',
        card_id: 'card-1',
        author_name: 'Ahmet Yılmaz',
        text: 'Tasarım ekibi yeni Figma paletini güncelledi.',
        created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
      },
    ],
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'card-2',
    list_id: 'list-todo',
    title: 'Çevrimdışı (offline-first) senkron çatışma çözüm motoru',
    description: 'İki cihaz aynı anda düzenleme yaptığında last-write-wins veya alan bazlı birleştirme uygula.',
    position: 131072,
    due_date: formatDate(7),
    labels: [
      { id: 'lbl-2', name: 'Backend', color: '#10B981' },
      { id: 'lbl-4', name: 'Yüksek Öncelik', color: '#EF4444' },
    ],
    checklist: [
      { id: 'chk-4', card_id: 'card-2', text: 'Zaman damgası karşılaştırma', is_done: true },
      { id: 'chk-5', card_id: 'card-2', text: 'IndexedDB fallback kontrolü', is_done: false },
    ],
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'card-3',
    list_id: 'list-in-progress',
    title: 'Trello mantığında kesirli float sıralama ve Kanban sürükle-bırak',
    description: 'position alanını FLOAT yaparak iki kart arasına taşıma ve 0.00001 altındaki boşluklarda yeniden normalizasyon.',
    position: 65536,
    due_date: formatDate(1),
    labels: [
      { id: 'lbl-1', name: 'Frontend', color: '#3B82F6' },
      { id: 'lbl-4', name: 'Yüksek Öncelik', color: '#EF4444' },
    ],
    checklist: [
      { id: 'chk-6', card_id: 'card-3', text: 'Sıralama formülü (prev + next) / 2', is_done: true },
      { id: 'chk-7', card_id: 'card-3', text: 'SortableJS sürükle bırak entegrasyonu', is_done: true },
      { id: 'chk-8', card_id: 'card-3', text: 'Optimistic UI ve hata rollback', is_done: true },
      { id: 'chk-9', card_id: 'card-3', text: 'Klavye kısayolları ve erişilebilirlik', is_done: true },
    ],
    comments: [
      {
        id: 'comm-2',
        card_id: 'card-3',
        author_name: 'Zeynep Kaya',
        text: 'Vite & React 19 testleri sorunsuz geçti!',
        created_at: new Date(Date.now() - 1800000).toISOString(),
      },
    ],
    created_at: new Date(Date.now() - 86400000).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'card-4',
    list_id: 'list-review',
    title: 'Mind Map akıllı telefon dokunmatik jestleri ve pinch-to-zoom',
    description: 'Mobil cihazlarda tek parmak pan ve iki parmak zoom kontrolleri doğrulandı.',
    position: 65536,
    due_date: formatDate(-1), // Geçmiş tarih örneği (Kırmızı rozet)
    labels: [
      { id: 'lbl-6', name: 'Mobil', color: '#06B6D4' },
      { id: 'lbl-5', name: 'İnceleme', color: '#F59E0B' },
    ],
    checklist: [
      { id: 'chk-10', card_id: 'card-4', text: 'Android Chrome testi', is_done: true },
      { id: 'chk-11', card_id: 'card-4', text: 'iOS Safari viewport testi', is_done: true },
    ],
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'card-5',
    list_id: 'list-done',
    title: '11 Defter türü için özel veri şablonları ve analitik',
    description: 'Akademik, Proje, Günlük, Finans, Kod ve diğer defter türleri hazırlandı.',
    position: 65536,
    due_date: formatDate(-4),
    labels: [
      { id: 'lbl-1', name: 'Frontend', color: '#3B82F6' },
      { id: 'lbl-2', name: 'Backend', color: '#10B981' },
    ],
    checklist: [
      { id: 'chk-12', card_id: 'card-5', text: 'Defter hub arayüzü', is_done: true },
      { id: 'chk-13', card_id: 'card-5', text: 'Örnek veriler ve yerel depolama', is_done: true },
    ],
    created_at: new Date(Date.now() - 86400000 * 4).toISOString(),
    updated_at: new Date().toISOString(),
  },
];

export const DEFAULT_ACTIVITIES: KanbanActivityLog[] = [
  {
    id: 'act-1',
    board_id: 'board-main',
    card_id: 'card-3',
    card_title: 'Trello mantığında kesirli float sıralama ve Kanban',
    action: 'move_card',
    details: '"Geliştiriliyor" listesine taşındı',
    user_name: 'Can Demir',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'act-2',
    board_id: 'board-main',
    card_id: 'card-1',
    card_title: 'Dark Mode kontrast oranları',
    action: 'create_card',
    details: 'Kart oluşturuldu',
    user_name: 'Ahmet Yılmaz',
    created_at: new Date(Date.now() - 3600000 * 6).toISOString(),
  },
];
