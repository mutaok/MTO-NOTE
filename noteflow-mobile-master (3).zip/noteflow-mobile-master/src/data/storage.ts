import {
  MindMap,
  Note,
  Task,
  Notebook,
  MathFormula,
  Flashcard,
  Citation,
  CountdownEvent,
  Milestone,
  FileVersion,
  MoodEntry,
  BookRecord,
  TravelPlan,
  RecipeData,
  FinanceItem,
  BudgetGoal,
  WorkoutEntry,
  PersonalRecord,
  StickyNote,
  CodeSnippet,
  BugResolution,
  AutomationRule,
  KanbanBoard,
  KanbanList,
  KanbanCard,
  KanbanLabel,
  KanbanActivityLog,
} from '../types';
import { MIND_MAP_TEMPLATES } from './mindmapTemplates';
import {
  DEFAULT_NOTEBOOKS,
  SAMPLE_FORMULAS,
  SAMPLE_FLASHCARDS,
  SAMPLE_CITATIONS,
  SAMPLE_COUNTDOWNS,
  SAMPLE_MILESTONES,
  SAMPLE_FILE_VERSIONS,
  SAMPLE_MOOD_ENTRIES,
  SAMPLE_BOOKS,
  SAMPLE_TRAVEL_PLAN,
  SAMPLE_RECIPES,
  SAMPLE_FINANCE_ITEMS,
  SAMPLE_BUDGET_GOALS,
  SAMPLE_WORKOUTS,
  SAMPLE_STICKY_NOTES,
  SAMPLE_SNIPPETS,
  SAMPLE_BUG_RESOLUTIONS,
  DEFAULT_AUTOMATIONS,
} from './notebookTemplates';
import {
  DEFAULT_BOARDS,
  DEFAULT_LISTS,
  DEFAULT_CARDS,
  DEFAULT_ACTIVITIES,
  DEFAULT_KANBAN_LABELS,
} from './kanbanDefaults';
import {
  SMMM_SGS_BOARD,
  SMMM_SGS_LISTS,
  SMMM_SGS_CARDS,
} from './smmmSgsData';
import type { LocalStore, SyncEngine } from './sync/SyncEngine';
import type { SyncTable } from './sync/mappers';

const NOTEBOOKS_KEY = 'noteflow_notebooks';
const NOTES_KEY = 'noteflow_notes';
const TASKS_KEY = 'noteflow_tasks';
const MINDMAPS_KEY = 'noteflow_mindmaps';

// Specialized storage keys
const FORMULAS_KEY = 'noteflow_formulas';
const FLASHCARDS_KEY = 'noteflow_flashcards';
const CITATIONS_KEY = 'noteflow_citations';
const COUNTDOWNS_KEY = 'noteflow_countdowns';
const MILESTONES_KEY = 'noteflow_milestones';
const FILE_VERSIONS_KEY = 'noteflow_file_versions';
const MOODS_KEY = 'noteflow_mood_entries';
const BOOKS_KEY = 'noteflow_books';
const TRAVEL_KEY = 'noteflow_travel_plan';
const RECIPES_KEY = 'noteflow_recipes';
const FINANCE_KEY = 'noteflow_finance_items';
const BUDGET_GOALS_KEY = 'noteflow_budget_goals';
const WORKOUTS_KEY = 'noteflow_workouts';
const PERSONAL_RECORDS_KEY = 'noteflow_personal_records';
const STICKY_NOTES_KEY = 'noteflow_sticky_notes';
const SNIPPETS_KEY = 'noteflow_snippets';
const BUGS_KEY = 'noteflow_bugs';
const AUTOMATIONS_KEY = 'noteflow_automations';
const SHOPPING_LIST_KEY = 'noteflow_shopping_list';

// Kanban Keys
const KANBAN_BOARDS_KEY = 'noteflow_kanban_boards';
const KANBAN_LISTS_KEY = 'noteflow_kanban_lists';
const KANBAN_CARDS_KEY = 'noteflow_kanban_cards';
const KANBAN_ACTIVITIES_KEY = 'noteflow_kanban_activities';
const KANBAN_LABELS_KEY = 'noteflow_kanban_labels';

const SAMPLE_PRS: PersonalRecord[] = [
  { id: 'pr_1', exercise: 'Bench Press', weight: 105, date: '2026-09-01' },
  { id: 'pr_2', exercise: 'Back Squat', weight: 140, date: '2026-08-25' },
  { id: 'pr_3', exercise: 'Deadlift', weight: 175, date: '2026-08-18' },
  { id: 'pr_4', exercise: 'Overhead Press', weight: 65, date: '2026-09-05' },
];

function getTodayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function getTomorrowStr(): string {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

const DEFAULT_NOTES: Note[] = [
  {
    id: '1',
    notebookId: '101', // Academic
    title: 'Dinamik Programlama & Bellman Denklemi',
    body: '## İpuçları & Sorular\n- Alt problemler örtüşüyor mu?\n- Optimal alt yapı özelliği nedir?\n\n## Notlar\nDinamik programlama (DP), karmaşık bir problemi daha basit alt problemlere bölerek çözen matematiksel bir optimizasyon yöntemidir. Bellman denklemi durum geçişlerini ve optimal maliyet fonksiyonunu belirler.\n\nFormül: V(s) = max_a { R(s,a) + gamma * sum(P(s\'|s,a) * V(s\')) }\n\n## Özet\nDP, memoization veya tabulation ile O(2^n) karmaşıklığını O(n) veya O(n^2) seviyesine indirir.',
    tag: 'Akademik',
    date: getTodayStr(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    customFields: {
      status: 'Öğrenildi',
      priority: 'yüksek',
      rating: 5,
    },
    cornell: {
      cues: ['Memoization vs Tabulation?', 'Bellman denklemi nerede kullanılır?', 'Zaman karmaşıklığı kazancı?'],
      notes: 'Dinamik programlama örtüşen alt problemler ve optimal alt yapı varsa uygulanır. Bellman denklemi takviyeli öğrenme (RL) ve optimal kontrol teorisinin kalbidir.',
      summary: 'Memoization bellek alanı harcayarak üstel karmaşıklığı polinomiyal seviyeye çeker.',
    },
  },
  {
    id: '2',
    notebookId: '102', // Project
    title: 'NoteFlow v2.0 Mimari Karar Raporu',
    body: '### Alınan Tasarım Kararları\n1. 11 farklı defter türüne özel işlevsel paneller ve araç setleri sunulacak.\n2. Çizgili, kareli ve noktalı kağıt dokusuyla otantik defter hissi sağlanacak.\n3. Toplantı notlarından tek tıkla görev ve takvim kaydı çıkarılacak.\n\n### Görevler & Sorumlular\n- [x] Tür bazlı veri şemaları (Can)\n- [ ] Kağıt desenleri ve SVG arka planlar (Selin)\n- [ ] AI özetleme ve quiz motoru (Can)',
    tag: 'Proje',
    date: getTodayStr(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    customFields: {
      status: 'Sürüyor',
      priority: 'kritik',
      assignee: 'Can Demir',
    },
  },
  {
    id: '3',
    notebookId: '104', // Meeting
    title: 'Haftalık Ürün ve Mühendislik Senkronizasyonu',
    body: 'Toplantıda yeni sürümdeki defter türü farklılıkları ve otomasyon akışları kararlaştırıldı.',
    tag: 'Toplantı',
    date: getTodayStr(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    meetingDetails: {
      agenda: ['1. Yeni defter türleri incelemesi', '2. Otomasyon kuralları ve takvim senkronu', '3. QA süreçleri'],
      attendees: [
        { name: 'Can Demir (Ürün)', email: 'can@example.com', present: true },
        { name: 'Selin Kaya (Tasarım)', email: 'selin@team.io', present: true },
        { name: 'Mehmet Eren (Frontend)', email: 'mehmet@team.io', present: true },
        { name: 'Elif Şahin (QA)', email: 'elif@team.io', present: false },
      ],
      decisions: [
        'Ders defterinde Cornell not düzeni ve formül kütüphanesi zorunlu tutulacak.',
        'Günlük defteri şifre korumalı (PIN) olabilecek.',
      ],
      actionItems: [
        { id: 'act1', task: 'Formül kütüphanesine LaTeX desteği ekle', owner: 'Mehmet Eren', deadline: '2026-09-14', done: false },
        { id: 'act2', task: 'Seyahat defteri için döviz çevirici widget\'ı tasarla', owner: 'Selin Kaya', deadline: '2026-09-15', done: false },
      ],
      followUpDate: '2026-09-18',
    },
  },
  {
    id: '4',
    notebookId: '107', // Recipe
    title: 'Geleneksel İtalyan Tiramisu',
    body: 'Otantik mascarpone kreması ve espresso ile ıslatılmış kedidili bisküvileri.',
    tag: 'Tarif',
    date: getTodayStr(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    recipeData: {
      title: 'Geleneksel İtalyan Tiramisu',
      servings: 6,
      prepTimeMinutes: 25,
      cookTimeMinutes: 0,
      difficulty: 'Orta',
      calories: 410,
      ingredients: [
        { id: 't1', name: 'Mascarpone Peyniri', amount: 500, unit: 'g' },
        { id: 't2', name: 'Taze Yumurta Sarısı', amount: 4, unit: 'adet' },
        { id: 't3', name: 'Toz Şeker', amount: 100, unit: 'g' },
        { id: 't4', name: 'Kedidili Bisküvi (Savoiardi)', amount: 24, unit: 'adet' },
        { id: 't5', name: 'Sert Espresso Kahve', amount: 250, unit: 'ml' },
        { id: 't6', name: 'Kakao Tozu (Üzeri için)', amount: 2, unit: 'yemek kaşığı' },
      ],
      steps: [
        'Yumurta sarılarını ve şekeri benmari usulü şeker eriyip krema kıvamına gelene kadar çırpın.',
        'Soğuyan karışıma mascarpone peynirini spatula ile yavaşça yedirin.',
        'Kedidili bisküvileri soğuk espressoya 1-2 saniye batırıp borcama dizin.',
        'Üzerine kremanın yarısını dökün, ikinci kat bisküvileri dizip kalan kremayı yayın.',
        'Buzdolabında en az 4 saat dinlendirin, servis etmeden önce üzerine bolca kakao serpin.',
      ],
      notes: 'Yumurtaların çok taze ve oda sıcaklığında olması kremanın kabarması için esastır.',
    },
  },
];

const DEFAULT_TASKS: Task[] = [
  {
    id: '1',
    notebookId: '102',
    title: 'Cornell not düzeni ve soru-cevap kartları entegrasyonu',
    list: 'Proje',
    dueDate: getTodayStr(),
    dueTime: '11:00',
    done: false,
    color: '#3B82F6',
    assignee: 'Can Demir',
    priority: 'yüksek',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    notebookId: '101',
    title: 'Algoritmalar sınavı için 10 adet flashcard tekrarı yap',
    list: 'Akademik',
    dueDate: getTodayStr(),
    dueTime: '15:30',
    done: false,
    color: '#4F46E5',
    assignee: 'Can Demir',
    priority: 'orta',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '3',
    notebookId: '107',
    title: 'Fettuccine Alfredo için parmesan ve krema al',
    list: 'Yemek',
    dueDate: getTodayStr(),
    dueTime: '18:00',
    done: true,
    color: '#EA580C',
    priority: 'düşük',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '4',
    notebookId: '104',
    title: 'Toplantı aksiyonu: Formül kütüphanesine LaTeX desteği ekle',
    list: 'Toplantı',
    dueDate: getTomorrowStr(),
    dueTime: '14:00',
    done: false,
    color: '#0D9488',
    assignee: 'Mehmet Eren',
    priority: 'yüksek',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// ------------------------------------------------------------- bulut senkronu --

const IDEAS_KEY = 'noteflow_brainstorm_ideas';
const DATA_OWNER_KEY = 'noteflow_data_owner';

const COLLECTION_KEYS: Record<SyncTable, string> = {
  notebooks: NOTEBOOKS_KEY,
  notes: NOTES_KEY,
  tasks: TASKS_KEY,
  mind_maps: MINDMAPS_KEY,
};

/** Hesapla senkronize edilen çalışma alanı verileri (anahtar başına tek JSON belge). */
const DOCUMENT_KEYS = [
  FORMULAS_KEY,
  FLASHCARDS_KEY,
  CITATIONS_KEY,
  COUNTDOWNS_KEY,
  MILESTONES_KEY,
  FILE_VERSIONS_KEY,
  MOODS_KEY,
  BOOKS_KEY,
  TRAVEL_KEY,
  RECIPES_KEY,
  FINANCE_KEY,
  BUDGET_GOALS_KEY,
  WORKOUTS_KEY,
  PERSONAL_RECORDS_KEY,
  STICKY_NOTES_KEY,
  SNIPPETS_KEY,
  BUGS_KEY,
  AUTOMATIONS_KEY,
  SHOPPING_LIST_KEY,
  IDEAS_KEY,
  KANBAN_BOARDS_KEY,
  KANBAN_LISTS_KEY,
  KANBAN_CARDS_KEY,
  KANBAN_ACTIVITIES_KEY,
  KANBAN_LABELS_KEY,
] as const;

/** Oturum açıkken bağlanan senkron motoru; hesapsız modda null. */
let activeEngine: SyncEngine | null = null;

/** Hesapsız modda boş koleksiyonlar örnek veriyle doldurulur; hesapta veriler sunucudan gelir. */
let seedDefaults = true;

export function attachSyncEngine(engine: SyncEngine | null): void {
  activeEngine = engine;
}

export function setSeedDefaults(value: boolean): void {
  seedDefaults = value;
}

/** Bu cihazdaki verinin sahibi: hesap kimliği, 'local' ya da eski sürümden kalma veride null. */
export function getDataOwner(): string | null {
  return localStorage.getItem(DATA_OWNER_KEY);
}

export function setDataOwner(owner: string): void {
  localStorage.setItem(DATA_OWNER_KEY, owner);
}

export function hasLocalData(): boolean {
  return [...Object.values(COLLECTION_KEYS), ...DOCUMENT_KEYS].some((key) => localStorage.getItem(key) !== null);
}

/** Çıkışta ya da başka hesaba geçişte bu cihazdaki kullanıcı verisini temizler. */
export function clearLocalData(): void {
  for (const key of [...Object.values(COLLECTION_KEYS), ...DOCUMENT_KEYS]) localStorage.removeItem(key);
  localStorage.removeItem(DATA_OWNER_KEY);
}

/** Eski sürümler sayısal kimlik kullanıyordu; arayüz her zaman string görür. */
function normalizeIds<T>(items: unknown): T[] {
  if (!Array.isArray(items)) return [];
  return items.map((item: { id: unknown; notebookId?: unknown }) => {
    const next: Record<string, unknown> = { ...item, id: String(item.id) };
    if (item.notebookId != null) next.notebookId = String(item.notebookId);
    return next as T;
  });
}

function readCollection<T>(key: string, defaults: () => T[]): T[] {
  const raw = localStorage.getItem(key);
  if (raw === null) {
    if (!seedDefaults) return [];
    const initial = defaults();
    localStorage.setItem(key, JSON.stringify(initial));
    return initial;
  }
  try {
    return normalizeIds<T>(JSON.parse(raw));
  } catch {
    return seedDefaults ? defaults() : [];
  }
}

function saveCollection(table: SyncTable, items: Array<{ id: string }>): void {
  localStorage.setItem(COLLECTION_KEYS[table], JSON.stringify(items));
  activeEngine?.notifyCollectionChanged(table, items);
}

function readDocument<T>(key: string, fallback: T): T {
  const raw = localStorage.getItem(key);
  if (raw === null) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function saveDocument(key: string, value: unknown): void {
  localStorage.setItem(key, JSON.stringify(value));
  activeEngine?.notifyDocumentChanged(key, value);
}

/** Senkron motorunun localStorage erişimi; yazmalar senkronu yeniden tetiklemez. */
export const localStore: LocalStore = {
  readCollection(table) {
    const raw = localStorage.getItem(COLLECTION_KEYS[table]);
    if (raw === null) return [];
    try {
      return normalizeIds(JSON.parse(raw));
    } catch {
      return [];
    }
  },
  writeCollection(table, items) {
    localStorage.setItem(COLLECTION_KEYS[table], JSON.stringify(items));
  },
  readDocument(key) {
    const raw = localStorage.getItem(key);
    if (raw === null) return undefined;
    try {
      return JSON.parse(raw);
    } catch {
      return undefined;
    }
  },
  writeDocument(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },
  documentKeys: DOCUMENT_KEYS,
};

type ShoppingItem = { id: string; item: string; checked: boolean; recipeTitle?: string };

const SAMPLE_IDEAS = [
  {
    id: 'idea_1',
    text: '11 Defter Türü için otomatik şablon ve widget yükleme sistemi',
    color: 'bg-amber-100 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800',
    votes: 12,
    tags: ['Ürün'],
  },
  {
    id: 'idea_2',
    text: 'Cornell notlarından tek tuşla aralıklı tekrar (Spaced Repetition) kartları üretimi',
    color: 'bg-sky-100 dark:bg-sky-950/60 border-sky-300 dark:border-sky-800',
    votes: 8,
    tags: ['AI'],
  },
  {
    id: 'idea_3',
    text: 'Yemek tariflerinden tek tıkla pazar alışveriş listesi ve adım adım pişirme modu',
    color: 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800',
    votes: 15,
    tags: ['Tasarım'],
  },
];

const SAMPLE_SHOPPING_LIST: ShoppingItem[] = [
  { id: 'sl1', item: '400g Fettuccine Makarna', checked: false, recipeTitle: 'Fettuccine Alfredo' },
  { id: 'sl2', item: '100g Parmesan Peyniri', checked: true, recipeTitle: 'Fettuccine Alfredo' },
  { id: 'sl3', item: '500g Mascarpone', checked: false, recipeTitle: 'Tiramisu' },
  { id: 'sl4', item: 'Savoiardi Kedidili Bisküvi', checked: false, recipeTitle: 'Tiramisu' },
];

export const StorageService = {
  // Notebooks
  getNotebooks(): Notebook[] {
    const list = readCollection(NOTEBOOKS_KEY, () => DEFAULT_NOTEBOOKS);
    return list.map((nb) => ({ ...nb, isLocked: false, pinCode: undefined, pin: undefined }));
  },
  saveNotebooks(notebooks: Notebook[]): void {
    saveCollection('notebooks', notebooks);
  },

  // Notes
  getNotes(): Note[] {
    return readCollection(NOTES_KEY, () => DEFAULT_NOTES);
  },
  saveNotes(notes: Note[]): void {
    saveCollection('notes', notes);
  },

  // Tasks
  getTasks(): Task[] {
    return readCollection(TASKS_KEY, () => DEFAULT_TASKS);
  },
  saveTasks(tasks: Task[]): void {
    saveCollection('tasks', tasks);
  },

  // MindMaps
  getMindMaps(): MindMap[] {
    return readCollection(MINDMAPS_KEY, () =>
      MIND_MAP_TEMPLATES.map((tpl, i) => ({
        id: String(i + 1),
        title: tpl.label,
        type: tpl.type,
        data: tpl.createDoc(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      })),
    );
  },
  saveMindMaps(maps: MindMap[]): void {
    saveCollection('mind_maps', maps);
  },

  // Formulas
  getFormulas(): MathFormula[] {
    return readDocument(FORMULAS_KEY, SAMPLE_FORMULAS);
  },
  saveFormulas(formulas: MathFormula[]): void {
    saveDocument(FORMULAS_KEY, formulas);
  },

  // Flashcards
  getFlashcards(): Flashcard[] {
    return readDocument(FLASHCARDS_KEY, SAMPLE_FLASHCARDS);
  },
  saveFlashcards(flashcards: Flashcard[]): void {
    saveDocument(FLASHCARDS_KEY, flashcards);
  },

  // Citations
  getCitations(): Citation[] {
    return readDocument(CITATIONS_KEY, SAMPLE_CITATIONS);
  },
  saveCitations(citations: Citation[]): void {
    saveDocument(CITATIONS_KEY, citations);
  },

  // Countdowns
  getCountdowns(): CountdownEvent[] {
    return readDocument(COUNTDOWNS_KEY, SAMPLE_COUNTDOWNS);
  },
  saveCountdowns(countdowns: CountdownEvent[]): void {
    saveDocument(COUNTDOWNS_KEY, countdowns);
  },

  // Milestones
  getMilestones(): Milestone[] {
    return readDocument(MILESTONES_KEY, SAMPLE_MILESTONES);
  },
  saveMilestones(milestones: Milestone[]): void {
    saveDocument(MILESTONES_KEY, milestones);
  },

  // File Versions
  getFileVersions(): FileVersion[] {
    return readDocument(FILE_VERSIONS_KEY, SAMPLE_FILE_VERSIONS);
  },
  saveFileVersions(versions: FileVersion[]): void {
    saveDocument(FILE_VERSIONS_KEY, versions);
  },

  // Mood Entries (Journal)
  getMoodEntries(): MoodEntry[] {
    return readDocument(MOODS_KEY, SAMPLE_MOOD_ENTRIES);
  },
  saveMoodEntries(entries: MoodEntry[]): void {
    saveDocument(MOODS_KEY, entries);
  },

  // Books
  getBooks(): BookRecord[] {
    return readDocument(BOOKS_KEY, SAMPLE_BOOKS);
  },
  saveBooks(books: BookRecord[]): void {
    saveDocument(BOOKS_KEY, books);
  },

  // Travel Plan
  getTravelPlan(): TravelPlan {
    return readDocument(TRAVEL_KEY, SAMPLE_TRAVEL_PLAN);
  },
  saveTravelPlan(plan: TravelPlan): void {
    saveDocument(TRAVEL_KEY, plan);
  },

  // Recipes
  getRecipes(): RecipeData[] {
    return readDocument(RECIPES_KEY, SAMPLE_RECIPES);
  },
  saveRecipes(recipes: RecipeData[]): void {
    saveDocument(RECIPES_KEY, recipes);
  },

  // Finance Items
  getFinanceItems(): FinanceItem[] {
    return readDocument(FINANCE_KEY, SAMPLE_FINANCE_ITEMS);
  },
  saveFinanceItems(items: FinanceItem[]): void {
    saveDocument(FINANCE_KEY, items);
  },

  // Budget Goals
  getBudgetGoals(): BudgetGoal[] {
    return readDocument(BUDGET_GOALS_KEY, SAMPLE_BUDGET_GOALS);
  },
  saveBudgetGoals(goals: BudgetGoal[]): void {
    saveDocument(BUDGET_GOALS_KEY, goals);
  },

  // Workouts
  getWorkouts(): WorkoutEntry[] {
    return readDocument(WORKOUTS_KEY, SAMPLE_WORKOUTS);
  },
  saveWorkouts(workouts: WorkoutEntry[]): void {
    saveDocument(WORKOUTS_KEY, workouts);
  },

  // Personal Records
  getPersonalRecords(): PersonalRecord[] {
    return readDocument(PERSONAL_RECORDS_KEY, SAMPLE_PRS);
  },
  savePersonalRecords(records: PersonalRecord[]): void {
    saveDocument(PERSONAL_RECORDS_KEY, records);
  },

  // Sticky Notes (Brainstorm)
  getStickyNotes(): StickyNote[] {
    return readDocument(STICKY_NOTES_KEY, SAMPLE_STICKY_NOTES);
  },
  saveStickyNotes(notes: StickyNote[]): void {
    saveDocument(STICKY_NOTES_KEY, notes);
  },
  getIdeas(): any[] {
    return readDocument(IDEAS_KEY, SAMPLE_IDEAS);
  },
  saveIdeas(ideas: any[]): void {
    saveDocument(IDEAS_KEY, ideas);
  },

  // Code Snippets
  getSnippets(): CodeSnippet[] {
    return readDocument(SNIPPETS_KEY, SAMPLE_SNIPPETS);
  },
  saveSnippets(snippets: CodeSnippet[]): void {
    saveDocument(SNIPPETS_KEY, snippets);
  },
  getCodeSnippets(): CodeSnippet[] {
    return readDocument(SNIPPETS_KEY, SAMPLE_SNIPPETS);
  },
  saveCodeSnippets(snippets: CodeSnippet[]): void {
    saveDocument(SNIPPETS_KEY, snippets);
  },

  // Bug Resolutions
  getBugs(): BugResolution[] {
    return readDocument(BUGS_KEY, SAMPLE_BUG_RESOLUTIONS);
  },
  saveBugs(bugs: BugResolution[]): void {
    saveDocument(BUGS_KEY, bugs);
  },

  // Automations
  getAutomations(): AutomationRule[] {
    return readDocument(AUTOMATIONS_KEY, DEFAULT_AUTOMATIONS);
  },
  saveAutomations(automations: AutomationRule[]): void {
    saveDocument(AUTOMATIONS_KEY, automations);
  },

  // Shopping List (converted from recipes)
  getShoppingList(): ShoppingItem[] {
    return readDocument(SHOPPING_LIST_KEY, SAMPLE_SHOPPING_LIST);
  },
  saveShoppingList(list: ShoppingItem[]): void {
    saveDocument(SHOPPING_LIST_KEY, list);
  },

  // Kanban Boards & Trello Module
  getKanbanBoards(): KanbanBoard[] {
    const boards = readDocument(KANBAN_BOARDS_KEY, DEFAULT_BOARDS);
    if (!boards.some((b) => b.id === SMMM_SGS_BOARD.id)) {
      const merged = [SMMM_SGS_BOARD, ...boards];
      saveDocument(KANBAN_BOARDS_KEY, merged);
      return merged;
    }
    return boards;
  },
  saveKanbanBoards(boards: KanbanBoard[]): void {
    saveDocument(KANBAN_BOARDS_KEY, boards);
  },

  getKanbanLists(): KanbanList[] {
    const lists = readDocument(KANBAN_LISTS_KEY, DEFAULT_LISTS);
    if (!lists.some((l) => l.board_id === SMMM_SGS_BOARD.id)) {
      const merged = [...SMMM_SGS_LISTS, ...lists];
      saveDocument(KANBAN_LISTS_KEY, merged);
      return merged;
    }
    return lists;
  },
  saveKanbanLists(lists: KanbanList[]): void {
    saveDocument(KANBAN_LISTS_KEY, lists);
  },

  getKanbanCards(): KanbanCard[] {
    const cards = readDocument(KANBAN_CARDS_KEY, DEFAULT_CARDS);
    const sgsCardIds = new Set(SMMM_SGS_CARDS.map((c) => c.id));
    if (!cards.some((c) => sgsCardIds.has(c.id))) {
      const merged = [...SMMM_SGS_CARDS, ...cards];
      saveDocument(KANBAN_CARDS_KEY, merged);
      return merged;
    }
    return cards;
  },
  saveKanbanCards(cards: KanbanCard[]): void {
    saveDocument(KANBAN_CARDS_KEY, cards);
  },

  getKanbanActivities(): KanbanActivityLog[] {
    return readDocument(KANBAN_ACTIVITIES_KEY, DEFAULT_ACTIVITIES);
  },
  saveKanbanActivities(activities: KanbanActivityLog[]): void {
    saveDocument(KANBAN_ACTIVITIES_KEY, activities);
  },

  getKanbanLabels(): KanbanLabel[] {
    return readDocument(KANBAN_LABELS_KEY, DEFAULT_KANBAN_LABELS);
  },
  saveKanbanLabels(labels: KanbanLabel[]): void {
    saveDocument(KANBAN_LABELS_KEY, labels);
  },
};

