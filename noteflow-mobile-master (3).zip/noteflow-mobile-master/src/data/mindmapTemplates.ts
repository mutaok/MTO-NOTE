import { MindMapDoc, MindMapNode, MindMapTableDoc, MindMapTreeDoc, MindMapType } from '../types';

export const NODE_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444', '#EC4899', '#06B6D4'];

let idCounter = 0;
export function makeNodeId(): string {
  idCounter += 1;
  return `n${Date.now().toString(36)}${idCounter}`;
}

export function makeNode(title: string, children: MindMapNode[] = [], color?: string): MindMapNode {
  return { id: makeNodeId(), title, children, color };
}

function treeDoc(root: MindMapNode): MindMapTreeDoc {
  return { kind: 'tree', root };
}

function tableDoc(rows: string[], cols: string[]): MindMapTableDoc {
  return { kind: 'table', rows, cols, cells: {} };
}

export interface MindMapTemplate {
  type: MindMapType;
  label: string;
  description: string;
  iconName: string;
  createDoc: () => MindMapDoc;
}

export const MIND_MAP_TEMPLATES: MindMapTemplate[] = [
  {
    type: 'mindmap',
    label: 'Zihin Haritası',
    description: 'Kök + çok çocuklu ağaç, iki yönlü dallanma',
    iconName: 'Network',
    createDoc: () =>
      treeDoc(
        makeNode('Ana Fikir', [
          makeNode('Proje Hedefleri', [makeNode('Zaman Çizelgesi'), makeNode('Bütçe')], NODE_COLORS[0]),
          makeNode('Pazar Araştırması', [makeNode('Rakip Analizi'), makeNode('Müşteri Geri Bildirimi')], NODE_COLORS[1]),
          makeNode('Tasarım & UI', [makeNode('Renk Paleti'), makeNode('Tipografi')], NODE_COLORS[2]),
          makeNode('Geliştirme', [makeNode('Frontend'), makeNode('API Entegrasyonu')], NODE_COLORS[3]),
        ]),
      ),
  },
  {
    type: 'logic',
    label: 'Mantık Şeması',
    description: 'Soldan sağa katmanlı akış',
    iconName: 'GitMerge',
    createDoc: () =>
      treeDoc(
        makeNode('Başlangıç', [
          makeNode('Gereksinim Analizi', [
            makeNode('Kullanıcı Hikayeleri', [makeNode('Onay ve Planlama')]),
          ]),
        ]),
      ),
  },
  {
    type: 'brace',
    label: 'Parantez (Küme) Haritası',
    description: 'Parça-bütün ağacı, iç içe gruplar',
    iconName: 'Split',
    createDoc: () =>
      treeDoc(
        makeNode('Bütün Sistem', [
          makeNode('Arayüz Katmanı', [makeNode('Bileşenler'), makeNode('Stiller')]),
          makeNode('Veri Katmanı', [makeNode('Depolama'), makeNode('Önbellek')]),
          makeNode('Mantık Katmanı', [makeNode('İş Kuralları')]),
        ]),
      ),
  },
  {
    type: 'org',
    label: 'Organizasyon Şeması',
    description: 'Katı hiyerarşik ağaç, dikey kutu-çizgi',
    iconName: 'Users',
    createDoc: () =>
      treeDoc(
        makeNode('Genel Müdür (CEO)', [
          makeNode('Teknoloji Direktörü (CTO)', [makeNode('Yazılım Ekibi'), makeNode('DevOps')]),
          makeNode('Ürün Direktörü (CPO)', [makeNode('UI/UX Tasarım'), makeNode('Ürün Yönetimi')]),
          makeNode('Pazarlama Direktörü (CMO)', [makeNode('Dijital Pazarlama')]),
        ]),
      ),
  },
  {
    type: 'tree',
    label: 'Ağaç Şeması',
    description: 'Klasik n-ary ağaç, üstten alta',
    iconName: 'FolderTree',
    createDoc: () =>
      treeDoc(
        makeNode('Kök Konu', [
          makeNode('Kategori A', [makeNode('Öğe 1'), makeNode('Öğe 2')]),
          makeNode('Kategori B', [makeNode('Öğe 3'), makeNode('Öğe 4')]),
        ]),
      ),
  },
  {
    type: 'timeline',
    label: 'Zaman Çizelgesi',
    description: 'Kronolojik, tek eksende sıralı düğümler',
    iconName: 'Milestone',
    createDoc: () =>
      treeDoc(
        makeNode('2026 Yol Haritası', [
          makeNode('Q1: Tasarım & Prototip', [makeNode('Figma tasarımları'), makeNode('Kullanıcı testleri')]),
          makeNode('Q2: MVP Lansmanı', [makeNode('Beta sürümü'), makeNode('Geri bildirim toplama')]),
          makeNode('Q3: Ölçeklenme', [makeNode('Performans iyileştirmeleri')]),
          makeNode('Q4: Global Çıkış', [makeNode('Çoklu dil desteği')]),
        ]),
      ),
  },
  {
    type: 'fishbone',
    label: 'Kılçık Diyagramı',
    description: 'Merkezi omurga + açılı kaburga dalları (Neden-Sonuç)',
    iconName: 'GitFork',
    createDoc: () =>
      treeDoc(
        makeNode('Düşük Dönüşüm Oranı', [
          makeNode('İnsan Faktörü', [makeNode('Eğitim eksikliği'), makeNode('İletişim kopukluğu')]),
          makeNode('Süreçler', [makeNode('Uzun adımlar'), makeNode('Gereksiz formlar')]),
          makeNode('Teknoloji', [makeNode('Yavaş yükleme'), makeNode('Mobil uyumsuzluk')]),
          makeNode('Çevre', [makeNode('Piyasa koşulları'), makeNode('Rakip kampanyaları')]),
        ]),
      ),
  },
  {
    type: 'treetable',
    label: 'Ağaç Tablosu',
    description: 'Hiyerarşik özellik ve veri dallanması',
    iconName: 'TableProperties',
    createDoc: () =>
      treeDoc(
        makeNode('Proje Kaynakları', [
          makeNode('İnsan Kaynakları', [makeNode('Geliştiriciler: 4'), makeNode('Tasarımcılar: 2')]),
          makeNode('Teknolojik Altyapı', [makeNode('Bulut Sunucular'), makeNode('Veritabanı')]),
        ]),
      ),
  },
  {
    type: 'matrix',
    label: 'Matris',
    description: 'Satır/sütun başlıklı 2 boyutlu karşılaştırma matrisi',
    iconName: 'Grid',
    createDoc: () => {
      const doc = tableDoc(['Önemli', 'Önemsiz'], ['Acil', 'Acil Değil']);
      doc.cells['0:0'] = 'Hemen Yap (Krizler, Teslimler)';
      doc.cells['0:1'] = 'Planla (Strateji, Egzersiz)';
      doc.cells['1:0'] = 'Devret (Aramalar, Rutinler)';
      doc.cells['1:1'] = 'Ele (Vakit Kaybettirenler)';
      return doc;
    },
  },
  {
    type: 'grid',
    label: 'Grid (Izgara)',
    description: 'Serbest hücre tablosu ve veri panosu',
    iconName: 'LayoutGrid',
    createDoc: () => {
      const doc = tableDoc(['Özellik 1', 'Özellik 2', 'Özellik 3'], ['Plan A', 'Plan B', 'Plan C']);
      doc.cells['0:0'] = 'Dahil';
      doc.cells['0:1'] = 'Dahil';
      doc.cells['0:2'] = 'Dahil';
      doc.cells['1:0'] = 'Sınırlı';
      doc.cells['1:1'] = 'Gelişmiş';
      doc.cells['1:2'] = 'Sınırsız';
      doc.cells['2:0'] = 'Destek Yok';
      doc.cells['2:1'] = 'E-posta';
      doc.cells['2:2'] = '7/24 Öncelikli';
      return doc;
    },
  },
];

export function templateFor(type: MindMapType): MindMapTemplate {
  const found = MIND_MAP_TEMPLATES.find((t) => t.type === type);
  return found || MIND_MAP_TEMPLATES[0];
}

export function isTableType(type: MindMapType): boolean {
  return type === 'matrix' || type === 'grid';
}
