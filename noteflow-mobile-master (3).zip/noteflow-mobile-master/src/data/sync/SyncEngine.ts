import type { PostgrestError, RealtimeChannel, SupabaseClient } from '@supabase/supabase-js';
import { isUuid, legacyUuid } from './ids';
import { SYNC_TABLES, TABLE_SPECS, rowSignature, type SyncTable } from './mappers';

/**
 * Web istemcisinin çevrimdışı-öncelikli senkronizasyon motoru. Flutter
 * uygulamasındaki SupabaseSyncService ile aynı kuralları izler:
 *
 * 1. **Yerel değişiklik**: StorageService tüm diziyi kaydeder; motor imzaları
 *    son senkronize sürümle karşılaştırıp yalnızca değişen kayıtları kuyruğa
 *    alır. Diziden çıkan kayıt yumuşak silinir (`deleted_at`).
 * 2. **Push**: kuyruk tablo sırasıyla upsert edilir (önce defterler). Sunucudaki
 *    last-write-wins tetikleyicisi daha eski düzenlemeyi atlarsa satır yanıtta
 *    dönmez; sunucudaki sürüm geri çekilir.
 * 3. **Pull**: `server_updated_at > imleç` (30 sn örtüşmeyle) sayfa sayfa çekilir;
 *    kuyrukta bekleyen değişikliği olan kaydın yerel sürümü ezilmez.
 *
 * Tetikleyiciler: yerel değişiklik (kısa gecikmeyle), Realtime bildirimi,
 * dakikalık zamanlayıcı, sekmenin öne gelmesi ve bağlantının geri gelmesi.
 */

export type SyncPhase = 'idle' | 'syncing' | 'offline' | 'error';

export interface SyncStatus {
  phase: SyncPhase;
  pending: number;
  lastSyncedAt: number | null;
  message: string | null;
}

/** Uzak değişiklikten etkilenen yerel veri: bir tablo ya da `documents`. */
export type ChangedArea = SyncTable | 'documents';

type Entity = { id: string; updatedAt?: string; notebookId?: string | null };

/** Motorun yerel depoya erişimi. Yazma metotları senkronu yeniden tetiklememelidir. */
export interface LocalStore {
  readCollection(table: SyncTable): Entity[];
  writeCollection(table: SyncTable, items: Entity[]): void;
  readDocument(key: string): unknown;
  writeDocument(key: string, value: unknown): void;
  documentKeys: readonly string[];
}

type QueueTable = SyncTable | 'app_documents';

interface QueueEntry {
  table: QueueTable;
  /** Satır kimliği (UUID) ya da belge anahtarı. */
  id: string;
  kind: 'upsert' | 'delete';
  payload: Record<string, unknown>;
  /** Başarılı gönderimden sonra gölgeye yazılacak içerik imzası. */
  signature: string | null;
  rev: number;
  attempts: number;
  nextAttemptAt: number;
  lastError?: string;
}

interface PersistedState {
  queue: Record<string, QueueEntry>;
  /** Sunucuyla eşleştiği bilinen içeriğin imzası: `tablo:kimlik` → imza. */
  shadow: Record<string, string>;
  cursors: Partial<Record<QueueTable, string>>;
  rev: number;
}

const STATE_PREFIX = 'noteflow_sync_v1:';
const DOCUMENTS_TABLE = 'app_documents';
const ALL_TABLES: readonly QueueTable[] = [...SYNC_TABLES, DOCUMENTS_TABLE];
const EPOCH = '1970-01-01T00:00:00.000Z';
const PUSH_BATCH = 50;
const PULL_PAGE = 500;
const PULL_OVERLAP_MS = 30_000;
const LOCAL_CHANGE_DELAY_MS = 1_500;
const PERIODIC_MS = 60_000;
/** Bu süre içinde uzaktan gelen kayıt, bayat bir dizi kaydedildi diye silinmez. */
const STALE_SAVE_GUARD_MS = 15_000;

const keyOf = (table: QueueTable, id: string) => `${table}:${id}`;

function backoffMs(attempts: number): number {
  return Math.min(5_000 * 2 ** Math.max(0, attempts - 1), 30 * 60_000);
}

function validIso(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const time = Date.parse(value);
  return Number.isNaN(time) ? null : new Date(time).toISOString();
}

/** Ağ hatası ya da geçersiz oturum: kayıt hatalı değil, çalıştırmayı durdur. */
function isTransportError(error: PostgrestError): boolean {
  const code = error.code ?? '';
  return !code || code.startsWith('PGRST3') || /JWT|fetch|network/i.test(error.message ?? '');
}

export function clearSyncState(userId: string): void {
  try {
    localStorage.removeItem(STATE_PREFIX + userId);
  } catch {
    // localStorage erişilemezse temizlenecek bir şey de yoktur.
  }
}

export class SyncEngine {
  private readonly client: SupabaseClient;
  private readonly userId: string;
  private readonly store: LocalStore;
  private state: PersistedState;

  private statusValue: SyncStatus;
  private statusListeners = new Set<(status: SyncStatus) => void>();
  private changeListeners = new Set<(areas: Set<ChangedArea>) => void>();
  private changedAreas = new Set<ChangedArea>();
  private recentlyApplied = new Map<string, { at: number; entity: Entity }>();

  private channel: RealtimeChannel | null = null;
  private debounce: ReturnType<typeof setTimeout> | null = null;
  private periodic: ReturnType<typeof setInterval> | null = null;
  private running: Promise<void> | null = null;
  private rerun = false;
  private stopped = false;
  private migrating: Promise<void> | null = null;

  constructor(options: { client: SupabaseClient; userId: string; store: LocalStore }) {
    this.client = options.client;
    this.userId = options.userId;
    this.store = options.store;
    this.state = this.load();
    this.statusValue = { phase: 'idle', pending: Object.keys(this.state.queue).length, lastSyncedAt: null, message: null };
  }

  // ------------------------------------------------------------- lifecycle --

  /** Tetikleyicileri kurar; dönen söz ilk senkron bitince çözülür. */
  start(): Promise<void> {
    this.channel = this.client.channel(`noteflow-web-${this.userId}`);
    for (const table of ALL_TABLES) {
      this.channel.on(
        'postgres_changes',
        { event: '*', schema: 'public', table, filter: `user_id=eq.${this.userId}` },
        () => this.schedule(500),
      );
    }
    this.channel.subscribe();
    this.periodic = setInterval(() => void this.syncNow(), PERIODIC_MS);
    document.addEventListener('visibilitychange', this.onVisibility);
    window.addEventListener('online', this.onOnline);
    return this.syncNow();
  }

  async stop(): Promise<void> {
    this.stopped = true;
    if (this.debounce) clearTimeout(this.debounce);
    if (this.periodic) clearInterval(this.periodic);
    document.removeEventListener('visibilitychange', this.onVisibility);
    window.removeEventListener('online', this.onOnline);
    if (this.channel) await this.client.removeChannel(this.channel);
    this.channel = null;
    this.statusListeners.clear();
    this.changeListeners.clear();
  }

  private onVisibility = () => {
    if (document.visibilityState === 'visible') this.schedule(0);
  };

  private onOnline = () => this.schedule(0);

  get status(): SyncStatus {
    return this.statusValue;
  }

  pendingCount(): number {
    return Object.keys(this.state.queue).length;
  }

  onStatus(listener: (status: SyncStatus) => void): () => void {
    this.statusListeners.add(listener);
    listener(this.statusValue);
    return () => {
      this.statusListeners.delete(listener);
    };
  }

  onRemoteChange(listener: (areas: Set<ChangedArea>) => void): () => void {
    this.changeListeners.add(listener);
    return () => {
      this.changeListeners.delete(listener);
    };
  }

  // --------------------------------------------------------- local changes --

  /**
   * StorageService bir koleksiyonu kaydettiğinde çağrılır. `preserveTimestamps`
   * ilk yüklemede kullanılır: kayıtlar kendi `updatedAt` değeriyle gider ki
   * başka cihazdaki daha yeni düzenleme ezilmesin.
   */
  notifyCollectionChanged(table: SyncTable, items: Entity[], options: { preserveTimestamps?: boolean } = {}): void {
    if (this.stopped) return;
    const spec = TABLE_SPECS[table] as unknown as { toRow(entity: Entity, userId: string): Record<string, unknown> };
    const now = new Date().toISOString();
    const present = new Set<string>();
    let hasLegacyIds = false;

    for (const item of items) {
      if (!isUuid(item.id)) {
        hasLegacyIds = true;
        continue;
      }
      present.add(item.id);
      const key = keyOf(table, item.id);
      const row = spec.toRow(item, this.userId);
      const signature = rowSignature(row);
      const queued = this.state.queue[key];
      if (queued ? queued.kind === 'upsert' && queued.signature === signature : this.state.shadow[key] === signature) continue;
      const updatedAt = (options.preserveTimestamps && validIso(item.updatedAt)) || now;
      this.enqueue({ table, id: item.id, kind: 'upsert', payload: { ...row, updated_at: updatedAt, deleted_at: null }, signature });
    }

    const restored: Entity[] = [];
    const prefix = `${table}:`;
    const candidates = new Set([...Object.keys(this.state.shadow), ...Object.keys(this.state.queue)]);
    for (const key of candidates) {
      if (!key.startsWith(prefix)) continue;
      const id = key.slice(prefix.length);
      if (present.has(id)) continue;
      const recent = this.recentlyApplied.get(key);
      if (recent && Date.now() - recent.at < STALE_SAVE_GUARD_MS) {
        // Uzaktan az önce gelen kaydı içermeyen bayat bir dizi kaydedildi: silme, geri koy.
        restored.push(recent.entity);
        continue;
      }
      if (this.state.shadow[key]) {
        this.enqueue({ table, id, kind: 'delete', payload: { updated_at: now, deleted_at: now }, signature: null });
      } else if (this.state.queue[key]) {
        delete this.state.queue[key];
      }
    }

    if (restored.length) {
      this.store.writeCollection(table, [...restored, ...items]);
      this.changedAreas.add(table);
      queueMicrotask(() => this.emitChanges());
    }
    if (hasLegacyIds) void this.migrateLegacyIds();
    this.persist();
    this.schedule(LOCAL_CHANGE_DELAY_MS);
  }

  /** Çalışma alanı verisi (flashcard, bütçe vb.) anahtar bazında tek belge olarak gider. */
  notifyDocumentChanged(key: string, value: unknown, options: { preferServer?: boolean } = {}): void {
    if (this.stopped || value === undefined) return;
    const queueKey = keyOf(DOCUMENTS_TABLE, key);
    const signature = rowSignature({ key, data: value });
    const queued = this.state.queue[queueKey];
    if (queued ? queued.signature === signature : this.state.shadow[queueKey] === signature) return;
    // preferServer: sunucuda bu belge varsa o kazanır (ilk girişte eski yerel veri için).
    const updatedAt = options.preferServer ? EPOCH : new Date().toISOString();
    this.enqueue({
      table: DOCUMENTS_TABLE,
      id: key,
      kind: 'upsert',
      payload: { user_id: this.userId, key, data: value, updated_at: updatedAt },
      signature,
    });
    this.persist();
    this.schedule(LOCAL_CHANGE_DELAY_MS);
  }

  /** Bu cihazdaki (hesapsız ya da eski sürümden kalma) verileri hesaba yükler. */
  async claimLocalData(): Promise<void> {
    await this.migrateLegacyIds();
    for (const table of SYNC_TABLES) {
      this.notifyCollectionChanged(table, this.store.readCollection(table), { preserveTimestamps: true });
    }
    for (const key of this.store.documentKeys) {
      const value = this.store.readDocument(key);
      if (value !== undefined) this.notifyDocumentChanged(key, value, { preferServer: true });
    }
  }

  private enqueue(entry: Omit<QueueEntry, 'rev' | 'attempts' | 'nextAttemptAt'>): void {
    this.state.rev += 1;
    this.state.queue[keyOf(entry.table, entry.id)] = { ...entry, rev: this.state.rev, attempts: 0, nextAttemptAt: 0 };
    this.setStatus({ pending: this.pendingCount() });
  }

  /**
   * Sayısal (eski) kimlikleri hesaba özgü deterministik UUID'lere çevirir ve
   * defter referanslarını günceller. Aynı eski veriye sahip cihazlar aynı
   * kimlikleri ürettiği için sunucuda kopya oluşmaz.
   */
  migrateLegacyIds(): Promise<void> {
    if (!this.migrating) {
      this.migrating = this.runLegacyMigration().finally(() => {
        this.migrating = null;
      });
    }
    return this.migrating;
  }

  private async runLegacyMigration(): Promise<void> {
    const collections = new Map<SyncTable, Entity[]>();
    for (const table of SYNC_TABLES) collections.set(table, this.store.readCollection(table));
    const dirty = new Set<SyncTable>();

    const notebookIds = new Map<string, string>();
    for (const notebook of collections.get('notebooks')!) {
      const oldId = String(notebook.id);
      if (!isUuid(oldId)) {
        notebook.id = await legacyUuid(this.userId, 'notebooks', oldId);
        dirty.add('notebooks');
      }
      notebookIds.set(oldId, notebook.id);
    }

    for (const table of ['notes', 'tasks', 'mind_maps'] as const) {
      for (const item of collections.get(table)!) {
        if (!isUuid(String(item.id))) {
          item.id = await legacyUuid(this.userId, table, String(item.id));
          dirty.add(table);
        }
        const ref = item.notebookId;
        if (ref != null && !isUuid(String(ref))) {
          // Yerelde olmayan bir deftere bağlı kayıt sunucuda reddedilirdi.
          item.notebookId = notebookIds.get(String(ref)) ?? null;
          dirty.add(table);
        }
      }
    }

    for (const table of dirty) {
      const items = collections.get(table)!;
      this.store.writeCollection(table, items);
      this.changedAreas.add(table);
      this.notifyCollectionChanged(table, items, { preserveTimestamps: true });
    }
    this.emitChanges();
  }

  // ------------------------------------------------------------------- run --

  syncNow(): Promise<void> {
    if (this.stopped) return Promise.resolve();
    if (this.running) {
      this.rerun = true;
      return this.running;
    }
    this.running = this.runLoop().finally(() => {
      this.running = null;
    });
    return this.running;
  }

  private schedule(delayMs: number): void {
    if (this.stopped) return;
    if (this.debounce) clearTimeout(this.debounce);
    this.debounce = setTimeout(() => void this.syncNow(), delayMs);
  }

  private async runLoop(): Promise<void> {
    do {
      this.rerun = false;
      await this.runOnce();
    } while (this.rerun && !this.stopped);
  }

  private async runOnce(): Promise<void> {
    if (this.debounce) clearTimeout(this.debounce);
    if (this.migrating) await this.migrating;
    this.setStatus({ phase: 'syncing' });
    try {
      const rejected = await this.push();
      await this.pull();
      this.persist();
      this.emitChanges();
      this.setStatus({
        phase: rejected > 0 ? 'error' : 'idle',
        lastSyncedAt: Date.now(),
        message: rejected > 0 ? `${rejected} değişiklik sunucu tarafından reddedildi; yeniden denenecek.` : null,
      });
    } catch {
      this.persist();
      this.emitChanges();
      this.setStatus({ phase: 'offline', message: 'Sunucuya ulaşılamadı; değişiklikler cihazda saklanıyor.' });
    }
  }

  // ------------------------------------------------------------------ push --

  /** Kuyruğu gönderir; sunucunun reddettiği kayıt sayısını döndürür. */
  private async push(): Promise<number> {
    const now = Date.now();
    const due = Object.values(this.state.queue).filter((entry) => entry.nextAttemptAt <= now);
    let rejected = 0;

    for (const table of ALL_TABLES) {
      const upserts = due.filter((entry) => entry.table === table && entry.kind === 'upsert');
      for (let i = 0; i < upserts.length; i += PUSH_BATCH) {
        const batch = upserts.slice(i, i + PUSH_BATCH);
        const revs = batch.map((entry) => entry.rev);
        const { data, error } = await this.upsert(table, batch.map((entry) => entry.payload));
        if (!error) {
          await this.finish(table, batch, revs, data);
          continue;
        }
        if (isTransportError(error)) throw error;
        // Toplu istek reddedildi: sorunlu kaydı bulmak için tek tek gönder.
        for (const entry of batch) rejected += await this.pushSingle(table, entry);
      }

      const deletes = due.filter((entry) => entry.table === table && entry.kind === 'delete');
      for (const entry of deletes) {
        const revs = [entry.rev];
        const { data, error } = await this.client
          .from(table)
          .update(entry.payload)
          .eq('id', entry.id)
          .select('id');
        if (!error) {
          await this.finish(table, [entry], revs, data ?? []);
        } else if (isTransportError(error)) {
          throw error;
        } else {
          this.fail(entry, error);
          rejected += 1;
        }
      }
    }
    return rejected;
  }

  private upsert(table: QueueTable, payloads: Record<string, unknown>[]) {
    const isDocument = table === DOCUMENTS_TABLE;
    return this.client
      .from(table)
      .upsert(payloads, { onConflict: isDocument ? 'user_id,key' : 'id' })
      .select(isDocument ? 'key' : 'id');
  }

  private async pushSingle(table: QueueTable, entry: QueueEntry): Promise<number> {
    const revs = [entry.rev];
    const { data, error } = await this.upsert(table, [entry.payload]);
    if (!error) {
      await this.finish(table, [entry], revs, data);
      return 0;
    }
    if (isTransportError(error)) throw error;
    this.fail(entry, error);
    return 1;
  }

  private fail(entry: QueueEntry, error: PostgrestError): void {
    const current = this.state.queue[keyOf(entry.table, entry.id)];
    if (!current || current.rev !== entry.rev) return;
    current.attempts += 1;
    current.nextAttemptAt = Date.now() + backoffMs(current.attempts);
    current.lastError = `${error.code ?? ''} ${error.message}`.trim();
    console.warn('[NoteFlow] Senkron reddedildi:', entry.table, entry.id, current.lastError);
  }

  private async finish(table: QueueTable, batch: QueueEntry[], revs: number[], returned: unknown[]): Promise<void> {
    const accepted = new Set(
      (returned as Array<{ id?: string; key?: string }>).map((row) => (table === DOCUMENTS_TABLE ? row.key : row.id)),
    );
    const superseded: string[] = [];
    batch.forEach((entry, index) => {
      const key = keyOf(table, entry.id);
      if (accepted.has(entry.id)) {
        if (entry.kind === 'upsert' && entry.signature) this.state.shadow[key] = entry.signature;
        else delete this.state.shadow[key];
      } else {
        // Last-write-wins: sunucuda daha yeni bir sürüm vardı (ya da satır yoktu).
        superseded.push(entry.id);
      }
      const current = this.state.queue[key];
      if (current && current.rev === revs[index]) delete this.state.queue[key];
    });
    this.setStatus({ pending: this.pendingCount() });

    if (!superseded.length) return;
    const column = table === DOCUMENTS_TABLE ? 'key' : 'id';
    const { data, error } = await this.client
      .from(table)
      .select('*')
      .eq('user_id', this.userId)
      .in(column, superseded);
    if (error) throw error;
    this.applyRemote(table, data ?? []);
  }

  // ------------------------------------------------------------------ pull --

  private async pull(): Promise<void> {
    for (const table of ALL_TABLES) {
      const cursor = this.state.cursors[table];
      let since = cursor ? new Date(Date.parse(cursor) - PULL_OVERLAP_MS).toISOString() : null;
      let newest = cursor ?? null;

      for (;;) {
        let query = this.client.from(table).select('*').eq('user_id', this.userId);
        if (since) query = query.gt('server_updated_at', since);
        const { data, error } = await query.order('server_updated_at', { ascending: true }).limit(PULL_PAGE);
        if (error) throw error;
        const rows = (data ?? []) as Array<Record<string, unknown>>;
        if (!rows.length) break;

        this.applyRemote(table, rows);
        const last = rows[rows.length - 1].server_updated_at as string;
        if (!newest || Date.parse(last) >= Date.parse(newest)) newest = last;
        if (rows.length < PULL_PAGE) break;
        since = last;
      }

      if (newest) this.state.cursors[table] = newest;
    }
  }

  private applyRemote(table: QueueTable, rows: Array<Record<string, unknown>>): void {
    if (table === DOCUMENTS_TABLE) {
      for (const row of rows) {
        const key = keyOf(table, row.key as string);
        if (this.state.queue[key]) continue;
        const signature = rowSignature({ key: row.key, data: row.data });
        if (this.state.shadow[key] === signature) continue;
        this.store.writeDocument(row.key as string, row.data);
        this.state.shadow[key] = signature;
        this.changedAreas.add('documents');
      }
      return;
    }

    const spec = TABLE_SPECS[table] as unknown as {
      toRow(entity: Entity, userId: string): Record<string, unknown>;
      fromRow(row: Record<string, unknown>): Entity;
    };
    const items = this.store.readCollection(table);
    const byId = new Map(items.map((item) => [item.id, item]));
    const replaced = new Map<string, Entity>();
    const removed = new Set<string>();
    const added: Entity[] = [];

    for (const row of rows) {
      const id = row.id as string;
      const key = keyOf(table, id);
      if (this.state.queue[key]) continue;

      if (row.deleted_at) {
        if (byId.has(id)) removed.add(id);
        delete this.state.shadow[key];
        this.recentlyApplied.delete(key);
        continue;
      }

      const entity = spec.fromRow(row);
      const signature = rowSignature(spec.toRow(entity, this.userId));
      if (this.state.shadow[key] === signature && byId.has(id)) continue;
      this.state.shadow[key] = signature;
      this.recentlyApplied.set(key, { at: Date.now(), entity });
      if (byId.has(id)) replaced.set(id, entity);
      else if (!added.some((item) => item.id === id)) added.push(entity);
    }

    if (!replaced.size && !removed.size && !added.length) return;
    const next = [
      ...added.reverse(),
      ...items.filter((item) => !removed.has(item.id)).map((item) => replaced.get(item.id) ?? item),
    ];
    this.store.writeCollection(table, next);
    this.changedAreas.add(table);
  }

  // ----------------------------------------------------------------- state --

  private emitChanges(): void {
    if (!this.changedAreas.size) return;
    const areas = new Set(this.changedAreas);
    this.changedAreas.clear();
    for (const listener of this.changeListeners) listener(areas);
  }

  private setStatus(patch: Partial<SyncStatus>): void {
    this.statusValue = { ...this.statusValue, ...patch };
    for (const listener of this.statusListeners) listener(this.statusValue);
  }

  private load(): PersistedState {
    try {
      const raw = localStorage.getItem(STATE_PREFIX + this.userId);
      if (raw) {
        const parsed = JSON.parse(raw) as PersistedState;
        return { queue: parsed.queue ?? {}, shadow: parsed.shadow ?? {}, cursors: parsed.cursors ?? {}, rev: parsed.rev ?? 0 };
      }
    } catch {
      // Bozuk durum: sıfırdan başla, pull her şeyi yeniden getirir.
    }
    return { queue: {}, shadow: {}, cursors: {}, rev: 0 };
  }

  private persist(): void {
    try {
      localStorage.setItem(STATE_PREFIX + this.userId, JSON.stringify(this.state));
    } catch (error) {
      console.warn('[NoteFlow] Senkron durumu kaydedilemedi', error);
    }
  }
}
