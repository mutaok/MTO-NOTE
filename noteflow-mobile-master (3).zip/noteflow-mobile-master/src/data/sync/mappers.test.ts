import { describe, expect, it } from 'vitest';
import type { MindMap, Note, Notebook, Task } from '../../types';
import { isUuid, legacyUuid, newId } from './ids';
import {
  mindMapFromRow,
  mindMapToRow,
  noteFromRow,
  noteToRow,
  notebookFromRow,
  notebookToRow,
  rowSignature,
  taskFromRow,
  taskToRow,
} from './mappers';

const USER = '11111111-1111-4111-8111-111111111111';
const OTHER_USER = '33333333-3333-4333-8333-333333333333';
const NOTEBOOK_ID = '22222222-2222-4222-8222-222222222222';
const CREATED = '2026-09-01T10:00:00.000Z';
const UPDATED = '2026-09-02T10:00:00.000Z';

describe('ids', () => {
  it('newId geçerli bir UUID üretir', () => {
    expect(isUuid(newId())).toBe(true);
    expect(isUuid('101')).toBe(false);
  });

  it('legacyUuid deterministiktir, hesaba ve tabloya özgüdür', async () => {
    const id = await legacyUuid(USER, 'notes', 101);
    expect(isUuid(id)).toBe(true);
    expect(await legacyUuid(USER, 'notes', '101')).toBe(id);
    expect(await legacyUuid(OTHER_USER, 'notes', 101)).not.toBe(id);
    expect(await legacyUuid(USER, 'notebooks', 101)).not.toBe(id);
  });
});

describe('notebooks', () => {
  const notebook: Notebook = {
    id: NOTEBOOK_ID,
    title: 'Ders Notları',
    name: 'Ders Notları',
    description: 'Algoritmalar',
    type: 'academic',
    color: '#4F46E5',
    icon: 'GraduationCap',
    paperStyle: 'lined',
    defaultView: 'notes',
    createdAt: CREATED,
    updatedAt: UPDATED,
    tags: ['Üniversite'],
  };

  it('ortak sütunları ve web alanlarını eşler, geri dönüşte aynı satırı verir', () => {
    const row = notebookToRow(notebook, USER);
    expect(row).toMatchObject({ title: 'Ders Notları', color: '#4F46E5' });
    expect(row.meta).toMatchObject({ type: 'academic', paperTexture: 'lined', tags: ['Üniversite'] });
    expect(notebookToRow(notebookFromRow({ ...row, updated_at: UPDATED }), USER)).toEqual(row);
  });

  it('CHECK kısıtına uymayan rengi meta içinde saklar', () => {
    const row = notebookToRow({ ...notebook, color: 'indigo' }, USER);
    expect(row.color).toBeNull();
    expect(row.meta.color).toBe('indigo');
    expect(notebookFromRow({ ...row, updated_at: UPDATED }).color).toBe('indigo');
  });

  it('Flutter satırını varsayılanlarla okur ve imzası kararlıdır', () => {
    const fromFlutter = notebookFromRow({
      id: NOTEBOOK_ID,
      user_id: USER,
      title: 'Flutter defteri',
      color: null,
      meta: {},
      created_at: '2026-09-01T10:00:00+00:00',
      updated_at: '2026-09-01T10:00:00.123456+00:00',
    });
    expect(fromFlutter).toMatchObject({ type: 'academic', name: 'Flutter defteri', isLocked: false });
    const row = notebookToRow(fromFlutter, USER);
    const again = notebookToRow(notebookFromRow({ ...row, updated_at: fromFlutter.updatedAt }), USER);
    expect(rowSignature(again)).toBe(rowSignature(row));
  });

  it('boş ve uzun başlıkları kısıta uydurur', () => {
    expect(notebookToRow({ ...notebook, name: '', title: '' }, USER).title).toBe('Adsız Defter');
    expect(Array.from(notebookToRow({ ...notebook, name: 'ş'.repeat(200) }, USER).title)).toHaveLength(120);
  });
});

describe('notes', () => {
  const note: Note = {
    id: '44444444-4444-4444-8444-444444444444',
    notebookId: NOTEBOOK_ID,
    title: 'Bellman Denklemi',
    body: 'Gövde',
    tag: 'İş',
    date: '2026-09-14',
    createdAt: CREATED,
    updatedAt: UPDATED,
    cornell: { cues: ['Memoization?'], notes: 'n', summary: 's' },
  };

  it('etiket, tarih ve defter türüne özel alanları eşler', () => {
    const row = noteToRow(note, USER);
    expect(row).toMatchObject({ notebook_id: NOTEBOOK_ID, tag: 'İş', note_date: '2026-09-14', meta: { cornell: note.cornell } });
    expect(noteFromRow({ ...row, updated_at: UPDATED })).toEqual(note);
  });

  it('UUID olmayan defter kimliğini ve geçersiz tarihi göndermez', () => {
    const row = noteToRow({ ...note, notebookId: '101', date: '' }, USER);
    expect(row.notebook_id).toBeNull();
    expect(row.note_date).toBeNull();
  });
});

describe('tasks', () => {
  const task: Task = {
    id: '55555555-5555-4555-8555-555555555555',
    title: 'Sınav tekrarı',
    list: 'Akademik',
    dueDate: '2026-09-15',
    dueTime: '14:00',
    done: false,
    color: '#4F46E5',
    assignee: 'Can',
    priority: 'yüksek',
    createdAt: CREATED,
    updatedAt: UPDATED,
  };

  it('saat, tarih ve önceliği doğrulayarak eşler', () => {
    const row = taskToRow(task, USER);
    expect(row).toMatchObject({ due_date: '2026-09-15', due_time: '14:00', notebook_id: null, meta: { assignee: 'Can', priority: 'yüksek' } });
    expect(taskFromRow({ ...row, updated_at: UPDATED })).toEqual({ ...task, notebookId: null });
    expect(taskToRow({ ...task, dueTime: '2pm' }, USER).due_time).toBeNull();
  });
});

describe('mind_maps', () => {
  it('belgeyi olduğu gibi taşır', () => {
    const map: MindMap = {
      id: '66666666-6666-4666-8666-666666666666',
      title: 'Proje haritası',
      type: 'mindmap',
      data: { kind: 'tree', root: { id: 'root', title: 'Ana Fikir', children: [] } },
      createdAt: CREATED,
      updatedAt: UPDATED,
    };
    const row = mindMapToRow(map, USER);
    expect(mindMapFromRow({ ...row, updated_at: UPDATED })).toEqual({ ...map, notebookId: null });
  });
});
