/**
 * Kimlik yardımcıları. Senkronize edilen tüm varlıklar Flutter uygulamasıyla
 * aynı biçimi, yani istemcide üretilen UUID'yi kullanır.
 */

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isUuid(value: unknown): value is string {
  return typeof value === 'string' && UUID_RE.test(value);
}

function formatUuid(bytes: Uint8Array): string {
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`;
}

export function newId(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  // randomUUID olmayan eski WebView'lar için RFC 4122 v4.
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  return formatUuid(bytes);
}

/**
 * Eski sayısal kimliği (ör. 101 ya da Date.now()) hesaba özgü, deterministik
 * bir UUID'ye çevirir. Aynı eski veriye sahip iki cihaz aynı UUID'yi ürettiği
 * için ilk girişte kopya kayıt oluşmaz; kullanıcı kimliği dahil edildiği için
 * farklı hesaplar çakışmaz.
 */
export async function legacyUuid(userId: string, table: string, legacyId: string | number): Promise<string> {
  const input = new TextEncoder().encode(`noteflow:${userId}:${table}:${legacyId}`);
  const bytes = new Uint8Array(await crypto.subtle.digest('SHA-256', input)).slice(0, 16);
  bytes[6] = (bytes[6] & 0x0f) | 0x50;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  return formatUuid(bytes);
}
