import type { MindMap, MindMapDoc, MindMapType, Note, Notebook, NotebookType, PaperTexture, Task } from '../../types';
import { isUuid } from './ids';

/**
 * Web varlıkları ile Supabase satırları (snake_case) arasındaki dönüşüm.
 *
 * Flutter uygulamasıyla ortak sütunlar (title, body, color...) doğrudan
 * eşlenir; yalnızca web'de olan alanlar `meta` jsonb sütununda saklanır.
 * `toRow` sunucu kısıtlarına (CHECK) uyan değerler üretir ve deterministiktir:
 * aynı varlık her zaman aynı satırı verir, böylece imza karşılaştırması
 * değişmeyen kayıtları yeniden göndermez.
 */

export type SyncTable = 'notebooks' | 'notes' | 'tasks' | 'mind_maps';

type Json = Record<string, unknown>;

export interface RowBase {
  id: string;
  user_id: string;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
  server_updated_at?: string;
}

export interface NotebookRow extends RowBase {
  title: string;
  color: string | null;
  meta: Json;
}

export interface NoteRow extends RowBase {
  notebook_id: string | null;
  title: string;
  body: string;
  tag: string | null;
  note_date: string | null;
  meta: Json;
}

export interface TaskRow extends RowBase {
  notebook_id: string | null;
  title: string;
  list: string;
  due_date: string | null;
  due_time: string | null;
  done: boolean;
  color: string | null;
  meta: Json;
}

export interface MindMapRow extends RowBase {
  notebook_id: string | null;
  title: string;
  type: string;
  data: unknown;
}

const HEX6_RE = /^#[0-9A-Fa-f]{6}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^[0-2]\d:[0-5]\d$/;
const EPOCH = '1970-01-01T00:00:00.000Z';

const NOTEBOOK_TYPES: readonly string[] = [
  'academic', 'project', 'journal', 'meeting', 'reading', 'travel',
  'recipe', 'finance', 'fitness', 'brainstorm', 'code',
];
const MIND_MAP_TYPES: readonly string[] = [
  'mindmap', 'logic', 'brace', 'org', 'tree', 'timeline', 'fishbone', 'treetable', 'matrix', 'grid',
];
const PAPER_TEXTURES: readonly string[] = ['plain', 'lined', 'grid', 'dots'];
const PRIORITIES: readonly string[] = ['düşük', 'orta', 'yüksek', 'kritik'];
const NOTE_META_KEYS = ['customFields', 'backlinks', 'cornell', 'meetingDetails', 'bookData', 'recipeData', 'codeSnippet'] as const;

/** Postgres `char_length` gibi kod noktası sayarak keser. */
function clamp(value: unknown, max: number): string {
  const text = typeof value === 'string' ? value : '';
  return text.length <= max ? text : Array.from(text).slice(0, max).join('');
}

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined;
}

function asObject(value: unknown): Json {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as Json) : {};
}

function stringArray(value: unknown): string[] | undefined {
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : undefined;
}

/** Geçersiz tarihte sabit bir değer döner; `new Date()` imzayı her çağrıda değiştirirdi. */
function iso(value: unknown): string {
  if (typeof value === 'string') {
    const time = Date.parse(value);
    if (!Number.isNaN(time)) return new Date(time).toISOString();
  }
  return EPOCH;
}

function compact(obj: Json): Json {
  const out: Json = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) out[key] = value;
  }
  return out;
}

// -------------------------------------------------------------- notebooks --

export function notebookToRow(notebook: Notebook, userId: string): NotebookRow {
  const title = clamp(notebook.name || notebook.title, 120);
  const color = typeof notebook.color === 'string' ? notebook.color : '';
  return {
    id: notebook.id,
    user_id: userId,
    title: title.trim() ? title : 'Adsız Defter',
    color: HEX6_RE.test(color) ? color : null,
    meta: compact({
      type: notebook.type,
      description: notebook.description,
      icon: notebook.icon,
      color: color && !HEX6_RE.test(color) ? color : undefined,
      isLocked: notebook.isLocked ? true : undefined,
      pinCode: notebook.pinCode || notebook.pin || undefined,
      paperTexture: notebook.paperTexture || notebook.paperStyle,
      defaultView: notebook.defaultView,
      views: notebook.views,
      tags: notebook.tags,
      collaborators: notebook.collaborators,
    }),
    created_at: iso(notebook.createdAt),
  };
}

export function notebookFromRow(row: NotebookRow): Notebook {
  const meta = asObject(row.meta);
  const type = NOTEBOOK_TYPES.includes(meta.type as string) ? (meta.type as NotebookType) : 'academic';
  const paper = PAPER_TEXTURES.includes(meta.paperTexture as string) ? (meta.paperTexture as PaperTexture) : undefined;
  const pin = optionalString(meta.pinCode);
  return {
    id: row.id,
    title: row.title,
    name: row.title,
    description: optionalString(meta.description) ?? '',
    type,
    color: row.color ?? optionalString(meta.color) ?? '',
    icon: optionalString(meta.icon) ?? '',
    isLocked: meta.isLocked === true,
    pin,
    pinCode: pin,
    paperStyle: paper,
    paperTexture: paper,
    defaultView: optionalString(meta.defaultView) as Notebook['defaultView'],
    views: stringArray(meta.views),
    tags: stringArray(meta.tags),
    collaborators: Array.isArray(meta.collaborators) ? (meta.collaborators as Notebook['collaborators']) : undefined,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
}

// ------------------------------------------------------------------ notes --

export function noteToRow(note: Note, userId: string): NoteRow {
  const meta: Json = {};
  for (const key of NOTE_META_KEYS) {
    if (note[key] !== undefined) meta[key] = note[key];
  }
  return {
    id: note.id,
    user_id: userId,
    notebook_id: isUuid(note.notebookId) ? note.notebookId : null,
    title: clamp(note.title, 300),
    body: typeof note.body === 'string' ? note.body : '',
    tag: clamp(note.tag, 64) || null,
    note_date: typeof note.date === 'string' && DATE_RE.test(note.date) ? note.date : null,
    meta,
    created_at: iso(note.createdAt),
  };
}

export function noteFromRow(row: NoteRow): Note {
  const meta = asObject(row.meta);
  const note: Note = {
    id: row.id,
    notebookId: row.notebook_id,
    title: row.title ?? '',
    body: row.body ?? '',
    tag: row.tag || 'Kişisel',
    date: row.note_date,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
  for (const key of NOTE_META_KEYS) {
    if (meta[key] !== undefined) (note as unknown as Json)[key] = meta[key];
  }
  return note;
}

// ------------------------------------------------------------------ tasks --

export function taskToRow(task: Task, userId: string): TaskRow {
  const title = clamp(task.title, 500);
  return {
    id: task.id,
    user_id: userId,
    notebook_id: isUuid(task.notebookId) ? task.notebookId : null,
    title: title.trim() ? title : 'Başlıksız görev',
    list: clamp(task.list, 64) || 'Kişisel',
    due_date: typeof task.dueDate === 'string' && DATE_RE.test(task.dueDate) ? task.dueDate : null,
    due_time: typeof task.dueTime === 'string' && TIME_RE.test(task.dueTime) ? task.dueTime : null,
    done: task.done === true,
    color: clamp(task.color, 32) || null,
    meta: compact({ assignee: task.assignee, priority: task.priority }),
    created_at: iso(task.createdAt),
  };
}

export function taskFromRow(row: TaskRow): Task {
  const meta = asObject(row.meta);
  return {
    id: row.id,
    notebookId: row.notebook_id,
    title: row.title,
    list: row.list || 'Kişisel',
    dueDate: row.due_date,
    dueTime: row.due_time,
    done: row.done === true,
    color: row.color || '#3B82F6',
    assignee: optionalString(meta.assignee),
    priority: PRIORITIES.includes(meta.priority as string) ? (meta.priority as Task['priority']) : undefined,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
}

// -------------------------------------------------------------- mind maps --

const EMPTY_MIND_MAP: MindMapDoc = { kind: 'tree', root: { id: 'root', title: 'Ana Fikir', children: [] } };

export function mindMapToRow(map: MindMap, userId: string): MindMapRow {
  return {
    id: map.id,
    user_id: userId,
    notebook_id: isUuid(map.notebookId) ? map.notebookId : null,
    title: clamp(map.title, 300),
    type: MIND_MAP_TYPES.includes(map.type) ? map.type : 'mindmap',
    data: map.data ?? EMPTY_MIND_MAP,
    created_at: iso(map.createdAt),
  };
}

export function mindMapFromRow(row: MindMapRow): MindMap {
  return {
    id: row.id,
    notebookId: row.notebook_id,
    title: row.title ?? '',
    type: MIND_MAP_TYPES.includes(row.type) ? (row.type as MindMapType) : 'mindmap',
    data: (row.data as MindMapDoc) ?? EMPTY_MIND_MAP,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
}

// ------------------------------------------------------------------ specs --

export interface TableSpec<E extends { id: string }, R extends RowBase> {
  table: SyncTable;
  toRow(entity: E, userId: string): R;
  fromRow(row: R): E;
}

export const TABLE_SPECS = {
  notebooks: { table: 'notebooks', toRow: notebookToRow, fromRow: notebookFromRow } as TableSpec<Notebook, NotebookRow>,
  notes: { table: 'notes', toRow: noteToRow, fromRow: noteFromRow } as TableSpec<Note, NoteRow>,
  tasks: { table: 'tasks', toRow: taskToRow, fromRow: taskFromRow } as TableSpec<Task, TaskRow>,
  mind_maps: { table: 'mind_maps', toRow: mindMapToRow, fromRow: mindMapFromRow } as TableSpec<MindMap, MindMapRow>,
};

/** Yabancı anahtar sırası: defterler önce gönderilir. */
export const SYNC_TABLES: readonly SyncTable[] = ['notebooks', 'notes', 'tasks', 'mind_maps'];

/**
 * Satır içeriğinin kısa özeti (cyrb53). `updated_at`/`deleted_at` dahil
 * değildir; yalnızca içerik değiştiğinde kayıt yeniden gönderilir.
 */
export function rowSignature(row: object): string {
  const text = JSON.stringify(row);
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
