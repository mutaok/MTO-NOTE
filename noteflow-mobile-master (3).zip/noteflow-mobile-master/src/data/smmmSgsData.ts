import { KanbanBoard, KanbanList, KanbanCard, KanbanLabel } from '../types/kanban';
import { SHARED_DEFAULT_USER_ID } from '../lib/supabase';

export const SMMM_SGS_BOARD_ID = 'board-smmm-sgs';

export const SMMM_SGS_BOARD: KanbanBoard = {
  id: SMMM_SGS_BOARD_ID,
  title: '📚 SMMM Staja Giriş Sınavı (SGS)',
  description:
    'SMMM SGS müfredatında yer alan 14 ders ve tüm ana konu başlıkları. Konuları görev olarak tamamlandı/tamamlanmadı şeklinde takip edebilirsiniz.',
  owner_id: SHARED_DEFAULT_USER_ID,
  color: '#0d9488',
  created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
  updated_at: new Date().toISOString(),
  archived: false,
};

export const SMMM_SGS_LABELS: KanbanLabel[] = [
  { id: 'lbl-sgs-alan', name: 'Alan Bilgisi (100 Soru)', color: '#0d9488' },
  { id: 'lbl-sgs-gkgy', name: 'GK/GY (30 Soru)', color: '#6366f1' },
  { id: 'lbl-sgs-w25', name: '%25 Ağırlık', color: '#ef4444' },
  { id: 'lbl-sgs-w16', name: '%16 Ağırlık', color: '#f97316' },
  { id: 'lbl-sgs-w13', name: '%13 Ağırlık', color: '#f59e0b' },
  { id: 'lbl-sgs-w8', name: '%8 Ağırlık', color: '#10b981' },
  { id: 'lbl-sgs-w7', name: '%7 Ağırlık', color: '#06b6d4' },
  { id: 'lbl-sgs-w6', name: '%6 Ağırlık', color: '#3b82f6' },
  { id: 'lbl-sgs-w5', name: '%5 Ağırlık', color: '#8b5cf6' },
  { id: 'lbl-sgs-w3', name: '%3 Ağırlık', color: '#ec4899' },
];

const STEP = 65536;

export const SMMM_SGS_LISTS: KanbanList[] = [
  {
    id: 'list-sgs-finansal-muhasebe',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Finansal Muhasebe (%25)',
    position: STEP * 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-muhasebe-denetimi',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Muhasebe Denetimi (%16)',
    position: STEP * 2,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-maliyet-muhasebesi',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Maliyet Muhasebesi (%13)',
    position: STEP * 3,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-vergi-hukuku',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Vergi Hukuku (%8)',
    position: STEP * 4,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-ticaret-borclar',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Ticaret & Borçlar Hukuku (%16)',
    position: STEP * 5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-muhasebe-standartlari',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Muhasebe Standartları (TMS/TFRS %7)',
    position: STEP * 6,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-mali-tablolar',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Mali Tablolar Analizi (%6)',
    position: STEP * 7,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-is-sosyal-guvenlik',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'İş ve Sosyal Güvenlik Hukuku',
    position: STEP * 8,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-ekonomi-maliye',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Ekonomi ve Maliye (%5)',
    position: STEP * 9,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-meslek-hukuku',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Meslek Hukuku (%3)',
    position: STEP * 10,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-turkce',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Türkçe (GK/GY)',
    position: STEP * 11,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-matematik',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Matematik (GK/GY)',
    position: STEP * 12,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-inkilap',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Atatürk İlkeleri & İnkılap Tarihi',
    position: STEP * 13,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'list-sgs-ingilizce',
    board_id: SMMM_SGS_BOARD_ID,
    title: 'Yabancı Dil (İngilizce)',
    position: STEP * 14,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const nowStr = new Date().toISOString();

export const SMMM_SGS_CARDS: KanbanCard[] = [
  // ==========================================================================
  // 1. FINANSAL MUHASEBE (%25)
  // ==========================================================================
  {
    id: 'sgs-c-fin-1',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Temel muhasebe kavramları, hesap kavramı ve Tek Düzen Hesap Planı işleyişi',
    description:
      'Muhasebenin 12 temel kavramı (Kişilik, Dönemsellik, İhtiyatlılık, Özün Önceliği vb.), aktif-pasif hesap kuralları ve TDHP hesap kodları yapısı.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w25', name: '%25 Ağırlık', color: '#ef4444' },
    ],
    checklist: [
      { id: 'chk-fin-1-1', card_id: 'sgs-c-fin-1', text: '12 Temel Muhasebe Kavramı tekrarı', is_done: true },
      { id: 'chk-fin-1-2', card_id: 'sgs-c-fin-1', text: 'Hesapların borç/alacak çalışma kuralları', is_done: true },
      { id: 'chk-fin-1-3', card_id: 'sgs-c-fin-1', text: 'TDHP sınıf ve grup kodlaması', is_done: true },
      { id: 'chk-fin-1-4', card_id: 'sgs-c-fin-1', text: 'Geçmiş SGS çıkmış soruları çözüldü', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-2',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Dönen varlıklar (Kasa, Banka, Alacaklar, Stoklar) ve duran varlıklar',
    description:
      '100 Kasa sayım fazlası/noksanı, 102 Bankalar, 120 Alıcılar, 121 Alacak Senetleri, 153 Ticari Mallar ve 25 Maddi Duran Varlıklar grubu.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w25', name: '%25 Ağırlık', color: '#ef4444' },
    ],
    checklist: [
      { id: 'chk-fin-2-1', card_id: 'sgs-c-fin-2', text: 'Kasa fazlası/noksanı ve 197/397 hesapları', is_done: false },
      { id: 'chk-fin-2-2', card_id: 'sgs-c-fin-2', text: 'Çek tahsilatı ve protestolu senetler', is_done: false },
      { id: 'chk-fin-2-3', card_id: 'sgs-c-fin-2', text: 'FIFO ve Ağırlıklı Ortalama Maliyet hesapları', is_done: false },
      { id: 'chk-fin-2-4', card_id: 'sgs-c-fin-2', text: 'Maddi duran varlık alış ve maliyet unsurları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-3',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Amortisman hesaplama yöntemleri ve değerleme işlemleri',
    description:
      'Normal (Doğrusal) Amortisman, Azalan Bakiyeler (Hızlandırılmış) Amortisman, Fevkalade Amortisman, Kıst Amortisman (binek otolar) ve VUK değerleme ölçüleri.',
    position: STEP * 3,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w25', name: '%25 Ağırlık', color: '#ef4444' },
    ],
    checklist: [
      { id: 'chk-fin-3-1', card_id: 'sgs-c-fin-3', text: 'Normal ve Azalan Bakiyeler formül uygulamaları', is_done: false },
      { id: 'chk-fin-3-2', card_id: 'sgs-c-fin-3', text: 'Binek otomobil kıst amortisman yevmiye kaydı', is_done: false },
      { id: 'chk-fin-3-3', card_id: 'sgs-c-fin-3', text: 'Duran varlık satış kârı ve 549 Yenileme Fonu', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-4',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Yevmiye kayıtları ve büyük defter (defterikebir) işleyişi',
    description:
      'Basit, bileşik ve karma yevmiye maddeleri; defterikebir T hesaplarına aktarım; açılış ve dönem içi muhasebe kayıtları.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-fin-4-1', card_id: 'sgs-c-fin-4', text: 'Yevmiye madde türleri ve kuralları', is_done: false },
      { id: 'chk-fin-4-2', card_id: 'sgs-c-fin-4', text: 'Büyük defter mizan ilişkisi', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-5',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Gelir ve gider hesapları, borçlar ve özkaynaklar',
    description:
      '6 Grubu Gelir Tablosu hesapları, 3 ve 4 Grubu Kısa/Uzun Vadeli Yabancı Kaynaklar, 5 Grubu Özkaynaklar (Ödenmiş Sermaye, Sermaye ve Kâr Yedekleri).',
    position: STEP * 5,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-fin-5-1', card_id: 'sgs-c-fin-5', text: 'Gelir ve gider hesaplarının devri ve kapatılması', is_done: false },
      { id: 'chk-fin-5-2', card_id: 'sgs-c-fin-5', text: 'Banka kredileri ve tahvil ihraç kayıtları', is_done: false },
      { id: 'chk-fin-5-3', card_id: 'sgs-c-fin-5', text: 'Sermaye taahhüdü ve temettü dağıtımı kayıtları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-6',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'KDV mahsuplaştırması, reeskont ve şüpheli alacak karşılıkları',
    description:
      '191 İndirilecek KDV, 391 Hesaplanan KDV, 190 Devreden KDV ve 360 Ödenecek Vergi mahsubu. İç ve dış iskonto ile reeskont hesaplaması.',
    position: STEP * 6,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-fin-6-1', card_id: 'sgs-c-fin-6', text: 'Ay sonu KDV mahsup kaydı örnekleri', is_done: false },
      { id: 'chk-fin-6-2', card_id: 'sgs-c-fin-6', text: 'İç iskonto formülü ile senet reeskontu', is_done: false },
      { id: 'chk-fin-6-3', card_id: 'sgs-c-fin-6', text: '128 Şüpheli Ticari Alacaklar ve 129 Karşılık kaydı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-fin-7',
    list_id: 'list-sgs-finansal-muhasebe',
    title: 'Dönem sonu işlemleri, envanter ve kapanış kayıtları',
    description:
      'Muhasebe dışı fiili envanter ve muhasebe içi envanter farkları, kesin mizan düzenleme, 690 Dönem Kârı/Zararı ve bilanço kapanış kaydı.',
    position: STEP * 7,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-fin-7-1', card_id: 'sgs-c-fin-7', text: 'Genel Geçici Mizan - Kesin Mizan aşamaları', is_done: false },
      { id: 'chk-fin-7-2', card_id: 'sgs-c-fin-7', text: '690 ve 691 hesaplarla vergi karşılığı ayırma', is_done: false },
      { id: 'chk-fin-7-3', card_id: 'sgs-c-fin-7', text: 'Aktif ve pasif hesapların ters kayıtla kapatılması', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 2. MUHASEBE DENETIMI (%16)
  // ==========================================================================
  {
    id: 'sgs-c-dnt-1',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Denetimin tanımı, amaçları, türleri ve denetim süreci/planlaması',
    description:
      'Mali tablo denetimi, uygunluk denetimi, faaliyet denetimi. Bağımsız denetçi, iç denetçi, kamu denetçisi. Müşteri kabulü, denetim stratejisi ve planı.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w16', name: '%16 Ağırlık', color: '#f97316' },
    ],
    checklist: [
      { id: 'chk-dnt-1-1', card_id: 'sgs-c-dnt-1', text: 'Denetim türleri ve denetçi sınıflandırması', is_done: true },
      { id: 'chk-dnt-1-2', card_id: 'sgs-c-dnt-1', text: 'Önemlilik düzeyi (Materiality) hesaplama', is_done: true },
      { id: 'chk-dnt-1-3', card_id: 'sgs-c-dnt-1', text: 'Denetim sözleşmesi zorunlu unsurları', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-2',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Bağımsız Denetim Standartları (BDS/TDS) ve mevzuatı',
    description:
      'Kamu Gözetimi Kurumu (KGK) tarafından yayımlanan Türkiye Denetim Standartları (TDS), BDS 200 genel ilkeler, BDS 700 raporlama esasları.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w16', name: '%16 Ağırlık', color: '#f97316' },
    ],
    checklist: [
      { id: 'chk-dnt-2-1', card_id: 'sgs-c-dnt-2', text: 'BDS 200 Bağımsız Denetçinin Genel Amaçları', is_done: false },
      { id: 'chk-dnt-2-2', card_id: 'sgs-c-dnt-2', text: 'BDS 500 Denetim Kanıtları', is_done: false },
      { id: 'chk-dnt-2-3', card_id: 'sgs-c-dnt-2', text: 'BDS 700 serisi denetçi raporları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-3',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'İç kontrol sistemleri ve COSO çerçevesi',
    description:
      'COSO iç kontrol piramidi: Kontrol Ortamı, Risk Değerlendirme, Kontrol Faaliyetleri, Bilgi ve İletişim, İzleme. Kontrol testleri ve maddi doğrulama testleri.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-dnt-3-1', card_id: 'sgs-c-dnt-3', text: 'COSO 5 bileşeni ve 17 temel ilkesi', is_done: false },
      { id: 'chk-dnt-3-2', card_id: 'sgs-c-dnt-3', text: 'Kontrol riski değerlemesi ve akış şemaları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-4',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Denetim riski, denetim kanıtları, denetim teknikleri ve örnekleme',
    description:
      'Denetim Riski Modeli: DR = Asıl Risk (IR) x Kontrol Riski (CR) x Bulgu Riski (DR). Fiziki inceleme, mutabakat mektupları, analitik prosedürler.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-dnt-4-1', card_id: 'sgs-c-dnt-4', text: 'Denetim riski formülü ve hesaplamaları', is_done: false },
      { id: 'chk-dnt-4-2', card_id: 'sgs-c-dnt-4', text: 'Pozitif ve negatif mutabakat mektupları', is_done: false },
      { id: 'chk-dnt-4-3', card_id: 'sgs-c-dnt-4', text: 'Parasal birim ve tabakalı örnekleme yöntemleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-5',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Denetim raporlama süreci ve görüş türleri',
    description:
      'Olumlu (Şartsız) Görüş, Sınırlı Olumlu (Şartlı) Görüş, Olumsuz Görüş ve Görüş Bildirmekten Kaçınma. Kilit Denetim Konuları (KAM) ve Dikkat Çekilen Hususlar paragrafı.',
    position: STEP * 5,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-dnt-5-1', card_id: 'sgs-c-dnt-5', text: '4 Görüş türünün ortaya çıkış şartları tablosu', is_done: false },
      { id: 'chk-dnt-5-2', card_id: 'sgs-c-dnt-5', text: 'Önemli ve Yaygın (Pervasive) kavramı analizi', is_done: false },
      { id: 'chk-dnt-5-3', card_id: 'sgs-c-dnt-5', text: 'KAM ve diğer hususlar paragraflarının yazımı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-6',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Hata ve hile tespiti',
    description:
      'Hata ve hile (yolsuzluk) farkı. Hile üçgeni: Baskı, Fırsat ve Haklı Gösterme (Rasyonelleştirme). Denetçinin hile riskine karşı prosedürleri.',
    position: STEP * 6,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-dnt-6-1', card_id: 'sgs-c-dnt-6', text: 'Hile üçgeni bileşenleri', is_done: false },
      { id: 'chk-dnt-6-2', card_id: 'sgs-c-dnt-6', text: 'Yönetimin kontrolleri ihlal etmesi riski', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-dnt-7',
    list_id: 'list-sgs-muhasebe-denetimi',
    title: 'Mesleki etik ilkeler, KGK yükümlülükleri ve Bağımsız Denetim Yönetmeliği',
    description:
      'Mesleki ahlak ve bağımsızlık: Dürüstlük, tarafsızlık, mesleki yeterlik, sır saklama, mesleğe uygun davranış. KGK denetçi sicili ve rotasyon kuralları.',
    position: STEP * 7,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-dnt-7-1', card_id: 'sgs-c-dnt-7', text: 'KGK bağımsız denetim yönetmeliği temel maddeleri', is_done: false },
      { id: 'chk-dnt-7-2', card_id: 'sgs-c-dnt-7', text: 'Denetçi rotasyonu kuralları (7 yıl kuralı)', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 3. MALIYET MUHASEBESI (%13)
  // ==========================================================================
  {
    id: 'sgs-c-mal-1',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Gider, maliyet, harcama kavramları ve maliyet unsurları',
    description:
      '710 Direkt İlk Madde ve Malzeme Giderleri (DİMMG), 720 Direkt İşçilik Giderleri (DİG), 730 Genel Üretim Giderleri (GÜG). 7/A ve 7/B seçeneği işleyişi.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w13', name: '%13 Ağırlık', color: '#f59e0b' },
    ],
    checklist: [
      { id: 'chk-mal-1-1', card_id: 'sgs-c-mal-1', text: 'Asal Maliyet ve Dönüşüm Maliyeti formülleri', is_done: true },
      { id: 'chk-mal-1-2', card_id: 'sgs-c-mal-1', text: '710, 720, 730 hesaplarının 151 hesaba yansıtılması', is_done: true },
      { id: 'chk-mal-1-3', card_id: 'sgs-c-mal-1', text: 'DİMMG formülü: Dönem başı + Alışlar - Dönem sonu', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-2',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Maliyet yerleri ve gider dağıtım yöntemleri (1. ve 2. Dağıtım)',
    description:
      'Birinci dağıtım: Giderlerin esas ve yardımcı gider yerlerine dağıtımı. İkinci dağıtım: Basit (Doğrudan), Kademeli (Basamaklı), Matematiksel ve Planlı dağıtım.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w13', name: '%13 Ağırlık', color: '#f59e0b' },
    ],
    checklist: [
      { id: 'chk-mal-2-1', card_id: 'sgs-c-mal-2', text: 'Basit dağıtım soru kalıpları', is_done: false },
      { id: 'chk-mal-2-2', card_id: 'sgs-c-mal-2', text: 'Kademeli dağıtımda sıralama kriteri', is_done: false },
      { id: 'chk-mal-2-3', card_id: 'sgs-c-mal-2', text: 'Matematiksel dağıtımda 2 bilinmeyenli denklem çözümü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-3',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Satışların Maliyeti Tablosu düzenleme',
    description:
      'Direkt ilk madde ve malzeme + Direkt işçilik + Genel üretim giderleri = Üretim Maliyeti. Yarı mamul ve mamul stok hareketleriyle SMM hesaplama.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-3-1', card_id: 'sgs-c-mal-3', text: 'Satılan Mamul Maliyeti şablonu çıkarma', is_done: false },
      { id: 'chk-mal-3-2', card_id: 'sgs-c-mal-3', text: 'Satılan Ticari Mal Maliyeti ve Hizmet Maliyeti', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-4',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Sipariş Maliyet Sistemi',
    description:
      'Müşteri talebine göre partiler halinde üretim. Sipariş maliyet kartları, tahmini GÜG yükleme oranları ve yıl sonu sapma hesapları.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-4-1', card_id: 'sgs-c-mal-4', text: 'GÜG yükleme oranı formülü (Tahmini GÜG / Tahmini Kapasite)', is_done: false },
      { id: 'chk-mal-4-2', card_id: 'sgs-c-mal-4', text: 'Fazla/Eksik yüklenen GÜG düzeltme kayıtları (732-733)', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-5',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Safha (Evre) Maliyet Sistemi ve eşdeğer birim hesaplamaları',
    description:
      'Seri ve kitle üretiminde safha maliyetleme. Eşdeğer Ürün Birimi (EÜB), Ağırlıklı Ortalama Maliyet Yöntemi ve FIFO Yöntemi ile birim maliyet bulma.',
    position: STEP * 5,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-5-1', card_id: 'sgs-c-mal-5', text: 'Ağırlıklı Ortalama Yöntemine göre EÜB ve birim maliyet', is_done: false },
      { id: 'chk-mal-5-2', card_id: 'sgs-c-mal-5', text: 'FIFO Yöntemine göre EÜB hesaplama adımları', is_done: false },
      { id: 'chk-mal-5-3', card_id: 'sgs-c-mal-5', text: 'Normal ve anormal fire muhasebesi', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-6',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Standart Maliyetleme ve varyans (sapma) analizi',
    description:
      'Önceden belirlenen standart maliyetler ile fiili maliyetlerin karşılaştırılması. Malzeme fiyat ve miktar sapması; İşçilik ücret ve süre sapması.',
    position: STEP * 6,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-6-1', card_id: 'sgs-c-mal-6', text: 'Malzeme fiyat sapması: Fiş x (Ff - Fs)', is_done: false },
      { id: 'chk-mal-6-2', card_id: 'sgs-c-mal-6', text: 'Malzeme miktar sapması: Fs x (Mifiili - Mistandart)', is_done: false },
      { id: 'chk-mal-6-3', card_id: 'sgs-c-mal-6', text: 'İşçilik ücret ve verim sapması formülleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-7',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Faaliyet Tabanlı Maliyetleme (ABC)',
    description:
      'Faaliyet havuzları ve maliyet etkenleri (Cost Drivers). Geleneksel hacim tabanlı dağıtıma kıyasla ürün kârlılıklarını doğru ölçme.',
    position: STEP * 7,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-7-1', card_id: 'sgs-c-mal-7', text: 'ABC temel kavramları ve maliyet sürücüleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-8',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Maliyet-Hacim-Kâr analizi, başabaş noktası, değişken ve sabit maliyetler',
    description:
      'Başabaş Noktası (Miktar = Sabit Maliyet / Katkı Payı; Tutar = Sabit Maliyet / Katkı Oranı). Hedef kâr hesaplamaları, Güvenlik Marjı ve İşletme Kaldıracı Derecesi (İKD).',
    position: STEP * 8,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-8-1', card_id: 'sgs-c-mal-8', text: 'Başabaş noktası miktar ve tutar soru tipleri', is_done: false },
      { id: 'chk-mal-8-2', card_id: 'sgs-c-mal-8', text: 'Vergi sonrası hedef kâr üretim miktarı', is_done: false },
      { id: 'chk-mal-8-3', card_id: 'sgs-c-mal-8', text: 'Güvenlik payı oranı ve İşletme kaldıracı formülü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mal-9',
    list_id: 'list-sgs-maliyet-muhasebesi',
    title: 'Birleşik mamul ve yan mamul maliyetlerinin dağıtımı',
    description:
      'Ayrılma noktası, fiziksel ölçüler yöntemi, satış değeri yöntemi ve net gerçekleşebilir değer yöntemi ile birleşik maliyet dağıtımı.',
    position: STEP * 9,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mal-9-1', card_id: 'sgs-c-mal-9', text: 'Fiziksel ölçüler ve piyasa değeri dağıtım hesapları', is_done: false },
      { id: 'chk-mal-9-2', card_id: 'sgs-c-mal-9', text: 'Yan mamul gelirinin ana mamul maliyetinden düşülmesi', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 4. VERGI HUKUKU (%8)
  // ==========================================================================
  {
    id: 'sgs-c-vrg-1',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Vergi Usul Hukuku (VUK): Vergi ödevi, mükellefiyet, tarh, tahakkuk, tahsil süreçleri',
    description:
      'Vergilendirme aşamaları: Vergiyi doğuran olay, Tarh (Beyana dayanan, ikmalen, re\'sen, idarece), Tebliğ, Tahakkuk ve Tahsil. Vergi ehliyeti ve kanuni temsilcinin ödevi.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w8', name: '%8 Ağırlık', color: '#10b981' },
    ],
    checklist: [
      { id: 'chk-vrg-1-1', card_id: 'sgs-c-vrg-1', text: '4 Tarhiyat çeşidi arasındaki farklar', is_done: false },
      { id: 'chk-vrg-1-2', card_id: 'sgs-c-vrg-1', text: 'Tebliğ usulleri (Posta, Memur, İlanen, Elektronik)', is_done: false },
      { id: 'chk-vrg-1-3', card_id: 'sgs-c-vrg-1', text: 'Süreler ve mücbir sebep halleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-vrg-2',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Vergi cezaları, uzlaşma, zamanaşımı ve yargı yolları',
    description:
      'Vergi ziyaı cezası (1 kat / 3 kat kaçakçılıkta), genel ve özel usulsüzlük. Tarhiyat öncesi/sonrası uzlaşma. Tahakkuk ve tahsil zamanaşımı (5 yıl). Vergi Mahkemesi dava açma süresi (30 gün).',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w8', name: '%8 Ağırlık', color: '#10b981' },
    ],
    checklist: [
      { id: 'chk-vrg-2-1', card_id: 'sgs-c-vrg-2', text: 'Vergi ziyaı ve kaçakçılık suçu hapis cezaları', is_done: false },
      { id: 'chk-vrg-2-2', card_id: 'sgs-c-vrg-2', text: 'Tarhiyat öncesi ve sonrası uzlaşma farkları', is_done: false },
      { id: 'chk-vrg-2-3', card_id: 'sgs-c-vrg-2', text: 'Tarh zamanaşımı başlangıcı ve süre durdurma sebepleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-vrg-3',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Gelir Vergisi (GV): Kazanç unsurları',
    description:
      'Gelirin 7 unsuru: Ticari Kazanç, Zirai Kazanç, Ücretler, Serbest Meslek Kazancı, Gayrimenkul Sermaye İradı (GMSİ), Menkul Sermaye İradı (MSİ), Diğer Kazanç ve İratlar. Yıllık beyanname verme şartları.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-vrg-3-1', card_id: 'sgs-c-vrg-3', text: 'Ticari kazançta indirilecek ve indirilemeyecek giderler', is_done: false },
      { id: 'chk-vrg-3-2', card_id: 'sgs-c-vrg-3', text: 'GMSİ gerçek gider vs. götürü gider yöntemi (%15)', is_done: false },
      { id: 'chk-vrg-3-3', card_id: 'sgs-c-vrg-3', text: 'Serbest meslek kazancında tahsil esası', is_done: false },
      { id: 'chk-vrg-3-4', card_id: 'sgs-c-vrg-3', text: 'Değer artış kazançları istisnası ve beyanı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-vrg-4',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Kurumlar Vergisi (KV)',
    description:
      'KV mükellefleri: Sermaye şirketleri, Kooperatifler, İktisadi Kamu Kuruluşları, Dernek ve Vakıf İktisadi İşletmeleri, İş Ortaklıkları. Tam ve dar mükellefiyet. İndirilecek giderler ve KKEG. İstisnalar (İştirak kazançları, emisyon primi vb.).',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-vrg-4-1', card_id: 'sgs-c-vrg-4', text: 'KV mükellefleri tanımı ve sorumlulukları', is_done: false },
      { id: 'chk-vrg-4-2', card_id: 'sgs-c-vrg-4', text: 'Kanunen Kabul Edilmeyen Giderler (KKEG) listesi', is_done: false },
      { id: 'chk-vrg-4-3', card_id: 'sgs-c-vrg-4', text: 'Zarar mahsubu şartları (5 yıl geriye/ileriye kuralı)', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-vrg-5',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Katma Değer Vergisi (KDV)',
    description:
      'KDV\'de vergiyi doğuran olay, tam istisna ve kısmi istisna ayrımı, tevkifat uygulaması (Kısmi tevkifat türleri 2/10, 5/10 vb.), indirim mekanizması ve iade.',
    position: STEP * 5,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-vrg-5-1', card_id: 'sgs-c-vrg-5', text: 'Tam istisna ve kısmi istisna farkı', is_done: false },
      { id: 'chk-vrg-5-2', card_id: 'sgs-c-vrg-5', text: 'KDV tevkifatı hesaplama ve 2 No\'lu beyanname', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-vrg-6',
    list_id: 'list-sgs-vergi-hukuku',
    title: 'Diğer vergiler (ÖTV, Harçlar, Damga Vergisi, Emlak Vergisi vb.)',
    description:
      'ÖTV listeleri (I, II, III, IV), Damga Vergisi kağıt mahiyeti ve azami ceza sınırı, Emlak Vergisi beyanı ve Harçlar Kanunu temel prensipleri.',
    position: STEP * 6,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-vrg-6-1', card_id: 'sgs-c-vrg-6', text: 'ÖTV tek aşamalı vergi mantığı', is_done: false },
      { id: 'chk-vrg-6-2', card_id: 'sgs-c-vrg-6', text: 'Damga vergisinde nispi ve maktu oranlar', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 5. TICARET VE BORCLAR HUKUKU (%16)
  // ==========================================================================
  {
    id: 'sgs-c-tic-1',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Ticari İşletme Hukuku: Tacir, ticari işletme, ticaret sicili (MERSİS), ticari defterler',
    description:
      'Gerçek kişi ve tüzel kişi tacir, tacir olmanın hükümleri (iflasa tabi olma, basiretli iş adamı gibi davranma), MERSİS tescil ve ilan, fiziki ve elektronik ticari defterler ve saklama süresi (TTK 10 yıl / VUK 5 yıl).',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w16', name: '%16 Ağırlık', color: '#f97316' },
    ],
    checklist: [
      { id: 'chk-tic-1-1', card_id: 'sgs-c-tic-1', text: 'Tacir sıfatının kazanılması ve kaybedilmesi', is_done: true },
      { id: 'chk-tic-1-2', card_id: 'sgs-c-tic-1', text: 'Ticari defterlerin onay (tasdik) zamanları', is_done: true },
      { id: 'chk-tic-1-3', card_id: 'sgs-c-tic-1', text: 'Zayi belgesi alma şartları (15 gün)', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-2',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Şirketler Hukuku: Şirket türleri, kuruluş şartları, yönetim ve genel kurul organları, pay devirleri',
    description:
      'Adi Ortaklık (TBK), Kollektif, Komandit. Anonim Şirket (asgari 50.000 TL / kayıtlı 100.000 TL, Yönetim Kurulu, Genel Kurul) ve Limited Şirket (asgari 10.000 TL / yeni yasa 50.000 TL, Müdürler Kurulu, pay devrinde noter ve genel kurul onayı).',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w16', name: '%16 Ağırlık', color: '#f97316' },
    ],
    checklist: [
      { id: 'chk-tic-2-1', card_id: 'sgs-c-tic-2', text: 'A.Ş. ve Ltd. Şti. sermaye ve ortak sayısı karşılaştırması', is_done: false },
      { id: 'chk-tic-2-2', card_id: 'sgs-c-tic-2', text: 'A.Ş. Genel Kurul toplantı ve karar nisapları', is_done: false },
      { id: 'chk-tic-2-3', card_id: 'sgs-c-tic-2', text: 'Yönetim kurulu üyelerinin hukuki ve cezai sorumluluğu', is_done: false },
      { id: 'chk-tic-2-4', card_id: 'sgs-c-tic-2', text: 'Şirketlerde birleşme, bölünme ve tür değiştirme', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-3',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Kıymetli Evrak Hukuku: Çek, bono ve poliçenin zorunlu unsurları ve hükümleri',
    description:
      'Kıymetli evrak türleri (Nama, Emre, Hamiline yazılı). Bono (Senet), Çek ve Poliçenin mutlak ve alternatif zorunlu unsurları. Ciro türleri (Temlik, Tahsil, Rehin cirosu), aval ve ibraz süreleri.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-3-1', card_id: 'sgs-c-tic-3', text: 'Bono zorunlu unsurları (Kayıtsız şartsız ödeme vaadi vb.)', is_done: false },
      { id: 'chk-tic-3-2', card_id: 'sgs-c-tic-3', text: 'Çek ibraz süreleri (Aynı yer 10 gün, başka yer 1 ay, kıta 3 ay)', is_done: false },
      { id: 'chk-tic-3-3', card_id: 'sgs-c-tic-3', text: 'Beyaz ciro ve tam ciro ayrımı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-4',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Borçlar Hukuku Genel Hükümler: Borç ilişkisinin kaynakları',
    description:
      'Hukuki İşlem (Sözleşme), Haksız Fiil (Kusur, Hukuka aykırılık, Zarar, İlliyet bağı) ve Sebepsiz Zenginleşme. Borcun doğum şartları.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-4-1', card_id: 'sgs-c-tic-4', text: 'Sözleşmeden doğan borçlar', is_done: false },
      { id: 'chk-tic-4-2', card_id: 'sgs-c-tic-4', text: 'Haksız fiil sorumluluğu ve kusursuz sorumluluk halleri', is_done: false },
      { id: 'chk-tic-4-3', card_id: 'sgs-c-tic-4', text: 'Sebepsiz zenginleşme davası zamanaşımı (2 yıl / 10 yıl)', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-5',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Sözleşmenin kurulması, şekil şartları, genel işlem şartları, temsil, ahde vefa',
    description:
      'Öneri (İcap) ve Kabul. Şekil serbestisi ve geçerlilik şekilleri (Yazılı, Resmi yazılı). İrade bozuklukları: Yanılma (Hata), Aldatma (Hile), Korkutma (İkrah), Gabin (Aşırı yararlanma). Ahde vefa ve sözleşmenin uyarlanması.',
    position: STEP * 5,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-5-1', card_id: 'sgs-c-tic-5', text: 'İrade fesadı halleri ve 1 yıllık iptal hakkı', is_done: false },
      { id: 'chk-tic-5-2', card_id: 'sgs-c-tic-5', text: 'Genel işlem koşulları denetimi (Yazılmamış sayılma)', is_done: false },
      { id: 'chk-tic-5-3', card_id: 'sgs-c-tic-5', text: 'Doğrudan ve dolaylı temsil, yetkisiz temsil sonuçları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-6',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Edim, ifa, ifa imkansızlığı, borçlu temerrüdü, tazminat ve zamanaşımı',
    description:
      'İfa yeri ve zamanı. Borçlu temerrüdünün şartları (Muacceliyet + İhtar). Aynen ifa, müspet zarar, menfi zarar. Kusursuz imkansızlık (TBK 136). Genel zamanaşımı (10 yıl) ve 5 yıllık zamanaşımı istisnaları.',
    position: STEP * 6,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-6-1', card_id: 'sgs-c-tic-6', text: 'Borçlu temerrüdü sonuçları ve seçimlik haklar', is_done: false },
      { id: 'chk-tic-6-2', card_id: 'sgs-c-tic-6', text: 'Kusurlu ve kusursuz ifa imkansızlığı farkı', is_done: false },
      { id: 'chk-tic-6-3', card_id: 'sgs-c-tic-6', text: 'TBK 146 ve 147 zamanaşımı süreleri tablosu', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-7',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Borcun sona erme halleri (İbra, yenileme, takas)',
    description:
      'İbra (Alacaklının hakkından vazgeçmesi), Yenileme (Tecdit), Birleşme (Alacaklı ve borçlu sıfatının aynı kişide toplanması), Takas (Karşılıklı muaccel ve aynı cins borçlar).',
    position: STEP * 7,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-7-1', card_id: 'sgs-c-tic-7', text: 'Takasın şartları ve tek taraflı irade beyanı', is_done: false },
      { id: 'chk-tic-7-2', card_id: 'sgs-c-tic-7', text: 'İbra sözleşmesi geçerlilik şartları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tic-8',
    list_id: 'list-sgs-ticaret-borclar',
    title: 'Özel Sözleşme Türleri (Satış, kira, vekalet, eser, hizmet)',
    description:
      'Satış sözleşmesinde yarar ve hasarın geçişi, ayıba karşı tekeffül. Kira sözleşmesinde fesih ve tahliye sebepleri. Eser sözleşmesinde sonuç taahhüdü vs. Vekalet sözleşmesinde özen borcu.',
    position: STEP * 8,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-tic-8-1', card_id: 'sgs-c-tic-8', text: 'Ayıplı malda alıcının 4 seçimlik hakkı', is_done: false },
      { id: 'chk-tic-8-2', card_id: 'sgs-c-tic-8', text: 'Kira tespit ve tahliye davası süreleri', is_done: false },
      { id: 'chk-tic-8-3', card_id: 'sgs-c-tic-8', text: 'Vekalet ve eser sözleşmesi ayrım soruları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 6. MUHASEBE STANDARTLARI (TMS/TFRS - %7)
  // ==========================================================================
  {
    id: 'sgs-c-std-1',
    list_id: 'list-sgs-muhasebe-standartlari',
    title: 'TMS/TFRS kavramsal çerçevesi, değerleme ve raporlama esasları',
    description:
      'Finansal bilginin niteliksel özellikleri (İhtiyaca uygunluk, Gerçeğe uygun sunum; Doğrulanabilirlik, Zamanındalık, Karşılaştırılabilirlik, Anlaşılırlık). Tarihi maliyet ve Cari değer esasları.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w7', name: '%7 Ağırlık', color: '#06b6d4' },
    ],
    checklist: [
      { id: 'chk-std-1-1', card_id: 'sgs-c-std-1', text: 'Temel ve destekleyici niteliksel özellikler', is_done: false },
      { id: 'chk-std-1-2', card_id: 'sgs-c-std-1', text: 'Kavramsal Çerçeve varlık ve yükümlülük tanımı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-std-2',
    list_id: 'list-sgs-muhasebe-standartlari',
    title: 'Önemli Standartlar: TMS 2, TMS 16, TMS 36, TFRS 15, TFRS 16, TMS 29',
    description:
      'TMS 2 Stoklar (Maliyet veya Net Gerçekleşebilir Değerin düşük olanı), TMS 16 Maddi Duran Varlıklar, TMS 36 Değer Düşüklüğü, TFRS 15 Hasılat (5 Aşamalı Model), TFRS 16 Kiralamalar (Kullanım Hakkı Varlığı), TMS 29 Yüksek Enflasyon Muhasebesi.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w7', name: '%7 Ağırlık', color: '#06b6d4' },
    ],
    checklist: [
      { id: 'chk-std-2-1', card_id: 'sgs-c-std-2', text: 'TMS 2 Net Gerçekleşebilir Değer hesaplama', is_done: false },
      { id: 'chk-std-2-2', card_id: 'sgs-c-std-2', text: 'TMS 16 Yeniden Değerleme ve Amortisman', is_done: false },
      { id: 'chk-std-2-3', card_id: 'sgs-c-std-2', text: 'TFRS 15 Hasılat 5 adımlı modeli', is_done: false },
      { id: 'chk-std-2-4', card_id: 'sgs-c-std-2', text: 'TFRS 16 Kiracı muhasebeleştirme kuralları', is_done: false },
      { id: 'chk-std-2-5', card_id: 'sgs-c-std-2', text: 'TMS 29 Parasal ve Parasal Olmayan Kalemler', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 7. MALI TABLOLAR ANALIZI (%6)
  // ==========================================================================
  {
    id: 'sgs-c-mta-1',
    list_id: 'list-sgs-mali-tablolar',
    title: 'Temel finansal tablolar: Bilanço (Finansal Durum Tablosu), Gelir Tablosu',
    description:
      'Bilanço temel denkliği: Aktif = Yabancı Kaynaklar + Özkaynaklar. Gelir tablosu aşamaları: Brüt Satış Kârı, Faaliyet Kârı, Olağan Kâr, Net Kâr.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w6', name: '%6 Ağırlık', color: '#3b82f6' },
    ],
    checklist: [
      { id: 'chk-mta-1-1', card_id: 'sgs-c-mta-1', text: 'Bilanço yapısı ve dönen/duran varlık ilkeleri', is_done: false },
      { id: 'chk-mta-1-2', card_id: 'sgs-c-mta-1', text: 'Gelir tablosunda kademeli kâr hesaplamaları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mta-2',
    list_id: 'list-sgs-mali-tablolar',
    title: 'Ek tablolar: Satışların Maliyeti, Nakit Akım, Fon Akım, Özkaynak Değişim Tabloları',
    description:
      'Nakit Akım Tablosu (İşletme, Yatırım ve Finansman faaliyetlerinden nakit akışları), Fon Akım Tablosu fon kaynakları ve kullanımları.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w6', name: '%6 Ağırlık', color: '#3b82f6' },
    ],
    checklist: [
      { id: 'chk-mta-2-1', card_id: 'sgs-c-mta-2', text: 'Nakit akım tablosu 3 ana faaliyet alanı', is_done: false },
      { id: 'chk-mta-2-2', card_id: 'sgs-c-mta-2', text: 'Özkaynak değişim tablosu kalemleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mta-3',
    list_id: 'list-sgs-mali-tablolar',
    title: 'Analiz Teknikleri: Karşılaştırmalı Tablolar, Yüzde Yöntemi, Trend Analizi',
    description:
      'Yatay Analiz (Fark / Baz Yıl x 100), Dikey Analiz (Kalem / Grup Toplamı veya Aktif Toplamı x 100), Trend Analizi (Cari Yıl / Baz Yıl x 100).',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mta-3-1', card_id: 'sgs-c-mta-3', text: 'Yatay analizde negatif ve tanımsız durumlar', is_done: false },
      { id: 'chk-mta-3-2', card_id: 'sgs-c-mta-3', text: 'Dikey analizde 100 kabul edilen kalemler', is_done: false },
      { id: 'chk-mta-3-3', card_id: 'sgs-c-mta-3', text: 'Eğilim yüzdeleri yorumlama kuralları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mta-4',
    list_id: 'list-sgs-mali-tablolar',
    title: 'Oran Analizi (Rasyolar): Likidite, mali yapı, kârlılık ve faaliyet (verimlilik) oranları',
    description:
      'Cari Oran (Dönen Varlık / KV YK), Asit-Test Oranı ((Dönen Varlık - Stok) / KV YK), Nakit Oranı. Kaldıraç Oranı (Toplam Borç / Aktif). Alacak ve Stok Devir Hızları. ROE, ROA ve DuPont analizi.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-mta-4-1', card_id: 'sgs-c-mta-4', text: 'Likidite oranları formülleri ve ideal değerleri (2, 1, 0.2)', is_done: false },
      { id: 'chk-mta-4-2', card_id: 'sgs-c-mta-4', text: 'Devir hızı ve gün cinsinden tahsilat süreleri', is_done: false },
      { id: 'chk-mta-4-3', card_id: 'sgs-c-mta-4', text: 'Finansman ve borçlanma oranları formülleri', is_done: false },
      { id: 'chk-mta-4-4', card_id: 'sgs-c-mta-4', text: 'DuPont kârlılık formülü açılımı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 8. IS VE SOSYAL GUVENLIK HUKUKU
  // ==========================================================================
  {
    id: 'sgs-c-is-1',
    list_id: 'list-sgs-is-sosyal-guvenlik',
    title: 'İş Hukuku: İş sözleşmesi türleri, işçi-işveren hak ve yükümlülükleri, çalışma süreleri, izinler',
    description:
      '4857 Sayılı İş Kanunu: Belirli/Belirsiz süreli iş sözleşmesi, Tam/Kısmi süreli çalışma. Haftalık 45 saat çalışma, denkleştirme süresi (2 ay). Fazla çalışma (%50 zamlı), yıllık ücretli izin süreleri (14, 20, 26 gün).',
    position: STEP * 1,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-is-1-1', card_id: 'sgs-c-is-1', text: 'İş sözleşmesi türleri ve deneme süresi (en çok 2 ay)', is_done: false },
      { id: 'chk-is-1-2', card_id: 'sgs-c-is-1', text: 'Fazla mesai ücreti ve serbest zaman hesabı', is_done: false },
      { id: 'chk-is-1-3', card_id: 'sgs-c-is-1', text: 'Kıdeme göre yıllık izin hak ediş günleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-is-2',
    list_id: 'list-sgs-is-sosyal-guvenlik',
    title: 'Sözleşmenin feshi, ihbar ve kıdem tazminatı hesaplamaları',
    description:
      'İş güvencesi (30 işçi + 6 ay kıdem) ve 1 ay içinde arabulucuya başvuru. İhbar önelleri (2, 4, 6, 8 hafta). Haklı nedenle fesih (Madde 24 ve 25). Kıdem tazminatı şartları ve tavan tutar.',
    position: STEP * 2,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-is-2-1', card_id: 'sgs-c-is-2', text: 'İhbar tazminatı hesaplama formülleri', is_done: false },
      { id: 'chk-is-2-2', card_id: 'sgs-c-is-2', text: 'Kıdem tazminatı giydirilmiş brüt ücret unsurları', is_done: false },
      { id: 'chk-is-2-3', card_id: 'sgs-c-is-2', text: 'İşe iade davası aşamaları ve boşta geçen süre tazminatı', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-is-3',
    list_id: 'list-sgs-is-sosyal-guvenlik',
    title: 'Sosyal Güvenlik Hukuku: SGK sigortalılık türleri, prim ödevleri, iş kazası, işsizlik ödeneği',
    description:
      '5510 Sayılı Kanun: 4/a (Hizmet akdi), 4/b (Bağımsız çalışanlar - Bağ-Kur), 4/c (Kamu görevlileri). İşe giriş bildirgesi (en geç işe başlamadan 1 gün önce). İş kazası bildirimi (3 iş günü). İşsizlik sigortası şartları.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-is-3-1', card_id: 'sgs-c-is-3', text: 'Sigortalılık başlangıcı ve bildirge verme süreleri', is_done: false },
      { id: 'chk-is-3-2', card_id: 'sgs-c-is-3', text: 'Prime esas kazanç (SPEK) taban ve tavanı', is_done: false },
      { id: 'chk-is-3-3', card_id: 'sgs-c-is-3', text: 'İş kazası ve meslek hastalığı yardımları', is_done: false },
      { id: 'chk-is-3-4', card_id: 'sgs-c-is-3', text: 'İşsizlik ödeneği süreleri (600, 900, 1080 gün)', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 9. EKONOMI VE MALIYE (%5)
  // ==========================================================================
  {
    id: 'sgs-c-eko-1',
    list_id: 'list-sgs-ekonomi-maliye',
    title: 'Mikro Ekonomi: Arz-talep, esneklik, tüketici teorisi, piyasa türleri',
    description:
      'Talep Kanunu, Fiyat Esnekliği (Talebin fiyat esnekliği formülü), Gelir ve Çapraz Esneklik. Tüketici Dengesi (Farksızlık Eğrisi & Bütçe Doğrusu). Tam Rekabet, Monopol, Oligopol ve Monopolcü Rekabet.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w5', name: '%5 Ağırlık', color: '#8b5cf6' },
    ],
    checklist: [
      { id: 'chk-eko-1-1', card_id: 'sgs-c-eko-1', text: 'Nokta ve yay esnekliği formül soru çözümü', is_done: false },
      { id: 'chk-eko-1-2', card_id: 'sgs-c-eko-1', text: 'Tüketici dengesi MRS = Px/Py kuralı', is_done: false },
      { id: 'chk-eko-1-3', card_id: 'sgs-c-eko-1', text: 'Piyasa yapıları özellikleri karşılaştırma tablosu', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-eko-2',
    list_id: 'list-sgs-ekonomi-maliye',
    title: 'Makro Ekonomi: Milli gelir, enflasyon, işsizlik, para politikası ve para arzı',
    description:
      'GSYH hesaplama yöntemleri (Üretim, Gelir, Harcama yaklaşımı). Çarpan (Mültiplikatör) mekanizması. Enflasyon türleri ve Philips Eğrisi. TCMB para politikası araçları (Açık Piyasa İşlemleri - APİ, Reeskont, Zorunlu Karşılıklar). Para tanımları (M1, M2).',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w5', name: '%5 Ağırlık', color: '#8b5cf6' },
    ],
    checklist: [
      { id: 'chk-eko-2-1', card_id: 'sgs-c-eko-2', text: 'GSYH ve Safi Milli Hasıla formülleri', is_done: false },
      { id: 'chk-eko-2-2', card_id: 'sgs-c-eko-2', text: 'Harcama çarpanı formülü: 1 / (1 - c)', is_done: false },
      { id: 'chk-eko-2-3', card_id: 'sgs-c-eko-2', text: 'TCMB para politikası araçları etkileri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-eko-3',
    list_id: 'list-sgs-ekonomi-maliye',
    title: 'Maliye: Kamu maliyesi, kamu gelirleri ve giderleri, devlet bütçesi, maliye politikası araçları',
    description:
      'Kamu harcamaları sınıflandırılması, Vergiye ilişkin temel ilkeler, 5018 Sayılı Kamu Mali Yönetimi ve Kontrol Kanunu bütçe ilkeleri (Genellik, Birlik, Açıklık, Samimilik), Bütçe açığı ve kamu borçlanması.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-eko-3-1', card_id: 'sgs-c-eko-3', text: 'Kamu harcamalarının ekonomik sınıflandırması', is_done: false },
      { id: 'chk-eko-3-2', card_id: 'sgs-c-eko-3', text: '5018 sayılı kanuna göre bütçe hazırlık takvimi', is_done: false },
      { id: 'chk-eko-3-3', card_id: 'sgs-c-eko-3', text: 'Genişletici ve daraltıcı maliye politikaları', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 10. MESLEK HUKUKU (%3)
  // ==========================================================================
  {
    id: 'sgs-c-msk-1',
    list_id: 'list-sgs-meslek-hukuku',
    title: '3568 Sayılı Kanun ve yasal dayanaklar',
    description:
      '3568 Sayılı Serbest Muhasebeci Mali Müşavirlik ve Yeminli Mali Müşavirlik Kanunu genel amaçları, yasal dayanakları ve mesleğin konusu.',
    position: STEP * 1,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w3', name: '%3 Ağırlık', color: '#ec4899' },
    ],
    checklist: [
      { id: 'chk-msk-1-1', card_id: 'sgs-c-msk-1', text: 'SMMM mesleğinin konusu ve yetkileri', is_done: true },
      { id: 'chk-msk-1-2', card_id: 'sgs-c-msk-1', text: 'YMM mesleğinin konusu ve tasdik yetkisi', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-msk-2',
    list_id: 'list-sgs-meslek-hukuku',
    title: 'Meslek unvanları (SMMM, YMM), ruhsat alma ve staj süreçleri',
    description:
      'SMMM staj süresi (3 yıl), staj değerlendirme notları, stajdan sayılan süreler. Ruhsat alma şartları, meslek kütüğüne kayıt, çalışanlar ve çalışmayanlar listesi.',
    position: STEP * 2,
    labels: [
      { id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' },
      { id: 'lbl-sgs-w3', name: '%3 Ağırlık', color: '#ec4899' },
    ],
    checklist: [
      { id: 'chk-msk-2-1', card_id: 'sgs-c-msk-2', text: 'SMMM genel ve özel şartları', is_done: false },
      { id: 'chk-msk-2-2', card_id: 'sgs-c-msk-2', text: 'Staj yönetmeliği ve TESMER işleyişi', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-msk-3',
    list_id: 'list-sgs-meslek-hukuku',
    title: 'Meslek mensuplarının hakları, yetkileri, yükümlülükleri, haksız rekabet ve mesleki yasaklar',
    description:
      'Mesleki yasaklar (Ticari faaliyette bulunma yasağı, reklam yasağı, büro açma standartları). Müşteri bildirimi, sözleşme zorunluluğu, asgari ücret tarifesi ve sır saklama.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-msk-3-1', card_id: 'sgs-c-msk-3', text: 'Reklam yasağı ve haksız rekabet yönetmeliği', is_done: false },
      { id: 'chk-msk-3-2', card_id: 'sgs-c-msk-3', text: 'Meslekle bağdaşan ve bağdaşmayan işler', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-msk-4',
    list_id: 'list-sgs-meslek-hukuku',
    title: 'Oda ve TÜRMOB teşkilat yapısı, görevleri ve disiplin cezaları',
    description:
      'Oda organları: Genel Kurul, Yönetim Kurulu, Denetleme Kurulu, Disiplin Kurulu. TÜRMOB organları. 5 Disiplin cezası: Uyarma, Kınama, Geçici olarak mesleki faaliyetten alıkoyma (6 aydan 1 yıla kadar), Yeminli sıfatını kaldırma, Meslekten çıkarma.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-alan', name: 'Alan Bilgisi', color: '#0d9488' }],
    checklist: [
      { id: 'chk-msk-4-1', card_id: 'sgs-c-msk-4', text: '5 Disiplin cezasının gerekçeleri ve süreleri tablosu', is_done: false },
      { id: 'chk-msk-4-2', card_id: 'sgs-c-msk-4', text: 'Oda ve TÜRMOB yönetim/disiplin kurulu üye sayıları', is_done: false },
      { id: 'chk-msk-4-3', card_id: 'sgs-c-msk-4', text: 'Disiplin cezalarına itiraz ve yargı yolu', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 11. TURKCE (GK/GY)
  // ==========================================================================
  {
    id: 'sgs-c-tur-1',
    list_id: 'list-sgs-turkce',
    title: 'Sözcükte ve cümlede anlam',
    description:
      'Gerçek, mecaz, yan ve terim anlam. Somutlaştırma, soyutlaştırma. Cümlede kesin yargı, amaç-sonuç, neden-sonuç, koşul, örtülü anlam.',
    position: STEP * 1,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-tur-1-1', card_id: 'sgs-c-tur-1', text: 'Söz öbeğinde anlam ve deyim/atasözü soruları', is_done: false },
      { id: 'chk-tur-1-2', card_id: 'sgs-c-tur-1', text: 'Cümleden kesin çıkarılabilecek yargı soru tipleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tur-2',
    list_id: 'list-sgs-turkce',
    title: 'Paragrafta ana fikir, yardımcı fikirler ve anlatım teknikleri',
    description:
      'Paragrafın konusu, ana düşüncesi, yardımcı düşünceler, paragraf tamamlama, akışı bozan cümle. Açıklayıcı, tartışmacı, betimleyici, öyküleyici anlatım.',
    position: STEP * 2,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-tur-2-1', card_id: 'sgs-c-tur-2', text: 'Hızlı okuma ve anahtar kelime teknikleri', is_done: false },
      { id: 'chk-tur-2-2', card_id: 'sgs-c-tur-2', text: 'Paragraf bölme ve sıralama soruları çözüldü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-tur-3',
    list_id: 'list-sgs-turkce',
    title: 'Dil bilgisi ve yazım kuralları',
    description:
      'Ses bilgisi (Ünlü düşmesi, ünsüz benzeşmesi, yumuşama). Sözcük türleri (İsim, sıfat, zamir, zarf, edat, bağlaç, fiil). TDK güncel yazım kuralları ve noktalama işaretleri.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-tur-3-1', card_id: 'sgs-c-tur-3', text: 'Büyük harflerin yazımı ve birleşik sözcükler', is_done: false },
      { id: 'chk-tur-3-2', card_id: 'sgs-c-tur-3', text: 'Noktalı virgül ve virgül ayrımı soru çözümü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 12. MATEMATIK (GK/GY)
  // ==========================================================================
  {
    id: 'sgs-c-mat-1',
    list_id: 'list-sgs-matematik',
    title: 'Sayı kümeleri, üslü ve köklü ifadeler',
    description:
      'Doğal sayılar, tam sayılar, rasyonel sayılar, basamak analizi, bölme-bölünebilme kuralları, EBOB-EKOK, üslü sayılar işlem kuralları ve köklü ifadeler.',
    position: STEP * 1,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-mat-1-1', card_id: 'sgs-c-mat-1', text: 'Bölünebilme ve basamak analizi pratikleri', is_done: false },
      { id: 'chk-mat-1-2', card_id: 'sgs-c-mat-1', text: 'Üslü ve köklü sayılarda denklem çözümleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mat-2',
    list_id: 'list-sgs-matematik',
    title: 'Denklemler ve eşitsizlikler',
    description:
      'Birinci dereceden bir ve iki bilinmeyenli denklemler, basit eşitsizlik özellikleri, mutlak değerli denklemler ve eşitsizlikler.',
    position: STEP * 2,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-mat-2-1', card_id: 'sgs-c-mat-2', text: 'Taraf tarafa toplama ve yok etme yöntemi', is_done: false },
      { id: 'chk-mat-2-2', card_id: 'sgs-c-mat-2', text: 'Mutlak değer özellikleri soru çözümü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mat-3',
    list_id: 'list-sgs-matematik',
    title: 'Oran-orantı ve problemler',
    description:
      'Doğru ve ters orantı, aritmetik ve geometrik ortalama. Sayı, kesir, yaş, yüzde, kâr-zarar, karışım, işçi ve hareket problemleri.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-mat-3-1', card_id: 'sgs-c-mat-3', text: 'Yüzde ve kâr-zarar problem kalıpları', is_done: false },
      { id: 'chk-mat-3-2', card_id: 'sgs-c-mat-3', text: 'Sayı ve kesir problemleri denklem kurma', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-mat-4',
    list_id: 'list-sgs-matematik',
    title: 'Küme işlemleri ve olasılık',
    description:
      'Kümelerde birleşim, kesişim, fark işlemleri ve Venn şeması. Sayma ilkeleri, permütasyon, kombinasyon ve basit olayların olasılığı.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-mat-4-1', card_id: 'sgs-c-mat-4', text: 'Kümeler problem çözümü', is_done: false },
      { id: 'chk-mat-4-2', card_id: 'sgs-c-mat-4', text: 'Kombinasyon ve olasılık çıkmış soru çözümleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 13. ATATURK ILKELERI VE INKILAP TARIHI
  // ==========================================================================
  {
    id: 'sgs-c-ink-1',
    list_id: 'list-sgs-inkilap',
    title: 'Osmanlı Devleti\'nin son dönemi ve çöküşü, I. Dünya Savaşı',
    description:
      'Trablusgarp Savaşı, Balkan Savaşları, I. Dünya Savaşı\'na giriş, cepheler (Çanakkale, Kafkas, Kanal vb.), Mondros Ateşkes Antlaşması ve işgaller.',
    position: STEP * 1,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-ink-1-1', card_id: 'sgs-c-ink-1', text: 'I. Dünya Savaşı taarruz ve savunma cepheleri', is_done: true },
      { id: 'chk-ink-1-2', card_id: 'sgs-c-ink-1', text: 'Mondros\'un kritik 7. ve 24. maddeleri', is_done: true },
    ],
    completed: true,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-ink-2',
    list_id: 'list-sgs-inkilap',
    title: 'Milli Mücadele dönemi, Amasya Genelgesi, Erzurum ve Sivas Kongreleri',
    description:
      'Mustafa Kemal\'in Samsun\'a çıkışı, Havza Genelgesi, Amasya Genelgesi (Milli Mücadelenin amaç, gerekçe ve yöntemi), Erzurum Kongresi (Temsil Heyeti), Sivas Kongresi, Amasya Görüşmeleri.',
    position: STEP * 2,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-ink-2-1', card_id: 'sgs-c-ink-2', text: 'Genelge ve kongrelerin kronolojisi ve kararları', is_done: false },
      { id: 'chk-ink-2-2', card_id: 'sgs-c-ink-2', text: 'Misak-ı Millî kararları ve önemi', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-ink-3',
    list_id: 'list-sgs-inkilap',
    title: 'TBMM\'nin açılması, Kurtuluş Savaşı cepheleri ve antlaşmalar',
    description:
      '23 Nisan 1920 I. TBMM\'nin özellikleri. Doğu Cephesi (Gümrü), Güney Cephesi (Ankara Antlaşması), Batı Cephesi (I. ve II. İnönü, Sakarya, Büyük Taarruz), Mudanya ve Lozan Barış Antlaşması.',
    position: STEP * 3,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-ink-3-1', card_id: 'sgs-c-ink-3', text: 'Batı cephesi savaşları ve sonuçları', is_done: false },
      { id: 'chk-ink-3-2', card_id: 'sgs-c-ink-3', text: 'Lozan\'da çözülen ve sonraya kalan konular', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-ink-4',
    list_id: 'list-sgs-inkilap',
    title: 'Atatürk İnkılapları ve İlkeleri',
    description:
      'Cumhuriyetçilik, Milliyetçilik, Halkçılık, Devletçilik, Laiklik, İnkılapçılık. Siyasal, hukuk, eğitim-kültür ve ekonomi alanındaki inkılaplar.',
    position: STEP * 4,
    labels: [{ id: 'lbl-sgs-gkgy', name: 'GK/GY', color: '#6366f1' }],
    checklist: [
      { id: 'chk-ink-4-1', card_id: 'sgs-c-ink-4', text: '6 Temel ilkenin anahtar kelimeleri ve eşleştirmeleri', is_done: false },
      { id: 'chk-ink-4-2', card_id: 'sgs-c-ink-4', text: 'Tevhid-i Tedrisat ve Medeni Kanun kabulleri', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },

  // ==========================================================================
  // 14. YABANCI DIL (INGILIZCE)
  // ==========================================================================
  {
    id: 'sgs-c-ing-1',
    list_id: 'list-sgs-ingilizce',
    title: 'Temel dil bilgisi',
    description:
      'Zamanlar (Simple Present, Past, Perfect Tenses), Modals, Passive Voice, Conditionals (Type 0, 1, 2) ve bağlaçlar.',
    position: STEP * 1,
    labels: [{ id: 'lbl-sgs-ing', name: 'Yabancı Dil', color: '#8b5cf6' }],
    checklist: [
      { id: 'chk-ing-1-1', card_id: 'sgs-c-ing-1', text: 'Tenses ve zaman zarfları kuralları', is_done: false },
      { id: 'chk-ing-1-2', card_id: 'sgs-c-ing-1', text: 'Bağlaçlar (Although, Because, However vb.) soru çözümü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
  {
    id: 'sgs-c-ing-2',
    list_id: 'list-sgs-ingilizce',
    title: 'Okuduğunu anlama ve kelime bilgisi',
    description:
      'Paragraf okuma ve ana düşünce soruları, diyalog tamamlama, eş anlamlı sözcükler ve finans/iş dünyası terimleri.',
    position: STEP * 2,
    labels: [{ id: 'lbl-sgs-ing', name: 'Yabancı Dil', color: '#8b5cf6' }],
    checklist: [
      { id: 'chk-ing-2-1', card_id: 'sgs-c-ing-2', text: 'Finans ve muhasebe İngilizce terimleri sözlüğü', is_done: false },
      { id: 'chk-ing-2-2', card_id: 'sgs-c-ing-2', text: 'SGS çıkmış İngilizce paragraf soruları çözüldü', is_done: false },
    ],
    completed: false,
    created_at: nowStr,
    updated_at: nowStr,
  },
];
