export interface KanbanLabel {
  id: string;
  name: string;
  color: string; // e.g. '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899'
}

export interface KanbanChecklistItem {
  id: string;
  card_id: string;
  text: string;
  is_done: boolean;
}

export interface KanbanComment {
  id: string;
  card_id: string;
  author_name: string;
  text: string;
  created_at: string;
}

export interface KanbanAttachment {
  id: string;
  card_id: string;
  name: string;
  url: string;
  size?: string;
  created_at: string;
}

export interface KanbanActivityLog {
  id: string;
  board_id: string;
  card_id?: string;
  card_title?: string;
  action: 'create_card' | 'move_card' | 'edit_card' | 'archive_card' | 'complete_checklist' | 'create_list' | 'move_list';
  details: string;
  user_name: string;
  created_at: string;
}

export interface KanbanCard {
  id: string;
  list_id: string;
  title: string;
  description?: string;
  position: number; // FLOAT: 65536, 131072...
  due_date?: string | null; // YYYY-MM-DD
  labels: KanbanLabel[];
  checklist: KanbanChecklistItem[];
  comments?: KanbanComment[];
  attachments?: KanbanAttachment[];
  created_at: string;
  updated_at: string;
  archived?: boolean;
  completed?: boolean;
}

export interface KanbanList {
  id: string;
  board_id: string;
  title: string;
  position: number; // FLOAT: 65536, 131072...
  created_at: string;
  updated_at: string;
  archived?: boolean;
}

export interface KanbanBoard {
  id: string;
  title: string;
  description?: string;
  created_at: string;
  updated_at: string;
  owner_id: string;
  color?: string; // background accent color
  archived?: boolean;
}
