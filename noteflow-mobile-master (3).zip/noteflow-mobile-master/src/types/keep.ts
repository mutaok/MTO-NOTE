export type KeepColor =
  | 'default'
  | 'coral'
  | 'peach'
  | 'sand'
  | 'mint'
  | 'sage'
  | 'fog'
  | 'storm'
  | 'dusk'
  | 'blossom'
  | 'clay'
  | 'chalk';

export interface KeepChecklistItem {
  id: string;
  text: string;
  done: boolean;
}

export interface KeepNote {
  id: string;
  title: string;
  content: string;
  isChecklist: boolean;
  checklistItems: KeepChecklistItem[];
  color: KeepColor;
  isPinned: boolean;
  isArchived: boolean;
  isTrashed: boolean;
  labels: string[];
  reminder?: string | null; // ISO Date string
  createdAt: string;
  updatedAt: string;
  googleKeepUrl?: string;
  syncSource?: 'keep_import' | 'manual' | 'noteflow_export';
}

export type KeepFilter = 'all' | 'pinned' | 'reminders' | 'archived' | 'trash';
