import { useState, useEffect, useCallback, useRef } from 'react';
import { AppTab, MindMap, Note, Task, Notebook } from './types';
import { StorageService, attachSyncEngine, localStore, setDataOwner } from './data/storage';
import { newId } from './data/sync/ids';
import { SyncEngine, type SyncStatus } from './data/sync/SyncEngine';
import { supabase, SHARED_DEFAULT_USER_ID, SHARED_DEFAULT_EMAIL } from './lib/supabase';
import { SupabaseSyncModal } from './components/SupabaseSyncModal';
import { InstallAppModal } from './components/InstallAppModal';
import { HomeTab } from './components/HomeTab';
import { NotesTab } from './components/NotesTab';
import { TasksTab } from './components/TasksTab';
import { MindMapTab } from './components/MindMapTab';
import { SearchTab } from './components/SearchTab';
import { NotebooksHub } from './components/notebooks/NotebooksHub';
import { GoogleDriveHub } from './components/GoogleDriveHub';
import { GmailHub } from './components/gmail/GmailHub';
import { GoogleKeepHub } from './components/keep/GoogleKeepHub';
import { ArchitectureTab } from './components/ArchitectureTab';
import { KanbanTab } from './components/kanban/KanbanTab';
import { NoteEditorModal } from './components/modals/NoteEditorModal';
import { TaskEditorModal } from './components/modals/TaskEditorModal';
import { ToastContainer, showToast } from './components/Toast';
import { SplashScreen } from './components/SplashScreen';

interface AppProps {
  /** Opsiyonel hesap bilgisi (geriye dönük uyumluluk) */
  account?: { userId?: string; email: string | null } | null;
  engine?: SyncEngine | null;
  onSignOut?: () => void;
  onRequestSignIn?: () => void;
}

export function App({ engine: initialEngine = null }: AppProps = {}) {
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isDark, setIsDark] = useState<boolean>(() => {
    return (
      localStorage.getItem('noteflow_theme') === 'dark' ||
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  });

  // Supabase & Flutter Sync Engine State
  const [sessionUser, setSessionUser] = useState<{ id: string; email: string | null } | null>(null);
  const [activeEngine, setActiveEngine] = useState<SyncEngine | null>(initialEngine);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [installInitialTab, setInstallInitialTab] = useState<'source' | 'android' | 'desktop'>('source');
  const engineRef = useRef<SyncEngine | null>(initialEngine);

  // State collections
  const [notebooks, setNotebooks] = useState<Notebook[]>(() => StorageService.getNotebooks());
  const [notes, setNotes] = useState<Note[]>(() => StorageService.getNotes());
  const [tasks, setTasks] = useState<Task[]>(() => StorageService.getTasks());
  const [mindmaps, setMindmaps] = useState<MindMap[]>(() => StorageService.getMindMaps());

  // Modal & Selection state
  const [isNoteEditorOpen, setIsNoteEditorOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  const [isTaskEditorOpen, setIsTaskEditorOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const [currentMindMap, setCurrentMindMap] = useState<MindMap | null>(null);

  // Sync dark class on html root
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('noteflow_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('noteflow_theme', 'light');
    }
  }, [isDark]);

  const startEngineForUser = useCallback(async (userId: string) => {
    if (engineRef.current) {
      await engineRef.current.stop();
    }
    setDataOwner(userId);
    const eng = new SyncEngine({ client: supabase, userId, store: localStore });
    engineRef.current = eng;
    setActiveEngine(eng);
    attachSyncEngine(eng);

    eng.onStatus((status) => {
      setSyncStatus(status);
    });

    eng.onRemoteChange((areas) => {
      if (areas.has('notebooks')) setNotebooks(StorageService.getNotebooks());
      if (areas.has('notes')) setNotes(StorageService.getNotes());
      if (areas.has('tasks')) setTasks(StorageService.getTasks());
      if (areas.has('mind_maps')) setMindmaps(StorageService.getMindMaps());
    });

    try {
      await eng.start();
    } catch {
      // Çevrimdışıyken hata vermeden sessizce devam eder
    }
  }, []);

  // Supabase & Flutter Sync motorunu otomatik başlat (Mail ve şifre istemeden doğrudan bağlanır)
  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data: { session } }) => {
        if (session?.user) {
          setSessionUser({ id: session.user.id, email: session.user.email ?? null });
          void startEngineForUser(session.user.id);
        } else {
          // Giriş yapılmamışsa bile ortak kullanıcı hesabı ile doğrudan senkronizasyon motorunu devreye sok
          setSessionUser({ id: SHARED_DEFAULT_USER_ID, email: SHARED_DEFAULT_EMAIL });
          void startEngineForUser(SHARED_DEFAULT_USER_ID);
        }
      })
      .catch((err) => {
        console.warn('Supabase oturum kontrolü atlandı (otomatik paylaşımlı mod):', err);
        setSessionUser({ id: SHARED_DEFAULT_USER_ID, email: SHARED_DEFAULT_EMAIL });
        void startEngineForUser(SHARED_DEFAULT_USER_ID);
      });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setSessionUser({ id: session.user.id, email: session.user.email ?? null });
        void startEngineForUser(session.user.id);
      } else {
        // Oturum kapansa dahi doğrudan eşitleme devam eder
        setSessionUser({ id: SHARED_DEFAULT_USER_ID, email: SHARED_DEFAULT_EMAIL });
        void startEngineForUser(SHARED_DEFAULT_USER_ID);
      }
    });

    return () => {
      subscription.unsubscribe();
      if (engineRef.current) {
        void engineRef.current.stop();
      }
    };
  }, [startEngineForUser]);

  const handleSignOutSupabase = async () => {
    if (engineRef.current) {
      await engineRef.current.stop();
      engineRef.current = null;
    }
    setActiveEngine(null);
    attachSyncEngine(null);
    setSessionUser(null);
    setSyncStatus(null);
    setIsSyncModalOpen(false);
    await supabase.auth.signOut({ scope: 'local' });
    showToast('Supabase bağlantısı kapatıldı, yerel moda geçildi', 'info');
  };

  const toggleDark = () => setIsDark(!isDark);

  // Kaydetmeler güncel listeyi depodan okur: uzaktan gelen bir değişiklik henüz
  // state'e yansımamış olsa bile bayat liste onu ezmez.

  // Persist notes
  const handleSaveNote = (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => {
    const now = new Date().toISOString();
    const current = StorageService.getNotes();
    let updated: Note[];
    if (noteData.id) {
      updated = current.map((n) => {
        if (n.id !== noteData.id) return n;
        return {
          ...n,
          ...noteData,
          notebookId: noteData.notebookId !== undefined ? noteData.notebookId : n.notebookId,
          id: n.id,
          updatedAt: now,
        };
      });
      showToast('Not kaydedildi');
    } else {
      const newNote: Note = {
        ...noteData,
        id: newId(),
        notebookId: noteData.notebookId || undefined,
        createdAt: now,
        updatedAt: now,
      };
      updated = [newNote, ...current];
      showToast('Yeni not oluşturuldu');
    }
    setNotes(updated);
    StorageService.saveNotes(updated);
  };

  const handleDeleteNote = (id: string) => {
    const updated = StorageService.getNotes().filter((n) => n.id !== id);
    setNotes(updated);
    StorageService.saveNotes(updated);
    showToast('Not silindi', 'info');
  };

  // Persist tasks
  const handleSaveTask = (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => {
    const now = new Date().toISOString();
    const current = StorageService.getTasks();
    let updated: Task[];
    if (taskData.id) {
      updated = current.map((t) => {
        if (t.id !== taskData.id) return t;
        return {
          ...t,
          ...taskData,
          notebookId: taskData.notebookId !== undefined ? taskData.notebookId : t.notebookId,
          id: t.id,
          updatedAt: now,
        };
      });
      showToast('Görev güncellendi');
    } else {
      const newTask: Task = {
        ...taskData,
        id: newId(),
        notebookId: taskData.notebookId || undefined,
        createdAt: now,
        updatedAt: now,
      };
      updated = [newTask, ...current];
      showToast('Yeni görev oluşturuldu');
    }
    setTasks(updated);
    StorageService.saveTasks(updated);
  };

  const handleToggleTask = (id: string) => {
    const now = new Date().toISOString();
    const updated = StorageService.getTasks().map((t) => (t.id === id ? { ...t, done: !t.done, updatedAt: now } : t));
    setTasks(updated);
    StorageService.saveTasks(updated);
  };

  const handleDeleteTask = (id: string) => {
    const updated = StorageService.getTasks().filter((t) => t.id !== id);
    setTasks(updated);
    StorageService.saveTasks(updated);
    showToast('Görev silindi', 'info');
  };

  // Persist mind maps
  const handleSaveMindMap = (map: MindMap) => {
    const current = StorageService.getMindMaps();
    const exists = current.some((m) => m.id === map.id);
    const updated = exists ? current.map((m) => (m.id === map.id ? map : m)) : [map, ...current];
    setMindmaps(updated);
    StorageService.saveMindMaps(updated);
  };

  const handleDeleteMindMap = (id: string) => {
    const updated = StorageService.getMindMaps().filter((m) => m.id !== id);
    setMindmaps(updated);
    StorageService.saveMindMaps(updated);
  };

  const handleImportBackup = (data: {
    notebooks?: Notebook[];
    notes?: Note[];
    tasks?: Task[];
    mindmaps?: MindMap[];
  }) => {
    // Eski yedeklerde sayısal kimlikler olabilir; depodan geri okumak onları string'e çevirir.
    if (data.notebooks) {
      StorageService.saveNotebooks(data.notebooks);
      setNotebooks(StorageService.getNotebooks());
    }
    if (data.notes) {
      StorageService.saveNotes(data.notes);
      setNotes(StorageService.getNotes());
    }
    if (data.tasks) {
      StorageService.saveTasks(data.tasks);
      setTasks(StorageService.getTasks());
    }
    if (data.mindmaps) {
      StorageService.saveMindMaps(data.mindmaps);
      setMindmaps(StorageService.getMindMaps());
    }
  };

  // Cross-navigation helpers
  const handleOpenNoteEditor = (note?: Note) => {
    setEditingNote(note || null);
    setIsNoteEditorOpen(true);
  };

  const handleOpenTaskEditor = (task?: Task) => {
    setEditingTask(task || null);
    setIsTaskEditorOpen(true);
  };

  const handleSelectMindMap = (map: MindMap) => {
    setCurrentMindMap(map);
    setActiveTab('mindmap');
  };

  const handleOpenNoteWithDate = (dateStr: string) => {
    setEditingNote({
      id: '',
      title: '',
      body: '',
      tag: 'Kişisel',
      date: dateStr,
      createdAt: '',
      updatedAt: '',
    });
    setIsNoteEditorOpen(true);
  };

  const handleSaveNotebook = (notebookData: Omit<Notebook, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => {
    const current = StorageService.getNotebooks();
    let updated: Notebook[];
    if (notebookData.id) {
      updated = current.map((nb) =>
        nb.id === notebookData.id
          ? {
              ...nb,
              ...notebookData,
              title: notebookData.name || (notebookData as any).title || nb.title || nb.name,
              name: notebookData.name || (notebookData as any).title || nb.name || nb.title,
              id: nb.id,
              updatedAt: new Date().toISOString(),
            }
          : nb
      );
      showToast('Defter güncellendi');
    } else {
      const newNb: Notebook = {
        id: newId(),
        title: notebookData.name || (notebookData as any).title || 'Yeni Defter',
        name: notebookData.name || (notebookData as any).title || 'Yeni Defter',
        description: notebookData.description,
        type: notebookData.type,
        color: notebookData.color,
        icon: notebookData.icon,
        paperStyle: notebookData.paperTexture || notebookData.paperStyle || 'lined',
        paperTexture: notebookData.paperTexture || notebookData.paperStyle || 'lined',
        isLocked: false,
        views: notebookData.views || ['notes', 'special'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        tags: notebookData.tags || [],
        collaborators: notebookData.collaborators || [],
      };
      updated = [newNb, ...current];
      showToast('Yeni defter oluşturuldu');
    }
    setNotebooks(updated);
    StorageService.saveNotebooks(updated);
  };

  const handleDeleteNotebook = (id: string) => {
    const updated = StorageService.getNotebooks().filter((nb) => nb.id !== id);
    setNotebooks(updated);
    StorageService.saveNotebooks(updated);
    showToast('Defter silindi', 'info');
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const tasksToday = tasks.filter((t) => !t.done && t.dueDate === todayStr).length;

  const formattedDate = new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'long',
  }).format(new Date());

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isKanbanBoardActive, setIsKanbanBoardActive] = useState<boolean>(() => {
    return Boolean(localStorage.getItem('noteflow_selected_kanban_board_id'));
  });
  const isKanbanFullscreen = activeTab === 'kanban' && isKanbanBoardActive;
  const isFullscreenApp = activeTab === 'notebooks' || activeTab === 'notes' || isKanbanFullscreen;

  return (
    <div
      className={`w-full ${
        isFullscreenApp ? 'max-w-none' : 'max-w-[1650px]'
      } h-[100dvh] mx-auto flex flex-col overflow-hidden relative transition-colors duration-200 ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Açılış Görseli - Splash Screen */}
      {showSplash && (
        <SplashScreen onFinish={() => setShowSplash(false)} isDark={isDark} />
      )}

      {/* Saydam Arka Plan Çizim Görseli */}
      <div
        className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center overflow-hidden select-none"
        aria-hidden="true"
      >
        <img
          src="/images/thought-cloud-bg.jpg"
          alt=""
          className="w-full h-full max-w-4xl max-h-[85vh] object-contain opacity-25 dark:opacity-15 mix-blend-multiply dark:mix-blend-screen transition-opacity duration-300"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Kibar ve Sade Tarih Başlığı (Başka Hiçbir Şey Yok) */}
      {!isFullscreenApp && (
        <header
          className="w-full py-4 px-6 flex items-center justify-center border-b border-slate-200/40 dark:border-slate-800/40 z-20 shrink-0 select-none backdrop-blur-xs"
        >
          <span className="text-xs sm:text-sm font-medium tracking-widest text-slate-500 dark:text-slate-400">
            {formattedDate}
          </span>
        </header>
      )}

      {/* Main Workspace */}
      <main
        className={`flex-1 flex flex-col overflow-hidden relative z-10 ${
          isKanbanFullscreen
            ? 'p-0'
            : isFullscreenApp
            ? 'p-1 sm:p-3 md:p-4'
            : 'p-3 sm:p-4 lg:p-6 pb-20 md:pb-6'
        }`}
      >
        {/* Active View Container */}
        <div
          className={`w-full flex-1 ${
            isKanbanFullscreen
              ? 'h-full overflow-hidden p-0 rounded-none border-0 bg-white/95 dark:bg-slate-900/95'
              : activeTab === 'kanban'
              ? 'overflow-hidden p-1 sm:p-4 lg:p-6 rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 backdrop-blur-sm shadow-xs'
              : 'overflow-y-auto p-3 sm:p-5 lg:p-6'
          } ${
            isKanbanFullscreen || activeTab === 'kanban'
              ? ''
              : isFullscreenApp
              ? 'h-full rounded-xl sm:rounded-2xl border border-slate-200/70 dark:border-slate-800/80 bg-white/95 dark:bg-slate-900/95 shadow-xs'
              : 'rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 backdrop-blur-sm shadow-xs'
          }`}
        >
          {/* Tam Ekran Modunda Üst Çıkış ve Başlık Çubuğu */}
          {isFullscreenApp && !isKanbanFullscreen && (
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-200/80 dark:border-slate-800 shrink-0">
              <button
                id="btn-fullscreen-exit-home"
                onClick={() => setActiveTab('home')}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs sm:text-sm shadow-sm active:scale-[0.98] transition-all cursor-pointer"
                title="Ana Sayfaya Dön (Tam Ekrandan Çık)"
              >
                <span>←</span>
                <span>Ana Sayfaya Dön</span>
              </button>

              <div className="flex items-center gap-3">
                <span className="text-xs sm:text-sm font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <span>{activeTab === 'notebooks' ? '📚 Defterler' : '📝 Notlar'}</span>
                  <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-teal-500/15 text-teal-600 dark:text-teal-400 font-bold">
                    Tam Ekran
                  </span>
                </span>
                <button
                  onClick={toggleDark}
                  className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Temayı Değiştir"
                >
                  {isDark ? '☀️' : '🌙'}
                </button>
              </div>
            </div>
          )}
          {activeTab === 'notebooks' && (
            <NotebooksHub
              notebooks={notebooks}
              notes={notes}
              tasks={tasks}
              onSaveNotebook={handleSaveNotebook}
              onOpenNoteEditor={handleOpenNoteEditor}
              onOpenTaskEditor={handleOpenTaskEditor}
              onSaveNote={handleSaveNote}
              onSaveTask={handleSaveTask}
              onToggleTask={handleToggleTask}
              onNavigateToMindMap={() => setActiveTab('mindmap')}
            />
          )}

          {activeTab === 'home' && (
            <HomeTab
              notes={notes}
              tasks={tasks}
              mindmaps={mindmaps}
              setActiveTab={setActiveTab}
              onOpenNoteEditor={handleOpenNoteEditor}
              onOpenTaskEditor={handleOpenTaskEditor}
              onSelectMindMap={handleSelectMindMap}
              onToggleTask={handleToggleTask}
              handleSaveMindMap={handleSaveMindMap}
              setCurrentMindMap={setCurrentMindMap}
            />
          )}

          {activeTab === 'notes' && (
            <NotesTab
              notes={notes}
              notebooks={notebooks}
              onSaveNote={handleSaveNote}
              onDeleteNote={handleDeleteNote}
              editorNote={editingNote}
              isEditorOpen={isNoteEditorOpen}
              onOpenEditor={handleOpenNoteEditor}
              onCloseEditor={() => {
                setIsNoteEditorOpen(false);
                setEditingNote(null);
              }}
            />
          )}

          {activeTab === 'tasks' && (
            <TasksTab
              tasks={tasks}
              notebooks={notebooks}
              onSaveTask={handleSaveTask}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              editorTask={editingTask}
              isEditorOpen={isTaskEditorOpen}
              onOpenEditor={handleOpenTaskEditor}
              onCloseEditor={() => {
                setIsTaskEditorOpen(false);
                setEditingTask(null);
              }}
              onOpenNoteWithDate={handleOpenNoteWithDate}
            />
          )}

          {activeTab === 'kanban' && (
            <KanbanTab
              isDark={isDark}
              onBoardSelectChange={(hasActive) => setIsKanbanBoardActive(hasActive)}
            />
          )}

          {activeTab === 'mindmap' && (
            <MindMapTab
              mindmaps={mindmaps}
              onSaveMindMap={handleSaveMindMap}
              onDeleteMindMap={handleDeleteMindMap}
              currentMap={currentMindMap}
              setCurrentMap={setCurrentMindMap}
            />
          )}

          {activeTab === 'drive' && (
            <GoogleDriveHub
              notebooks={notebooks}
              notes={notes}
              tasks={tasks}
              mindmaps={mindmaps}
              onImportBackup={handleImportBackup}
            />
          )}

          {activeTab === 'gmail' && (
            <GmailHub
              notebooks={notebooks}
              notes={notes}
              tasks={tasks}
              onSaveNote={handleSaveNote}
              onSaveTask={handleSaveTask}
              isDark={isDark}
              showToast={showToast}
            />
          )}

          {activeTab === 'search' && (
            <SearchTab
              notes={notes}
              tasks={tasks}
              mindmaps={mindmaps}
              onOpenNote={(note) => {
                handleOpenNoteEditor(note);
                setActiveTab('notes');
              }}
              onOpenTask={(task) => {
                handleOpenTaskEditor(task);
                setActiveTab('tasks');
              }}
              onOpenMindMap={(map) => {
                handleSelectMindMap(map);
              }}
            />
          )}

          {activeTab === 'architecture' && <ArchitectureTab />}
        </div>
      </main>

      {/* Android & Mobile Bottom Navigation Bar (Visible only on md:hidden when not in fullscreen defter/not mode) */}
      {!isFullscreenApp && (
        <nav
          className={`md:hidden fixed bottom-0 left-0 right-0 z-40 border-t ${
            isDark ? 'bg-slate-900/95 border-slate-800' : 'bg-white/95 border-slate-200'
          } backdrop-blur-lg pb-safe`}
        >
          <div className="grid grid-cols-6 h-14 items-center">
            {[
              { id: 'notebooks', label: 'Defterler', icon: '📚' },
              { id: 'kanban', label: 'Kanban', icon: '📋' },
              { id: 'notes', label: 'Notlar', icon: '📝' },
              { id: 'tasks', label: 'Görevler', icon: '✓' },
              { id: 'mindmap', label: 'Mind Map', icon: '🧠' },
              { id: 'menu', label: 'Menü', icon: '☰' },
            ].map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.id === 'menu') {
                      setIsMenuOpen(true);
                    } else {
                      setActiveTab(item.id as AppTab);
                    }
                  }}
                  className={`flex flex-col items-center justify-center h-full transition-colors ${
                    isActive
                      ? 'text-teal-500 font-semibold'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <span className="text-lg leading-none mb-1">{item.icon}</span>
                  <span className="text-[10px] tracking-tight">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Slide-over Drawer Menu (Tüm 11 Defter Türü ve Modüller) */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
            onClick={() => setIsMenuOpen(false)}
          />

          {/* Drawer Panel */}
          <div
            className={`relative ml-auto w-full max-w-sm h-full shadow-2xl flex flex-col z-10 transition-transform ${
              isDark
                ? 'bg-slate-900 text-slate-100 border-l border-slate-800'
                : 'bg-white text-slate-900 border-l border-slate-200'
            }`}
          >
            <div className="p-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="text-xl">✦</span>
                <h2 className="font-bold text-lg text-teal-500">Modüller & Menü</h2>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-800 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-3">
              {/* Supabase Status Summary in Drawer */}
              <div className="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 mb-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-semibold text-teal-600 dark:text-teal-400">
                    ⚡ Supabase & Flutter Sync
                  </div>
                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      setIsSyncModalOpen(true);
                    }}
                    className="text-xs font-bold underline text-teal-500 hover:text-teal-600"
                  >
                    Yönet
                  </button>
                </div>
                <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                  {sessionUser ? `Bağlı: ${sessionUser.email}` : 'Yerel Mod (Çevrimdışı)'}
                </div>
              </div>

              {/* Install / APK button in Drawer */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  setIsInstallModalOpen(true);
                }}
                className="w-full p-3.5 rounded-2xl bg-teal-500 text-white font-semibold text-sm shadow-md shadow-teal-500/20 hover:bg-teal-600 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <span>📲</span>
                  <span>Android APK & Masaüstü Kur</span>
                </div>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">Yükle</span>
              </button>

              {/* Theme Switcher in Drawer */}
              <button
                onClick={toggleDark}
                className={`w-full p-3 rounded-2xl border transition-all flex items-center justify-between text-xs font-semibold ${
                  isDark
                    ? 'border-slate-850 bg-slate-800/80 hover:bg-slate-800 text-amber-400'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>{isDark ? '☀️' : '🌙'}</span>
                  <span className="text-slate-800 dark:text-slate-200">
                    {isDark ? 'Açık Temaya Geç' : 'Koyu Temaya Geç'}
                  </span>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                  {isDark ? 'Koyu' : 'Açık'}
                </span>
              </button>

              <div className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-2">
                Gezinme Alanları
              </div>
              {[
                { id: 'notebooks', label: '📚 Defterler Hub', desc: '11 Defter Türü' },
                { id: 'kanban', label: '📋 Kanban Pano', desc: 'Trello mantığında kart ve sütun panosu' },
                { id: 'home', label: '🏠 Ana Sayfa', desc: 'Genel Bakış' },
                { id: 'notes', label: '📝 Notlar', desc: 'Tüm notlar ve düzenleyici' },
                { id: 'tasks', label: '✓ Görevler & Takvim', desc: 'Görev listesi ve takvim' },
                { id: 'mindmap', label: '🧠 Zihin Haritaları', desc: 'Görsel fikir diyagramları' },
                { id: 'drive', label: '☁️ Google Drive', desc: 'Bulut yedekleme ve senkronizasyon' },
                { id: 'gmail', label: '✉️ Gmail E-posta', desc: 'Gelen kutusu, e-posta gönder ve notlara bağla' },
                {
                  id: 'architecture',
                  label: '⚡ Flutter & Supabase Mimari',
                  desc: 'Offline-First & Clean Architecture',
                },
                { id: 'search', label: '🔍 Global Arama', desc: 'Hızlı arama' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as AppTab);
                    setIsMenuOpen(false);
                  }}
                  className={`w-full p-3.5 rounded-2xl text-left border transition-all flex flex-col gap-0.5 ${
                    activeTab === item.id
                      ? 'border-teal-500 bg-teal-500/10 text-teal-600 dark:text-teal-400 font-semibold'
                      : isDark
                      ? 'border-slate-800 bg-slate-900/60 hover:bg-slate-800'
                      : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-sm">{item.label}</span>
                  <span className="text-xs opacity-60">{item.desc}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Supabase & Flutter Sync Modal */}
      <SupabaseSyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        userEmail={sessionUser?.email ?? null}
        userId={sessionUser?.id ?? null}
        syncStatus={syncStatus}
        engine={activeEngine}
        onRefreshSession={() => {
          supabase.auth.getSession().then(({ data: { session } }) => {
            if (session?.user) {
              setSessionUser({ id: session.user.id, email: session.user.email ?? null });
              void startEngineForUser(session.user.id);
            }
          });
        }}
        onSignOut={() => void handleSignOutSupabase()}
        isDark={isDark}
      />

      {/* Android & Desktop Install/APK Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isDark={isDark}
        initialTab={installInitialTab}
      />

      {/* Global Note & Task Modals */}
      <NoteEditorModal
        isOpen={isNoteEditorOpen}
        onClose={() => {
          setIsNoteEditorOpen(false);
          setEditingNote(null);
        }}
        onSave={handleSaveNote}
        onDelete={handleDeleteNote}
        note={editingNote}
        notebooks={notebooks}
      />

      <TaskEditorModal
        isOpen={isTaskEditorOpen}
        onClose={() => {
          setIsTaskEditorOpen(false);
          setEditingTask(null);
        }}
        onSave={handleSaveTask}
        onDelete={handleDeleteTask}
        task={editingTask}
        notebooks={notebooks}
      />

      <ToastContainer />
    </div>
  );
}

export default App;
