export type MindMapType =
  | 'mindmap'
  | 'logic'
  | 'brace'
  | 'org'
  | 'tree'
  | 'timeline'
  | 'fishbone'
  | 'treetable'
  | 'matrix'
  | 'grid';

export interface MindMapNode {
  id: string;
  title: string;
  notes?: string;
  color?: string;
  children: MindMapNode[];
}

export interface MindMapTreeDoc {
  kind: 'tree';
  root: MindMapNode;
}

export interface MindMapTableDoc {
  kind: 'table';
  rows: string[];
  cols: string[];
  cells: Record<string, string>;
}

export type MindMapDoc = MindMapTreeDoc | MindMapTableDoc;

export interface MindMap {
  id: string;
  title: string;
  type: MindMapType;
  data: MindMapDoc;
  createdAt: string;
  updatedAt: string;
  notebookId?: string | null;
}

export interface Task {
  id: string;
  title: string;
  list: string;
  dueDate: string | null; // YYYY-MM-DD
  dueTime: string | null; // HH:mm
  done: boolean;
  color: string;
  createdAt: string;
  updatedAt: string;
  notebookId?: string | null;
  assignee?: string;
  priority?: 'düşük' | 'orta' | 'yüksek' | 'kritik';
}

// 11 Notebook Types specified by user
export type NotebookType =
  | 'academic'    // Ders / Akademik
  | 'project'     // Proje
  | 'journal'     // Günlük
  | 'meeting'     // Toplantı
  | 'reading'     // Kitap / Okuma
  | 'travel'      // Seyahat
  | 'recipe'      // Tarif / Yemek
  | 'finance'     // Finans / Bütçe
  | 'fitness'     // Sağlık / Spor
  | 'brainstorm'  // Fikir / Beyin Fırtınası
  | 'code';       // Kod / Teknik

export type NotebookViewMode =
  | 'notes'
  | 'kanban'
  | 'calendar'
  | 'table'
  | 'gallery'
  | 'map'
  | 'mindmap'
  | 'analytics'
  | 'special';

export type PaperTexture = 'plain' | 'lined' | 'grid' | 'dots';

export interface Collaborator {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'editor' | 'commenter' | 'viewer';
  avatar?: string;
}

export interface Notebook {
  id: string;
  title: string;
  name?: string;
  description: string;
  type: NotebookType;
  color: string;
  icon: string;
  isLocked?: boolean;
  pin?: string;
  pinCode?: string;
  paperStyle?: 'plain' | 'lined' | 'grid' | 'dots'; // Visual paper texture
  paperTexture?: PaperTexture;
  defaultView?: NotebookViewMode;
  views?: string[];
  noteCount?: number;
  createdAt: string;
  updatedAt: string;
  tags?: string[];
  collaborators?: Collaborator[];
}

export interface NoteReference {
  targetNoteId: string;
  targetTitle: string;
}

// Custom fields common across notes
export interface CustomFields {
  status?: string;
  priority?: 'düşük' | 'orta' | 'yüksek' | 'kritik';
  date?: string | null;
  assignee?: string;
  location?: string;
  price?: number;
  rating?: number; // 1 to 5
}

// Cornell Note Structure for Academic
export interface CornellData {
  cues: string[];     // Sorular, ipuçları, anahtar kavramlar
  notes: string;      // Ana not alanı
  summary: string;    // Sayfa altı özeti
}

// Soru-Cevap Flashcard
export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  deck?: string;
  difficulty?: 'kolay' | 'orta' | 'zor';
  nextReviewDate?: string;
  repetitions?: number;
}

// Formül Kütüphanesi Elemanı
export interface MathFormula {
  id: string;
  title: string;
  category: 'Matematik' | 'Fizik' | 'Kimya' | 'Mühendislik';
  latex: string;
  description: string;
}

// Kaynakça Referansı
export interface Citation {
  id: string;
  authors: string;
  title: string;
  source: string;
  year: number;
  format: 'APA' | 'MLA' | 'IEEE';
}

// Sınav / Kilometre Taşı Sayacı
export interface CountdownEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string;
  type: 'sınav' | 'teslim' | 'sunum' | 'etkinlik';
}

// Proje Kilometre Taşı
export interface Milestone {
  id: string;
  title: string;
  dueDate: string;
  completed: boolean;
  description?: string;
}

// Dosya Sürümü
export interface FileVersion {
  id: string;
  version: string;
  name: string;
  updatedAt: string;
  author: string;
  changeLog: string;
}

// Günlük Mood & Alışkanlık Kaydı
export interface MoodEntry {
  id: string;
  date: string; // YYYY-MM-DD
  mood: 'çok_iyi' | 'mutlu' | 'sakin' | 'yorgun' | 'stresli';
  energyLevel: number; // 1 to 5
  habits: {
    water: boolean;
    exercise: boolean;
    reading: boolean;
    meditation: boolean;
  };
  gratitude: string[];
  weather?: 'güneşli' | 'bulutlu' | 'yağmurlu' | 'karlı';
  reflection?: string;
}

// Toplantı Elemanları
export interface MeetingDetails {
  agenda: string[];
  attendees: { name: string; email?: string; present: boolean }[];
  decisions: string[];
  actionItems: { id: string; task: string; owner: string; deadline: string; done: boolean }[];
  followUpDate?: string;
  audioDurationSeconds?: number;
  transcript?: string;
}

// Kitap / Okuma Bilgisi
export interface BookRecord {
  id: string;
  title: string;
  author: string;
  isbn?: string;
  totalPages: number;
  readPages: number;
  status: 'okunacak' | 'okunuyor' | 'tamamlandı' | 'bırakıldı';
  rating: number; // 1 to 5
  startDate?: string;
  finishDate?: string;
  coverUrl?: string;
  quotes: { text: string; page?: number }[];
  summary?: string;
}

// Seyahat Verisi
export interface TravelPlan {
  destination: string;
  startDate: string;
  endDate: string;
  budgetTotal: number;
  budgetSpent: number;
  currency: 'TRY' | 'USD' | 'EUR' | 'GBP';
  packingList: { id: string; item: string; packed: boolean; category: string }[];
  reservations: { id: string; type: 'Uçuş' | 'Otel' | 'Tren' | 'Bilet'; title: string; code: string; date: string }[];
  itinerary: { day: number; title: string; activities: string[] }[];
  placesToVisit: { name: string; address?: string; visited: boolean }[];
}

// Tarif / Yemek Verisi
export interface RecipeData {
  title: string;
  servings: number; // Base servings (e.g. 4)
  prepTimeMinutes: number;
  prepTime?: number | string;
  cookTimeMinutes: number;
  cookTime?: number | string;
  difficulty: 'Kolay' | 'Orta' | 'Zor';
  calories?: number;
  ingredients: { id: string; name: string; amount: number; unit: string }[];
  steps: string[];
  instructions?: string[];
  notes?: string;
  nutrition?: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

// Finans Verisi
export interface FinanceItem {
  id: string;
  title?: string;
  description?: string;
  amount: number;
  type: 'gelir' | 'gider' | 'yatırım';
  category: string;
  date: string;
  currency?: string;
  recurring?: boolean;
}

export interface BudgetGoal {
  category: string;
  limit: number;
  current: number;
}

export interface PersonalRecord {
  id: string;
  exercise: string;
  weight: number;
  date: string;
}

// Sağlık & Spor
export interface WorkoutEntry {
  id: string;
  date: string;
  activity?: string; // e.g. Göğüs & Arka Kol, Koşu, Yoga
  split?: string;
  durationMinutes: number;
  caloriesBurned?: number;
  exercises?: { exerciseName: string; sets: number; reps: number; weight: number }[];
  sets?: { exercise: string; sets: number; reps: number; weightKg: number }[];
  waterGlasses?: number; // Daily glasses (e.g. 8)
  weightKg?: number;
}

// Fikir / Beyin Fırtınası Sticky Note
export interface StickyNote {
  id: string;
  content: string;
  color: 'yellow' | 'pink' | 'cyan' | 'green' | 'purple';
  x: number;
  y: number;
  tags?: string[];
}

export interface StickyIdea {
  id: string;
  text: string;
  color: string;
  votes: number;
  tags: string[];
}

// Kod / Teknik Snippet & Bug Report
export interface CodeSnippet {
  id: string;
  title: string;
  language: 'typescript' | 'javascript' | 'python' | 'go' | 'rust' | 'html' | 'css' | 'sql' | 'bash';
  code: string;
  description?: string;
  tags?: string[];
}

export interface BugResolution {
  id: string;
  title: string;
  errorMessage: string;
  rootCause: string;
  solution: string;
  resolvedDate: string;
}

// Note Entity
export interface Note {
  id: string;
  notebookId?: string | null;
  title: string;
  body: string;
  tag: string;
  date?: string | null;
  createdAt: string;
  updatedAt: string;
  customFields?: CustomFields;
  backlinks?: NoteReference[];
  
  // Specific data slices depending on notebook type
  cornell?: CornellData;
  meetingDetails?: MeetingDetails;
  bookData?: BookRecord;
  recipeData?: RecipeData;
  codeSnippet?: CodeSnippet;
}

// Automation Rule
export interface AutomationRule {
  id: string;
  title?: string;
  name?: string;
  trigger: string;
  actionDescription?: string;
  action?: string;
  enabled: boolean;
}

export type NotebookAutomation = AutomationRule;

export * from './types/kanban';
export * from './types/gmail';
export * from './types/keep';

export type AppTab =
  | 'notebooks'
  | 'home'
  | 'notes'
  | 'tasks'
  | 'kanban'
  | 'mindmap'
  | 'drive'
  | 'gmail'
  | 'keep'
  | 'search'
  | 'architecture';
