import React, { useState } from 'react';
import type { AuthError } from '@supabase/supabase-js';
import { supabase } from '../../lib/supabase';

type Mode = 'signIn' | 'signUp';

interface AuthScreenProps {
  onContinueWithoutAccount: () => void;
}

const OFFLINE_MESSAGE = 'Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.';

/** Flutter uygulamasındaki SupabaseAuthRepository ile aynı mesajlar. */
function messageFor(error: AuthError): string {
  switch (error.code) {
    case 'invalid_credentials':
      return 'E-posta veya şifre hatalı.';
    case 'email_not_confirmed':
      return 'E-posta adresiniz henüz doğrulanmamış. Gelen kutunuzu kontrol edin.';
    case 'user_already_exists':
    case 'email_exists':
      return 'Bu e-posta adresiyle zaten bir hesap var.';
    case 'weak_password':
      return 'Şifre çok zayıf. Daha uzun bir şifre seçin.';
    case 'email_address_invalid':
      return 'Geçerli bir e-posta adresi girin.';
    case 'over_email_send_rate_limit':
    case 'over_request_rate_limit':
      return 'Çok fazla deneme yapıldı. Biraz bekleyip tekrar deneyin.';
    case 'signup_disabled':
      return 'Yeni kayıtlar şu anda kapalı.';
    default:
      return error.name === 'AuthRetryableFetchError' ? OFFLINE_MESSAGE : error.message;
  }
}

const inputClass =
  'w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500';

export function AuthScreen({ onContinueWithoutAccount }: AuthScreenProps) {
  const [mode, setMode] = useState<Mode>('signIn');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const switchMode = (next: Mode) => {
    setMode(next);
    setError(null);
    setInfo(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === 'signIn') {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signInError) setError(messageFor(signInError));
        return;
      }
      const name = displayName.trim();
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: name ? { display_name: name } : undefined,
          emailRedirectTo: window.location.origin,
        },
      });
      if (signUpError) {
        setError(messageFor(signUpError));
      } else if (!data.session) {
        setInfo('Hesabın oluşturuldu. E-postana gelen bağlantıyla adresini doğrula, ardından giriş yap.');
        setMode('signIn');
        setPassword('');
      }
    } catch {
      setError(OFFLINE_MESSAGE);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-teal-500 flex items-center justify-center text-white shadow-md shadow-teal-500/20 font-bold text-lg mb-3">
            ✦
          </div>
          <h1 className="text-xl font-bold">NoteFlow</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Flutter uygulamasıyla aynı hesap: notların tüm cihazlarında.
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
          <div className="grid grid-cols-2 gap-1 p-1 mb-5 rounded-xl bg-slate-100 dark:bg-slate-800">
            {(['signIn', 'signUp'] as const).map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => switchMode(value)}
                className={`py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  mode === value
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                {value === 'signIn' ? 'Giriş Yap' : 'Kayıt Ol'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {mode === 'signUp' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Ad (isteğe bağlı)</label>
                <input
                  type="text"
                  autoComplete="name"
                  maxLength={80}
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className={inputClass}
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">E-posta</label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Şifre</label>
              <input
                type="password"
                required
                minLength={mode === 'signUp' ? 6 : undefined}
                autoComplete={mode === 'signUp' ? 'new-password' : 'current-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={inputClass}
              />
            </div>

            {error && (
              <p className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 rounded-xl px-3 py-2">{error}</p>
            )}
            {info && (
              <p className="text-xs text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 rounded-xl px-3 py-2">{info}</p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 disabled:opacity-60 text-white text-sm font-semibold shadow-sm transition-colors"
            >
              {busy ? 'Bekleyin…' : mode === 'signIn' ? 'Giriş Yap' : 'Hesap Oluştur'}
            </button>
          </form>
        </div>

        <button
          type="button"
          onClick={onContinueWithoutAccount}
          className="w-full mt-4 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
        >
          Hesapsız devam et (veriler yalnızca bu cihazda kalır)
        </button>
      </div>
    </div>
  );
}
