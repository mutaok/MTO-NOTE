import React, { useState, useEffect } from 'react';
import {
  initDriveAuth,
  googleDriveSignIn,
  googleDriveSignOut,
  getDriveAccessToken,
} from '../lib/googleDriveAuth';
import { GoogleDriveService, DriveFile, DriveAbout } from '../lib/googleDriveService';
import { Notebook, Note, Task, MindMap } from '../types';
import {
  HardDrive,
  UploadCloud,
  DownloadCloud,
  RefreshCw,
  Trash2,
  ExternalLink,
  Search,
  CheckCircle,
  AlertCircle,
  LogOut,
  FileText,
  Clock,
  FolderOpen,
  FolderPlus,
  Eye,
  X,
  FileCode,
} from 'lucide-react';
import type { User } from 'firebase/auth';

interface GoogleDriveHubProps {
  notebooks: Notebook[];
  notes: Note[];
  tasks: Task[];
  mindmaps: MindMap[];
  onImportBackup: (data: {
    notebooks?: Notebook[];
    notes?: Note[];
    tasks?: Task[];
    mindmaps?: MindMap[];
  }) => void;
}

function formatBytes(bytesStr?: string | number): string {
  if (!bytesStr) return '0 B';
  const bytes = typeof bytesStr === 'string' ? parseInt(bytesStr, 10) : bytesStr;
  if (isNaN(bytes) || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export const GoogleDriveHub: React.FC<GoogleDriveHubProps> = ({
  notebooks,
  notes,
  tasks,
  mindmaps,
  onImportBackup,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getDriveAccessToken());
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [driveAbout, setDriveAbout] = useState<DriveAbout | null>(null);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'backups' | 'notes'>('all');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);

  // Destructive delete modal state (MANDATORY per skill)
  const [fileToDelete, setFileToDelete] = useState<DriveFile | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Restore confirmation modal state (MANDATORY per skill for mutating user data)
  const [fileToRestore, setFileToRestore] = useState<DriveFile | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  // File Preview modal state
  const [previewFile, setPreviewFile] = useState<DriveFile | null>(null);
  const [previewContent, setPreviewContent] = useState<string | null>(null);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);

  // Single Note Export to Drive modal state
  const [isExportNoteModalOpen, setIsExportNoteModalOpen] = useState(false);
  const [selectedNoteId, setSelectedNoteId] = useState<string>(notes[0]?.id || '');
  const [exportFormat, setExportFormat] = useState<'md' | 'txt' | 'json'>('md');
  const [isExportingNote, setIsExportingNote] = useState(false);

  useEffect(() => {
    const unsubscribe = initDriveAuth(
      (authUser, authToken) => {
        setUser(authUser);
        setToken(authToken);
      },
      () => {
        setUser(null);
        setToken(null);
        setDriveAbout(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const fetchDriveInfo = async (authToken = token) => {
    if (!authToken) return;
    try {
      const about = await GoogleDriveService.getAbout(authToken);
      setDriveAbout(about);
    } catch (e) {
      console.warn('Could not fetch drive about info:', e);
    }
  };

  const fetchFiles = async (authToken = token) => {
    if (!authToken) return;
    setIsLoadingFiles(true);
    setStatusMessage(null);
    try {
      const driveFiles = await GoogleDriveService.listFiles(authToken);
      setFiles(driveFiles);
      await fetchDriveInfo(authToken);
    } catch (err: any) {
      console.error(err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Drive dosyaları yüklenirken hata oluştu.',
      });
    } finally {
      setIsLoadingFiles(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchFiles(token);
    }
  }, [token]);

  const handleSignIn = async () => {
    setIsLoggingIn(true);
    setStatusMessage(null);
    try {
      const res = await googleDriveSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        setStatusMessage({
          type: 'success',
          text: `Google Drive başarıyla bağlandı (${res.user.email || 'Kullanıcı'})`,
        });
        await fetchFiles(res.accessToken);
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Google ile giriş başarısız oldu. Lütfen açılır pencere engelleyicinizi kontrol edin.',
      });
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    await googleDriveSignOut();
    setUser(null);
    setToken(null);
    setFiles([]);
    setDriveAbout(null);
    setStatusMessage({ type: 'info', text: 'Google Drive oturumu kapatıldı.' });
  };

  // Upload complete NoteFlow backup to Google Drive
  const handleBackupToDrive = async () => {
    if (!token) return;
    setIsUploading(true);
    setStatusMessage(null);
    try {
      const dateStr = new Date().toISOString().slice(0, 10);
      const timeStr = new Date().toTimeString().slice(0, 5).replace(':', '-');
      const filename = `NoteFlow_Yedek_${dateStr}_${timeStr}.json`;

      const backupPayload = {
        app: 'NoteFlow',
        version: '1.0.0',
        exportedAt: new Date().toISOString(),
        summary: {
          notebookCount: notebooks.length,
          noteCount: notes.length,
          taskCount: tasks.length,
          mindmapCount: mindmaps.length,
        },
        data: {
          notebooks,
          notes,
          tasks,
          mindmaps,
        },
      };

      const uploaded = await GoogleDriveService.uploadFile(
        token,
        filename,
        JSON.stringify(backupPayload, null, 2),
        'application/json'
      );

      setStatusMessage({
        type: 'success',
        text: `"${uploaded.name}" başarıyla Google Drive'ınıza yüklendi!`,
      });
      await fetchFiles(token);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Yedekleme yüklenirken hata oluştu.',
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Create a dedicated NoteFlow folder in Google Drive
  const handleCreateNoteFlowFolder = async () => {
    if (!token) return;
    setIsCreatingFolder(true);
    try {
      const folder = await GoogleDriveService.createFolder(token, 'NoteFlow Workspace');
      setStatusMessage({
        type: 'success',
        text: `"${folder.name}" klasörü Google Drive'ınızda oluşturuldu!`,
      });
      await fetchFiles(token);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Klasör oluşturulamadı.',
      });
    } finally {
      setIsCreatingFolder(false);
    }
  };

  // Export selected note to Google Drive
  const handleExportNoteToDrive = async () => {
    if (!token) return;
    const noteToExport = notes.find((n) => n.id === selectedNoteId);
    if (!noteToExport) return;

    setIsExportingNote(true);
    try {
      const sanitizedTitle = (noteToExport.title || 'Adsız Not').replace(/[\\/:*?"<>|]/g, '_');
      let filename = `${sanitizedTitle}.${exportFormat}`;
      let content = '';
      let mimeType = 'text/plain';

      if (exportFormat === 'md') {
        mimeType = 'text/markdown';
        content = `# ${noteToExport.title || 'Adsız Not'}\n\n` +
          `*Etiket:* ${noteToExport.tag || 'Kişisel'} | *Tarih:* ${noteToExport.date || 'Belirtilmedi'}\n\n` +
          `---\n\n${noteToExport.body || ''}`;
      } else if (exportFormat === 'json') {
        mimeType = 'application/json';
        content = JSON.stringify(noteToExport, null, 2);
      } else {
        mimeType = 'text/plain';
        content = `${noteToExport.title || 'Adsız Not'}\n\n${noteToExport.body || ''}`;
      }

      const uploaded = await GoogleDriveService.uploadFile(token, filename, content, mimeType);
      setStatusMessage({
        type: 'success',
        text: `"${uploaded.name}" başarıyla Google Drive'a aktarıldı!`,
      });
      setIsExportNoteModalOpen(false);
      await fetchFiles(token);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Not Drive\'a aktarılırken hata oluştu.',
      });
    } finally {
      setIsExportingNote(false);
    }
  };

  // Preview file content
  const handlePreviewFile = async (file: DriveFile) => {
    if (!token) return;
    setPreviewFile(file);
    setIsLoadingPreview(true);
    setPreviewContent(null);
    try {
      const content = await GoogleDriveService.getFileContent(token, file.id);
      setPreviewContent(content);
    } catch (err: any) {
      setPreviewContent(`Dosya içeriği yüklenemedi: ${err.message || 'Bilinmeyen hata'}`);
    } finally {
      setIsLoadingPreview(false);
    }
  };

  // Restore/Import from Google Drive
  const handleConfirmRestore = async () => {
    if (!token || !fileToRestore) return;
    setIsRestoring(true);
    try {
      const content = await GoogleDriveService.getFileContent(token, fileToRestore.id);
      const parsed = JSON.parse(content);

      if (parsed.data) {
        onImportBackup(parsed.data);
        setStatusMessage({
          type: 'success',
          text: `"${fileToRestore.name}" yedeği başarıyla içeri aktarıldı ve NoteFlow güncellendi!`,
        });
      } else {
        throw new Error('Dosya geçerli bir NoteFlow yedeği formatında değil.');
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Yedek geri yüklenirken hata oluştu.',
      });
    } finally {
      setIsRestoring(false);
      setFileToRestore(null);
    }
  };

  // Delete file from Drive
  const handleConfirmDelete = async () => {
    if (!token || !fileToDelete) return;
    setIsDeleting(true);
    try {
      await GoogleDriveService.deleteFile(token, fileToDelete.id);
      setFiles((prev) => prev.filter((f) => f.id !== fileToDelete.id));
      setStatusMessage({
        type: 'success',
        text: `"${fileToDelete.name}" Google Drive'dan silindi.`,
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Dosya silinirken hata oluştu.',
      });
    } finally {
      setIsDeleting(false);
      setFileToDelete(null);
    }
  };

  // Calculate quota percent
  const quotaLimit = driveAbout?.storageQuota?.limit ? parseInt(driveAbout.storageQuota.limit, 10) : 0;
  const quotaUsage = driveAbout?.storageQuota?.usage ? parseInt(driveAbout.storageQuota.usage, 10) : 0;
  const quotaPercent = quotaLimit > 0 ? Math.min(100, Math.round((quotaUsage / quotaLimit) * 100)) : 0;

  // Filtered files
  const filteredFiles = files.filter((f) => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (activeFilter === 'backups') return f.name.startsWith('NoteFlow_');
    if (activeFilter === 'notes') return f.name.endsWith('.md') || f.name.endsWith('.txt');
    return true;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="p-6 sm:p-7 rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-600 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md shadow-xs">
                <HardDrive className="w-7 h-7 text-white" />
              </span>
              <div>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight">Google Drive</h1>
                <p className="text-xs sm:text-sm text-blue-100 font-medium">
                  Bulut Depolama, Yedekleme ve Senkronizasyon Merkezi
                </p>
              </div>
            </div>
            <p className="text-blue-100/90 text-xs sm:text-sm max-w-2xl pt-1">
              Tüm notlarınızı, 11 defterinizi, görevlerinizi ve zihin haritalarınızı doğrudan kendi
              Google Drive hesabınıza aktarın, güvenle yedekleyin veya istediğiniz zaman geri yükleyin.
            </p>
          </div>

          {token && user ? (
            <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto">
              <button
                onClick={handleBackupToDrive}
                disabled={isUploading}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white text-blue-700 font-bold text-xs sm:text-sm hover:bg-blue-50 transition-all shadow-md active:scale-95 disabled:opacity-60 cursor-pointer"
              >
                <UploadCloud className={`w-4 h-4 ${isUploading ? 'animate-bounce' : ''}`} />
                <span>{isUploading ? 'Yükleniyor...' : 'Tam Yedek Al'}</span>
              </button>

              <button
                onClick={() => setIsExportNoteModalOpen(true)}
                disabled={notes.length === 0}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer backdrop-blur-sm"
                title="Tekil bir notu Drive'a metin/markdown olarak aktar"
              >
                <FileCode className="w-4 h-4" />
                <span>Not Aktar</span>
              </button>

              <button
                onClick={handleCreateNoteFlowFolder}
                disabled={isCreatingFolder}
                className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-all cursor-pointer backdrop-blur-sm"
                title="Drive'da 'NoteFlow Workspace' Klasörü Oluştur"
              >
                <FolderPlus className={`w-4 h-4 ${isCreatingFolder ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={() => fetchFiles()}
                disabled={isLoadingFiles}
                className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-all cursor-pointer backdrop-blur-sm"
                title="Dosyaları Yenile"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingFiles ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={handleSignOut}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-medium transition-all cursor-pointer"
                title="Çıkış Yap"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Çıkış</span>
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={isLoggingIn}
              className="flex items-center justify-center gap-3 px-6 py-3.5 rounded-2xl bg-white text-slate-800 font-bold text-sm hover:bg-slate-50 transition-all shadow-xl active:scale-95 disabled:opacity-60 cursor-pointer self-stretch md:self-auto"
            >
              <svg className="w-5 h-5" viewBox="0 0 48 48">
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
              </svg>
              <span>{isLoggingIn ? 'Bağlanıyor...' : 'Google Drive ile Bağlan'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Notification status bar */}
      {statusMessage && (
        <div
          className={`flex items-center justify-between gap-3 p-4 rounded-2xl text-sm border shadow-xs ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
              : statusMessage.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800'
              : 'bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800'
          }`}
        >
          <div className="flex items-center gap-3">
            {statusMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 flex-shrink-0 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
            )}
            <span className="font-medium">{statusMessage.text}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-xs opacity-70 hover:opacity-100 p-1"
          >
            ✕
          </button>
        </div>
      )}

      {!token ? (
        /* Not Connected State Card */
        <div className="p-8 sm:p-12 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-6 shadow-sm">
          <div className="w-20 h-20 rounded-3xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto shadow-inner">
            <HardDrive className="w-10 h-10" />
          </div>
          <div className="max-w-lg mx-auto space-y-2">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100">
              Google Drive Hesabınızı Bağlayın
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
              Google Drive hesabınızı entegre ederek tüm defterlerinizi, notlarınızı, görevlerinizi ve zihin haritalarınızı
              güvenli bulut alanınıza yedekleyin, cihazlar arası senkronize edin ve geçmiş yedeklerinizi tek tıkla geri yükleyin.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={handleSignIn}
              disabled={isLoggingIn}
              className="inline-flex items-center gap-3 px-7 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-all shadow-lg shadow-blue-500/25 active:scale-95 cursor-pointer"
            >
              <UploadCloud className="w-5 h-5" />
              <span>{isLoggingIn ? 'Bağlanıyor...' : 'Drive Erişim İzni Ver ve Bağlan'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto pt-4 text-left">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
              <span className="text-xl mb-1 block">🔒</span>
              <h3 className="font-bold text-xs text-slate-900 dark:text-slate-100 mb-0.5">Güvenli ve Özel</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Verileriniz yalnızca sizin Google Drive alanınızda saklanır.</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
              <span className="text-xl mb-1 block">⚡</span>
              <h3 className="font-bold text-xs text-slate-900 dark:text-slate-100 mb-0.5">Tek Tıkla Yedekleme</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">11 defter türü, görevler ve zihin haritaları tek dosyada.</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
              <span className="text-xl mb-1 block">📄</span>
              <h3 className="font-bold text-xs text-slate-900 dark:text-slate-100 mb-0.5">Markdown & Metin</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Notlarınızı .md ve .txt dosyası olarak da Drive'a aktarabilirsiniz.</p>
            </div>
          </div>
        </div>
      ) : (
        /* Connected State: Files List & Quick Stats */
        <div className="space-y-5">
          {/* Account Profile & Storage Quota Banner */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Account Card */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-3.5 shadow-xs">
              {driveAbout?.user?.photoLink ? (
                <img
                  src={driveAbout.user.photoLink}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full border border-slate-200 dark:border-slate-700 object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-base">
                  {(driveAbout?.user?.displayName || user?.email || 'U')[0].toUpperCase()}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-slate-400 dark:text-slate-500">Google Drive Hesabı</p>
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                  {driveAbout?.user?.displayName || user?.displayName || 'Google Kullanıcısı'}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                  {driveAbout?.user?.emailAddress || user?.email}
                </p>
              </div>
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
            </div>

            {/* Storage Quota Card */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Drive Depolama Alanı</span>
                  <span className="font-mono text-[11px] font-bold text-blue-600 dark:text-blue-400">
                    %{quotaPercent}
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-teal-500 transition-all duration-500"
                    style={{ width: `${quotaPercent}%` }}
                  />
                </div>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 flex justify-between">
                <span>Kullanılan: <strong>{formatBytes(quotaUsage)}</strong></span>
                <span>Toplam: <strong>{quotaLimit > 0 ? formatBytes(quotaLimit) : 'Sınırsız'}</strong></span>
              </div>
            </div>

            {/* Workspace Stats Card */}
            <div className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-slate-400 dark:text-slate-500">Mevcut Çalışma Alanı</p>
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-0.5">
                  {notebooks.length} Defter • {notes.length} Not
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {tasks.length} Görev • {mindmaps.length} Zihin Haritası
                </p>
              </div>
              <div className="p-3 rounded-2xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400">
                <FolderOpen className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Files Explorer Card */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            {/* Header / Filter Toolbar */}
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">
                    Google Drive Dosyaları ({files.length})
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Hesabınızdaki yedekler ve aktarılan belgeler
                  </p>
                </div>
              </div>

              {/* Filter Pills and Search */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 text-xs font-semibold">
                  <button
                    onClick={() => setActiveFilter('all')}
                    className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                      activeFilter === 'all'
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    Tümü
                  </button>
                  <button
                    onClick={() => setActiveFilter('backups')}
                    className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                      activeFilter === 'backups'
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    Yedekler
                  </button>
                  <button
                    onClick={() => setActiveFilter('notes')}
                    className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                      activeFilter === 'notes'
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    Notlar & Metinler
                  </button>
                </div>

                <div className="relative flex-1 sm:w-56">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Dosyalarda ara..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl text-xs bg-slate-100 dark:bg-slate-800 border-none text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Content List */}
            {isLoadingFiles ? (
              <div className="p-16 text-center text-slate-500 space-y-3">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-600" />
                <p className="text-sm font-medium">Google Drive dosyaları taranıyor...</p>
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="p-16 text-center text-slate-500 dark:text-slate-400 space-y-3.5">
                <HardDrive className="w-12 h-12 mx-auto text-slate-400 opacity-60" />
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    {searchQuery
                      ? 'Aramanıza uygun dosya bulunamadı.'
                      : 'Henüz Drive\'da bu filtrelere uygun dosya yok.'}
                  </p>
                  <p className="text-xs text-slate-400">
                    "Tam Yedek Al" butonuna basarak tüm çalışma alanınızı hemen Drive'a yükleyebilirsiniz.
                  </p>
                </div>
                <button
                  onClick={handleBackupToDrive}
                  disabled={isUploading}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700 transition-colors shadow-sm cursor-pointer"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>İlk Yedeğinizi Oluşturun</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredFiles.map((file) => {
                  const isNoteFlowBackup = file.name.startsWith('NoteFlow_');
                  const isMarkdown = file.name.endsWith('.md');
                  const isText = file.name.endsWith('.txt');

                  return (
                    <div
                      key={file.id}
                      className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <div className="flex items-start gap-3.5 min-w-0">
                        <div
                          className={`p-2.5 rounded-xl flex-shrink-0 ${
                            isNoteFlowBackup
                              ? 'bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400'
                              : isMarkdown || isText
                              ? 'bg-teal-100 dark:bg-teal-950 text-teal-600 dark:text-teal-400'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {isNoteFlowBackup ? (
                            <HardDrive className="w-5 h-5" />
                          ) : isMarkdown || isText ? (
                            <FileCode className="w-5 h-5" />
                          ) : (
                            <FileText className="w-5 h-5" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                              {file.name}
                            </p>
                            {isNoteFlowBackup && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200/50 dark:border-blue-900/40">
                                NoteFlow Yedeği
                              </span>
                            )}
                            {file.size && (
                              <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
                                ({formatBytes(file.size)})
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {file.modifiedTime && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(file.modifiedTime).toLocaleString('tr-TR')}
                              </span>
                            )}
                            <span className="truncate max-w-[200px] opacity-75">{file.mimeType}</span>
                          </div>
                        </div>
                      </div>

                      {/* File Actions */}
                      <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                        {/* Preview button */}
                        <button
                          onClick={() => handlePreviewFile(file)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                          title="İçeriği Önizle"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Önizle</span>
                        </button>

                        {/* Restore button for backup files */}
                        {isNoteFlowBackup && (
                          <button
                            onClick={() => setFileToRestore(file)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors cursor-pointer"
                            title="Bu yedeği NoteFlow'a geri yükle"
                          >
                            <DownloadCloud className="w-3.5 h-3.5" />
                            <span>Geri Yükle</span>
                          </button>
                        )}

                        {/* External link to Drive */}
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Google Drive'da Yeni Sekmede Aç"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}

                        {/* Safe Delete with confirmation modal */}
                        <button
                          onClick={() => setFileToDelete(file)}
                          className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title="Google Drive'dan Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Export Note to Drive Modal */}
      {isExportNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="max-w-md w-full p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
                  <FileCode className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  Notu Google Drive'a Aktar
                </h3>
              </div>
              <button
                onClick={() => setIsExportNoteModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              NoteFlow notunuzu doğrudan Google Drive hesabınıza bir dosya olarak kaydedin.
            </p>

            <div className="space-y-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Aktarılacak Not
                </label>
                <select
                  value={selectedNoteId}
                  onChange={(e) => setSelectedNoteId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 outline-none"
                >
                  {notes.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.title || 'Adsız Not'} ({n.tag || 'Not'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Dosya Formatı
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'md', label: 'Markdown (.md)' },
                    { id: 'txt', label: 'Düz Metin (.txt)' },
                    { id: 'json', label: 'JSON Verisi (.json)' },
                  ].map((fmt) => (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setExportFormat(fmt.id as any)}
                      className={`p-2 rounded-xl text-xs font-bold border transition-all cursor-pointer text-center ${
                        exportFormat === fmt.id
                          ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {fmt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsExportNoteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleExportNoteToDrive}
                disabled={isExportingNote}
                className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md active:scale-95 disabled:opacity-60 cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                <span>{isExportingNote ? 'Aktarılıyor...' : 'Drive\'a Kaydet'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* File Content Preview Modal */}
      {previewFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="max-w-2xl w-full max-h-[85vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText className="w-5 h-5 text-blue-600 shrink-0" />
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm truncate">
                  {previewFile.name}
                </h3>
              </div>
              <button
                onClick={() => setPreviewFile(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 flex-1 overflow-y-auto">
              {isLoadingPreview ? (
                <div className="p-12 text-center text-slate-500 space-y-2">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto text-blue-600" />
                  <p className="text-xs">Dosya içeriği okunuyor...</p>
                </div>
              ) : (
                <pre className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 text-xs font-mono text-slate-800 dark:text-slate-200 whitespace-pre-wrap break-words max-h-[50vh] overflow-y-auto">
                  {previewContent}
                </pre>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              {previewFile.webViewLink && (
                <a
                  href={previewFile.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Google Drive'da Aç</span>
                </a>
              )}
              <button
                onClick={() => setPreviewFile(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Explicit User Confirmation Modal for Destructive Delete (MANDATORY per skill) */}
      {fileToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="max-w-md w-full p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400">
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold">Google Drive Dosyasını Sil</h3>
                <p className="text-xs text-slate-400">Kalıcı işlem onayı</p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              <strong>"{fileToDelete.name}"</strong> dosyasını Google Drive hesabınızdan kalıcı olarak silmek istediğinize emin misiniz? Bu işlem geri alınamaz.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setFileToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                İptal
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white transition-colors cursor-pointer"
              >
                {isDeleting ? 'Siliniyor...' : 'Evet, Dosyayı Sil'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Explicit User Confirmation Modal for Data Mutating Restore (MANDATORY per skill) */}
      {fileToRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="max-w-md w-full p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-indigo-600 dark:text-indigo-400">
              <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50">
                <DownloadCloud className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold">Yedeği Geri Yükle</h3>
                <p className="text-xs text-slate-400">Veri senkronizasyon onayı</p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              <strong>"{fileToRestore.name}"</strong> yedeğindeki veriler NoteFlow çalışma alanınıza aktarılacak ve mevcut defter ve notlarınız güncellenecektir. Devam etmek istiyor musunuz?
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setFileToRestore(null)}
                disabled={isRestoring}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                İptal
              </button>
              <button
                onClick={handleConfirmRestore}
                disabled={isRestoring}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors cursor-pointer"
              >
                {isRestoring ? 'Yükleniyor...' : 'Evet, Yedeği Geri Yükle'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

