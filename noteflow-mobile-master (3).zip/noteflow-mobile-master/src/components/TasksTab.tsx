import React, { useMemo, useState } from 'react';
import { Task, Notebook } from '../types';
import {
  Plus,
  Calendar as CalendarIcon,
  Clock,
  CheckCircle2,
  Circle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Edit3,
  Filter,
  CheckSquare,
  BookOpen,
} from 'lucide-react';

interface TasksTabProps {
  tasks: Task[];
  notebooks?: Notebook[];
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string; notebookId?: string }) => void;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  editorTask?: Task | null;
  isEditorOpen?: boolean;
  onOpenEditor: (task?: Task) => void;
  onCloseEditor?: () => void;
  onOpenNoteWithDate?: (dateStr: string) => void;
}

const TABS = ['Bugün', 'Gelecek', 'Takvim', 'Tamamlanan'] as const;
type TabType = (typeof TABS)[number];

const LIST_PRESETS = ['Kişisel', 'İş', 'Fikir', 'Alışveriş', 'Proje', 'Akademik'];

const WEEKDAYS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
const MONTH_NAMES = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

export const TasksTab: React.FC<TasksTabProps> = ({
  tasks,
  notebooks = [],
  onToggleTask,
  onDeleteTask,
  onOpenEditor,
  onOpenNoteWithDate,
}) => {
  const [tab, setTab] = useState<TabType>('Bugün');
  const [listFilter, setListFilter] = useState<string>('Tümü');

  // Calendar view state
  const today = new Date();
  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(today);

  // Helper date strings
  const todayStr = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const toKey = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const selectedKey = useMemo(() => toKey(selectedDate), [selectedDate]);

  // Distinct lists from user tasks
  const availableLists = useMemo(() => {
    const set = new Set<string>();
    tasks.forEach((t) => {
      if (t.list) set.add(t.list);
    });
    return ['Tümü', ...Array.from(new Set([...LIST_PRESETS, ...Array.from(set)]))];
  }, [tasks]);

  // Filter tasks based on tab & list
  const filteredTasks = useMemo(() => {
    let result = tasks;

    if (listFilter !== 'Tümü') {
      result = result.filter((t) => t.list === listFilter);
    }

    if (tab === 'Bugün') {
      result = result.filter((t) => !t.done && (t.dueDate === todayStr || !t.dueDate));
    } else if (tab === 'Gelecek') {
      result = result.filter((t) => !t.done && t.dueDate && t.dueDate > todayStr);
    } else if (tab === 'Tamamlanan') {
      result = result.filter((t) => t.done);
    }

    return [...result].sort((a, b) => {
      if (a.dueDate && b.dueDate) {
        return a.dueDate.localeCompare(b.dueDate);
      }
      return (a.dueDate ? -1 : 1);
    });
  }, [tasks, tab, listFilter, todayStr]);

  // Calendar logic
  const calendarCells = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    const startDayIndex = (firstDay.getDay() + 6) % 7; // Monday = 0
    const totalDays = lastDay.getDate();

    const cells: (number | null)[] = [];
    for (let i = 0; i < startDayIndex; i++) {
      cells.push(null);
    }
    for (let day = 1; day <= totalDays; day++) {
      cells.push(day);
    }
    return cells;
  }, [viewDate]);

  const tasksByDate = useMemo(() => {
    const set = new Set<string>();
    tasks.forEach((t) => {
      if (t.dueDate) set.add(t.dueDate);
    });
    return set;
  }, [tasks]);

  const selectedDayTasks = useMemo(() => {
    return tasks.filter((t) => t.dueDate === selectedKey);
  }, [tasks, selectedKey]);

  const changeMonth = (delta: number) => {
    const next = new Date(viewDate.getFullYear(), viewDate.getMonth() + delta, 1);
    setViewDate(next);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Bar: Title + Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Hedeflerin
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Görevler ({tasks.length})
          </h1>
        </div>
        <button
          onClick={() => onOpenEditor()}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm transition-colors shadow-sm self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Görev Ekle</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-fit">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              tab === t
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Calendar View vs List View */}
      {tab === 'Takvim' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar Grid */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {MONTH_NAMES[viewDate.getMonth()]} {viewDate.getFullYear()}
              </h2>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => changeMonth(-1)}
                  className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => changeMonth(1)}
                  className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Weekday Labels */}
            <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-bold text-slate-400 mb-2">
              {WEEKDAYS.map((w) => (
                <div key={w} className="py-2">
                  {w}
                </div>
              ))}
            </div>

            {/* Day Cells */}
            <div className="grid grid-cols-7 gap-1">
              {calendarCells.map((day, idx) => {
                if (day === null) {
                  return <div key={`empty-${idx}`} className="h-14 p-1" />;
                }
                const cellDate = new Date(viewDate.getFullYear(), viewDate.getMonth(), day);
                const cellKey = toKey(cellDate);
                const isSelected = cellKey === selectedKey;
                const isCurrentToday = cellKey === todayStr;
                const hasTasks = tasksByDate.has(cellKey);

                return (
                  <button
                    key={cellKey}
                    onClick={() => setSelectedDate(cellDate)}
                    className={`h-14 p-1 rounded-xl flex flex-col items-center justify-center transition-all relative cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-500/20'
                        : isCurrentToday
                        ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-900'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <span className="text-xs">{day}</span>
                    {hasTasks && (
                      <span
                        className={`w-1.5 h-1.5 rounded-full mt-1 ${
                          isSelected ? 'bg-white' : 'bg-blue-500'
                        }`}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Day Details */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {selectedDate.getDate()} {MONTH_NAMES[selectedDate.getMonth()]}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {selectedDate.toLocaleDateString('tr-TR', { weekday: 'long', year: 'numeric' })}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {onOpenNoteWithDate && (
                    <button
                      onClick={() => onOpenNoteWithDate(selectedKey)}
                      className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 cursor-pointer"
                    >
                      + Not
                    </button>
                  )}
                  <button
                    onClick={() =>
                      onOpenEditor({
                        id: '',
                        title: '',
                        list: 'Kişisel',
                        dueDate: selectedKey,
                        dueTime: '',
                        done: false,
                        color: '#3B82F6',
                        createdAt: '',
                        updatedAt: '',
                      })
                    }
                    className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
                  >
                    + Görev
                  </button>
                </div>
              </div>

              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {selectedDayTasks.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    Bu gün için kayıtlı görev yok.
                  </div>
                ) : (
                  selectedDayTasks.map((t) => {
                    const linkedNotebook = notebooks.find((nb) => nb.id === t.notebookId);
                    return (
                      <div
                        key={t.id}
                        className="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30"
                      >
                        <div className="flex items-center gap-2.5 flex-1 min-w-0 mr-2">
                          <button
                            onClick={() => onToggleTask(t.id)}
                            className="text-slate-400 hover:text-blue-600 shrink-0 cursor-pointer"
                          >
                            {t.done ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                            ) : (
                              <Circle className="w-4 h-4" />
                            )}
                          </button>
                          <div className="truncate">
                            <p
                              className={`text-xs font-semibold truncate ${
                                t.done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                              }`}
                            >
                              {t.title}
                            </p>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                              {t.dueTime && <span>{t.dueTime}</span>}
                              {linkedNotebook && (
                                <span className="text-teal-600 dark:text-teal-400 flex items-center gap-0.5">
                                  <BookOpen className="w-2.5 h-2.5" />
                                  {linkedNotebook.name || linkedNotebook.title}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => onOpenEditor(t)}
                            className="p-1 rounded text-slate-400 hover:text-blue-600 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteTask(t.id)}
                            className="p-1 rounded text-slate-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Regular List View */
        <div className="space-y-4">
          {/* List Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 shrink-0 mr-1">
              <Filter className="w-3.5 h-3.5" /> Liste:
            </span>
            {availableLists.map((l) => (
              <button
                key={l}
                onClick={() => setListFilter(l)}
                className={`px-3 py-1 rounded-xl text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  listFilter === l
                    ? 'bg-blue-600 text-white'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {l}
              </button>
            ))}
          </div>

          {/* Tasks List */}
          {filteredTasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-12 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
                <CheckSquare className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Bu alanda görev bulunamadı
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Hedeflerine ulaşmak için yeni bir görev ekleyebilirsin.
              </p>
              <button
                onClick={() => onOpenEditor()}
                className="mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Yeni Görev Ekle
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredTasks.map((task) => {
                const linkedNotebook = notebooks.find((nb) => nb.id === task.notebookId);
                return (
                  <div
                    key={task.id}
                    className="group flex items-center justify-between p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500/80 hover:shadow-xs transition-all"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1 mr-4">
                      <button
                        onClick={() => onToggleTask(task.id)}
                        className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors shrink-0 cursor-pointer"
                      >
                        {task.done ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-50 dark:fill-emerald-950/40" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div className="truncate">
                        <h3
                          className={`text-sm font-semibold truncate ${
                            task.done
                              ? 'line-through text-slate-400 dark:text-slate-500'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {task.title}
                        </h3>

                        <div className="flex items-center gap-2 mt-1 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                          <span className="flex items-center gap-1.5">
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: task.color }}
                            />
                            <span className="font-medium text-slate-600 dark:text-slate-300">
                              {task.list}
                            </span>
                          </span>

                          {linkedNotebook && (
                            <span className="flex items-center gap-1 font-medium text-teal-600 dark:text-teal-400">
                              <BookOpen className="w-3 h-3" />
                              {linkedNotebook.name || linkedNotebook.title}
                            </span>
                          )}

                          {task.dueDate && (
                            <span className="flex items-center gap-1">
                              <CalendarIcon className="w-3 h-3 text-slate-400" />
                              {task.dueDate}
                            </span>
                          )}

                          {task.dueTime && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-slate-400" />
                              {task.dueTime}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onOpenEditor(task)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Düzenle"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteTask(task.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Sil"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
