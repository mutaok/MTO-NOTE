import React, { useState, useEffect } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
  initialTab?: 'source' | 'android' | 'desktop';
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  isDark,
  initialTab = 'source',
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [activeTab, setActiveTab] = useState<'source' | 'android' | 'desktop'>(initialTab);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
        onClose();
      }
      setDeferredPrompt(null);
    }
  };

  const handleCopyCommand = (cmd: string) => {
    navigator.clipboard.writeText(cmd).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
      <div
        className={`w-full max-w-xl rounded-3xl p-6 shadow-2xl border transition-all max-h-[90vh] overflow-y-auto ${
          isDark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-500 flex items-center justify-center text-white font-bold text-lg shadow-md shadow-teal-500/20">
              📲
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">NoteFlow'u Cihazınıza Yükleyin</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Android (APK & Bağımsız Uygulama) ve Masaüstü (Windows, macOS, Linux)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 font-bold transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex gap-2 p-1.5 mt-4 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/50">
          <button
            onClick={() => setActiveTab('source')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'source'
                ? 'bg-teal-500 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>📦</span>
            <span>Kaynak Kodları (ZIP)</span>
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'android'
                ? 'bg-teal-500 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>🤖</span>
            <span>Android (APK & PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('desktop')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'desktop'
                ? 'bg-teal-500 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>💻</span>
            <span>Masaüstü (Desktop)</span>
          </button>
        </div>

        {/* Tab 1: Full Source Code (ZIP) Content */}
        {activeTab === 'source' && (
          <div className="mt-4 space-y-4">
            {/* Direct Source ZIP Download Button */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-500/15 via-teal-500/15 to-emerald-500/10 border border-teal-500/40 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
                  NoteFlow Tam Proje Paketi (ZIP)
                </span>
              </div>
              <p className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 mb-3">
                Bu uygulamanın tüm dosyalarını (React, TypeScript, Defterler, Zihin Haritaları, Görevler, Supabase) tek tıkla indirin:
              </p>
              <a
                href="/downloads/noteflow-source-code.zip"
                download="noteflow-source-code.zip"
                className="w-full py-3.5 px-5 rounded-2xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm sm:text-base active:scale-[0.99] transition-all shadow-lg shadow-teal-500/30 flex items-center justify-center gap-2.5"
              >
                <span>📥</span>
                <span>NoteFlow Tüm Kaynak Kodunu İndir (.ZIP ~3.0 MB)</span>
              </a>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                ✓ 190+ kaynak dosyası • Eksiksiz React + Vite projesi • README ve Kurulum Kılavuzu dahil
              </p>
            </div>

            {/* Explanation Note for Flutter confusion */}
            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800/60 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5 text-sm">
                <span>⚠️</span>
                <span>Neden bilgisayarınızdaki Flutter eski APK'yı üretiyordu?</span>
              </div>
              <p className="leading-relaxed">
                Bilgisayarınızdaki <code>Desktop\NOTEFLOW\noteflow</code> klasörü eski/farklı bir projeydi. Bu sebeple orada <code>flutter build apk</code> çalıştırdığınızda buradaki NoteFlow değil, bambaşka bir uygulamanın APK'sı çıkıyordu.
              </p>
              <p className="leading-relaxed">
                Buradaki gerçek NoteFlow <strong>React + TypeScript + Vite</strong> projesidir. Yukarıdaki ZIP dosyasını indirerek bu çalışan uygulamanın <strong>bütün kaynak kodlarına</strong> sahip olabilirsiniz!
              </p>
            </div>

            {/* How to run locally */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold text-xs flex items-center justify-center">
                  💻
                </span>
                <h4 className="font-semibold text-sm">Bilgisayarınızda Çalıştırma (3 Adım)</h4>
              </div>
              <ol className="text-xs text-slate-600 dark:text-slate-300 space-y-2 list-decimal list-inside leading-relaxed">
                <li>İndirdiğiniz <code>noteflow-source-code.zip</code> dosyasını bilgisayarınızda bir klasöre çıkartın.</li>
                <li>Klasör içinde terminal açıp bağımlılıkları yükleyin:
                  <div className="relative my-1.5">
                    <pre className="p-2.5 rounded-xl bg-slate-950 text-teal-400 font-mono text-xs overflow-x-auto select-all">
                      npm install
                    </pre>
                    <button
                      onClick={() => handleCopyCommand('npm install')}
                      className="absolute right-2 top-1.5 px-2 py-0.5 rounded bg-teal-500 text-white text-[10px] font-medium"
                    >
                      {copied ? 'Kopyalandı' : 'Kopyala'}
                    </button>
                  </div>
                </li>
                <li>Uygulamayı yerel geliştirme modunda başlatın:
                  <div className="relative my-1.5">
                    <pre className="p-2.5 rounded-xl bg-slate-950 text-teal-400 font-mono text-xs overflow-x-auto select-all">
                      npm run dev
                    </pre>
                    <button
                      onClick={() => handleCopyCommand('npm run dev')}
                      className="absolute right-2 top-1.5 px-2 py-0.5 rounded bg-teal-500 text-white text-[10px] font-medium"
                    >
                      {copied ? 'Kopyalandı' : 'Kopyala'}
                    </button>
                  </div>
                  Tarayıcınızda <code>http://localhost:3000</code> adresinde açılacaktır.
                </li>
              </ol>
            </div>
          </div>
        )}

        {/* Tab 2: Android Content */}
        {activeTab === 'android' && (
          <div className="mt-4 space-y-4">
            {/* Direct APK Download Button (Primary) */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-500/20 to-emerald-500/10 border border-teal-500/40 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
                  Android APK Hazır & İmzalandı (v1.0.0)
                </span>
              </div>
              <p className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 mb-3">
                Doğrudan Android telefonunuza kurabileceğiniz imzalı resmi NoteFlow APK dosyası:
              </p>
              <a
                href="/downloads/noteflow-release.apk"
                download="noteflow-release.apk"
                className="w-full py-3.5 px-5 rounded-2xl bg-teal-500 text-white font-bold text-sm sm:text-base hover:bg-teal-600 active:scale-[0.99] transition-all shadow-lg shadow-teal-500/30 flex items-center justify-center gap-2.5"
              >
                <span>📥</span>
                <span>NoteFlow APK İndir (1.5 MB)</span>
              </a>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                ✓ Standalone Android paketi • Otomatik Supabase senkronizasyonlu • v1.0.0 Release
              </p>
            </div>

            {/* Quick 1-Click Install Button if supported */}
            {deferredPrompt && (
              <div className="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-center">
                <p className="text-xs sm:text-sm font-medium text-teal-600 dark:text-teal-400 mb-2.5">
                  Tarayıcınız doğrudan Android ana ekranına uygulama olarak eklemeyi destekliyor!
                </p>
                <button
                  onClick={handleInstallClick}
                  className="w-full py-3 px-4 rounded-2xl bg-slate-800 text-teal-400 border border-teal-500/40 font-semibold text-sm hover:bg-slate-700 active:scale-[0.99] transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <span>⚡</span>
                  <span>Android Cihazına Doğrudan Kur (PWA)</span>
                </button>
              </div>
            )}

            {/* Android Option 1: Chrome Ana Ekrana Ekle */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold text-xs flex items-center justify-center">
                  1
                </span>
                <h4 className="font-semibold text-sm">Tarayıcıdan Ana Ekrana Ekleme (Kolay Kurulum)</h4>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Google Chrome veya mobil tarayıcınızda bu adresteyken sağ üstteki <strong>üç nokta (⋮)</strong> menüsüne dokunup <strong>"Uygulamayı Yükle"</strong> ya da <strong>"Ana Ekrana Ekle"</strong> seçeneğini seçebilirsiniz.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Desktop Content */}
        {activeTab === 'desktop' && (
          <div className="mt-4 space-y-4">
            {/* Desktop Option 1: Chrome / Edge Masaüstü Uygulaması */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold text-xs flex items-center justify-center">
                  1
                </span>
                <h4 className="font-semibold text-sm">Windows & Mac Masaüstü Uygulaması (Tek Tık)</h4>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Chrome, Edge veya Brave tarayıcınızın adres çubuğunun en sağındaki <strong>"Uygulamayı Yükle" (⊕)</strong> simgesine tıklayın. NoteFlow masaüstünüze kısayol olarak eklenir, tarayıcı sekmeleri olmadan pencere içinde yerel masaüstü programı olarak çalışır.
              </p>
            </div>

            {/* Desktop Option 2: Local Node.js */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold text-xs flex items-center justify-center">
                  2
                </span>
                <h4 className="font-semibold text-sm">Kaynak Kodundan Masaüstünde Çalıştırma</h4>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                "Kaynak Kodları (ZIP)" sekmesinden projeyi indirip <code>npm install</code> ve <code>npm run dev</code> ile masaüstünüzde çalıştırabilirsiniz.
              </p>
            </div>
          </div>
        )}

        {/* Sync Guarantee Badge */}
        <div className="mt-5 p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
          <span className="text-base">⚡</span>
          <div className="leading-relaxed">
            <span className="font-bold text-teal-600 dark:text-teal-400">Çift Yönlü Supabase Senkronizasyonu: </span>
            Hangi platformdan (Android APK, PWA veya Masaüstü) not alırsanız alın, tüm notlarınız, defterleriniz ve görevleriniz aynı Supabase hesabınız altında anında eşitlenir.
          </div>
        </div>
      </div>
    </div>
  );
};
