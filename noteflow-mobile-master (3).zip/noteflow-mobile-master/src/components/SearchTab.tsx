import React, { useMemo, useState } from 'react';
import { MindMap, MindMapTreeDoc, Note, Task } from '../types';
import {
  Search,
  FileText,
  CheckSquare,
  Network,
  Calendar,
  Clock,
  ArrowRight,
} from 'lucide-react';

interface SearchTabProps {
  notes: Note[];
  tasks: Task[];
  mindmaps: MindMap[];
  onOpenNote: (note: Note) => void;
  onOpenTask: (task: Task) => void;
  onOpenMindMap: (map: MindMap) => void;
}

type SearchCategory = 'all' | 'notes' | 'tasks' | 'mindmaps';

export const SearchTab: React.FC<SearchTabProps> = ({
  notes,
  tasks,
  mindmaps,
  onOpenNote,
  onOpenTask,
  onOpenMindMap,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('all');

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) {
      return { notes: [], tasks: [], mindmaps: [] };
    }

    const matchedNotes =
      category === 'all' || category === 'notes'
        ? notes.filter(
            (n) =>
              n.title.toLowerCase().includes(q) ||
              n.body.toLowerCase().includes(q) ||
              n.tag.toLowerCase().includes(q),
          )
        : [];

    const matchedTasks =
      category === 'all' || category === 'tasks'
        ? tasks.filter(
            (t) => t.title.toLowerCase().includes(q) || t.list.toLowerCase().includes(q),
          )
        : [];

    const matchedMindMaps =
      category === 'all' || category === 'mindmaps'
        ? mindmaps.filter((m) => {
            if (m.title.toLowerCase().includes(q) || m.type.toLowerCase().includes(q)) return true;
            if (m.data.kind === 'tree') {
              const str = JSON.stringify((m.data as MindMapTreeDoc).root).toLowerCase();
              return str.includes(q);
            }
            return false;
          })
        : [];

    return { notes: matchedNotes, tasks: matchedTasks, mindmaps: matchedMindMaps };
  }, [notes, tasks, mindmaps, query, category]);

  const totalResults =
    filtered.notes.length + filtered.tasks.length + filtered.mindmaps.length;

  return (
    <div className="space-y-6 animate-fadeIn max-w-4xl mx-auto">
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          Evrensel Arama
        </span>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          Tüm Kaynaklarda Ara
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Notlar, yapılacak görevler ve zihin haritaları içinde eşzamanlı hızlı arama yapın.
        </p>
      </div>

      {/* Large Search Input */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="Not başlığı, görev veya zihin haritası ara..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-base shadow-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 placeholder-slate-400"
        />
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all' as SearchCategory, label: 'Tümü' },
          { id: 'notes' as SearchCategory, label: `Notlar (${notes.length})` },
          { id: 'tasks' as SearchCategory, label: `Görevler (${tasks.length})` },
          { id: 'mindmaps' as SearchCategory, label: `Mind Maps (${mindmaps.length})` },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setCategory(item.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
              category === item.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Results Container */}
      {!query.trim() ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Aramaya başlayın
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
            Yukarıdaki arama kutusuna bir kelime veya etiket yazarak arama yapabilirsiniz.
          </p>
        </div>
      ) : totalResults === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center">
          <p className="text-sm font-semibold text-slate-900 dark:text-white">
            "{query}" ile eşleşen sonuç bulunamadı.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Farklı bir anahtar kelime veya kategori seçmeyi deneyin.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Matched Notes */}
          {filtered.notes.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-blue-600" />
                Notlar ({filtered.notes.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {filtered.notes.map((note) => (
                  <div
                    key={note.id}
                    onClick={() => onOpenNote(note)}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500 hover:shadow-xs transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors truncate">
                        {note.title}
                      </h4>
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 shrink-0">
                        {note.tag}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                      {note.body}
                    </p>
                    {note.date && (
                      <div className="mt-2 text-[11px] text-blue-600 dark:text-blue-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {note.date}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matched Tasks */}
          {filtered.tasks.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <CheckSquare className="w-4 h-4 text-emerald-600" />
                Görevler ({filtered.tasks.length})
              </h2>
              <div className="space-y-2">
                {filtered.tasks.map((task) => (
                  <div
                    key={task.id}
                    onClick={() => onOpenTask(task)}
                    className="flex items-center justify-between p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-500 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-3 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: task.color }}
                      />
                      <span
                        className={`text-sm font-semibold truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 ${
                          task.done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {task.title}
                      </span>
                      <span className="text-xs text-slate-400">• {task.list}</span>
                    </div>
                    {task.dueDate && (
                      <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0 ml-2">
                        <Calendar className="w-3 h-3" />
                        {task.dueDate}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matched Mind Maps */}
          {filtered.mindmaps.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Network className="w-4 h-4 text-purple-600" />
                Mind Map Şemaları ({filtered.mindmaps.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {filtered.mindmaps.map((map) => (
                  <div
                    key={map.id}
                    onClick={() => onOpenMindMap(map)}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-500 hover:shadow-xs transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                        {map.title}
                      </h4>
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 capitalize">
                        {map.type}
                      </span>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Görüntülemek için tıkla</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
