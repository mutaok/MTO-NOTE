import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Filter,
  Lock,
  Unlock,
  Sparkles,
  Layers,
  GraduationCap,
  Kanban,
  BookHeart,
  Users,
  Plane,
  UtensilsCrossed,
  PieChart,
  Activity,
  Lightbulb,
  Code2,
  ChevronRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { Notebook, NotebookType, Note, Task } from '../../types';
import { NOTEBOOK_TYPES_CONFIG } from '../../data/notebookTemplates';
import { CreateNotebookModal } from './CreateNotebookModal';
import { NotebookDetailView } from './NotebookDetailView';

interface NotebooksHubProps {
  notebooks: Notebook[];
  notes: Note[];
  tasks: Task[];
  onSaveNotebook: (notebook: Omit<Notebook, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onOpenNoteEditor: (note?: Note) => void;
  onOpenTaskEditor: (task?: Task) => void;
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onToggleTask: (id: string) => void;
  onNavigateToMindMap?: () => void;
}

const TYPE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  academic: GraduationCap,
  project: Kanban,
  journal: BookHeart,
  meeting: Users,
  reading: BookOpen,
  travel: Plane,
  recipe: UtensilsCrossed,
  finance: PieChart,
  fitness: Activity,
  brainstorm: Lightbulb,
  code: Code2,
};

export function NotebooksHub({
  notebooks,
  notes,
  tasks,
  onSaveNotebook,
  onOpenNoteEditor,
  onOpenTaskEditor,
  onSaveNote,
  onSaveTask,
  onToggleTask,
  onNavigateToMindMap,
}: NotebooksHubProps) {
  const [selectedNotebookId, setSelectedNotebookId] = useState<string | null>(() => {
    return localStorage.getItem('noteflow_selected_notebook_id');
  });
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const activeNotebook = useMemo(() => {
    if (!selectedNotebookId) return null;
    return notebooks.find((nb) => nb.id === selectedNotebookId) || null;
  }, [notebooks, selectedNotebookId]);

  const handleSelectNotebook = (nb: Notebook | null) => {
    if (nb) {
      setSelectedNotebookId(nb.id);
      localStorage.setItem('noteflow_selected_notebook_id', nb.id);
    } else {
      setSelectedNotebookId(null);
      localStorage.removeItem('noteflow_selected_notebook_id');
    }
  };

  // If a notebook is selected, show its full dedicated workspace!
  if (activeNotebook) {
    return (
      <NotebookDetailView
        notebook={activeNotebook}
        allNotes={notes}
        allTasks={tasks}
        onBack={() => handleSelectNotebook(null)}
        onOpenNoteEditor={onOpenNoteEditor}
        onOpenTaskEditor={onOpenTaskEditor}
        onSaveNote={onSaveNote}
        onSaveTask={onSaveTask}
        onToggleTask={onToggleTask}
        onNavigateToMindMap={onNavigateToMindMap}
      />
    );
  }

  // Filter notebooks
  const filteredNotebooks = notebooks.filter((nb) => {
    const notebookName = nb.name || nb.title || '';
    const matchesFilter = filterType === 'all' || nb.type === filterType;
    const matchesSearch =
      notebookName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (nb.description && nb.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner: Defter Türleri Manifestosu */}
      <div className="bg-[#ffffff] text-slate-800 border border-slate-200/80 rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full text-xs font-semibold tracking-wide text-indigo-700">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Defter = Tür + Şablon + Görünüm + Özel Alanlar + Otomasyon
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            11 İşlevsel Defter Türü ile Kişiselleştirilmiş Deneyim
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Ders için Cornell ve formül kütüphanesi, proje için Kanban ve Gantt, günlük için duygu & enerji takibi, tarifler için porsiyon ölçekleyici ve pişirme sayacı otomatik açılır.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              id="btn-open-create-notebook"
              onClick={() => setIsCreateModalOpen(true)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Yeni Defter Oluştur
            </button>
          </div>
        </div>

        {/* Decorative Grid BG effect */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:16px_16px]" />
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Defter adı veya açıklama ile ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-2xs"
          />
        </div>

        {/* Type Filter Pills */}
        <div className="flex flex-wrap gap-1.5 overflow-x-auto pb-1 max-w-2xl">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filterType === 'all'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            Tümü ({notebooks.length})
          </button>

          {(Object.keys(NOTEBOOK_TYPES_CONFIG) as NotebookType[]).map((typeKey) => {
            const config = NOTEBOOK_TYPES_CONFIG[typeKey];
            const IconComp = TYPE_ICONS[typeKey] || BookOpen;
            const count = notebooks.filter((n) => n.type === typeKey).length;
            if (count === 0 && filterType !== typeKey) return null;

            return (
              <button
                key={typeKey}
                onClick={() => setFilterType(typeKey)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
                  filterType === typeKey
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                }`}
              >
                <IconComp className="w-3.5 h-3.5" />
                {config.name} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Notebooks Grid (11 Defter Görünümü) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredNotebooks.map((nb) => {
          const config = NOTEBOOK_TYPES_CONFIG[nb.type] || NOTEBOOK_TYPES_CONFIG.academic;
          const IconComponent = TYPE_ICONS[nb.type] || BookOpen;
          const noteCount = notes.filter((n) => n.notebookId === nb.id).length;

          return (
            <div
              key={nb.id}
              onClick={() => handleSelectNotebook(nb)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/80 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group relative overflow-hidden"
            >
              {/* Top Row: Icon, Type Badge, Lock */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform"
                      style={{ backgroundColor: nb.color || config.color }}
                    >
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                        {config.name}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                        {nb.name || nb.title}
                      </h3>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                  {nb.description || config.description}
                </p>

                {/* Specialized Tool Chips */}
                {(() => {
                  const tools = config.specialTools || config.keyFeatures || [];
                  return (
                    <div className="flex flex-wrap gap-1 mb-4">
                      {tools.slice(0, 3).map((tool, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 bg-slate-50 dark:bg-slate-800/80 rounded text-[10px] font-medium text-slate-600 dark:text-slate-400"
                        >
                          • {tool}
                        </span>
                      ))}
                      {tools.length > 3 && (
                        <span className="px-1.5 py-0.5 text-[10px] text-slate-400 font-mono">
                          +{tools.length - 3}
                        </span>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Bottom Row: Note Count & Open Trigger */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono">
                  {noteCount} not kayıtlı
                </span>
                <span className="font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                  Çalışma Alanını Aç <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Modal */}
      <CreateNotebookModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreate={(newNotebook) => {
          onSaveNotebook(newNotebook);
        }}
      />
    </div>
  );
}
