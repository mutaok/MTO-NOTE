import React, { useState, useEffect } from 'react';
import {
  UtensilsCrossed,
  Timer,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Minus,
  Check,
  Flame,
  Clock,
  Sparkles,
  ShoppingCart,
  ChevronRight,
  ChefHat,
  Scale,
  FileText,
} from 'lucide-react';
import { RecipeData, Note, Task } from '../../types';
import { StorageService } from '../../data/storage';
import { showToast } from '../Toast';

interface RecipeWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function RecipeWorkspace({
  notebookId,
  notes,
  onSaveNote,
  onSaveTask,
}: RecipeWorkspaceProps) {
  const [recipes, setRecipes] = useState<RecipeData[]>(() => StorageService.getRecipes());
  const [selectedRecipe, setSelectedRecipe] = useState<RecipeData>(recipes[0] || ({} as any));

  // Servings Scaling State
  const [currentServings, setCurrentServings] = useState<number>(selectedRecipe.servings || 4);

  // Cooking Mode
  const [isCookingMode, setIsCookingMode] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  // Integrated Cooking Timer
  const [timerSeconds, setTimerSeconds] = useState(12 * 60); // 12 mins default
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => setTimerSeconds((s) => s - 1), 1000);
    } else if (timerSeconds === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      alert('Süre doldu! Yemeğiniz hazır!');
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  // Scaler ratio
  const scaleRatio = selectedRecipe.servings ? currentServings / selectedRecipe.servings : 1;
  const recipeSteps = selectedRecipe.instructions || selectedRecipe.steps || [];
  const prepTimeDisplay = selectedRecipe.prepTime ?? selectedRecipe.prepTimeMinutes ?? 15;
  const cookTimeDisplay = selectedRecipe.cookTime ?? selectedRecipe.cookTimeMinutes ?? 20;

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Export ingredients to tasks (Alışveriş Listesi)
  const handleExportToShoppingList = () => {
    selectedRecipe.ingredients.forEach((ing) => {
      const scaledAmount = ing.amount * scaleRatio;
      onSaveTask({
        notebookId,
        title: `[Market] ${ing.name} (${scaledAmount % 1 === 0 ? scaledAmount : scaledAmount.toFixed(1)} ${ing.unit})`,
        list: 'Alışveriş',
        dueDate: new Date().toISOString().slice(0, 10),
        dueTime: '17:00',
        done: false,
        color: '#F97316',
        priority: 'orta',
      });
    });
    showToast(`${selectedRecipe.ingredients.length} malzeme Alışveriş Listesi görevlerine eklendi!`);
  };

  const handleSaveRecipeAsNote = () => {
    const ingList = (selectedRecipe.ingredients || [])
      .map((ing) => `- ${ing.amount * scaleRatio} ${ing.unit} ${ing.name}`)
      .join('\n');
    const stepList = recipeSteps.map((st, i) => `${i + 1}. ${st}`).join('\n');
    const content = `🍳 ${selectedRecipe.title}\n\nPorsiyon: ${currentServings}\nHazırlık: ${prepTimeDisplay} dk | Pişirme: ${cookTimeDisplay} dk\n\nMalzemeler:\n${ingList}\n\nHazırlanışı:\n${stepList}`;

    onSaveNote({
      notebookId,
      title: `Tarif: ${selectedRecipe.title}`,
      body: content,
      tag: 'Tarif',
      date: new Date().toISOString().slice(0, 10),
    });
    showToast('Tarif defter notlarına kaydedildi!');
  };

  return (
    <div className="space-y-6">
      {/* Recipe Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-orange-100 dark:bg-orange-950/60 text-orange-600 rounded-xl">
              <ChefHat className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 dark:text-orange-400">
                Özel Tarif & Mutfak Notu
              </span>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{selectedRecipe.title}</h3>
              <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                <span className="flex items-center gap-1 font-mono">
                  <Clock className="w-3.5 h-3.5" /> Hazırlık: {prepTimeDisplay} dk
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 font-mono">
                  <Flame className="w-3.5 h-3.5 text-orange-500" /> Pişirme: {cookTimeDisplay} dk
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-save-recipe-note"
              onClick={handleSaveRecipeAsNote}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <FileText className="w-3.5 h-3.5" />
              Tarifi Not Olarak Kaydet
            </button>
            <button
              id="btn-export-shopping-list"
              onClick={handleExportToShoppingList}
              className="px-3 py-1.5 bg-orange-50 dark:bg-orange-950 text-orange-700 dark:text-orange-300 hover:bg-orange-100 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              Alışveriş Listesine Aktar
            </button>
            <button
              id="btn-toggle-cooking-mode"
              onClick={() => setIsCookingMode(!isCookingMode)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm ${
                isCookingMode
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 hover:opacity-90'
              }`}
            >
              <ChefHat className="w-3.5 h-3.5" />
              {isCookingMode ? 'Standart Görünüme Dön' : 'Pişirme Modunu Başlat'}
            </button>
          </div>
        </div>
      </div>

      {/* ADIM ADIM PİŞİRME MODU (FULLSCREEN / FOCUS EXPERIENCE) */}
      {isCookingMode ? (
        <div className="bg-orange-50/50 dark:bg-orange-950/20 border-2 border-orange-300 dark:border-orange-800 rounded-2xl p-8 space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-700 dark:text-orange-400">
              Adım {currentStepIndex + 1} / {recipeSteps.length}
            </span>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-3 py-1 rounded-lg border text-xs font-mono font-bold text-orange-600">
              <Timer className="w-4 h-4" />
              {formatTimer(timerSeconds)}
            </div>
          </div>

          <p className="text-xl sm:text-2xl font-semibold text-slate-900 dark:text-slate-100 leading-relaxed max-w-3xl">
            {recipeSteps[currentStepIndex]}
          </p>

          <div className="flex items-center justify-between pt-4 border-t border-orange-200 dark:border-orange-900">
            <button
              disabled={currentStepIndex === 0}
              onClick={() => setCurrentStepIndex((i) => Math.max(0, i - 1))}
              className="px-5 py-2.5 bg-white dark:bg-slate-800 rounded-xl text-sm font-semibold border disabled:opacity-40"
            >
              ← Önceki Adım
            </button>

            {currentStepIndex < recipeSteps.length - 1 ? (
              <button
                onClick={() => setCurrentStepIndex((i) => Math.min(recipeSteps.length - 1, i + 1))}
                className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-sm font-semibold shadow-md"
              >
                Sonraki Adım →
              </button>
            ) : (
              <button
                onClick={() => {
                  alert('Tebrikler! Tarif başarıyla tamamlandı, afiyet olsun!');
                  setIsCookingMode(false);
                }}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-md"
              >
                Pişirmeyi Bitir
              </button>
            )}
          </div>
        </div>
      ) : (
        /* STANDART TARİF GÖRÜNÜMÜ */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Malzeme Listesi & Porsiyon Ölçekleme */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-700 dark:text-orange-400 flex items-center gap-1.5">
                <UtensilsCrossed className="w-4 h-4" />
                Malzemeler
              </h4>

              {/* Servings Scaler Controls */}
              <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                <button
                  onClick={() => setCurrentServings((s) => Math.max(1, s - 1))}
                  className="p-1 text-slate-500 hover:text-orange-600"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="text-xs font-bold font-mono px-1">{currentServings} Kişilik</span>
                <button
                  onClick={() => setCurrentServings((s) => s + 1)}
                  className="p-1 text-slate-500 hover:text-orange-600"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Scaled Ingredients */}
            <div className="space-y-2">
              {selectedRecipe.ingredients.map((ing, idx) => {
                const scaledAmount = ing.amount * scaleRatio;
                return (
                  <div
                    key={idx}
                    className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg text-xs flex items-center justify-between"
                  >
                    <span className="font-medium text-slate-800 dark:text-slate-200">{ing.name}</span>
                    <span className="font-mono font-bold text-orange-600 dark:text-orange-400">
                      {scaledAmount % 1 === 0 ? scaledAmount : scaledAmount.toFixed(1)} {ing.unit}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Besin Değerleri Paneli */}
            {selectedRecipe.nutrition && (
              <div className="p-3 bg-orange-50/40 dark:bg-orange-950/20 rounded-xl border border-orange-100 dark:border-orange-900/40 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-orange-800 dark:text-orange-300 block">
                  Besin Değerleri (Porsiyon Başına)
                </span>
                <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
                  <div className="p-1.5 bg-white dark:bg-slate-900 rounded">
                    <span className="text-[10px] text-slate-400 block">Kalori</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedRecipe.nutrition.calories}</span>
                  </div>
                  <div className="p-1.5 bg-white dark:bg-slate-900 rounded">
                    <span className="text-[10px] text-slate-400 block">Protein</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedRecipe.nutrition.protein}g</span>
                  </div>
                  <div className="p-1.5 bg-white dark:bg-slate-900 rounded">
                    <span className="text-[10px] text-slate-400 block">Karb</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedRecipe.nutrition.carbs}g</span>
                  </div>
                  <div className="p-1.5 bg-white dark:bg-slate-900 rounded">
                    <span className="text-[10px] text-slate-400 block">Yağ</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedRecipe.nutrition.fat}g</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Adımlar & Pişirme Zamanlayıcısı */}
          <div className="lg:col-span-2 space-y-4">
            {/* Pişirme Zamanlayıcısı Widget */}
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 dark:bg-orange-950 text-orange-600 rounded-lg">
                  <Timer className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">Mutfak Pişirme Zamanlayıcısı</h5>
                  <div className="text-2xl font-mono font-extrabold text-orange-600 dark:text-orange-400">
                    {formatTimer(timerSeconds)}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  id="btn-timer-toggle"
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  {isTimerRunning ? 'Durdur' : 'Başlat'}
                </button>
                <button
                  id="btn-timer-reset"
                  onClick={() => {
                    setIsTimerRunning(false);
                    setTimerSeconds(12 * 60);
                  }}
                  className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-500 hover:text-slate-800"
                  title="Sıfırla"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Adım Adım Hazırlanış */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-700 dark:text-orange-400">
                Hazırlanış Adımları ({recipeSteps.length} Adım)
              </h4>
              <div className="space-y-3">
                {recipeSteps.map((step: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg text-xs leading-relaxed">
                    <span className="w-6 h-6 rounded-full bg-orange-100 dark:bg-orange-950 text-orange-700 dark:text-orange-300 font-bold flex items-center justify-center shrink-0 font-mono text-[11px]">
                      {idx + 1}
                    </span>
                    <span className="text-slate-800 dark:text-slate-200 pt-0.5">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
