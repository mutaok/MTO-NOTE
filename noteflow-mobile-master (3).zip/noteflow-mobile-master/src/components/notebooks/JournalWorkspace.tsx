import React, { useState } from 'react';
import {
  BookHeart,
  Smile,
  Meh,
  Frown,
  Heart,
  Sparkles,
  Lock,
  Unlock,
  Calendar as CalendarIcon,
  Sun,
  Cloud,
  CloudRain,
  Check,
  Plus,
  TrendingUp,
  Droplets,
  Dumbbell,
  BookOpen,
  Compass,
} from 'lucide-react';
import { MoodEntry, Note } from '../../types';
import { StorageService } from '../../data/storage';
import { DAILY_REFLECTION_QUESTIONS } from '../../data/notebookTemplates';

interface JournalWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onOpenNoteEditor: (note?: Note) => void;
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  isLocked?: boolean;
  onUnlockRequest?: () => void;
}

export function JournalWorkspace({
  notebookId,
  notes,
  onOpenNoteEditor,
  onSaveNote,
  isLocked = false,
  onUnlockRequest,
}: JournalWorkspaceProps) {
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>(() => StorageService.getMoodEntries());
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().slice(0, 10));

  // Current Day Form State
  const [todayMood, setTodayMood] = useState<'çok_iyi' | 'mutlu' | 'sakin' | 'yorgun' | 'stresli'>('çok_iyi');
  const [todayEnergy, setTodayEnergy] = useState<number>(5);
  const [todayWeather, setTodayWeather] = useState<'güneşli' | 'bulutlu' | 'yağmurlu' | 'karlı'>('güneşli');
  const [todayHabits, setTodayHabits] = useState({ water: true, exercise: true, reading: false, meditation: true });
  const [gratitude1, setGratitude1] = useState('');
  const [gratitude2, setGratitude2] = useState('');
  const [gratitude3, setGratitude3] = useState('');
  const [reflectionNote, setReflectionNote] = useState('');

  const handleSaveDayEntry = () => {
    const gratitudeList = [gratitude1, gratitude2, gratitude3].filter((g) => g.trim().length > 0);
    const newEntry: MoodEntry = {
      id: 'mood_' + Date.now(),
      date: selectedDate,
      mood: todayMood,
      energyLevel: todayEnergy,
      weather: todayWeather,
      habits: todayHabits,
      gratitude: gratitudeList.length > 0 ? gratitudeList : ['Güne huzurla başlayabildiğim için'],
      reflection: reflectionNote || 'Bugün verimli ve dingin geçti.',
    };

    const existsIndex = moodEntries.findIndex((m) => m.date === selectedDate);
    let updated: MoodEntry[];
    if (existsIndex >= 0) {
      updated = [...moodEntries];
      updated[existsIndex] = newEntry;
    } else {
      updated = [newEntry, ...moodEntries];
    }
    setMoodEntries(updated);
    StorageService.saveMoodEntries(updated);

    // Also persist as a note
    onSaveNote({
      notebookId,
      title: `${selectedDate} Günlük & Şükran Kaydı`,
      body: `### Ruh Hali & Enerji\nRuh Hali: ${(todayMood || '').replace('_', ' ')} | Enerji: ${todayEnergy}/5 | Hava: ${todayWeather}\n\n### Bugün Neye Minnettarım?\n${(gratitudeList || []).map((g, i) => `${i + 1}. ${g}`).join('\n')}\n\n### Günlük Değerlendirme\n${reflectionNote || ''}`,
      tag: 'Günlük',
      date: selectedDate,
    });

    alert('Günlük kaydınız başarıyla kaydedildi!');
  };

  const handleUseQuestion = (q: string) => {
    setReflectionNote((prev) => (prev ? `${prev}\n\n**${q}**\n` : `**${q}**\n`));
  };

  return (
    <div className="space-y-6">
      {/* Date Bar & Weather Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-100 dark:bg-amber-950/60 text-amber-600 rounded-xl">
            <BookHeart className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Günlük Farkındalık & Ruh Hali Takibi
            </h3>
            <p className="text-xs text-slate-500">
              Düşüncelerinizi kaydedin, alışkanlıklarınızı ve enerji eğrinizi izleyin.
            </p>
          </div>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-3">
          <label className="text-xs font-medium text-slate-500 flex items-center gap-1">
            <CalendarIcon className="w-3.5 h-3.5" /> Tarih:
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
        </div>
      </div>

      {/* Mood & Energy Trend SVG Graph */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" />
            Haftalık Enerji & Ruh Hali Grafiği
          </h4>
          <span className="text-[11px] text-slate-400">1 (Düşük) - 5 (Yüksek) Skala</span>
        </div>

        {/* Simple Scaled Bar/Point Visualizer */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 pt-2">
          {moodEntries.slice(0, 7).map((entry, idx) => (
            <div key={idx} className="flex flex-col items-center bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 font-mono mb-1">{entry.date ? entry.date.slice(5) : ''}</span>
              <div className="w-full bg-slate-200 dark:bg-slate-700 h-16 rounded-md flex items-end justify-center p-1 relative overflow-hidden">
                <div
                  className="w-full bg-linear-to-t from-amber-500 to-orange-400 rounded-sm transition-all duration-300"
                  style={{ height: `${(entry.energyLevel / 5) * 100}%` }}
                />
              </div>
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400 mt-1.5 font-mono">
                {entry.energyLevel}/5
              </span>
              <span className="text-[10px] text-slate-500 uppercase mt-0.5">{entry.mood.replace('_', ' ')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Input Form: Mood, Energy, Weather, Habits, Gratitude, Reflection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Daily Entry Card */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-5">
          {/* Mood Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Bugünkü Ruh Halin
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[
                { key: 'çok_iyi', label: 'Çok İyi', emoji: '🌟' },
                { key: 'mutlu', label: 'Mutlu', emoji: '😊' },
                { key: 'sakin', label: 'Sakin', emoji: '🌿' },
                { key: 'yorgun', label: 'Yorgun', emoji: '😴' },
                { key: 'stresli', label: 'Stresli', emoji: '⚡' },
              ].map((m) => (
                <button
                  key={m.key}
                  type="button"
                  onClick={() => setTodayMood(m.key as any)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    todayMood === m.key
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-900 dark:text-amber-200 shadow-sm'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="text-2xl mb-1">{m.emoji}</div>
                  <div className="text-xs font-medium">{m.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Energy Slider & Weather */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <div className="flex justify-between text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                <span>Enerji Seviyesi</span>
                <span className="text-amber-600 font-mono font-extrabold">{todayEnergy} / 5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={todayEnergy}
                onChange={(e) => setTodayEnergy(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                Hava Durumu
              </label>
              <div className="flex gap-2">
                {[
                  { key: 'güneşli', icon: Sun, label: 'Güneşli' },
                  { key: 'bulutlu', icon: Cloud, label: 'Bulutlu' },
                  { key: 'yağmurlu', icon: CloudRain, label: 'Yağmurlu' },
                ].map((w) => {
                  const Icon = w.icon;
                  return (
                    <button
                      key={w.key}
                      type="button"
                      onClick={() => setTodayWeather(w.key as any)}
                      className={`flex-1 py-1.5 px-2 rounded-lg border text-xs font-medium flex items-center justify-center gap-1 transition-colors ${
                        todayWeather === w.key
                          ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-800 dark:text-amber-300'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {w.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Habit Tracker */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Günlük Alışkanlıklar
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { key: 'water', label: '2.5L Su', icon: Droplets },
                { key: 'exercise', label: 'Egzersiz', icon: Dumbbell },
                { key: 'reading', label: 'Okuma', icon: BookOpen },
                { key: 'meditation', label: 'Meditasyon', icon: Compass },
              ].map((h) => {
                const isChecked = (todayHabits as any)[h.key];
                const Icon = h.icon;
                return (
                  <button
                    key={h.key}
                    type="button"
                    onClick={() => setTodayHabits({ ...todayHabits, [h.key]: !isChecked })}
                    className={`p-2.5 rounded-lg border flex items-center gap-2 text-xs font-medium transition-all ${
                      isChecked
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-emerald-800 dark:text-emerald-300 font-semibold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {h.label}
                    {isChecked && <Check className="w-3.5 h-3.5 ml-auto text-emerald-600" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Gratitude List (3 Things) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5 text-rose-500" />
              Bugün Neye Minnettarım? (3 Şükran Maddesi)
            </label>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="1. Minnettarlık duyduğum bir durum veya insan..."
                value={gratitude1}
                onChange={(e) => setGratitude1(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
              />
              <input
                type="text"
                placeholder="2. Günün bana kattığı güzel bir an..."
                value={gratitude2}
                onChange={(e) => setGratitude2(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
              />
              <input
                type="text"
                placeholder="3. Kendimde takdir ettiğim bir şey..."
                value={gratitude3}
                onChange={(e) => setGratitude3(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          {/* Free Reflection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Günün Düşünceleri & Notları
            </label>
            <textarea
              rows={4}
              value={reflectionNote}
              onChange={(e) => setReflectionNote(e.target.value)}
              placeholder="Bugün zihninden geçenleri özgürce dök..."
              className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 leading-relaxed"
            />
          </div>

          <button
            id="btn-save-day-entry"
            onClick={handleSaveDayEntry}
            className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-sm transition-colors"
          >
            Günlük Girişini Kaydet
          </button>
        </div>

        {/* Right Col: Daily Question Prompts */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 flex items-center gap-1.5 mb-3">
              <Sparkles className="w-4 h-4" />
              Günün Soru Önerileri
            </h4>
            <p className="text-xs text-slate-500 mb-3">
              Sorulardan birine tıklayarak doğrudan bugünün notuna ekleyin:
            </p>
            <div className="space-y-2">
              {DAILY_REFLECTION_QUESTIONS.map((q, i) => (
                <button
                  key={i}
                  onClick={() => handleUseQuestion(q)}
                  className="w-full text-left p-2.5 rounded-lg border border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-800/60 hover:bg-amber-50 hover:border-amber-300 dark:hover:bg-amber-950/20 text-xs text-slate-800 dark:text-slate-200 transition-colors"
                >
                  "{q}"
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
