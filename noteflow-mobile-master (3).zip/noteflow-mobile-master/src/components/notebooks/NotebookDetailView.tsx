import React, { useState } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Zap,
  Users,
  Lock,
  Unlock,
  Download,
  Plus,
  Search,
  BookOpen,
  FileText,
  Calendar,
  Grid,
  Check,
  Share2,
  Settings,
  GraduationCap,
  Kanban,
  BookHeart,
  Plane,
  UtensilsCrossed,
  PieChart,
  Activity,
  Lightbulb,
  Code2,
} from 'lucide-react';
import { Notebook, Note, Task, PaperTexture } from '../../types';
import { NOTEBOOK_TYPES_CONFIG } from '../../data/notebookTemplates';
import { AcademicWorkspace } from './AcademicWorkspace';
import { ProjectWorkspace } from './ProjectWorkspace';
import { JournalWorkspace } from './JournalWorkspace';
import { MeetingWorkspace } from './MeetingWorkspace';
import { ReadingWorkspace } from './ReadingWorkspace';
import { TravelWorkspace } from './TravelWorkspace';
import { RecipeWorkspace } from './RecipeWorkspace';
import { FinanceWorkspace } from './FinanceWorkspace';
import { FitnessWorkspace } from './FitnessWorkspace';
import { BrainstormWorkspace } from './BrainstormWorkspace';
import { CodeWorkspace } from './CodeWorkspace';
import { AISuiteModal } from './AISuiteModal';
import { AutomationsModal } from './AutomationsModal';
import { CollaborationModal } from './CollaborationModal';
import { SecurityPinModal } from './SecurityPinModal';

interface NotebookDetailViewProps {
  notebook: Notebook;
  allNotes: Note[];
  allTasks: Task[];
  onBack: () => void;
  onOpenNoteEditor: (note?: Note) => void;
  onOpenTaskEditor: (task?: Task) => void;
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onToggleTask: (id: string) => void;
  onNavigateToMindMap?: () => void;
}

const TYPE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  academic: GraduationCap,
  project: Kanban,
  journal: BookHeart,
  meeting: Users,
  reading: BookOpen,
  travel: Plane,
  recipe: UtensilsCrossed,
  finance: PieChart,
  fitness: Activity,
  brainstorm: Lightbulb,
  code: Code2,
};

export function NotebookDetailView({
  notebook,
  allNotes,
  allTasks,
  onBack,
  onOpenNoteEditor,
  onOpenTaskEditor,
  onSaveNote,
  onSaveTask,
  onToggleTask,
  onNavigateToMindMap,
}: NotebookDetailViewProps) {
  // Main view inside this notebook: 'workspace' (specialized tools) vs 'notes' (note collection)
  const [activeMainView, setActiveMainView] = useState<'workspace' | 'notes'>('workspace');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPaperTexture, setCurrentPaperTexture] = useState<PaperTexture>(
    notebook.paperTexture || 'lined'
  );

  // Modals state
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isAutomationsOpen, setIsAutomationsOpen] = useState(false);
  const [isCollabOpen, setIsCollabOpen] = useState(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(!notebook.isLocked);

  const config = NOTEBOOK_TYPES_CONFIG[notebook.type] || NOTEBOOK_TYPES_CONFIG.academic;
  const TypeIcon = TYPE_ICONS[notebook.type] || BookOpen;
  const notebookName = notebook.name || notebook.title || 'İsimsiz Defter';

  // Notes belonging to this notebook
  const notebookNotes = allNotes.filter(
    (n) => n.notebookId === notebook.id || (notebookName && n.tag === notebookName)
  );

  const filteredNotes = notebookNotes.filter(
    (n) =>
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.body.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleExportMarkdown = () => {
    const text = `# ${notebookName}\n\n${notebook.description || ''}\n\nDefter Türü: ${config.name}\nOluşturulma: ${notebook.createdAt || new Date().toISOString()}\n\n---\n\n## Notlar\n\n${(notebookNotes || [])
      .map((n) => `### ${n.title}\n*Tarih: ${n.date || 'Belirtilmedi'}*\n\n${n.body}\n`)
      .join('\n---\n\n')}`;

    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${notebookName.replace(/\s+/g, '_')}_defter.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Get paper texture background class
  const getTextureBgClass = () => {
    if (currentPaperTexture === 'lined') return 'bg-lined-pattern';
    if (currentPaperTexture === 'grid') return 'bg-grid-pattern';
    if (currentPaperTexture === 'dots') return 'bg-dots-pattern';
    return '';
  };

  return (
    <div className={`space-y-6 ${getTextureBgClass()}`}>
      {/* Top Breadcrumb & Controls Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              id="btn-back-to-notebooks"
              onClick={onBack}
              className="p-2 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
              title="Tüm Defterlere Dön"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-white shadow-xs"
                style={{ backgroundColor: notebook.color || config.color }}
              >
                <TypeIcon className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    {config.name} Defteri
                  </span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mt-0.5">
                  {notebookName}
                </h2>
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Kağıt Dokusu Değiştirici */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              {[
                { id: 'lined', label: 'Çizgili' },
                { id: 'grid', label: 'Kareli' },
                { id: 'dots', label: 'Noktalı' },
                { id: 'plain', label: 'Düz' },
              ].map((tex) => (
                <button
                  key={tex.id}
                  onClick={() => setCurrentPaperTexture(tex.id as any)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                    currentPaperTexture === tex.id
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-2xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tex.label}
                </button>
              ))}
            </div>

            <button
              id="btn-open-ai-suite"
              onClick={() => setIsAiOpen(true)}
              className="px-3 py-1.5 bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              AI Asistanı
            </button>

            <button
              id="btn-open-automations"
              onClick={() => setIsAutomationsOpen(true)}
              className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              Otomasyonlar
            </button>

            <button
              id="btn-open-collaboration"
              onClick={() => setIsCollabOpen(true)}
              className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 flex items-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5 text-sky-500" />
              Paylaş
            </button>

            <button
              id="btn-export-notebook"
              onClick={handleExportMarkdown}
              className="p-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100"
              title="Markdown / Notları İndir"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* View Tabs: Özelleştirilmiş Araçlar vs Defter Notları */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            id="tab-specialized-workspace"
            onClick={() => setActiveMainView('workspace')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeMainView === 'workspace'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            <TypeIcon className="w-3.5 h-3.5" />
            {config.name} Çalışma Alanı
          </button>

          <button
            id="tab-notebook-notes-list"
            onClick={() => setActiveMainView('notes')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeMainView === 'notes'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Defter Notları ({notebookNotes.length})
          </button>
        </div>
      </div>

      {/* RENDER ACTIVE VIEW */}
      {activeMainView === 'notes' ? (
        /* NOTES LIST VIEW */
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Bu defterde ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border rounded-xl bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800"
              />
            </div>

            <button
              onClick={() =>
                onOpenNoteEditor({
                  id: '',
                  title: '',
                  body: '',
                  tag: notebook.name || notebook.title || 'Genel',
                  notebookId: notebook.id,
                  date: new Date().toISOString().slice(0, 10),
                  createdAt: '',
                  updatedAt: '',
                })
              }
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Yeni Not Ekle
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredNotes.map((note) => (
              <div
                key={note.id}
                onClick={() => onOpenNoteEditor(note)}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 shadow-xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between min-h-[170px]"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded text-[10px] font-semibold">
                      {note.tag || notebook.name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{note.date}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 line-clamp-1">
                    {note.title}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-3 mt-1.5 leading-relaxed">
                    {note.body}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-indigo-600 font-semibold">
                  <span>İncele & Düzenle</span>
                  <span>→</span>
                </div>
              </div>
            ))}

            {filteredNotes.length === 0 && (
              <div className="col-span-full py-12 text-center bg-white dark:bg-slate-900 border border-dashed rounded-2xl p-8">
                <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs text-slate-500">Bu defterde henüz not bulunmuyor.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* SPECIALIZED WORKSPACE BY NOTEBOOK TYPE */
        <div>
          {notebook.type === 'academic' && (
            <AcademicWorkspace
              notebookId={notebook.id}
              notes={notebookNotes}
              onOpenNoteEditor={onOpenNoteEditor}
              onSaveNote={onSaveNote}
            />
          )}

          {notebook.type === 'project' && (
            <ProjectWorkspace
              notebookId={notebook.id}
              tasks={allTasks}
              notes={notebookNotes}
              onToggleTask={onToggleTask}
              onSaveTask={onSaveTask}
              onOpenTaskEditor={onOpenTaskEditor}
            />
          )}

          {notebook.type === 'journal' && (
            <JournalWorkspace
              notebookId={notebook.id}
              notes={notebookNotes}
              onOpenNoteEditor={onOpenNoteEditor}
              onSaveNote={onSaveNote}
            />
          )}

              {notebook.type === 'meeting' && (
                <MeetingWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                  onSaveTask={onSaveTask}
                />
              )}

              {notebook.type === 'reading' && (
                <ReadingWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                />
              )}

              {notebook.type === 'travel' && (
                <TravelWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                />
              )}

              {notebook.type === 'recipe' && (
                <RecipeWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                  onSaveTask={onSaveTask}
                />
              )}

              {notebook.type === 'finance' && (
                <FinanceWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                />
              )}

              {notebook.type === 'fitness' && (
                <FitnessWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                />
              )}

              {notebook.type === 'brainstorm' && (
                <BrainstormWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                  onNavigateToMindMap={onNavigateToMindMap}
                />
              )}

              {notebook.type === 'code' && (
                <CodeWorkspace
                  notebookId={notebook.id}
                  notes={notebookNotes}
                  onSaveNote={onSaveNote}
                />
              )}
        </div>
      )}

      {/* MODALS */}
      <AISuiteModal
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        notebookName={notebookName}
        onSaveGeneratedNote={(note) => onSaveNote({ ...note, notebookId: notebook.id })}
        onSaveGeneratedTask={(task) => onSaveTask({ ...task, notebookId: notebook.id })}
      />

      <AutomationsModal
        isOpen={isAutomationsOpen}
        onClose={() => setIsAutomationsOpen(false)}
        notebookId={notebook.id}
      />

      <CollaborationModal
        isOpen={isCollabOpen}
        onClose={() => setIsCollabOpen(false)}
        notebookName={notebookName}
      />
    </div>
  );
}
