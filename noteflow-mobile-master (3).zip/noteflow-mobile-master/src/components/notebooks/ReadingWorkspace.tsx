import React, { useState } from 'react';
import {
  BookOpen,
  Bookmark,
  Star,
  Quote,
  Check,
  Plus,
  ArrowRight,
  Sparkles,
  Layers,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { BookRecord, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface ReadingWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function ReadingWorkspace({ notebookId, notes, onSaveNote }: ReadingWorkspaceProps) {
  const [books, setBooks] = useState<BookRecord[]>(() => StorageService.getBooks());
  const [activeShelf, setActiveShelf] = useState<'tümü' | 'okunuyor' | 'okunacak' | 'tamamlandı'>('tümü');
  const [selectedBook, setSelectedBook] = useState<BookRecord | null>(books[0] || null);

  // New book state
  const [isAddingBook, setIsAddingBook] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    isbn: '',
    totalPages: 300,
    readPages: 0,
    status: 'okunuyor' as const,
    rating: 5,
  });

  // Quote state for selected book
  const [newQuoteText, setNewQuoteText] = useState('');
  const [newQuotePage, setNewQuotePage] = useState<number>(1);

  const handleUpdateReadPages = (bookId: string, pages: number) => {
    const updated = books.map((b) => {
      if (b.id !== bookId) return b;
      const readPages = Math.min(pages, b.totalPages);
      const isFinished = readPages >= b.totalPages;
      return {
        ...b,
        readPages,
        status: isFinished ? ('tamamlandı' as const) : b.status,
        finishDate: isFinished ? new Date().toISOString().slice(0, 10) : b.finishDate,
      };
    });
    setBooks(updated);
    StorageService.saveBooks(updated);
    if (selectedBook && selectedBook.id === bookId) {
      setSelectedBook(updated.find((b) => b.id === bookId) || null);
    }
  };

  const handleAddBook = () => {
    if (!newBook.title) return;
    const item: BookRecord = {
      id: 'book_' + Date.now(),
      ...newBook,
      quotes: [],
    };
    const updated = [item, ...books];
    setBooks(updated);
    StorageService.saveBooks(updated);
    setSelectedBook(item);
    setIsAddingBook(false);
    setNewBook({ title: '', author: '', isbn: '', totalPages: 300, readPages: 0, status: 'okunuyor', rating: 5 });
  };

  const handleAddQuote = () => {
    if (!selectedBook || !newQuoteText.trim()) return;
    const quote = { text: newQuoteText.trim(), page: newQuotePage };
    const updated = books.map((b) =>
      b.id === selectedBook.id ? { ...b, quotes: [...b.quotes, quote] } : b
    );
    setBooks(updated);
    StorageService.saveBooks(updated);
    setSelectedBook({ ...selectedBook, quotes: [...selectedBook.quotes, quote] });
    setNewQuoteText('');
  };

  const filteredBooks = books.filter(
    (b) => activeShelf === 'tümü' || b.status === activeShelf
  );

  return (
    <div className="space-y-6">
      {/* Shelf Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'tümü', label: `Tüm Kitaplar (${books.length})` },
            { id: 'okunuyor', label: `Şu An Okunanlar (${books.filter((b) => b.status === 'okunuyor').length})` },
            { id: 'okunacak', label: `Okunacaklar (${books.filter((b) => b.status === 'okunacak').length})` },
            { id: 'tamamlandı', label: `Tamamlananlar (${books.filter((b) => b.status === 'tamamlandı').length})` },
          ].map((shelf) => (
            <button
              key={shelf.id}
              onClick={() => setActiveShelf(shelf.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeShelf === shelf.id
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {shelf.label}
            </button>
          ))}
        </div>

        <button
          id="btn-open-add-book"
          onClick={() => setIsAddingBook(!isAddingBook)}
          className="px-3 py-1.5 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Yeni Kitap Ekle
        </button>
      </div>

      {/* Add Book Form */}
      {isAddingBook && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 shadow-sm">
          <h4 className="text-xs font-bold uppercase text-slate-700 dark:text-slate-300">Yeni Kitap Kaydı</h4>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input
              type="text"
              placeholder="Kitap Adı..."
              value={newBook.title}
              onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
              className="px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="text"
              placeholder="Yazar..."
              value={newBook.author}
              onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
              className="px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="text"
              placeholder="ISBN..."
              value={newBook.isbn}
              onChange={(e) => setNewBook({ ...newBook, isbn: e.target.value })}
              className="px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="number"
              placeholder="Toplam Sayfa..."
              value={newBook.totalPages}
              onChange={(e) => setNewBook({ ...newBook, totalPages: Number(e.target.value) })}
              className="px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsAddingBook(false)}
              className="px-3 py-1.5 text-xs text-slate-500"
            >
              İptal
            </button>
            <button
              onClick={handleAddBook}
              className="px-4 py-1.5 bg-violet-600 text-white rounded-lg text-xs font-medium"
            >
              Kaydet
            </button>
          </div>
        </div>
      )}

      {/* Bookshelf Grid & Detail Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bookshelf View (Cards) */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredBooks.map((book) => {
            const progress = Math.round((book.readPages / book.totalPages) * 100);
            return (
              <div
                key={book.id}
                onClick={() => setSelectedBook(book)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  selectedBook?.id === book.id
                    ? 'bg-violet-50/50 dark:bg-violet-950/30 border-violet-500 shadow-sm'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-violet-300'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        book.status === 'tamamlandı'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : book.status === 'okunuyor'
                          ? 'bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {book.status}
                    </span>
                    <div className="flex text-amber-400">
                      {Array.from({ length: book.rating || 5 }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400" />
                      ))}
                    </div>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 line-clamp-1">
                    {book.title}
                  </h4>
                  <p className="text-xs text-slate-500 mb-3">{book.author}</p>
                </div>

                {/* Reading Progress */}
                <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-500">
                      {book.readPages} / {book.totalPages} sayfa
                    </span>
                    <span className="font-bold text-violet-600 dark:text-violet-400">%{progress}</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-violet-600 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Book Details & Quotes & Character Map */}
        {selectedBook && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] text-slate-400 font-mono">ISBN: {selectedBook.isbn || 'Belirtilmedi'}</span>
                {selectedBook.status === 'tamamlandı' && (
                  <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Okundu Rafında
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{selectedBook.title}</h3>
              <p className="text-xs text-slate-500">{selectedBook.author}</p>
            </div>

            {/* Quick Page Update Slider */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Sayfa İlerlemesini Güncelle</span>
                <span className="font-mono text-violet-600">
                  {selectedBook.readPages} / {selectedBook.totalPages}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max={selectedBook.totalPages}
                value={selectedBook.readPages}
                onChange={(e) => handleUpdateReadPages(selectedBook.id, Number(e.target.value))}
                className="w-full accent-violet-600"
              />
            </div>

            {/* Quotes Library */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-violet-700 dark:text-violet-400 flex items-center gap-1.5">
                <Quote className="w-3.5 h-3.5" />
                Alıntılar Kütüphanesi ({selectedBook.quotes.length})
              </h4>

              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {selectedBook.quotes.map((q, i) => (
                  <div key={i} className="p-2.5 bg-violet-50/40 dark:bg-violet-950/20 rounded-lg border border-violet-100 dark:border-violet-900/40 text-xs italic text-slate-800 dark:text-slate-200">
                    "{q.text}"
                    {q.page && <span className="block not-italic text-[10px] text-slate-400 font-mono mt-1">- Sayfa {q.page}</span>}
                  </div>
                ))}
              </div>

              {/* Add Quote */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <textarea
                  rows={2}
                  placeholder="Yeni bir alıntı ekle..."
                  value={newQuoteText}
                  onChange={(e) => setNewQuoteText(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 leading-relaxed"
                />
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Sayfa No"
                    value={newQuotePage}
                    onChange={(e) => setNewQuotePage(Number(e.target.value))}
                    className="w-24 px-2.5 py-1 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
                  />
                  <button
                    onClick={handleAddQuote}
                    className="flex-1 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-xs font-medium"
                  >
                    Alıntıyı Kaydet
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
