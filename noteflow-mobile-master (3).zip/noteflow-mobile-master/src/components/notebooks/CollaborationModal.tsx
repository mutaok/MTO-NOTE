import React, { useState } from 'react';
import { X, Users, UserPlus, Shield, Copy, Check, Mail, Share2 } from 'lucide-react';
import { Collaborator } from '../../types';

interface CollaborationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notebookName: string;
}

export function CollaborationModal({ isOpen, onClose, notebookName }: CollaborationModalProps) {
  const [collaborators, setCollaborators] = useState<Collaborator[]>([
    { id: 'c1', name: 'Can Demir', email: 'can@example.com', role: 'owner' },
    { id: 'c2', name: 'Selin Kaya', email: 'selin@team.io', role: 'editor' },
    { id: 'c3', name: 'Mehmet Eren', email: 'mehmet@team.io', role: 'viewer' },
  ]);

  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'editor' | 'viewer'>('editor');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim()) return;
    const item: Collaborator = {
      id: 'c_' + Date.now(),
      name: newEmail.split('@')[0],
      email: newEmail.trim(),
      role: newRole,
    };
    setCollaborators([...collaborators, item]);
    setNewEmail('');
  };

  const handleCopyShareLink = () => {
    navigator.clipboard.writeText(`https://noteflow.app/share/notebook/${encodeURIComponent(notebookName)}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl space-y-5 my-8">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Ekip Paylaşımı & Yetkiler</h3>
              <p className="text-xs text-slate-500">"{notebookName}" defteri üzerinde ortak çalışma</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invite Form */}
        <form onSubmit={handleInvite} className="flex gap-2">
          <input
            type="email"
            required
            placeholder="Kullanıcı e-posta adresi..."
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            className="flex-1 px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
          />
          <select
            value={newRole}
            onChange={(e) => setNewRole(e.target.value as any)}
            className="px-2.5 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-semibold"
          >
            <option value="editor">Düzenleyici</option>
            <option value="viewer">İzleyici</option>
          </select>
          <button
            type="submit"
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold"
          >
            Davet Et
          </button>
        </form>

        {/* Collaborators List */}
        <div className="space-y-2.5 divide-y divide-slate-100 dark:divide-slate-800 max-h-56 overflow-y-auto pr-1">
          {collaborators.map((c) => (
            <div key={c.id} className="pt-2 flex items-center justify-between text-xs">
              <div>
                <div className="font-semibold text-slate-900 dark:text-slate-100">{c.name}</div>
                <div className="text-[11px] text-slate-400">{c.email}</div>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                  c.role === 'owner'
                    ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                    : c.role === 'editor'
                    ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {c.role === 'owner' ? 'Sahibi' : c.role === 'editor' ? 'Düzenleyici' : 'İzleyici'}
              </span>
            </div>
          ))}
        </div>

        {/* Share Link Box */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
          <div className="text-xs text-slate-500 font-mono truncate">
            https://noteflow.app/share/notebook/...
          </div>
          <button
            onClick={handleCopyShareLink}
            className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 flex items-center gap-1.5 shrink-0"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedLink ? 'Kopyalandı' : 'Bağlantıyı Kopyala'}
          </button>
        </div>
      </div>
    </div>
  );
}
