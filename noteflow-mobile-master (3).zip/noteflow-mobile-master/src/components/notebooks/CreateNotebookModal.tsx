import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Lock,
  Layers,
  GraduationCap,
  Kanban,
  BookHeart,
  Users,
  BookOpen,
  Plane,
  UtensilsCrossed,
  PieChart,
  Activity,
  Lightbulb,
  Code2,
  Check,
} from 'lucide-react';
import { Notebook, NotebookType, PaperTexture } from '../../types';
import { NOTEBOOK_TYPES_CONFIG } from '../../data/notebookTemplates';

interface CreateNotebookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (notebook: Omit<Notebook, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const TYPE_ICONS: Record<NotebookType, React.ComponentType<{ className?: string }>> = {
  academic: GraduationCap,
  project: Kanban,
  journal: BookHeart,
  meeting: Users,
  reading: BookOpen,
  travel: Plane,
  recipe: UtensilsCrossed,
  finance: PieChart,
  fitness: Activity,
  brainstorm: Lightbulb,
  code: Code2,
};

export function CreateNotebookModal({ isOpen, onClose, onCreate }: CreateNotebookModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedType, setSelectedType] = useState<NotebookType>('academic');
  const [paperTexture, setPaperTexture] = useState<PaperTexture>('lined');

  const scrollContainerRef = React.useRef<HTMLDivElement>(null);
  const typeGridRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (isOpen) {
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTop = 0;
      }
      if (typeGridRef.current) {
        typeGridRef.current.scrollTop = 0;
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentTypeConfig = NOTEBOOK_TYPES_CONFIG[selectedType];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onCreate({
      title: name.trim(),
      name: name.trim(),
      description: description.trim() || currentTypeConfig.description,
      type: selectedType,
      color: currentTypeConfig.accentColor,
      icon: currentTypeConfig.iconName,
      isLocked: false,
      paperTexture,
      views: currentTypeConfig.defaultViews,
      noteCount: 0,
      collaborators: [],
    });

    onClose();
  };

  return (
    <div
      ref={scrollContainerRef}
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs p-3 sm:p-5 flex flex-col items-center justify-start sm:justify-center"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-4 sm:p-6 shadow-2xl space-y-5 my-4 sm:my-auto shrink-0">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 rounded-xl">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Yeni Defter Oluştur</h3>
              <p className="text-xs text-slate-500">
                11 işlevsel defter türünden birini seçin; araçlar ve şablonlar otomatik yüklensin.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Defter Türü Seçimi (11 Tür) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                1. Defter Türü (11 İşlevsel Paket)
              </label>
              <span className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                Seçili: {currentTypeConfig.name}
              </span>
            </div>
            <div
              ref={typeGridRef}
              className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 max-h-60 sm:max-h-72 overflow-y-auto p-1.5 border border-slate-200/80 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40"
            >
              {(Object.keys(NOTEBOOK_TYPES_CONFIG) as NotebookType[]).map((typeKey) => {
                const config = NOTEBOOK_TYPES_CONFIG[typeKey];
                const IconComponent = TYPE_ICONS[typeKey];
                const isSelected = selectedType === typeKey;
                return (
                  <button
                    key={typeKey}
                    type="button"
                    onClick={() => {
                      setSelectedType(typeKey);
                      if (!name) setName(config.name);
                    }}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                      isSelected
                        ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-600 text-indigo-950 dark:text-indigo-200 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <IconComponent className="w-4 h-4" />
                      {isSelected && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                    </div>
                    <span className="text-xs font-bold leading-tight line-clamp-1">{config.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Type Capabilities Preview Banner */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 text-xs space-y-1.5">
            <div className="flex items-center justify-between font-semibold text-slate-800 dark:text-slate-200">
              <span>{currentTypeConfig.name} Paketi İle Birlikte Gelen Araçlar:</span>
              <span className="text-[10px] px-2 py-0.5 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 rounded">
                Otomatik Aktif
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {(currentTypeConfig.specialTools || currentTypeConfig.keyFeatures || []).map((tool, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-[11px] text-slate-600 dark:text-slate-300"
                >
                  ✓ {tool}
                </span>
              ))}
            </div>
          </div>

          {/* Name & Description */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                2. Defter Adı
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Örn. Algoritmalar & Veri Yapıları, 2026 Ürün Yol Haritası..."
                className="w-full px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                Açıklama (Opsiyonel)
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Defterin amacını kısaca belirtin..."
                className="w-full px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          {/* Paper Texture Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              3. Kağıt Dokusu (Not Sayfası Arka Planı)
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'plain', label: 'Düz Kağıt' },
                { id: 'lined', label: 'Çizgili Kağıt' },
                { id: 'grid', label: 'Kareli Kağıt' },
                { id: 'dots', label: 'Noktalı (Bullet)' },
              ].map((tex) => (
                <button
                  key={tex.id}
                  type="button"
                  onClick={() => setPaperTexture(tex.id as any)}
                  className={`p-2 rounded-lg border text-xs font-medium transition-all ${
                    paperTexture === tex.id
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {tex.label}
                </button>
              ))}
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-500 hover:text-slate-800"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-sm transition-colors"
            >
              Defteri Oluştur ve Başla
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
