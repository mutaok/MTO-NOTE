import React, { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  ThumbsUp,
  Heart,
  Plus,
  Trash2,
  Network,
  Wand2,
  Compass,
  Tag,
  Shuffle,
  ChevronRight,
} from 'lucide-react';
import { StickyIdea, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface BrainstormWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onNavigateToMindMap?: () => void;
}

const INSPIRATION_PROMPTS = [
  'Eğer bütçe ve teknik sınırımız sıfır olsaydı bu sorunu nasıl çözerdik?',
  'Bu fikrin tam zıttını uygulasaydık ortaya ne çıkardı?',
  'Bir çocuk bu özelliği tasarlasaydı nasıl görünürdü?',
  'Kullanıcının tek dokunuşta bunu yapabilmesi için hangi 3 adımı kaldırmalıyız?',
  '5 yıl sonra bu sektörün en çılgın standart özelliği ne olacak?',
];

export function BrainstormWorkspace({
  notebookId,
  notes,
  onSaveNote,
  onNavigateToMindMap,
}: BrainstormWorkspaceProps) {
  const [ideas, setIdeas] = useState<StickyIdea[]>(() => StorageService.getIdeas());
  const [selectedTag, setSelectedTag] = useState<string>('Tümü');
  const [randomPromptIndex, setRandomPromptIndex] = useState(0);

  // New Idea Form
  const [newIdeaText, setNewIdeaText] = useState('');
  const [newIdeaTag, setNewIdeaTag] = useState('Ürün');
  const [newIdeaColor, setNewIdeaColor] = useState('bg-amber-100 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800');

  const stickyColors = [
    { name: 'Sarı', class: 'bg-amber-100 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800' },
    { name: 'Mavi', class: 'bg-sky-100 dark:bg-sky-950/60 border-sky-300 dark:border-sky-800' },
    { name: 'Pembe', class: 'bg-pink-100 dark:bg-pink-950/60 border-pink-300 dark:border-pink-800' },
    { name: 'Yeşil', class: 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800' },
    { name: 'Mor', class: 'bg-purple-100 dark:bg-purple-950/60 border-purple-300 dark:border-purple-800' },
  ];

  const handleAddIdea = () => {
    if (!newIdeaText.trim()) return;
    const item: StickyIdea = {
      id: 'idea_' + Date.now(),
      text: newIdeaText.trim(),
      color: newIdeaColor,
      votes: 1,
      tags: [newIdeaTag],
    };
    const updated = [item, ...ideas];
    setIdeas(updated);
    StorageService.saveIdeas(updated);
    setNewIdeaText('');
  };

  const handleVote = (id: string, delta: number) => {
    const updated = ideas.map((idea) =>
      idea.id === id ? { ...idea, votes: Math.max(0, idea.votes + delta) } : idea
    );
    setIdeas(updated);
    StorageService.saveIdeas(updated);
  };

  const handleDelete = (id: string) => {
    const updated = ideas.filter((idea) => idea.id !== id);
    setIdeas(updated);
    StorageService.saveIdeas(updated);
  };

  // AI Expand Idea Simulation
  const handleAIExpand = (ideaText: string) => {
    const expanded = `💡 **Yapay Zeka Fikir Geliştirme:**\n\n"${ideaText}" fikri için önerilen 3 alt aksiyon:\n1. Topluluk odaklı prototip testi yapılması\n2. Geri bildirim döngüsünü 48 saate indiren mikro anketler\n3. Kullanıcıların kendi şablonlarını paylaşabileceği açık galeri`;
    onSaveNote({
      notebookId,
      title: `Fikir Geliştirme: ${(ideaText || '').slice(0, 30)}...`,
      body: expanded,
      tag: 'Beyin Fırtınası',
      date: new Date().toISOString().slice(0, 10),
    });
    alert('Fikir yapay zeka ile genişletildi ve notlarınıza eklendi!');
  };

  const filteredIdeas = ideas.filter(
    (item) => selectedTag === 'Tümü' || item.tags.includes(selectedTag)
  );

  return (
    <div className="space-y-6">
      {/* Top Banner: Inspiration Generator & Mind Map Bridge */}
      <div className="bg-linear-to-r from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 border border-amber-200 dark:border-amber-900/40 rounded-xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex-1 min-w-[280px]">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              Rastgele İlham Verici Soru (SCAMPER)
            </span>
            <button
              onClick={() => setRandomPromptIndex((i) => (i + 1) % INSPIRATION_PROMPTS.length)}
              className="p-1 text-amber-600 hover:rotate-180 transition-transform duration-300"
              title="Yeni Soru"
            >
              <Shuffle className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 italic">
            "{INSPIRATION_PROMPTS[randomPromptIndex]}"
          </p>
        </div>

        {onNavigateToMindMap && (
          <button
            id="btn-goto-mind-map"
            onClick={onNavigateToMindMap}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center gap-2 transition-colors"
          >
            <Network className="w-4 h-4" />
            Zihin Haritası Tuvaline Git
          </button>
        )}
      </div>

      {/* Tags Filter & Add Sticky Section */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          {['Tümü', 'Ürün', 'Büyüme', 'AI', 'Tasarım', 'Teknoloji'].map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                selectedTag === tag
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-500 font-mono">
          {filteredIdeas.length} Fikir Notu
        </span>
      </div>

      {/* New Sticky Note Creator Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
        <div className="flex gap-2">
          <textarea
            rows={2}
            value={newIdeaText}
            onChange={(e) => setNewIdeaText(e.target.value)}
            placeholder="Aklına gelen çılgın bir fikri buraya yapıştır..."
            className="flex-1 px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 resize-none leading-relaxed"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Renk:</span>
            <div className="flex gap-1.5">
              {stickyColors.map((sc, i) => (
                <button
                  key={i}
                  onClick={() => setNewIdeaColor(sc.class)}
                  className={`w-6 h-6 rounded-full border-2 ${sc.class} ${
                    newIdeaColor === sc.class ? 'ring-2 ring-amber-500 ring-offset-1' : ''
                  }`}
                  title={sc.name}
                />
              ))}
            </div>
            <select
              value={newIdeaTag}
              onChange={(e) => setNewIdeaTag(e.target.value)}
              className="px-2.5 py-1 text-xs border rounded-md bg-slate-50 dark:bg-slate-800 ml-2"
            >
              <option value="Ürün">Ürün</option>
              <option value="Büyüme">Büyüme</option>
              <option value="AI">AI</option>
              <option value="Tasarım">Tasarım</option>
              <option value="Teknoloji">Teknoloji</option>
            </select>
          </div>

          <button
            id="btn-add-sticky-idea"
            onClick={handleAddIdea}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Panoya Yapıştır
          </button>
        </div>
      </div>

      {/* Sticky Notes Grid (Corkboard/Canvas Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredIdeas.map((idea) => (
          <div
            key={idea.id}
            className={`p-4 rounded-xl border-2 shadow-sm flex flex-col justify-between min-h-[170px] transition-transform hover:-translate-y-1 ${idea.color}`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="px-2 py-0.5 bg-white/70 dark:bg-black/40 rounded text-[10px] font-bold text-slate-800 dark:text-slate-200">
                  {idea.tags[0] || 'Genel'}
                </span>
                <button
                  onClick={() => handleDelete(idea.id)}
                  className="text-slate-400 hover:text-rose-600"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <p className="text-xs font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
                {idea.text}
              </p>
            </div>

            {/* Bottom: Votes & AI Expansion */}
            <div className="pt-3 border-t border-black/10 dark:border-white/10 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleVote(idea.id, 1)}
                  className="flex items-center gap-1 px-2 py-1 bg-white/60 dark:bg-black/30 rounded font-bold font-mono hover:bg-white"
                >
                  <ThumbsUp className="w-3.5 h-3.5 text-amber-700 dark:text-amber-300" />
                  {idea.votes}
                </button>
              </div>

              <button
                onClick={() => handleAIExpand(idea.text)}
                className="p-1 text-slate-700 dark:text-slate-300 hover:text-amber-800 flex items-center gap-1 font-semibold text-[11px]"
                title="AI ile Genişlet"
              >
                <Wand2 className="w-3.5 h-3.5" />
                Genişlet
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
