import React, { useState } from 'react';
import {
  PieChart,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Download,
  Calendar,
  AlertCircle,
  Check,
} from 'lucide-react';
import { FinanceItem, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface FinanceWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function FinanceWorkspace({ notebookId, notes, onSaveNote }: FinanceWorkspaceProps) {
  const [transactions, setTransactions] = useState<FinanceItem[]>(() => StorageService.getFinanceItems());
  const [filterType, setFilterType] = useState<'all' | 'gelir' | 'gider' | 'yatırım'>('all');

  // New Transaction Form State
  const [isAdding, setIsAdding] = useState(false);
  const [newType, setNewType] = useState<'gelir' | 'gider' | 'yatırım'>('gider');
  const [newCategory, setNewCategory] = useState('Market');
  const [newAmount, setNewAmount] = useState<number>(500);
  const [newDesc, setNewDesc] = useState('');
  const [newDate, setNewDate] = useState(new Date().toISOString().slice(0, 10));

  // Category Budgets
  const categoryBudgets = [
    { category: 'Kira & Konut', spent: 18500, limit: 20000, color: 'bg-indigo-500' },
    { category: 'Market & Gıda', spent: 6850, limit: 8000, color: 'bg-rose-500' },
    { category: 'Faturalar & Aidat', spent: 1750, limit: 2500, color: 'bg-amber-500' },
    { category: 'Eğlence & Sosyal', spent: 3100, limit: 4000, color: 'bg-purple-500' },
    { category: 'Yatırım & Fon', spent: 10000, limit: 10000, color: 'bg-emerald-500' },
  ];

  // Recurring Subscriptions
  const subscriptions = [
    { name: 'Kira Ödemesi', amount: 18500, day: '1. Gün', status: 'Ödendi' },
    { name: 'Spotify Aile Planı', amount: 99.99, day: '14. Gün', status: 'Yaklaşıyor' },
    { name: 'GitHub Copilot / Pro', amount: 340, day: '21. Gün', status: 'Beklemede' },
    { name: 'Fiber İnternet', amount: 480, day: '25. Gün', status: 'Beklemede' },
  ];

  // Calculations
  const totalIncome = transactions
    .filter((t) => t.type === 'gelir')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpense = transactions
    .filter((t) => t.type === 'gider')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalInvest = transactions
    .filter((t) => t.type === 'yatırım')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const netBalance = totalIncome - totalExpense;

  const handleAddTransaction = () => {
    if (!newDesc.trim() || newAmount <= 0) return;
    const item: FinanceItem = {
      id: 'fin_' + Date.now(),
      type: newType,
      category: newCategory,
      amount: newAmount,
      currency: 'TRY',
      date: newDate,
      description: newDesc.trim(),
    };
    const updated = [item, ...transactions];
    setTransactions(updated);
    StorageService.saveFinanceItems(updated);
    setNewDesc('');
    setIsAdding(false);
  };

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      'Tarih,Tip,Kategori,Açıklama,Tutar,ParaBirimi\n' +
      (transactions || [])
        .map((t) => `${t.date},${t.type},${t.category},"${t.description}",${t.amount},${t.currency}`)
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'noteflow_finans_raporu.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = transactions.filter((t) => filterType === 'all' || t.type === filterType);

  return (
    <div className="space-y-6">
      {/* 3 Metric Cards: Net Bakiye, Gelir, Gider */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Net Bakiye & Tasarruf</span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100">
            {netBalance.toLocaleString()} ₺
          </div>
          <span className="text-[11px] text-emerald-600 flex items-center gap-0.5 mt-1 font-medium">
            <ArrowUpRight className="w-3.5 h-3.5" /> %18 Tasarruf Oranı
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Aylık Toplam Gelir</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-600">
            +{totalIncome.toLocaleString()} ₺
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Maaş & Freelance</span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Aylık Toplam Gider</span>
            <TrendingDown className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-600">
            -{totalExpense.toLocaleString()} ₺
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Kira, Market & Faturalar</span>
        </div>
      </div>

      {/* Category Budgets & Subscriptions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Budget Bars */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Kategori Bütçe Limitleri & Gerçekleşen
            </h4>
            <span className="text-xs text-slate-400">Aylık Limit Takibi</span>
          </div>

          <div className="space-y-3.5">
            {categoryBudgets.map((b, i) => {
              const pct = Math.min(100, Math.round((b.spent / b.limit) * 100));
              return (
                <div key={i} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-800 dark:text-slate-200">{b.category}</span>
                    <span className="font-mono text-slate-500">
                      {b.spent.toLocaleString()} / {b.limit.toLocaleString()} ₺ (%{pct})
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${b.color} rounded-full transition-all duration-300`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Subscriptions Calendar */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            Tekrarlayan Abonelikler
          </h4>
          <div className="space-y-2.5">
            {subscriptions.map((sub, idx) => (
              <div key={idx} className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg text-xs flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">{sub.name}</div>
                  <div className="text-[10px] text-slate-400">Her ayın {sub.day} günü</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-900 dark:text-slate-100">{sub.amount} ₺</div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${sub.status === 'Ödendi' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                    {sub.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Transactions Table & Controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex gap-2">
            {[
              { id: 'all', label: 'Tümü' },
              { id: 'gider', label: 'Giderler' },
              { id: 'gelir', label: 'Gelirler' },
              { id: 'yatırım', label: 'Yatırımlar' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterType(f.id as any)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  filterType === f.id
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              CSV Dışa Aktar
            </button>
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              İşlem Ekle
            </button>
          </div>
        </div>

        {/* Add Transaction Form */}
        {isAdding && (
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as any)}
                className="px-3 py-2 text-xs border rounded-lg bg-white dark:bg-slate-800 font-semibold"
              >
                <option value="gider">Gider</option>
                <option value="gelir">Gelir</option>
                <option value="yatırım">Yatırım</option>
              </select>
              <input
                type="text"
                placeholder="Kategori (Örn. Market, Kira)..."
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="px-3 py-2 text-xs border rounded-lg bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                placeholder="Açıklama..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                className="px-3 py-2 text-xs border rounded-lg bg-white dark:bg-slate-800"
              />
              <input
                type="number"
                placeholder="Tutar (₺)..."
                value={newAmount}
                onChange={(e) => setNewAmount(Number(e.target.value))}
                className="px-3 py-2 text-xs border rounded-lg bg-white dark:bg-slate-800 font-mono"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setIsAdding(false)} className="px-3 py-1.5 text-xs text-slate-500">
                İptal
              </button>
              <button
                onClick={handleAddTransaction}
                className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
              >
                Kaydet
              </button>
            </div>
          </div>
        )}

        {/* Transactions List */}
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {filtered.map((item) => (
            <div key={item.id} className="py-3 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div
                  className={`p-2 rounded-lg ${
                    item.type === 'gelir'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                      : item.type === 'yatırım'
                      ? 'bg-purple-100 dark:bg-purple-950 text-purple-600'
                      : 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                  }`}
                >
                  {item.type === 'gelir' ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : item.type === 'yatırım' ? (
                    <Wallet className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{item.description}</div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {item.category} • {item.date}
                  </div>
                </div>
              </div>

              <div
                className={`font-mono font-bold text-sm ${
                  item.type === 'gelir'
                    ? 'text-emerald-600'
                    : item.type === 'yatırım'
                    ? 'text-purple-600'
                    : 'text-rose-600'
                }`}
              >
                {item.type === 'gelir' ? '+' : '-'}
                {item.amount.toLocaleString()} {item.currency}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
