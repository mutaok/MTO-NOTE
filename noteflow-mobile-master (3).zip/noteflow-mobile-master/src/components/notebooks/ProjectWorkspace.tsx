import React, { useState } from 'react';
import {
  Kanban,
  CheckCircle2,
  Clock,
  Flag,
  FileCode2,
  Users,
  Plus,
  ArrowRight,
  TrendingUp,
  Link2,
  ShieldCheck,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { Task, Milestone, FileVersion, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface ProjectWorkspaceProps {
  notebookId: string;
  tasks: Task[];
  notes: Note[];
  onToggleTask: (id: string) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onOpenTaskEditor: (task?: Task) => void;
}

export function ProjectWorkspace({
  notebookId,
  tasks,
  notes,
  onToggleTask,
  onSaveTask,
  onOpenTaskEditor,
}: ProjectWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<'kanban' | 'timeline' | 'milestones' | 'versions' | 'team'>('kanban');

  // Milestones & Versions state
  const [milestones, setMilestones] = useState<Milestone[]>(() => StorageService.getMilestones());
  const [versions, setVersions] = useState<FileVersion[]>(() => StorageService.getFileVersions());
  const [newMilestone, setNewMilestone] = useState({ title: '', dueDate: '' });
  const [isAddingMilestone, setIsAddingMilestone] = useState(false);

  // Filter tasks for this project
  const projectTasks = tasks.filter((t) => t.notebookId === notebookId || t.list === 'Proje');
  const completedCount = projectTasks.filter((t) => t.done).length;
  const progressPercent = projectTasks.length > 0 ? Math.round((completedCount / projectTasks.length) * 100) : 65;

  // Kanban Columns
  const columns = [
    { id: 'todo', title: 'Yapılacak (To Do)', color: 'border-slate-300 dark:border-slate-700' },
    { id: 'in_progress', title: 'Sürüyor (In Progress)', color: 'border-sky-500' },
    { id: 'review', title: 'İnceleme & QA', color: 'border-amber-500' },
    { id: 'done', title: 'Tamamlandı (Done)', color: 'border-emerald-500' },
  ];

  // Helper to categorize tasks into columns. Kimlikler UUID olduğu için sütun,
  // kimlikten türetilen sabit bir sayıyla seçilir.
  const bucket = (id: string) => Array.from(id).reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
  const getTasksForColumn = (colId: string) => {
    if (colId === 'done') return projectTasks.filter((t) => t.done);
    if (colId === 'in_progress') return projectTasks.filter((t) => !t.done && bucket(t.id) % 2 === 0);
    if (colId === 'review') return projectTasks.filter((t) => !t.done && bucket(t.id) % 3 === 0);
    return projectTasks.filter((t) => !t.done && bucket(t.id) % 2 !== 0 && bucket(t.id) % 3 !== 0);
  };

  const handleAddMilestone = () => {
    if (!newMilestone.title) return;
    const item: Milestone = {
      id: 'm_' + Date.now(),
      title: newMilestone.title,
      dueDate: newMilestone.dueDate || new Date().toISOString().slice(0, 10),
      completed: false,
    };
    const updated = [...milestones, item];
    setMilestones(updated);
    StorageService.saveMilestones(updated);
    setNewMilestone({ title: '', dueDate: '' });
    setIsAddingMilestone(false);
  };

  const handleToggleMilestone = (id: string) => {
    const updated = milestones.map((m) => (m.id === id ? { ...m, completed: !m.completed } : m));
    setMilestones(updated);
    StorageService.saveMilestones(updated);
  };

  // Connected meeting notes
  const meetingNotes = notes.filter((n) => n.tag === 'Toplantı');

  return (
    <div className="space-y-6">
      {/* Top Banner: Project Progress Bar & Metrics */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-3">
          <div>
            <span className="text-xs font-semibold px-2 py-0.5 bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 rounded uppercase">
              Sprint v2.0
            </span>
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mt-1">
              Proje İlerlemesi & Kilometre Taşları
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-2xl font-extrabold text-sky-600 dark:text-sky-400 font-mono">
              %{progressPercent}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {completedCount} / {projectTasks.length} Görev Tamamlandı
            </span>
          </div>
        </div>

        {/* Dynamic Colorful Progress Bar */}
        <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
          <div
            className="h-full bg-linear-to-r from-sky-500 via-indigo-500 to-emerald-500 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* View Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          <button
            id="tab-proj-kanban"
            onClick={() => setActiveTab('kanban')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'kanban'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Kanban className="w-4 h-4" />
            Kanban Panosu
          </button>
          <button
            id="tab-proj-timeline"
            onClick={() => setActiveTab('timeline')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'timeline'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Gantt / Zaman Çizelgesi
          </button>
          <button
            id="tab-proj-milestones"
            onClick={() => setActiveTab('milestones')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'milestones'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Flag className="w-4 h-4" />
            Kilometre Taşları ({milestones.length})
          </button>
          <button
            id="tab-proj-versions"
            onClick={() => setActiveTab('versions')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'versions'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <FileCode2 className="w-4 h-4" />
            Dosya Sürümleri ({versions.length})
          </button>
          <button
            id="tab-proj-team"
            onClick={() => setActiveTab('team')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'team'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            Ekip & Toplantı Bağlantısı
          </button>
        </div>

        <button
          id="btn-add-proj-task"
          onClick={() => onOpenTaskEditor()}
          className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Yeni Görev Ekle
        </button>
      </div>

      {/* 1. KANBAN PANOSU */}
      {activeTab === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((col) => {
            const colTasks = getTasksForColumn(col.id);
            return (
              <div
                key={col.id}
                className={`bg-slate-50 dark:bg-slate-900/60 border-t-4 ${col.color} border-x border-b border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-col min-h-[400px]`}
              >
                <div className="flex items-center justify-between mb-3 px-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    {col.title}
                  </span>
                  <span className="px-2 py-0.5 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full text-[11px] font-semibold font-mono">
                    {colTasks.length}
                  </span>
                </div>

                <div className="space-y-2.5 flex-1">
                  {colTasks.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => onOpenTaskEditor(t)}
                      className="bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-lg p-3 shadow-2xs hover:shadow-sm transition-all cursor-pointer group"
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <span className="text-xs font-medium text-slate-900 dark:text-slate-100 group-hover:text-sky-600 line-clamp-2">
                          {t.title}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleTask(t.id);
                          }}
                          className={`mt-0.5 shrink-0 ${t.done ? 'text-emerald-600' : 'text-slate-300 hover:text-slate-500'}`}
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {t.dueDate || 'Belirtilmedi'}
                        </span>
                        <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-[10px] font-medium">
                          {t.assignee || 'Atanmadı'}
                        </span>
                      </div>
                    </div>
                  ))}

                  {colTasks.length === 0 && (
                    <div className="py-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                      Bu kolonda kart yok
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 2. GANTT / ZAMAN ÇİZELGESİ */}
      {activeTab === 'timeline' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Eylül - Ekim 2026 Sprint Zaman Çizelgesi
            </h4>
            <span className="text-xs text-slate-500">Gün gün dağılım</span>
          </div>

          <div className="space-y-3">
            {[
              { name: 'UI Tasarım Sistemi v2.0', owner: 'Selin K.', start: 10, duration: 40, color: 'bg-sky-500' },
              { name: 'API Servisleri & tRPC Entegrasyonu', owner: 'Mehmet E.', start: 25, duration: 50, color: 'bg-indigo-500' },
              { name: 'AI Özet & Quiz Özelliği', owner: 'Can D.', start: 45, duration: 35, color: 'bg-amber-500' },
              { name: 'Sistem QA & Güvenlik Testleri', owner: 'Elif Ş.', start: 65, duration: 30, color: 'bg-emerald-500' },
            ].map((bar, i) => (
              <div key={i} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800">
                <div className="flex justify-between text-xs font-medium mb-1.5">
                  <span className="text-slate-800 dark:text-slate-200 font-semibold">{bar.name}</span>
                  <span className="text-slate-500">{bar.owner}</span>
                </div>
                <div className="w-full h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden relative">
                  <div
                    className={`h-full ${bar.color} rounded-full absolute`}
                    style={{ left: `${bar.start}%`, width: `${bar.duration}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. KİLOMETRE TAŞLARI */}
      {activeTab === 'milestones' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Lansman Kilometre Taşları</h4>
            <button
              id="btn-open-milestone-form"
              onClick={() => setIsAddingMilestone(!isAddingMilestone)}
              className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-medium flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              Kilometre Taşı Ekle
            </button>
          </div>

          {isAddingMilestone && (
            <div className="p-4 bg-slate-50 dark:bg-slate-900 border rounded-xl flex gap-3 items-center">
              <input
                type="text"
                placeholder="Kilometre taşı başlığı..."
                value={newMilestone.title}
                onChange={(e) => setNewMilestone({ ...newMilestone, title: e.target.value })}
                className="flex-1 px-3 py-2 text-xs border rounded bg-white dark:bg-slate-800"
              />
              <input
                type="date"
                value={newMilestone.dueDate}
                onChange={(e) => setNewMilestone({ ...newMilestone, dueDate: e.target.value })}
                className="px-3 py-2 text-xs border rounded bg-white dark:bg-slate-800"
              />
              <button
                onClick={handleAddMilestone}
                className="px-4 py-2 bg-sky-600 text-white rounded text-xs font-medium"
              >
                Ekle
              </button>
            </div>
          )}

          <div className="space-y-3">
            {milestones.map((m) => (
              <div
                key={m.id}
                onClick={() => handleToggleMilestone(m.id)}
                className={`p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  m.completed
                    ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-sky-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${m.completed ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                    <Flag className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className={`text-sm font-semibold ${m.completed ? 'line-through text-slate-500' : 'text-slate-900 dark:text-slate-100'}`}>
                      {m.title}
                    </h5>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">Hedef: {m.dueDate}</p>
                  </div>
                </div>
                <span className={`px-2.5 py-1 rounded text-xs font-medium ${m.completed ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'}`}>
                  {m.completed ? 'Tamamlandı' : 'Beklemede'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. DOSYA SÜRÜMLERİ */}
      {activeTab === 'versions' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Sürüm Geçmişi & Değişiklik Günlüğü (Changelog)
          </h4>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {versions.map((v) => (
              <div key={v.id} className="py-3 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-mono text-xs font-bold rounded">
                      {v.version}
                    </span>
                    <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">{v.name}</span>
                    <span className="text-xs text-slate-400 font-mono">• {v.updatedAt}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 pl-1">
                    {v.changeLog}
                  </p>
                </div>
                <span className="text-xs text-slate-500">{v.author}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. EKİP & TOPLANTI BAĞLANTISI */}
      {activeTab === 'team' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Team Roles */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-sky-600" />
              Proje Ekibi & Yetkiler
            </h4>
            <div className="space-y-3">
              {[
                { name: 'Can Demir', role: 'Proje Yöneticisi', email: 'can@example.com', badge: 'Yönetici' },
                { name: 'Selin Kaya', role: 'Kıdemli UI/UX Tasarımcı', email: 'selin@team.io', badge: 'Düzenleyici' },
                { name: 'Mehmet Eren', role: 'Frontend & Full-stack', email: 'mehmet@team.io', badge: 'Düzenleyici' },
              ].map((member, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                  <div>
                    <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">{member.name}</div>
                    <div className="text-[11px] text-slate-500">{member.role}</div>
                  </div>
                  <span className="px-2 py-0.5 bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 text-[10px] font-semibold rounded">
                    {member.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Connected Meeting Notes */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2">
              <Link2 className="w-4 h-4 text-sky-600" />
              Projeye Bağlı Toplantı Notları
            </h4>
            <div className="space-y-2.5">
              {meetingNotes.map((n) => (
                <div key={n.id} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">{n.title}</div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">{n.date || 'Tarih belirtilmedi'}</div>
                  </div>
                  <span className="text-xs text-sky-600 font-medium hover:underline flex items-center gap-0.5">
                    İncele <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
