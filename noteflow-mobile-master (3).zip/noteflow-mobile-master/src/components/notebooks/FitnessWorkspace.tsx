import React, { useState, useEffect } from 'react';
import {
  Activity,
  Dumbbell,
  Timer,
  Trophy,
  Flame,
  Droplets,
  Plus,
  Play,
  Pause,
  RotateCcw,
  Check,
  TrendingUp,
} from 'lucide-react';
import { WorkoutEntry, PersonalRecord, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface FitnessWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function FitnessWorkspace({ notebookId, notes, onSaveNote }: FitnessWorkspaceProps) {
  const [workouts, setWorkouts] = useState<WorkoutEntry[]>(() => StorageService.getWorkouts());
  const [records, setRecords] = useState<PersonalRecord[]>(() => StorageService.getPersonalRecords());

  // Rest Timer State
  const [restSeconds, setRestSeconds] = useState(90);
  const [initialRest, setInitialRest] = useState(90);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Water Tracker
  const [glassesDrank, setGlassesDrank] = useState(6);
  const totalGlasses = 10; // 2.5L

  // Active workout editor
  const [currentSplit, setCurrentSplit] = useState('Push (Göğüs & Omuz & Triceps)');
  const [exercises, setExercises] = useState([
    { name: 'Barbell Bench Press', sets: 4, reps: 8, weight: 85, done: true },
    { name: 'Incline Dumbbell Press', sets: 3, reps: 10, weight: 30, done: true },
    { name: 'Overhead Shoulder Press', sets: 3, reps: 10, weight: 50, done: false },
    { name: 'Cable Lateral Raise', sets: 4, reps: 15, weight: 12, done: false },
  ]);

  const [newExName, setNewExName] = useState('');
  const [newExSets, setNewExSets] = useState(3);
  const [newExReps, setNewExReps] = useState(10);
  const [newExWeight, setNewExWeight] = useState(50);

  // Rest Timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && restSeconds > 0) {
      interval = setInterval(() => setRestSeconds((s) => s - 1), 1000);
    } else if (restSeconds === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      alert('Dinlenme bitti! Sıradaki sete başla! 🏋️');
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, restSeconds]);

  const handleStartRestTimer = (seconds: number) => {
    setInitialRest(seconds);
    setRestSeconds(seconds);
    setIsTimerRunning(true);
  };

  const handleAddExercise = () => {
    if (!newExName.trim()) return;
    setExercises([
      ...exercises,
      {
        name: newExName.trim(),
        sets: newExSets,
        reps: newExReps,
        weight: newExWeight,
        done: false,
      },
    ]);
    setNewExName('');
  };

  const handleSaveWorkout = () => {
    const entry: WorkoutEntry = {
      id: 'wo_' + Date.now(),
      date: new Date().toISOString().slice(0, 10),
      split: currentSplit,
      exercises: exercises.map((e) => ({
        exerciseName: e.name,
        sets: e.sets,
        reps: e.reps,
        weight: e.weight,
      })),
      caloriesBurned: 480,
      durationMinutes: 65,
    };
    const updated = [entry, ...workouts];
    setWorkouts(updated);
    StorageService.saveWorkouts(updated);

    onSaveNote({
      notebookId,
      title: `${new Date().toISOString().slice(0, 10)} - ${currentSplit} Antrenmanı`,
      body: `### Yapılan Egzersizler\n${(exercises || []).map((e) => `- ${e.name}: ${e.sets} set x ${e.reps} tekrar @ ${e.weight}kg`).join('\n')}\n\nSüre: 65 dk | Yakılan Kalori: ~480 kcal`,
      tag: 'Fitness',
      date: new Date().toISOString().slice(0, 10),
    });

    alert('Antrenman günlüğü başarıyla kaydedildi!');
  };

  return (
    <div className="space-y-6">
      {/* Metrics Row: PRs, Calorie, Water, Rest Timer */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Calorie & Split Status */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Günün Antrenmanı</span>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-base font-bold text-slate-900 dark:text-slate-100">{currentSplit}</div>
          <div className="flex items-center gap-3 text-xs text-slate-500 mt-2 font-mono">
            <span>🔥 ~480 kcal</span>
            <span>•</span>
            <span>⏱️ 65 Dakika</span>
          </div>
        </div>

        {/* Dynamic Rest Timer */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Set Arası Dinlenme Sayacı</span>
            <Timer className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-rose-600 dark:text-rose-400">
              {restSeconds}s
            </span>
            <span className="text-xs text-slate-400">({initialRest}s hedef)</span>
          </div>
          <div className="flex gap-1.5 mt-3">
            {[60, 90, 120].map((sec) => (
              <button
                key={sec}
                onClick={() => handleStartRestTimer(sec)}
                className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 rounded text-xs font-mono font-semibold hover:bg-rose-50 hover:text-rose-600"
              >
                {sec}s
              </button>
            ))}
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="px-3 py-1 bg-rose-600 text-white rounded text-xs font-semibold ml-auto flex items-center gap-1"
            >
              {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {isTimerRunning ? 'Dur' : 'Başla'}
            </button>
          </div>
        </div>

        {/* Water Tracker */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Günlük Su Alımı (2.5L Hedef)</span>
            <Droplets className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-sky-600 dark:text-sky-400">
            {glassesDrank * 250} ml / 2500 ml
          </div>
          <div className="flex items-center gap-1.5 mt-3">
            <div className="flex gap-1 flex-1">
              {Array.from({ length: totalGlasses }).map((_, i) => (
                <div
                  key={i}
                  onClick={() => setGlassesDrank(i + 1)}
                  className={`h-6 flex-1 rounded cursor-pointer transition-all ${
                    i < glassesDrank ? 'bg-sky-500' : 'bg-slate-100 dark:bg-slate-800'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => setGlassesDrank((g) => Math.min(totalGlasses, g + 1))}
              className="p-1.5 bg-sky-50 dark:bg-sky-950 text-sky-600 rounded"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Active Workout Table & PR Trophy Wall */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workout Table */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
              <Dumbbell className="w-4 h-4" />
              Set x Tekrar x Ağırlık Tablosu
            </h4>
            <button
              id="btn-save-workout-day"
              onClick={handleSaveWorkout}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-sm"
            >
              Antrenmanı Tamamla
            </button>
          </div>

          <div className="space-y-2.5">
            {exercises.map((ex, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      const copy = [...exercises];
                      copy[idx].done = !copy[idx].done;
                      setExercises(copy);
                    }}
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      ex.done ? 'bg-emerald-600 text-white' : 'border border-slate-300'
                    }`}
                  >
                    {ex.done && <Check className="w-3 h-3" />}
                  </button>
                  <div>
                    <div className={`font-semibold ${ex.done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-slate-100'}`}>
                      {ex.name}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      {ex.sets} set • {ex.reps} tekrar
                    </div>
                  </div>
                </div>

                <div className="font-mono font-bold text-sm text-slate-800 dark:text-slate-200">
                  {ex.weight} kg
                </div>
              </div>
            ))}
          </div>

          {/* Add Exercise Row */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <input
              type="text"
              placeholder="Egzersiz Adı..."
              value={newExName}
              onChange={(e) => setNewExName(e.target.value)}
              className="sm:col-span-2 px-3 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="number"
              placeholder="Set"
              value={newExSets}
              onChange={(e) => setNewExSets(Number(e.target.value))}
              className="px-2 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
            />
            <input
              type="number"
              placeholder="Tekrar"
              value={newExReps}
              onChange={(e) => setNewExReps(Number(e.target.value))}
              className="px-2 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
            />
            <button
              onClick={handleAddExercise}
              className="px-3 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-semibold"
            >
              Ekle
            </button>
          </div>
        </div>

        {/* PR (Personal Records) Wall */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-500" />
            Kişisel Rekorlar (PR Wall)
          </h4>

          <div className="space-y-2.5">
            {records.map((pr) => (
              <div key={pr.id} className="p-3 bg-amber-50/40 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{pr.exercise}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{pr.date}</div>
                </div>
                <div className="text-sm font-extrabold font-mono text-amber-600 dark:text-amber-400">
                  {pr.weight} kg
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
