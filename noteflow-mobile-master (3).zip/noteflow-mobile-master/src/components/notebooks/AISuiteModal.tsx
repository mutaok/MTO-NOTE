import React, { useState } from 'react';
import {
  X,
  Sparkles,
  HelpCircle,
  ListTodo,
  Languages,
  Wand2,
  FileText,
  Copy,
  Check,
  ArrowRight,
} from 'lucide-react';
import { Note, Task } from '../../types';

interface AISuiteModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeNote?: Note;
  notebookName: string;
  onSaveGeneratedNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveGeneratedTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function AISuiteModal({
  isOpen,
  onClose,
  activeNote,
  notebookName,
  onSaveGeneratedNote,
  onSaveGeneratedTask,
}: AISuiteModalProps) {
  const [selectedTool, setSelectedTool] = useState<'summary' | 'quiz' | 'tasks' | 'translate' | 'tone' | 'expand'>('summary');
  const [targetLang, setTargetLang] = useState('İngilizce');
  const [toneOption, setToneOption] = useState('Akademik / Resmi');
  const [inputText, setInputText] = useState(
    activeNote ? `${activeNote.title}\n\n${activeNote.body}` : `Not içeriği: "${notebookName}" defteri genel ders ve proje hedefleri.`
  );
  const [aiOutput, setAiOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const handleRunAI = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      if (selectedTool === 'summary') {
        setAiOutput(
          `📌 **YAPAY ZEKA ÖZETİ:**\n\n1. Ana Odak: Verilen içerikteki temel konseptlerin hızlı kavranması ve yapılandırılması amaçlanmaktadır.\n2. Kritik Bulgular: Süreç aşamaları ve alt sorumluluklar netleştirilmiş, sprint hedefleri belirlenmiştir.\n3. Sonuç: Hazırlanan şablon hem bireysel öğrenme hem de ekip iş birliği için hazırdır.`
        );
      } else if (selectedTool === 'quiz') {
        setAiOutput(
          `❓ **ÜRETİLEN TEST VE QUIZ SORULARI:**\n\nQ1: Dinamik programlamanın brute-force yinelemeden temel farkı nedir?\nA: Tekrarlanan alt problemleri önbelleğe almasıdır.\n\nQ2: Takım içi senkronizasyonun en kritik çıktısı nedir?\nA: Aksiyon maddeleri ve sahiplerinin atanması.\n\nQ3: Cornell not tekniğinde ipucu sütununun işlevi nedir?\nA: Aktif hatırlamayı ve sınav provasını tetiklemek.`
        );
      } else if (selectedTool === 'tasks') {
        setAiOutput(
          `✅ **ÇIKARILAN YAPILACAKLAR (GÖREVLER):**\n\n- [ ] 1. Cornell özet şablonunu gözden geçir ve tamamla (Sorumlu: Bireysel, Bitiş: Yarın)\n- [ ] 2. Formül kütüphanesindeki LaTeX çıktılarını kontrol et (Sorumlu: Mehmet)\n- [ ] 3. Takip toplantısı takvim davetini katılımcılara ilet (Sorumlu: Can)`
        );
      } else if (selectedTool === 'translate') {
        setAiOutput(
          `🌐 **${targetLang.toUpperCase()} ÇEVİRİSİ:**\n\n"The notebook structure is organized into 11 distinct functional suites with automated action triggers, custom field bindings, and seamless workspace integrations."`
        );
      } else if (selectedTool === 'tone') {
        setAiOutput(
          `✍️ **DÜZELTİLMİŞ TON (${toneOption}):**\n\n"Belirtilen süreç ve metodolojiler titizlikle incelenmiş olup, hedeflenen çalışma takvimine uygun şekilde hayata geçirilmesi hususunda tam mutabakata varılmıştır."`
        );
      } else {
        setAiOutput(
          `💡 **FİKİR GENİŞLETME & BEYİN FIRTINASI AĞI:**\n\n• Mikro-şablon pazar yeri kurulması\n• Kullanıcıların sesli notlarını otomatik Cornell formatına çeviren arka plan worker'ı\n• Pomodoro zamanlayıcı ile çalışma odak analitiği raporlaması`
        );
      }
    }, 500);
  };

  const handleSaveAsNote = () => {
    if (!aiOutput) return;
    onSaveGeneratedNote({
      title: `AI Çıktısı: ${selectedTool.toUpperCase()} (${notebookName})`,
      body: aiOutput,
      tag: 'AI',
      date: new Date().toISOString().slice(0, 10),
    });
    alert('AI çıktısı defterinize yeni bir not olarak kaydedildi!');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-xl space-y-5 my-8">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-linear-to-r from-purple-500 to-indigo-600 text-white rounded-xl shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">NoteFlow AI Araç Kiti</h3>
              <p className="text-xs text-slate-500">"{notebookName}" için yapay zeka asistanı</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tool Selector Bar */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {[
            { id: 'summary', label: 'Özetle', icon: FileText },
            { id: 'quiz', label: 'Quiz Üret', icon: HelpCircle },
            { id: 'tasks', label: 'Görev Çıkar', icon: ListTodo },
            { id: 'translate', label: 'Çevir', icon: Languages },
            { id: 'tone', label: 'Ton Düzelt', icon: Wand2 },
            { id: 'expand', label: 'Fikir Genişlet', icon: Sparkles },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => {
                  setSelectedTool(t.id as any);
                  setAiOutput('');
                }}
                className={`p-2 rounded-xl border text-center flex flex-col items-center gap-1 transition-all ${
                  selectedTool === t.id
                    ? 'bg-purple-50 dark:bg-purple-950/50 border-purple-500 text-purple-700 dark:text-purple-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-[11px]">{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Controls for Translate or Tone */}
        {selectedTool === 'translate' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Hedef Dil:</span>
            {['İngilizce', 'Almanca', 'İspanyolca', 'Fransızca'].map((lang) => (
              <button
                key={lang}
                onClick={() => setTargetLang(lang)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  targetLang === lang
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        )}

        {selectedTool === 'tone' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Hedef Üslup:</span>
            {['Akademik / Resmi', 'Samimi / Rahat', 'Kısa & Öz'].map((tone) => (
              <button
                key={tone}
                onClick={() => setToneOption(tone)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  toneOption === tone
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                {tone}
              </button>
            ))}
          </div>
        )}

        {/* Input Text Box */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
            İşlenecek Metin
          </label>
          <textarea
            rows={3}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl bg-slate-50 dark:bg-slate-800 leading-relaxed"
          />
        </div>

        <button
          id="btn-run-ai-action"
          onClick={handleRunAI}
          disabled={isGenerating}
          className="w-full py-2.5 bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4" />
          {isGenerating ? 'Yapay Zeka Analiz Ediyor...' : 'Yapay Zekayı Çalıştır'}
        </button>

        {/* Output Box */}
        {aiOutput && (
          <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-700 dark:text-purple-300">
                Sonuç
              </span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(aiOutput);
                  setIsCopied(true);
                  setTimeout(() => setIsCopied(false), 2000);
                }}
                className="text-xs text-slate-500 hover:text-purple-600 flex items-center gap-1"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {isCopied ? 'Kopyalandı' : 'Kopyala'}
              </button>
            </div>
            <div className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
              {aiOutput}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveAsNote}
                className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold shadow-xs"
              >
                Deftere Not Olarak Ekle
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
