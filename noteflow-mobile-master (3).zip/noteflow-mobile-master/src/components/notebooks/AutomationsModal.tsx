import React, { useState } from 'react';
import { X, Sparkles, Zap, Check, ArrowRight, Clock, Bell, RefreshCw } from 'lucide-react';
import { AutomationRule } from '../../types';
import { StorageService } from '../../data/storage';

interface AutomationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notebookId: string;
}

export function AutomationsModal({ isOpen, onClose, notebookId }: AutomationsModalProps) {
  const [automations, setAutomations] = useState<AutomationRule[]>(() =>
    StorageService.getAutomations()
  );

  if (!isOpen) return null;

  const handleToggleAutomation = (id: string) => {
    const updated = automations.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a));
    setAutomations(updated);
    StorageService.saveAutomations(updated);
  };

  const handleRunAutomation = (name: string) => {
    alert(`⚡ "${name}" otomasyonu tetiklendi ve arka planda başarıyla yürütüldü!`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-xl space-y-5 my-8">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-100 dark:bg-amber-950/60 text-amber-600 rounded-xl">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Defter Otomasyonları</h3>
              <p className="text-xs text-slate-500">
                Eylemler arası akıllı tetikleyiciler (Trigger & Action)
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
          {automations.map((auto) => (
            <div
              key={auto.id}
              className={`p-4 rounded-xl border transition-all ${
                auto.enabled
                  ? 'bg-amber-50/30 dark:bg-amber-950/10 border-amber-300 dark:border-amber-800'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    {(auto as any).title || (auto as any).name}
                  </h4>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={auto.enabled}
                    onChange={() => handleToggleAutomation(auto.id)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {/* Trigger & Action Details */}
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-mono bg-white/70 dark:bg-slate-900/60 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold uppercase text-slate-400">Tetikleyici:</span>
                  <span className="text-amber-700 dark:text-amber-300">{auto.trigger}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold uppercase text-slate-400">Eylem:</span>
                  <span className="text-emerald-700 dark:text-emerald-300 font-semibold">
                    {(auto as any).actionDescription || (auto as any).action}
                  </span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => handleRunAutomation((auto as any).title || (auto as any).name)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-950/40 rounded flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> Şimdi Çalıştır
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
