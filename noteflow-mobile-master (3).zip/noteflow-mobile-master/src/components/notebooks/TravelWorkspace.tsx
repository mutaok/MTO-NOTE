import React, { useState } from 'react';
import {
  Plane,
  Compass,
  Calendar,
  DollarSign,
  CheckSquare,
  MapPin,
  RefreshCw,
  Plus,
  Trash2,
  Ticket,
  Luggage,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { TravelPlan, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface TravelWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function TravelWorkspace({ notebookId, notes, onSaveNote }: TravelWorkspaceProps) {
  const [travelPlan, setTravelPlan] = useState<TravelPlan>(() => StorageService.getTravelPlan());
  const [activeTab, setActiveTab] = useState<'itinerary' | 'reservations' | 'packing' | 'budget' | 'converter'>('itinerary');

  // Currency Converter state
  const [convertAmount, setConvertAmount] = useState<number>(100);
  const [fromCurrency, setFromCurrency] = useState<'TRY' | 'EUR' | 'USD' | 'GBP'>('EUR');
  const [toCurrency, setToCurrency] = useState<'TRY' | 'EUR' | 'USD' | 'GBP'>('TRY');

  const exchangeRates = {
    TRY: 1,
    USD: 34.2,
    EUR: 37.5,
    GBP: 44.1,
  };

  const calculateConversion = () => {
    const amountInTry = convertAmount * exchangeRates[fromCurrency];
    const targetAmount = amountInTry / exchangeRates[toCurrency];
    return targetAmount.toFixed(2);
  };

  const handleTogglePackingItem = (id: string) => {
    const updatedList = travelPlan.packingList.map((p) =>
      p.id === id ? { ...p, packed: !p.packed } : p
    );
    const updatedPlan = { ...travelPlan, packingList: updatedList };
    setTravelPlan(updatedPlan);
    StorageService.saveTravelPlan(updatedPlan);
  };

  const handleTogglePlaceVisited = (placeName: string) => {
    const updatedPlaces = travelPlan.placesToVisit.map((p) =>
      p.name === placeName ? { ...p, visited: !p.visited } : p
    );
    const updatedPlan = { ...travelPlan, placesToVisit: updatedPlaces };
    setTravelPlan(updatedPlan);
    StorageService.saveTravelPlan(updatedPlan);
  };

  return (
    <div className="space-y-6">
      {/* Destination & Budget Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 rounded-xl">
              <Plane className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                Aktif Rota
              </span>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{travelPlan.destination}</h3>
              <p className="text-xs text-slate-500 font-mono">
                {travelPlan.startDate} - {travelPlan.endDate}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-right">
              <span className="text-[11px] text-slate-400">Seyahat Bütçesi</span>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100 font-mono">
                {travelPlan.budgetSpent.toLocaleString()} / {travelPlan.budgetTotal.toLocaleString()} {travelPlan.currency}
              </div>
            </div>
            <div className="w-24 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full"
                style={{ width: `${Math.round((travelPlan.budgetSpent / travelPlan.budgetTotal) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'itinerary', label: 'Gün Gün Plan', icon: Calendar },
          { id: 'reservations', label: `Rezervasyonlar & PNR (${travelPlan.reservations.length})`, icon: Ticket },
          { id: 'packing', label: `Paket Listesi (${travelPlan.packingList.filter((p) => p.packed).length}/${travelPlan.packingList.length})`, icon: Luggage },
          { id: 'converter', label: 'Döviz Çevirici', icon: DollarSign },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 1. GÜN GÜN PLAN & GEZİLECEK YERLER */}
      {activeTab === 'itinerary' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Itinerary Timeline */}
          <div className="lg:col-span-2 space-y-4">
            {travelPlan.itinerary.map((day) => (
              <div
                key={day.day}
                className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm space-y-3"
              >
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center font-mono">
                    {day.day}
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{day.title}</h4>
                </div>

                <ul className="space-y-2 pl-9 text-xs text-slate-700 dark:text-slate-300">
                  {day.activities.map((act, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                      <span>{act}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Places to Visit / Bookmarks */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
              <MapPin className="w-4 h-4" />
              Gezilecek Yer İmleri & Rota
            </h4>
            <div className="space-y-2">
              {travelPlan.placesToVisit.map((place, idx) => (
                <div
                  key={idx}
                  onClick={() => handleTogglePlaceVisited(place.name)}
                  className={`p-3 rounded-lg border text-xs cursor-pointer flex items-center justify-between transition-colors ${
                    place.visited
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div>
                    <div className={`font-semibold ${place.visited ? 'line-through text-slate-500' : 'text-slate-900 dark:text-slate-100'}`}>
                      {place.name}
                    </div>
                    {place.address && <div className="text-[10px] text-slate-400">{place.address}</div>}
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${place.visited ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                    {place.visited ? 'Görüldü' : 'Gidilecek'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. REZERVASYONLAR */}
      {activeTab === 'reservations' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {travelPlan.reservations.map((res) => (
            <div
              key={res.id}
              className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm flex items-start justify-between"
            >
              <div>
                <span className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded text-[10px] font-bold uppercase">
                  {res.type}
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-1">{res.title}</h4>
                <div className="text-xs text-slate-500 font-mono mt-1">Tarih: {res.date}</div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block uppercase">PNR / Kod</span>
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-mono text-xs font-bold text-slate-800 dark:text-slate-200">
                  {res.code}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 3. PAKET LİSTESİ */}
      {activeTab === 'packing' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
            Valiz & Paket Listesi (İşaretlenebilir)
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {travelPlan.packingList.map((item) => (
              <div
                key={item.id}
                onClick={() => handleTogglePackingItem(item.id)}
                className={`p-3 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition-all ${
                  item.packed
                    ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className={`font-medium ${item.packed ? 'line-through text-slate-500' : ''}`}>
                  {item.item}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 bg-white dark:bg-slate-800 rounded text-slate-500">
                  {item.category}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. DÖVİZ ÇEVİRİCİ */}
      {activeTab === 'converter' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm max-w-lg mx-auto space-y-5">
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            Canlı Seyahat Döviz Çevirici
          </h4>

          <div className="space-y-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Miktar</label>
              <input
                type="number"
                value={convertAmount}
                onChange={(e) => setConvertAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-base font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Kaynak Para Birimi</label>
                <select
                  value={fromCurrency}
                  onChange={(e) => setFromCurrency(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="EUR">EUR (€)</option>
                  <option value="USD">USD ($)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="TRY">TRY (₺)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-500 mb-1">Hedef Para Birimi</label>
                <select
                  value={toCurrency}
                  onChange={(e) => setToCurrency(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="TRY">TRY (₺)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="USD">USD ($)</option>
                  <option value="GBP">GBP (£)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 text-center">
              <span className="text-xs text-emerald-800 dark:text-emerald-300">Dönüşüm Sonucu:</span>
              <div className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono mt-1">
                {calculateConversion()} {toCurrency}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
