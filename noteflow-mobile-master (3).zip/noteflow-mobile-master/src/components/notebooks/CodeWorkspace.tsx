import React, { useState } from 'react';
import {
  Code2,
  Terminal,
  Copy,
  Check,
  Play,
  Bug,
  Globe,
  Plus,
  GitBranch,
  Sparkles,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';
import { CodeSnippet, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface CodeWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function CodeWorkspace({ notebookId, notes, onSaveNote }: CodeWorkspaceProps) {
  const [snippets, setSnippets] = useState<CodeSnippet[]>(() => StorageService.getCodeSnippets());
  const [activeTab, setActiveTab] = useState<'snippets' | 'terminal' | 'api' | 'git'>('snippets');
  const [selectedSnippet, setSelectedSnippet] = useState<CodeSnippet>(snippets[0] || ({} as any));
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Terminal state
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'noteflow-core v2.0.0 initialized on port 3000',
    'Connected to persistent storage engine: localStorage [OK]',
    'Active modules loaded: 11 specialized notebook suites',
    'Ready for commands. Try typing "help", "status", "test" or "clear"...',
  ]);

  // API Tester state
  const [apiMethod, setApiMethod] = useState<'GET' | 'POST' | 'PUT'>('GET');
  const [apiUrl, setApiUrl] = useState('https://api.noteflow.app/v1/notebooks/101');
  const [apiResponse, setApiResponse] = useState(`{
  "status": 200,
  "data": {
    "id": 101,
    "title": "Algoritmalar ve Veri Yapıları",
    "type": "academic",
    "tools": ["cornell", "flashcards", "formulas", "citations"]
  }
}`);
  const [isLoadingApi, setIsLoadingApi] = useState(false);

  // Git Commit Generator
  const [commitType, setCommitType] = useState('feat');
  const [commitScope, setCommitScope] = useState('notebooks');
  const [commitMsg, setCommitMsg] = useState('11 defter türü için dinamik çalışma alanı tamamlandı');

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;
    const cmd = terminalInput.trim();
    const newLogs = [...terminalLogs, `$ ${cmd}`];

    if (cmd === 'clear') {
      setTerminalLogs([]);
      setTerminalInput('');
      return;
    } else if (cmd === 'help') {
      newLogs.push('Kullanılabilir komutlar: status, test, list, clear, build, run');
    } else if (cmd === 'status') {
      newLogs.push('Sistem Durumu: 🟢 Aktif | Bellek: 42MB | Gecikme: 14ms | Modül Sağlığı: 100%');
    } else if (cmd === 'test') {
      newLogs.push('Birim testleri çalıştırılıyor... [OK] 24/24 test geçti.');
    } else {
      newLogs.push(`Komut çalıştırıldı: ${cmd} (Çıkış kodu: 0)`);
    }

    setTerminalLogs(newLogs);
    setTerminalInput('');
  };

  const handleSendApiRequest = () => {
    setIsLoadingApi(true);
    setTimeout(() => {
      setIsLoadingApi(false);
      setApiResponse(
        JSON.stringify(
          {
            status: 200,
            message: 'İstek başarıyla simüle edildi.',
            method: apiMethod,
            endpoint: apiUrl,
            timestamp: new Date().toISOString(),
          },
          null,
          2
        )
      );
    }, 600);
  };

  const fullCommitMessage = `${commitType}(${commitScope}): ${commitMsg}`;

  return (
    <div className="space-y-6">
      {/* Sub Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'snippets', label: `Kod Parçacıkları (${snippets.length})`, icon: Code2 },
            { id: 'terminal', label: 'Konsol / Terminal Simülatörü', icon: Terminal },
            { id: 'api', label: 'API Test Aracı', icon: Globe },
            { id: 'git', label: 'Git Commit Oluşturucu', icon: GitBranch },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
                  activeTab === tab.id
                    ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. KOD PARÇACIKLARI (SNIPPETS) */}
      {activeTab === 'snippets' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Snippet List */}
          <div className="space-y-2.5">
            {snippets.map((snip) => (
              <div
                key={snip.id}
                onClick={() => setSelectedSnippet(snip)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  selectedSnippet?.id === snip.id
                    ? 'bg-slate-100 dark:bg-slate-800 border-slate-400 dark:border-slate-600 shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="px-2 py-0.5 bg-slate-200 dark:bg-slate-700 rounded text-[10px] font-mono font-bold uppercase text-slate-700 dark:text-slate-300">
                    {snip.language}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {(snip.tags || []).join(', ')}
                  </span>
                </div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">{snip.title}</h5>
                <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{snip.description}</p>
              </div>
            ))}
          </div>

          {/* Snippet Code Viewer & Copy */}
          {selectedSnippet && (
            <div className="lg:col-span-2 bg-slate-950 text-slate-100 rounded-xl p-5 border border-slate-800 shadow-sm flex flex-col justify-between font-mono">
              <div>
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
                    <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
                    <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
                    <span className="text-xs text-slate-400 font-sans ml-2">
                      {selectedSnippet.title} ({selectedSnippet.language})
                    </span>
                  </div>

                  <button
                    onClick={() => handleCopyCode(selectedSnippet.id, selectedSnippet.code)}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 rounded text-xs text-slate-300 flex items-center gap-1 transition-colors"
                  >
                    {copiedId === selectedSnippet.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" /> Kopyalandı
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" /> Kodu Kopyala
                      </>
                    )}
                  </button>
                </div>

                <pre className="text-xs text-emerald-400 overflow-x-auto p-2 leading-relaxed whitespace-pre-wrap">
                  {selectedSnippet.code}
                </pre>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800 text-[11px] text-slate-400 font-sans flex justify-between items-center">
                <span>{selectedSnippet.description}</span>
                <span className="font-mono text-slate-500">UTF-8 • {selectedSnippet.language}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. TERMİNAL SİMÜLATÖRÜ */}
      {activeTab === 'terminal' && (
        <div className="bg-slate-950 text-slate-200 rounded-xl p-5 border border-slate-800 font-mono text-xs shadow-md space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>bash - noteflow@workspace:~</span>
            </div>
            <span className="text-[10px]">interaktif kabuk</span>
          </div>

          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-2">
            {terminalLogs.map((log, i) => (
              <div
                key={i}
                className={log.startsWith('$') ? 'text-amber-400 font-bold' : 'text-slate-300'}
              >
                {log}
              </div>
            ))}
          </div>

          <form onSubmit={handleTerminalSubmit} className="flex items-center gap-2 pt-2 border-t border-slate-800">
            <span className="text-emerald-400 font-bold">$</span>
            <input
              type="text"
              value={terminalInput}
              onChange={(e) => setTerminalInput(e.target.value)}
              placeholder="Bir komut girin (örn. help, test, status, clear)..."
              className="flex-1 bg-transparent border-none text-xs text-white focus:outline-hidden font-mono"
            />
          </form>
        </div>
      )}

      {/* 3. API TEST ARACI */}
      {activeTab === 'api' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Globe className="w-4 h-4 text-sky-500" />
            REST API Endpoint Test Aracı
          </h4>

          <div className="flex gap-2">
            <select
              value={apiMethod}
              onChange={(e) => setApiMethod(e.target.value as any)}
              className="px-3 py-2 text-xs font-bold border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
            </select>
            <input
              type="text"
              value={apiUrl}
              onChange={(e) => setApiUrl(e.target.value)}
              className="flex-1 px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
            />
            <button
              onClick={handleSendApiRequest}
              disabled={isLoadingApi}
              className="px-5 py-2 bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-lg text-xs font-semibold hover:opacity-90 flex items-center gap-1"
            >
              {isLoadingApi ? 'İstek Atılıyor...' : 'İstek Gönder'}
            </button>
          </div>

          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-xs text-emerald-400">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-2">Yanıt (Response):</div>
            <pre className="whitespace-pre-wrap">{apiResponse}</pre>
          </div>
        </div>
      )}

      {/* 4. GIT COMMIT OLUŞTURUCU */}
      {activeTab === 'git' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm max-w-xl mx-auto space-y-4">
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-orange-500" />
            Conventional Commits Standart Mesaj Üretici
          </h4>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Commit Türü</label>
              <select
                value={commitType}
                onChange={(e) => setCommitType(e.target.value)}
                className="w-full px-3 py-2 text-xs font-bold border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
              >
                <option value="feat">feat (Yeni Özellik)</option>
                <option value="fix">fix (Hata Düzeltme)</option>
                <option value="chore">chore (Bakım / Yapılandırma)</option>
                <option value="docs">docs (Dokümantasyon)</option>
                <option value="refactor">refactor (Kod İyileştirme)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Kapsam (Scope)</label>
              <input
                type="text"
                value={commitScope}
                onChange={(e) => setCommitScope(e.target.value)}
                placeholder="Örn. ui, auth, db"
                className="w-full px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1">Açıklama</label>
            <input
              type="text"
              value={commitMsg}
              onChange={(e) => setCommitMsg(e.target.value)}
              placeholder="Yapılan değişikliği özetleyin..."
              className="w-full px-3 py-2 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div className="p-3.5 bg-slate-950 text-amber-400 font-mono text-xs rounded-xl flex items-center justify-between">
            <span className="font-bold">{fullCommitMessage}</span>
            <button
              onClick={() => {
                navigator.clipboard.writeText(`git commit -m "${fullCommitMessage}"`);
                alert('Commit komutu panoya kopyalandı!');
              }}
              className="p-1.5 text-slate-400 hover:text-white"
              title="Kopyala"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
