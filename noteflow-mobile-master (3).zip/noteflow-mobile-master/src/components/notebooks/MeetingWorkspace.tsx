import React, { useState } from 'react';
import {
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  Send,
  Copy,
  Plus,
  Trash2,
  Check,
  FileText,
  Mail,
  Share2,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { MeetingDetails, Note, Task } from '../../types';
import { showToast } from '../Toast';

interface MeetingWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function MeetingWorkspace({
  notebookId,
  notes,
  onSaveNote,
  onSaveTask,
}: MeetingWorkspaceProps) {
  const [meetingTitle, setMeetingTitle] = useState('Haftalık Ürün ve Mühendislik Senkronizasyonu');
  const [meetingDate, setMeetingDate] = useState(new Date().toISOString().slice(0, 10));
  const [followUpDate, setFollowUpDate] = useState('2026-09-18');

  // Agenda items
  const [agenda, setAgenda] = useState<string[]>([
    'Sprint v2.0 hedeflerinin ve defter türlerinin gözden geçirilmesi',
    'Akademik, Proje, Günlük ve Mutfak modüllerinin demo sunumu',
    'Otomasyon akışlarının doğrulanması',
  ]);
  const [newAgendaItem, setNewAgendaItem] = useState('');

  // Attendees
  const [attendees, setAttendees] = useState([
    { name: 'Can Demir (Ürün Yöneticisi)', present: true },
    { name: 'Selin Kaya (Tasarım Lideri)', present: true },
    { name: 'Mehmet Eren (Frontend & Core)', present: true },
    { name: 'Elif Şahin (QA & Test)', present: false },
  ]);
  const [newAttendeeName, setNewAttendeeName] = useState('');

  // Decisions
  const [decisions, setDecisions] = useState<string[]>([
    'Tüm 11 defter türü için özelleştirilmiş işlevsel araç kutuları aktif edilecek.',
    'Toplantı aksiyonları tek dokunuşla ana görev listesine aktarılacak.',
  ]);
  const [newDecision, setNewDecision] = useState('');

  // Action items (kime, ne zamana)
  const [actionItems, setActionItems] = useState([
    { id: 'act_1', task: 'Formül kütüphanesine LaTeX render desteği ekle', owner: 'Mehmet Eren', deadline: '2026-09-14', done: false },
    { id: 'act_2', task: 'Döviz çevirici ve seyahat harita kartlarını tamamla', owner: 'Selin Kaya', deadline: '2026-09-15', done: false },
    { id: 'act_3', task: 'Kullanıcı test senaryolarını hazırla', owner: 'Elif Şahin', deadline: '2026-09-16', done: false },
  ]);
  const [newActionTask, setNewActionTask] = useState('');
  const [newActionOwner, setNewActionOwner] = useState('');
  const [newActionDeadline, setNewActionDeadline] = useState('2026-09-15');

  const [copiedSuccess, setCopiedSuccess] = useState(false);

  const handleAddAgenda = () => {
    if (!newAgendaItem.trim()) return;
    setAgenda([...agenda, newAgendaItem.trim()]);
    setNewAgendaItem('');
  };

  const handleAddAttendee = () => {
    if (!newAttendeeName.trim()) return;
    setAttendees([...attendees, { name: newAttendeeName.trim(), present: true }]);
    setNewAttendeeName('');
  };

  const handleAddDecision = () => {
    if (!newDecision.trim()) return;
    setDecisions([...decisions, newDecision.trim()]);
    setNewDecision('');
  };

  const handleAddAction = () => {
    if (!newActionTask.trim()) return;
    setActionItems([
      ...actionItems,
      {
        id: 'act_' + Date.now(),
        task: newActionTask.trim(),
        owner: newActionOwner.trim() || 'Atanmadı',
        deadline: newActionDeadline,
        done: false,
      },
    ]);
    setNewActionTask('');
    setNewActionOwner('');
  };

  // Automation: Export actions to tasks
  const handleExportActionsToTasks = () => {
    actionItems.forEach((act) => {
      onSaveTask({
        notebookId,
        title: `[Toplantı] ${act.task} (${act.owner})`,
        list: 'Toplantı',
        dueDate: act.deadline,
        dueTime: '12:00',
        done: act.done,
        color: '#0D9488',
        assignee: act.owner,
        priority: 'yüksek',
      });
    });
    showToast(`${actionItems.length} aksiyon maddesi görevlere eklendi!`);
  };

  const handleSaveAsNote = () => {
    onSaveNote({
      notebookId,
      title: `Toplantı Tutanağı: ${meetingTitle}`,
      body: getFormattedSummary(),
      tag: 'Toplantı',
      date: meetingDate,
    });
    showToast('Toplantı tutanağı defter notlarına kaydedildi!');
  };

  // Generate formatted text for WhatsApp / Email
  const getFormattedSummary = () => {
    return `📋 *TOPLANTI TUTANAĞI: ${meetingTitle}*\n📅 Tarih: ${meetingDate} | Takip: ${followUpDate}\n\n👥 *Katılımcılar:*\n${(attendees || [])
      .map((a) => `- ${a.name} [${a.present ? 'Katıldı' : 'Mazeretli'}]`)
      .join('\n')}\n\n🎯 *Gündem:*\n${(agenda || []).map((ag, i) => `${i + 1}. ${ag}`).join('\n')}\n\n✅ *Alınan Kararlar:*\n${(decisions || [])
      .map((d, i) => `${i + 1}. ${d}`)
      .join('\n')}\n\n🚀 *Aksiyon Maddeleri:*\n${(actionItems || [])
      .map((act) => `- [ ] ${act.task} -> Sorumlu: ${act.owner} (Bitiş: ${act.deadline})`)
      .join('\n')}`;
  };

  const handleCopyMinutes = () => {
    const text = getFormattedSummary();
    navigator.clipboard.writeText(text);
    setCopiedSuccess(true);
    setTimeout(() => setCopiedSuccess(false), 2000);
  };

  const handleSendWhatsApp = () => {
    const text = encodeURIComponent(getFormattedSummary());
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const handleSendEmail = () => {
    const subject = encodeURIComponent(`Toplantı Tutanağı: ${meetingTitle}`);
    const body = encodeURIComponent(getFormattedSummary());
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex-1 min-w-[280px]">
            <span className="text-xs font-semibold px-2 py-0.5 bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 rounded uppercase">
              Toplantı Tutanağı
            </span>
            <input
              type="text"
              value={meetingTitle}
              onChange={(e) => setMeetingTitle(e.target.value)}
              className="mt-1 text-lg font-bold text-slate-900 dark:text-slate-100 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-teal-500 focus:outline-hidden w-full"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-save-meeting-note"
              onClick={handleSaveAsNote}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <FileText className="w-3.5 h-3.5" />
              Not Olarak Kaydet
            </button>
            <button
              id="btn-copy-meeting-minutes"
              onClick={handleCopyMinutes}
              className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 flex items-center gap-1.5"
            >
              {copiedSuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedSuccess ? 'Kopyalandı!' : 'Metni Kopyala'}
            </button>
            <button
              id="btn-send-whatsapp"
              onClick={handleSendWhatsApp}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm"
            >
              <Share2 className="w-3.5 h-3.5" />
              WhatsApp'a Gönder
            </button>
            <button
              id="btn-send-email"
              onClick={handleSendEmail}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm"
            >
              <Mail className="w-3.5 h-3.5" />
              E-posta
            </button>
          </div>
        </div>

        {/* Meeting Metadata */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span>Toplantı Tarihi:</span>
            <input
              type="date"
              value={meetingDate}
              onChange={(e) => setMeetingDate(e.target.value)}
              className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
            />
          </div>
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <Clock className="w-4 h-4 text-teal-600" />
            <span>Takip Toplantısı (Follow-up):</span>
            <input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
              className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Grid: Agenda & Attendees */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Agenda */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            Gündem Maddeleri ({agenda.length})
          </h4>
          <div className="space-y-2">
            {agenda.map((item, idx) => (
              <div key={idx} className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-xs flex items-center justify-between">
                <span className="font-medium text-slate-800 dark:text-slate-200">{idx + 1}. {item}</span>
                <button
                  onClick={() => setAgenda(agenda.filter((_, i) => i !== idx))}
                  className="text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
          <div className="flex gap-2 pt-2">
            <input
              type="text"
              placeholder="Yeni gündem maddesi ekle..."
              value={newAgendaItem}
              onChange={(e) => setNewAgendaItem(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddAgenda()}
              className="flex-1 px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
            <button
              onClick={handleAddAgenda}
              className="px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-medium"
            >
              Ekle
            </button>
          </div>
        </div>

        {/* Attendees */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
            <Users className="w-4 h-4" />
            Katılımcı Listesi ({attendees.filter((a) => a.present).length} / {attendees.length} Mevcut)
          </h4>
          <div className="space-y-2">
            {attendees.map((att, idx) => (
              <div
                key={idx}
                onClick={() => {
                  const copy = [...attendees];
                  copy[idx].present = !copy[idx].present;
                  setAttendees(copy);
                }}
                className={`p-2.5 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                  att.present
                    ? 'bg-teal-50/50 dark:bg-teal-950/20 border-teal-200 dark:border-teal-900/60'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60'
                }`}
              >
                <span className="font-medium text-slate-800 dark:text-slate-200">{att.name}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${att.present ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                  {att.present ? 'Katıldı' : 'Mazeretli'}
                </span>
              </div>
            ))}
          </div>
          <div className="flex gap-2 pt-2">
            <input
              type="text"
              placeholder="Yeni katılımcı ekle..."
              value={newAttendeeName}
              onChange={(e) => setNewAttendeeName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddAttendee()}
              className="flex-1 px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
            <button
              onClick={handleAddAttendee}
              className="px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-medium"
            >
              Ekle
            </button>
          </div>
        </div>
      </div>

      {/* Decisions Log */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4" />
          Alınan Kararlar (Decisions)
        </h4>
        <div className="space-y-2">
          {decisions.map((dec, idx) => (
            <div key={idx} className="p-3 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 rounded-lg text-xs flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">{dec}</span>
            </div>
          ))}
        </div>
        <div className="flex gap-2 pt-2">
          <input
            type="text"
            placeholder="Alınan yeni bir kararı kaydet..."
            value={newDecision}
            onChange={(e) => setNewDecision(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddDecision()}
            className="flex-1 px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
          />
          <button
            onClick={handleAddDecision}
            className="px-4 py-2 bg-teal-600 text-white rounded-lg text-xs font-medium"
          >
            Kararı Kaydet
          </button>
        </div>
      </div>

      {/* Action Items (Otomasyon Destekli) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              Aksiyon Maddeleri (Görevler)
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Toplantıdan çıkan görevleri ve sorumluları belirleyin.
            </p>
          </div>

          <button
            id="btn-auto-export-actions"
            onClick={handleExportActionsToTasks}
            className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold shadow-sm flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Otomasyon: Görevler & Takvime Aktar
          </button>
        </div>

        {/* Action Items List */}
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {actionItems.map((act) => (
            <div key={act.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <input
                  type="checkbox"
                  checked={act.done}
                  onChange={() => {
                    setActionItems(
                      actionItems.map((a) => (a.id === act.id ? { ...a, done: !a.done } : a))
                    );
                  }}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                />
                <span className={`text-xs font-medium ${act.done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-slate-100'}`}>
                  {act.task}
                </span>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="px-2 py-0.5 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 rounded font-medium">
                  {act.owner}
                </span>
                <span className="text-slate-400 font-mono flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {act.deadline}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Add New Action Form */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
          <input
            type="text"
            placeholder="Aksiyon görevi..."
            value={newActionTask}
            onChange={(e) => setNewActionTask(e.target.value)}
            className="sm:col-span-2 px-3 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
          />
          <input
            type="text"
            placeholder="Sorumlu kişi..."
            value={newActionOwner}
            onChange={(e) => setNewActionOwner(e.target.value)}
            className="px-3 py-1.5 text-xs border rounded-lg bg-slate-50 dark:bg-slate-800"
          />
          <button
            id="btn-add-action-item"
            onClick={handleAddAction}
            className="px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-medium"
          >
            Aksiyon Ekle
          </button>
        </div>
      </div>
    </div>
  );
}
