import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  HelpCircle,
  Calculator,
  Bookmark,
  Clock,
  Mic,
  MicOff,
  Copy,
  Check,
  Plus,
  RotateCw,
  Award,
  ChevronRight,
  FileText,
  Volume2,
} from 'lucide-react';
import { MathFormula, Flashcard, Citation, CountdownEvent, Note } from '../../types';
import { StorageService } from '../../data/storage';

interface AcademicWorkspaceProps {
  notebookId: string;
  notes: Note[];
  onOpenNoteEditor: (note?: Note) => void;
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
}

export function AcademicWorkspace({
  notebookId,
  notes,
  onOpenNoteEditor,
  onSaveNote,
}: AcademicWorkspaceProps) {
  const [activeSubTab, setActiveSubTab] = useState<'cornell' | 'flashcards' | 'formulas' | 'citations' | 'countdowns' | 'audio'>('cornell');

  // Flashcards state
  const [flashcards, setFlashcards] = useState<Flashcard[]>(() => StorageService.getFlashcards());
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [newQuestion, setNewQuestion] = useState('');
  const [newAnswer, setNewAnswer] = useState('');
  const [newDeck, setNewDeck] = useState('Genel');

  // Formulas state
  const [formulas, setFormulas] = useState<MathFormula[]>(() => StorageService.getFormulas());
  const [formulaFilter, setFormulaFilter] = useState<string>('Tümü');
  const [copiedFormulaId, setCopiedFormulaId] = useState<string | null>(null);

  // Citations state
  const [citations, setCitations] = useState<Citation[]>(() => StorageService.getCitations());
  const [newCitation, setNewCitation] = useState({ authors: '', title: '', source: '', year: 2026, format: 'APA' as const });
  const [isAddingCitation, setIsAddingCitation] = useState(false);

  // Countdowns state
  const [countdowns, setCountdowns] = useState<CountdownEvent[]>(() => StorageService.getCountdowns());
  const [newCountdown, setNewCountdown] = useState({ title: '', date: '', time: '09:00', type: 'sınav' as const });

  // Audio / Speech recording simulation
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [transcriptText, setTranscriptText] = useState(
    'Hoca: Dinamik programlamanın temel koşulu alt problemlerin tekrarlanması ve optimal alt yapı özelliğidir. Sınavda Bellman denkleminden bir soru kesinlikle gelecektir.'
  );

  // Spaced Repetition status
  const [spacedRepetition, setSpacedRepetition] = useState([
    { day: '1. Gün', label: 'İlk Öğrenme & Not Çıkarma', done: true },
    { day: '3. Gün', label: 'Hızlı Gözden Geçirme', done: true },
    { day: '7. Gün', label: 'Flashcard Quiz Tekrarı', done: false },
    { day: '14. Gün', label: 'Formül ve Problem Çözümü', done: false },
    { day: '30. Gün', label: 'Sınav Öncesi Genel Tarama', done: false },
  ]);

  // Audio timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => setRecordingSeconds((s) => s + 1), 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const handleNextCard = () => {
    setIsFlipped(false);
    setCurrentCardIndex((i) => (i + 1) % flashcards.length);
  };

  const handlePrevCard = () => {
    setIsFlipped(false);
    setCurrentCardIndex((i) => (i - 1 + flashcards.length) % flashcards.length);
  };

  const handleAddFlashcard = () => {
    if (!newQuestion.trim() || !newAnswer.trim()) return;
    const card: Flashcard = {
      id: 'fc_' + Date.now(),
      question: newQuestion.trim(),
      answer: newAnswer.trim(),
      deck: newDeck,
      difficulty: 'orta',
      repetitions: 0,
    };
    const updated = [...flashcards, card];
    setFlashcards(updated);
    StorageService.saveFlashcards(updated);
    setNewQuestion('');
    setNewAnswer('');
  };

  const handleCopyFormula = (f: MathFormula) => {
    navigator.clipboard.writeText(f.latex);
    setCopiedFormulaId(f.id);
    setTimeout(() => setCopiedFormulaId(null), 2000);
  };

  const handleAddCitation = () => {
    if (!newCitation.title || !newCitation.authors) return;
    const item: Citation = {
      id: 'cit_' + Date.now(),
      ...newCitation,
    };
    const updated = [item, ...citations];
    setCitations(updated);
    StorageService.saveCitations(updated);
    setNewCitation({ authors: '', title: '', source: '', year: 2026, format: 'APA' });
    setIsAddingCitation(false);
  };

  const handleAddCountdown = () => {
    if (!newCountdown.title || !newCountdown.date) return;
    const item: CountdownEvent = {
      id: 'cd_' + Date.now(),
      ...newCountdown,
    };
    const updated = [...countdowns, item];
    setCountdowns(updated);
    StorageService.saveCountdowns(updated);
    setNewCountdown({ title: '', date: '', time: '09:00', type: 'sınav' });
  };

  // Convert transcript to new note
  const handleTranscriptToNote = () => {
    onSaveNote({
      notebookId,
      title: 'Ders Ses Kaydı & Transkript Notu',
      body: `### Ses Transkripti\n${transcriptText}\n\n### İpuçları\n- Hoca tarafından vurgulanan sınav noktası: Bellman denklemi.\n- Tekrar planına eklendi.`,
      tag: 'Akademik',
      date: new Date().toISOString().slice(0, 10),
      cornell: {
        cues: ['Dinamik programlama temel şartı?', 'Sınavda beklenen soru?'],
        notes: transcriptText,
        summary: 'DP temel koşulu alt problemlerin örtüşmesidir. Bellman denklemi sınav için kritiktir.',
      },
    });
    alert('Transkript başarıyla Cornell notuna dönüştürüldü!');
  };

  // Calculate days remaining
  const getDaysRemaining = (targetDate: string) => {
    const diff = new Date(targetDate).getTime() - new Date().getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  return (
    <div className="space-y-6">
      {/* Sub Tab Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          <button
            id="tab-cornell"
            onClick={() => setActiveSubTab('cornell')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'cornell'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            Cornell Düzeni
          </button>
          <button
            id="tab-flashcards"
            onClick={() => setActiveSubTab('flashcards')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'flashcards'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            Soru-Cevap Kartları ({flashcards.length})
          </button>
          <button
            id="tab-formulas"
            onClick={() => setActiveSubTab('formulas')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'formulas'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Formül Kütüphanesi
          </button>
          <button
            id="tab-citations"
            onClick={() => setActiveSubTab('citations')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'citations'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            Kaynakça ({citations.length})
          </button>
          <button
            id="tab-countdowns"
            onClick={() => setActiveSubTab('countdowns')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'countdowns'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            Sınav Sayacı
          </button>
          <button
            id="tab-audio"
            onClick={() => setActiveSubTab('audio')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'audio'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Mic className="w-4 h-4" />
            Ses & Transkript
          </button>
        </div>

        <button
          id="btn-new-academic-note"
          onClick={() => onOpenNoteEditor()}
          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Cornell Notu Ekle
        </button>
      </div>

      {/* 1. CORNELL NOT DÜZENİ */}
      {activeSubTab === 'cornell' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-600" />
                  Cornell Not Tekniği Şablonu
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Sayfa üç ana bölüme ayrılır: Sol sütunda ipuçları/sorular, sağda ana ders notları, altta ise öz ve kalıcı bir sayfa özeti.
                </p>
              </div>
              <span className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 rounded-md text-xs font-semibold uppercase tracking-wider">
                Akademik Standart
              </span>
            </div>

            {/* Cornell Layout Preview Box with Lined Paper Effect */}
            <div className="border-2 border-indigo-200 dark:border-indigo-900/60 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-950/40">
              <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-indigo-200 dark:divide-indigo-900/60">
                {/* Sol Sütun: Cues / İpuçları (1 birim) */}
                <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/20">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-800 dark:text-indigo-300 mb-2 flex items-center gap-1">
                    <HelpCircle className="w-3.5 h-3.5" />
                    İpuçları & Sorular (Cues)
                  </h4>
                  <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-2">
                    <li className="p-2 bg-white dark:bg-slate-900 rounded border border-indigo-100 dark:border-indigo-900/40 shadow-2xs">
                      • Optimal alt yapı özelliği nedir?
                    </li>
                    <li className="p-2 bg-white dark:bg-slate-900 rounded border border-indigo-100 dark:border-indigo-900/40 shadow-2xs">
                      • Bellman denklemi takviyeli öğrenmede nasıl formüle edilir?
                    </li>
                    <li className="p-2 bg-white dark:bg-slate-900 rounded border border-indigo-100 dark:border-indigo-900/40 shadow-2xs">
                      • Memoization ile Tabulation arasındaki bellek farkı?
                    </li>
                  </ul>
                </div>

                {/* Sağ Sütun: Notlar (2 birim) */}
                <div className="p-4 md:col-span-2 bg-white dark:bg-slate-900 relative">
                  <div className="absolute top-2 right-2 px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-[10px] text-slate-500 font-mono">
                    Çizgili Kağıt
                  </div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    Ana Ders Notları (Lecture Notes)
                  </h4>
                  <div className="text-xs text-slate-700 dark:text-slate-300 space-y-2.5 leading-relaxed font-sans">
                    <p>
                      <strong>1. Dinamik Programlama Prensibi:</strong> Karmaşık bir problemi tekrarlanan alt kümelere bölerek
                      hafızaya alma (caching) tekniğidir. Recursive çağrı ağacındaki üstel büyüme O(2^n), DP ile O(n) seviyesine iner.
                    </p>
                    <div className="p-2.5 bg-slate-50 dark:bg-slate-800/80 rounded border border-slate-200 dark:border-slate-700 font-mono text-[11px] text-indigo-700 dark:text-indigo-300">
                      V(s) = max_a &#123; R(s,a) + &gamma; &sum; P(s'|s,a) V(s') &#125;
                    </div>
                    <p>
                      <strong>2. Adımlar:</strong> Durumları (State) tanımla, durum geçiş bağıntısını (Recurrence) yaz, taban
                      durumları (Base cases) belirle ve döngüyle çöz.
                    </p>
                  </div>
                </div>
              </div>

              {/* Alt Sütun: Özet (Summary) */}
              <div className="p-4 bg-amber-50/70 dark:bg-amber-950/20 border-t-2 border-indigo-200 dark:border-indigo-900/60">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 mb-1 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Sayfa Özeti (Summary)
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  DP, optimum alt yapı ve örtüşen alt problemler içeren optimizasyon sorularında vazgeçilmezdir. Sınavda Bellman
                  denkleminin durum geçiş matrisi üzerinden soru beklenmektedir.
                </p>
              </div>
            </div>
          </div>

          {/* Konu Tekrar Planı (Spaced Repetition) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2 mb-3">
              <Award className="w-5 h-5 text-indigo-600" />
              Aralıklı Tekrar Planı (Spaced Repetition Scheduler)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Hermann Ebbinghaus unutma eğrisine göre optimize edilmiş 5 aşamalı tekrar döngüsü:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
              {spacedRepetition.map((step, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    const copy = [...spacedRepetition];
                    copy[idx].done = !copy[idx].done;
                    setSpacedRepetition(copy);
                  }}
                  className={`p-3 rounded-lg border text-center cursor-pointer transition-all ${
                    step.done
                      ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-indigo-300'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-xs font-bold mb-1">
                    <Check className={`w-3.5 h-3.5 ${step.done ? 'text-emerald-600' : 'text-slate-400'}`} />
                    {step.day}
                  </div>
                  <div className="text-[11px] leading-tight font-medium">{step.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. SORU - CEVAP KARTLARI (FLASHCARDS) */}
      {activeSubTab === 'flashcards' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Flashcard Quiz View */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[380px]">
              <div className="flex items-center justify-between mb-4">
                <span className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-md text-xs font-medium">
                  {flashcards[currentCardIndex]?.deck || 'Genel'} • Kart {currentCardIndex + 1} / {flashcards.length}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Cevabı görmek için karta tıklayın
                </span>
              </div>

              {/* Interactive Card */}
              {flashcards.length > 0 ? (
                <div
                  id="flashcard-interactive"
                  onClick={() => setIsFlipped(!isFlipped)}
                  className={`w-full flex-1 rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 border-2 ${
                    isFlipped
                      ? 'bg-indigo-900 text-white border-indigo-700 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 border-indigo-200 dark:border-indigo-900/60 hover:shadow-md'
                  }`}
                >
                  <div className="text-xs uppercase tracking-widest font-semibold text-indigo-400 dark:text-indigo-300 mb-3">
                    {isFlipped ? 'CEVAP' : 'SORU'}
                  </div>
                  <p className="text-lg sm:text-xl font-medium max-w-lg leading-relaxed">
                    {isFlipped
                      ? flashcards[currentCardIndex]?.answer
                      : flashcards[currentCardIndex]?.question}
                  </p>
                  <div className="mt-4 text-xs text-indigo-400 flex items-center gap-1">
                    <RotateCw className="w-3.5 h-3.5" />
                    Çevirmek için tıkla
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center text-slate-500">Henüz soru kartı eklenmedi.</div>
              )}

              {/* Card Navigation Controls */}
              <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  id="btn-prev-card"
                  onClick={handlePrevCard}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100"
                >
                  ← Önceki
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const copy = [...flashcards];
                      copy[currentCardIndex].difficulty = 'kolay';
                      setFlashcards(copy);
                      StorageService.saveFlashcards(copy);
                      handleNextCard();
                    }}
                    className="px-3 py-1.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded text-xs font-medium"
                  >
                    Kolay (+1)
                  </button>
                  <button
                    onClick={() => {
                      const copy = [...flashcards];
                      copy[currentCardIndex].difficulty = 'orta';
                      setFlashcards(copy);
                      StorageService.saveFlashcards(copy);
                      handleNextCard();
                    }}
                    className="px-3 py-1.5 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded text-xs font-medium"
                  >
                    Orta
                  </button>
                  <button
                    onClick={() => {
                      const copy = [...flashcards];
                      copy[currentCardIndex].difficulty = 'zor';
                      setFlashcards(copy);
                      StorageService.saveFlashcards(copy);
                      handleNextCard();
                    }}
                    className="px-3 py-1.5 bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 rounded text-xs font-medium"
                  >
                    Zor (Tekrar)
                  </button>
                </div>
                <button
                  id="btn-next-card"
                  onClick={handleNextCard}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium"
                >
                  Sonraki →
                </button>
              </div>
            </div>

            {/* Add New Flashcard */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 mb-3">
                <Plus className="w-4 h-4 text-indigo-600" />
                Yeni Flashcard Ekle
              </h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Deste / Konu</label>
                  <input
                    type="text"
                    value={newDeck}
                    onChange={(e) => setNewDeck(e.target.value)}
                    placeholder="Örn. Algoritmalar, Fizik"
                    className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Soru (Ön Yüz)</label>
                  <textarea
                    rows={3}
                    value={newQuestion}
                    onChange={(e) => setNewQuestion(e.target.value)}
                    placeholder="Soru veya kavram..."
                    className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Cevap (Arka Yüz)</label>
                  <textarea
                    rows={4}
                    value={newAnswer}
                    onChange={(e) => setNewAnswer(e.target.value)}
                    placeholder="Açıklama, formül veya doğru cevap..."
                    className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <button
                  id="btn-save-flashcard"
                  onClick={handleAddFlashcard}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-medium transition-colors"
                >
                  Kartı Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. FORMÜL KÜTÜPHANESİ */}
      {activeSubTab === 'formulas' && (
        <div className="space-y-6">
          {/* Category Filter */}
          <div className="flex gap-2">
            {['Tümü', 'Matematik', 'Fizik', 'Kimya', 'Mühendislik'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFormulaFilter(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  formulaFilter === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {formulas
              .filter((f) => formulaFilter === 'Tümü' || f.category === formulaFilter)
              .map((f) => (
                <div
                  key={f.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm hover:border-indigo-400 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded">
                        {f.category}
                      </span>
                      <button
                        onClick={() => handleCopyFormula(f)}
                        className="text-xs text-slate-500 hover:text-indigo-600 flex items-center gap-1"
                        title="LaTeX Kopyala"
                      >
                        {copiedFormulaId === f.id ? (
                          <span className="text-emerald-600 flex items-center gap-0.5 font-medium">
                            <Check className="w-3.5 h-3.5" /> Kopyalandı
                          </span>
                        ) : (
                          <span className="flex items-center gap-0.5">
                            <Copy className="w-3.5 h-3.5" /> LaTeX
                          </span>
                        )}
                      </button>
                    </div>
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-1">{f.title}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">{f.description}</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-center text-indigo-600 dark:text-indigo-400 text-sm font-semibold">
                    {f.latex}
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 4. KAYNAKÇA ALANI (CITATIONS) */}
      {activeSubTab === 'citations' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Akademik Kaynakça & Referanslar (APA, MLA, IEEE)
            </h3>
            <button
              id="btn-add-citation-open"
              onClick={() => setIsAddingCitation(!isAddingCitation)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-medium flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              Kaynak Ekle
            </button>
          </div>

          {isAddingCitation && (
            <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Yazar(lar) - Örn. Cormen, T. H. vb."
                  value={newCitation.authors}
                  onChange={(e) => setNewCitation({ ...newCitation, authors: e.target.value })}
                  className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
                <input
                  type="text"
                  placeholder="Eser / Makale Başlığı"
                  value={newCitation.title}
                  onChange={(e) => setNewCitation({ ...newCitation, title: e.target.value })}
                  className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
                <input
                  type="text"
                  placeholder="Yayınevi / Dergi"
                  value={newCitation.source}
                  onChange={(e) => setNewCitation({ ...newCitation, source: e.target.value })}
                  className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setIsAddingCitation(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400"
                >
                  İptal
                </button>
                <button
                  onClick={handleAddCitation}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-medium"
                >
                  Kaydet
                </button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {citations.map((c) => (
              <div
                key={c.id}
                className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between"
              >
                <div>
                  <div className="text-xs text-indigo-600 font-semibold mb-1">{c.format} Formatı</div>
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                    {c.authors} ({c.year}). <em>{c.title}</em>. {c.source}.
                  </div>
                </div>
                <button
                  onClick={() => {
                    const text = `${c.authors} (${c.year}). ${c.title}. ${c.source}.`;
                    navigator.clipboard.writeText(text);
                    alert('Kaynak metni panoya kopyalandı!');
                  }}
                  className="p-2 text-slate-400 hover:text-indigo-600 rounded-lg"
                  title="Alıntıyı Kopyala"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. SINAV GERİ SAYIMI */}
      {activeSubTab === 'countdowns' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {countdowns.map((cd) => {
              const days = getDaysRemaining(cd.date);
              return (
                <div
                  key={cd.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm relative overflow-hidden"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2.5 py-0.5 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 rounded text-xs font-semibold uppercase">
                      {cd.type}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">{cd.date}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-4">{cd.title}</h4>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400">{days}</span>
                    <span className="text-xs text-slate-500 font-medium">gün kaldı</span>
                  </div>
                </div>
              );
            })}

            {/* Add Countdown Event Card */}
            <div className="bg-slate-50 dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-5 flex flex-col justify-between">
              <h4 className="text-xs font-bold uppercase text-slate-600 dark:text-slate-400 mb-2">
                Yeni Sınav / Teslimat Ekle
              </h4>
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Sınav veya teslim adı..."
                  value={newCountdown.title}
                  onChange={(e) => setNewCountdown({ ...newCountdown, title: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border rounded bg-white dark:bg-slate-800"
                />
                <input
                  type="date"
                  value={newCountdown.date}
                  onChange={(e) => setNewCountdown({ ...newCountdown, date: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border rounded bg-white dark:bg-slate-800"
                />
                <button
                  id="btn-add-countdown"
                  onClick={handleAddCountdown}
                  className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-medium"
                >
                  Sayaca Ekle
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. SES KAYDI & TRANSKRİPT */}
      {activeSubTab === 'audio' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Mic className="w-5 h-5 text-indigo-600" />
                Ders Ses Kaydı & Canlı Transkript Simülatörü
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Ders esnasında ses kaydı başlatın, konuşulanları metne dökün ve tek tıkla Cornell notuna dönüştürün.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {isRecording && (
                <span className="flex items-center gap-1.5 text-xs font-mono text-rose-600 font-bold animate-pulse">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                  Kayıt Yapılıyor: 00:{recordingSeconds.toString().padStart(2, '0')}
                </span>
              )}
              <button
                id="btn-toggle-recording"
                onClick={() => setIsRecording(!isRecording)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                  isRecording
                    ? 'bg-rose-600 text-white hover:bg-rose-700 shadow-md'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'
                }`}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    Kaydı Durdur
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    Ses Kaydını Başlat
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Transcript display */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Canlı Transkript Çıktısı
              </span>
              <button
                id="btn-transcript-to-note"
                onClick={handleTranscriptToNote}
                className="px-3 py-1 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded text-xs font-medium hover:bg-indigo-100 flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" />
                Cornell Notuna Aktar
              </button>
            </div>
            <textarea
              rows={4}
              value={transcriptText}
              onChange={(e) => setTranscriptText(e.target.value)}
              className="w-full text-xs text-slate-800 dark:text-slate-200 bg-transparent border-none focus:outline-hidden leading-relaxed resize-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}
