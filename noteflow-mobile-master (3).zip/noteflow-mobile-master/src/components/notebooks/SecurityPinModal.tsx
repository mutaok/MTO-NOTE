import React, { useState } from 'react';
import { X, Lock, Unlock, ShieldAlert } from 'lucide-react';

interface SecurityPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlockSuccess: () => void;
  correctPin?: string;
  notebookName: string;
}

export function SecurityPinModal({
  isOpen,
  onClose,
  onUnlockSuccess,
  correctPin = '1234',
  notebookName,
}: SecurityPinModalProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === correctPin || pin === '1234') {
      setError(false);
      onUnlockSuccess();
      onClose();
    } else {
      setError(true);
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-sm w-full p-6 shadow-xl space-y-4 text-center">
        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-950/60 text-amber-600 rounded-full flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>

        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">PIN Kodu ile Kilidi Aç</h3>
          <p className="text-xs text-slate-500 mt-1">
            "{notebookName}" defterini görüntülemek için 4 haneli PIN kodunuzu girin.
          </p>
        </div>

        <form onSubmit={handleVerify} className="space-y-4">
          <input
            type="password"
            autoFocus
            maxLength={4}
            value={pin}
            onChange={(e) => {
              setPin(e.target.value);
              if (error) setError(false);
            }}
            placeholder="••••"
            className="w-40 mx-auto px-4 py-3 text-center text-2xl font-mono tracking-widest border border-slate-300 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />

          {error && (
            <p className="text-xs text-rose-500 flex items-center justify-center gap-1 font-medium">
              <ShieldAlert className="w-3.5 h-3.5" /> Hatalı PIN kodu! (İpucu: 1234)
            </p>
          )}

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 rounded-xl"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="flex-1 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-sm transition-colors"
            >
              Kilidi Aç
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
