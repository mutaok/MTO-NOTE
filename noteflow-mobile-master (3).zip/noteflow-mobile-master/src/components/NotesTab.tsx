import React, { useMemo, useState } from 'react';
import { Note, Notebook } from '../types';
import {
  Plus,
  Search,
  ArrowUpDown,
  FileText,
  Calendar,
  Trash2,
  Edit3,
  BookOpen,
} from 'lucide-react';

interface NotesTabProps {
  notes: Note[];
  notebooks?: Notebook[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string; notebookId?: string }) => void;
  onDeleteNote: (id: string) => void;
  editorNote?: Note | null;
  isEditorOpen?: boolean;
  onOpenEditor: (note?: Note) => void;
  onCloseEditor?: () => void;
}

const PRESET_TAGS = ['Kişisel', 'İş', 'Fikir', 'Proje', 'Eğitim', 'Akademik', 'Günlük', 'Toplantı'];
const TAG_COLORS: Record<string, string> = {
  İş: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-200 dark:border-blue-800',
  Kişisel: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800',
  Fikir: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border-purple-200 dark:border-purple-800',
  Proje: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
  Eğitim: 'bg-pink-100 text-pink-800 dark:bg-pink-950 dark:text-pink-300 border-pink-200 dark:border-pink-800',
  Akademik: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
  Günlük: 'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300 border-orange-200 dark:border-orange-800',
  Toplantı: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-200 dark:border-teal-800',
};

export const NotesTab: React.FC<NotesTabProps> = ({
  notes,
  notebooks = [],
  onDeleteNote,
  onOpenEditor,
}) => {
  const [activeTag, setActiveTag] = useState<string>('Tümü');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  const tags = useMemo(() => {
    const list = Array.from(new Set(notes.map((n) => n.tag))).filter(Boolean);
    return ['Tümü', ...Array.from(new Set([...PRESET_TAGS, ...list]))];
  }, [notes]);

  const filteredNotes = useMemo(() => {
    let result = notes;
    if (activeTag !== 'Tümü') {
      result = result.filter((n) => n.tag === activeTag);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (n) => n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q) || n.tag.toLowerCase().includes(q),
      );
    }
    return [...result].sort((a, b) => {
      const diff = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
      return sortAsc ? diff : -diff;
    });
  }, [notes, activeTag, searchQuery, sortAsc]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Bar: Title + Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Kütüphanen
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Notlar ({notes.length})
          </h1>
        </div>
        <button
          onClick={() => onOpenEditor()}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm transition-colors shadow-sm self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Not Oluştur</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Notlarda ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
          />
        </div>

        {/* Sort Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSortAsc(!sortAsc)}
            className="flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>{sortAsc ? 'En Eski' : 'En Yeni'}</span>
          </button>
        </div>
      </div>

      {/* Tags Scroll */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {tags.map((t) => {
          const isActive = activeTag === t;
          return (
            <button
              key={t}
              onClick={() => setActiveTag(t)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {t}
            </button>
          );
        })}
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Henüz not bulunamadı
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mt-1">
            Yeni bir not oluşturarak düşüncelerini veya çalışma maddelerini kaydetmeye başla.
          </p>
          <button
            onClick={() => onOpenEditor()}
            className="mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Yeni Not Ekle
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => {
            const tagStyle =
              TAG_COLORS[note.tag] ||
              'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700';

            const linkedNotebook = notebooks.find((nb) => nb.id === note.notebookId);

            return (
              <div
                key={note.id}
                className="group flex flex-col justify-between p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500/80 hover:shadow-md transition-all relative"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span
                        className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${tagStyle}`}
                      >
                        {note.tag}
                      </span>
                      {linkedNotebook && (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 flex items-center gap-1">
                          <BookOpen className="w-3 h-3 text-blue-500" />
                          {linkedNotebook.name || linkedNotebook.title}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onOpenEditor(note)}
                        className="p-1 rounded-lg text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Düzenle"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteNote(note.id)}
                        className="p-1 rounded-lg text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3
                    onClick={() => onOpenEditor(note)}
                    className="text-base font-bold text-slate-900 dark:text-white cursor-pointer group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-1"
                  >
                    {note.title}
                  </h3>

                  <p
                    onClick={() => onOpenEditor(note)}
                    className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-4 leading-relaxed cursor-pointer whitespace-pre-line"
                  >
                    {note.body || 'Boş not'}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>
                    {new Date(note.updatedAt).toLocaleDateString('tr-TR', {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </span>
                  {note.date && (
                    <span className="flex items-center gap-1 font-medium text-blue-600 dark:text-blue-400">
                      <Calendar className="w-3 h-3" />
                      {note.date}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
