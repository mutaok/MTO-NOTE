import React from 'react';
import { AppTab } from '../types';
import {
  Home,
  FileText,
  CheckSquare,
  Network,
  Search,
  Sun,
  Moon,
  Sparkles,
  BookOpen,
  CloudCheck,
  HardDrive,
  Cpu,
  Mail,
  StickyNote,
} from 'lucide-react';

interface NavbarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  isDark: boolean;
  toggleDark: () => void;
  badgeCounts: {
    notebooks?: number;
    notes: number;
    tasksToday: number;
    mindmaps: number;
  };
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleDark,
  badgeCounts,
}) => {
  const tabs = [
    {
      id: 'notebooks' as AppTab,
      label: 'Defterler (11 Tür)',
      icon: BookOpen,
      badge: badgeCounts.notebooks,
    },
    { id: 'home' as AppTab, label: 'Ana Sayfa', icon: Home },
    {
      id: 'notes' as AppTab,
      label: 'Notlar',
      icon: FileText,
      badge: badgeCounts.notes,
    },
    {
      id: 'tasks' as AppTab,
      label: 'Görevler & Takvim',
      icon: CheckSquare,
      badge: badgeCounts.tasksToday > 0 ? badgeCounts.tasksToday : undefined,
    },
    {
      id: 'mindmap' as AppTab,
      label: 'Mind Map',
      icon: Network,
      badge: badgeCounts.mindmaps,
    },
    {
      id: 'drive' as AppTab,
      label: 'Google Drive',
      icon: HardDrive,
    },
    {
      id: 'gmail' as AppTab,
      label: 'Gmail',
      icon: Mail,
    },
    {
      id: 'keep' as AppTab,
      label: 'Google Keep',
      icon: StickyNote,
    },
    {
      id: 'architecture' as AppTab,
      label: 'Flutter & Supabase Mimari',
      icon: Cpu,
    },
    { id: 'search' as AppTab, label: 'Arama', icon: Search },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                Note<span className="text-blue-600 dark:text-blue-400">Flow</span>
              </span>
              <span className="hidden sm:inline-block ml-2 text-xs font-medium px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200/60 dark:border-blue-900/50">
                Workspace
              </span>
            </div>
          </div>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 font-semibold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400'}`} />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span
                      className={`ml-1 text-[11px] font-bold px-1.5 py-0.2 rounded-full ${
                        isActive
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right actions: Cloud sync status & Theme toggle */}
          <div className="flex items-center gap-2">
            <div
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-900/40 text-xs font-medium"
              title="Supabase PostgreSQL ve Cihazlar Arası Otomatik Senkronizasyon Etkin"
            >
              <CloudCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span className="hidden sm:inline">Supabase Bulut Senkron</span>
            </div>

            <button
              onClick={toggleDark}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={isDark ? 'Açık Mod' : 'Karanlık Mod'}
              aria-label="Tema Değiştir"
            >
              {isDark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Tabs */}
      <div className="md:hidden flex items-center overflow-x-auto no-scrollbar border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 py-2 px-2 gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-xs font-medium transition-colors shrink-0 ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/40'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 text-[10px] font-bold px-1 rounded-full bg-blue-600 text-white">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="whitespace-nowrap text-[11px]">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
