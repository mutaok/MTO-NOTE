import React from 'react';
import { MindMap, Note, Task, AppTab } from '../types';
import { newId } from '../data/sync/ids';
import { FileText, CheckSquare, Network } from 'lucide-react';

interface HomeTabProps {
  notes: Note[];
  tasks: Task[];
  mindmaps: MindMap[];
  setActiveTab: (tab: AppTab) => void;
  onOpenNoteEditor: (note?: Note) => void;
  onOpenTaskEditor: (task?: Task) => void;
  onSelectMindMap: (map: MindMap) => void;
  onToggleTask: (taskId: string) => void;
  handleSaveMindMap?: (map: MindMap) => void;
  setCurrentMindMap?: (map: MindMap) => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  setActiveTab,
  onOpenNoteEditor,
  onOpenTaskEditor,
  handleSaveMindMap,
  setCurrentMindMap,
}) => {
  const handleCreateMindMap = () => {
    const newMap: MindMap = {
      id: newId(),
      title: 'Yeni Zihin Haritası',
      type: 'mindmap',
      data: {
        kind: 'tree',
        root: {
          id: 'root',
          title: 'Ana Fikir',
          children: [],
          color: '#14b8a6',
        },
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (handleSaveMindMap) handleSaveMindMap(newMap);
    if (setCurrentMindMap) setCurrentMindMap(newMap);
    setActiveTab('mindmap');
  };

  return (
    <div className="w-full h-full min-h-[70vh] flex flex-col items-center justify-center p-4">
      {/* Sadece İstenen 3 Buton: Yeni Not, Yeni Görev, Yeni Mind Map */}
      <div className="w-full max-w-md flex flex-col gap-3.5">
        <button
          id="home-btn-new-note"
          onClick={() => {
            onOpenNoteEditor();
            setActiveTab('notes');
          }}
          className="w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl bg-teal-500 hover:bg-teal-600 active:scale-[0.99] text-white font-bold text-base shadow-sm transition-all cursor-pointer"
        >
          <FileText className="w-5 h-5" />
          <span>Yeni Not</span>
        </button>

        <button
          id="home-btn-new-task"
          onClick={() => {
            onOpenTaskEditor();
            setActiveTab('tasks');
          }}
          className="w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-bold text-base shadow-sm transition-all cursor-pointer"
        >
          <CheckSquare className="w-5 h-5" />
          <span>Yeni Görev</span>
        </button>

        <button
          id="home-btn-new-mindmap"
          onClick={handleCreateMindMap}
          className="w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl bg-purple-600 hover:bg-purple-700 active:scale-[0.99] text-white font-bold text-base shadow-sm transition-all cursor-pointer"
        >
          <Network className="w-5 h-5" />
          <span>Yeni Mind Map</span>
        </button>
      </div>
    </div>
  );
};
