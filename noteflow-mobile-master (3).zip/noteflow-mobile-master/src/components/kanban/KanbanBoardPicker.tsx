import React, { useState, useMemo } from 'react';
import {
  Kanban,
  Plus,
  Search,
  CheckCircle2,
  Layers,
  Calendar,
  Trash2,
  ArrowRight,
  Sparkles,
  LayoutGrid,
} from 'lucide-react';
import { KanbanBoard } from '../../types/kanban';
import { StorageService } from '../../data/storage';

interface KanbanBoardPickerProps {
  boards: KanbanBoard[];
  onSelectBoard: (boardId: string) => void;
  onCreateBoardClick: () => void;
  onDeleteBoard: (boardId: string) => void;
  isDark: boolean;
}

export const KanbanBoardPicker: React.FC<KanbanBoardPickerProps> = ({
  boards,
  onSelectBoard,
  onCreateBoardClick,
  onDeleteBoard,
  isDark,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Calculate stats for each board from storage
  const boardStats = useMemo(() => {
    const allLists = StorageService.getKanbanLists();
    const allCards = StorageService.getKanbanCards();

    const statsMap: Record<
      string,
      { listCount: number; cardCount: number; completedCount: number; percent: number }
    > = {};

    boards.forEach((b) => {
      const boardLists = allLists.filter((l) => l.board_id === b.id && !l.archived);
      const boardCards = allCards.filter((c) => c.list_id && boardLists.some((l) => l.id === c.list_id) && !c.archived);
      const completedCards = boardCards.filter((c) => {
        const totalItems = c.checklist?.length || 0;
        const doneItems = c.checklist?.filter((item) => item.is_done).length || 0;
        return Boolean(c.completed || (totalItems > 0 && doneItems === totalItems));
      });

      const total = boardCards.length;
      const completed = completedCards.length;
      const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

      statsMap[b.id] = {
        listCount: boardLists.length,
        cardCount: total,
        completedCount: completed,
        percent,
      };
    });

    return statsMap;
  }, [boards]);

  // Filtered boards
  const filteredBoards = useMemo(() => {
    if (!searchQuery.trim()) return boards;
    const q = searchQuery.toLowerCase();
    return boards.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        (b.description && b.description.toLowerCase().includes(q))
    );
  }, [boards, searchQuery]);

  return (
    <div className="w-full h-full flex flex-col p-4 sm:p-8 max-w-7xl mx-auto overflow-y-auto custom-scrollbar">
      {/* Hero Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200/80 dark:border-slate-800 shrink-0">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-500/10 text-teal-600 dark:text-teal-400 mb-2">
            <Kanban className="w-3.5 h-3.5" />
            <span>Pano Seçimi</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Kanban Panoları
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
            Çalışmak istediğiniz panoyu seçin. Seçilen pano ve kartlar doğrudan <strong>tam ekran</strong> çalışma alanında açılır.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onCreateBoardClick}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-xs sm:text-sm font-bold shadow-md shadow-teal-500/20 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Pano Oluştur</span>
          </button>
        </div>
      </div>

      {/* Search & Stats Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 py-4 shrink-0">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Panolarda ara..."
            className={`w-full pl-9 pr-4 py-2 text-xs sm:text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all ${
              isDark
                ? 'bg-slate-900/90 border-slate-800 text-white placeholder-slate-500'
                : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
            }`}
          />
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1.5 font-medium">
            <LayoutGrid className="w-3.5 h-3.5 text-teal-500" />
            Toplam <strong>{boards.length}</strong> pano
          </span>
        </div>
      </div>

      {/* Boards Grid */}
      {filteredBoards.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 pt-2 pb-12">
          {filteredBoards.map((board) => {
            const stats = boardStats[board.id] || {
              listCount: 0,
              cardCount: 0,
              completedCount: 0,
              percent: 0,
            };
            const boardAccent = board.color || '#0d9488';
            const isDeleting = confirmDeleteId === board.id;

            return (
              <div
                key={board.id}
                onClick={() => !isDeleting && onSelectBoard(board.id)}
                className={`group relative rounded-2xl border transition-all duration-200 flex flex-col justify-between overflow-hidden cursor-pointer hover:shadow-xl hover:-translate-y-0.5 ${
                  isDark
                    ? 'bg-slate-900/90 border-slate-800/90 hover:border-teal-500/50'
                    : 'bg-white border-slate-200 hover:border-teal-500/50 shadow-xs'
                }`}
              >
                {/* Top Accent Color Stripe */}
                <div
                  className="h-2 w-full transition-opacity group-hover:opacity-100"
                  style={{ backgroundColor: boardAccent }}
                />

                <div className="p-5 flex-1 flex flex-col justify-between">
                  {/* Header Row */}
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full shrink-0 ring-2 ring-white/20"
                          style={{ backgroundColor: boardAccent }}
                        />
                        <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors line-clamp-1">
                          {board.title}
                        </h3>
                      </div>

                      {/* Delete Action */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (isDeleting) {
                            onDeleteBoard(board.id);
                            setConfirmDeleteId(null);
                          } else {
                            setConfirmDeleteId(board.id);
                          }
                        }}
                        title={isDeleting ? 'Silmeyi Onayla' : 'Panoyu Sil'}
                        className={`p-1.5 rounded-lg text-xs transition-colors shrink-0 ${
                          isDeleting
                            ? 'bg-rose-500 text-white font-bold px-2'
                            : 'text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 opacity-0 group-hover:opacity-100'
                        }`}
                      >
                        {isDeleting ? 'Onayla' : <Trash2 className="w-4 h-4" />}
                      </button>
                    </div>

                    {isDeleting && (
                      <div className="text-[11px] text-rose-500 mb-2 font-medium flex items-center justify-between">
                        <span>Pano ve tüm kartları silinecek?</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setConfirmDeleteId(null);
                          }}
                          className="underline text-slate-400 hover:text-slate-600"
                        >
                          Vazgeç
                        </button>
                      </div>
                    )}

                    {board.description && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                        {board.description}
                      </p>
                    )}
                  </div>

                  {/* Metrics & Progress */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80 mt-4 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span className="flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-slate-400" />
                        <strong>{stats.listCount}</strong> sütun
                      </span>
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-500" />
                        <strong>{stats.cardCount}</strong> kart
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div>
                      <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
                        <span className="text-slate-500 dark:text-slate-400">Tamamlanma</span>
                        <span className="text-teal-600 dark:text-teal-400 font-mono">
                          %{stats.percent} ({stats.completedCount}/{stats.cardCount})
                        </span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-teal-500 transition-all duration-300 rounded-full"
                          style={{ width: `${stats.percent}%` }}
                        />
                      </div>
                    </div>

                    {/* CTA Button */}
                    <div className="pt-2 flex items-center justify-between text-xs font-bold text-teal-600 dark:text-teal-400 group-hover:translate-x-1 transition-transform">
                      <span className="flex items-center gap-1">
                        <span>Panoyu Aç (Tam Ekran)</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {board.updated_at ? new Date(board.updated_at).toLocaleDateString('tr-TR') : ''}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Quick Add New Board Card */}
          <button
            onClick={onCreateBoardClick}
            className={`rounded-2xl border-2 border-dashed p-8 flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer min-h-[220px] ${
              isDark
                ? 'border-slate-800 hover:border-teal-500/60 bg-slate-900/40 hover:bg-slate-900/70 text-slate-400 hover:text-teal-400'
                : 'border-slate-200 hover:border-teal-500/60 bg-slate-50/50 hover:bg-teal-50/20 text-slate-500 hover:text-teal-600'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-teal-500/10 flex items-center justify-center text-teal-500 mb-1">
              <Plus className="w-6 h-6" />
            </div>
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              Yeni Bir Pano Oluşturun
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 max-w-xs">
              Projeleriniz, görev akışlarınız veya fikirleriniz için özel sütun ve kart panosu oluşturun.
            </span>
          </button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-slate-400">
          <Kanban className="w-16 h-16 text-teal-500/40 mb-4" />
          <h3 className="text-lg font-bold text-slate-700 dark:text-slate-200 mb-2">
            {searchQuery ? 'Eşleşen Pano Bulunamadı' : 'Henüz Hiç Pano Yok'}
          </h3>
          <p className="text-xs sm:text-sm max-w-md mb-6 text-slate-500 dark:text-slate-400">
            {searchQuery
              ? `"${searchQuery}" aramasıyla eşleşen bir pano bulunamadı. Aramayı temizlemeyi deneyin.`
              : 'Yeni bir Kanban panosu oluşturarak kartlarınızı sürükle-bırak yöntemiyle tam ekran organize edin.'}
          </p>
          {searchQuery ? (
            <button
              onClick={() => setSearchQuery('')}
              className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              Aramayı Temizle
            </button>
          ) : (
            <button
              onClick={onCreateBoardClick}
              className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-teal-500/20"
            >
              + İlk Panoyu Oluştur
            </button>
          )}
        </div>
      )}
    </div>
  );
};
