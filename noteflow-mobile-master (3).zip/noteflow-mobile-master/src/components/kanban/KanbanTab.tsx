import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  KanbanBoard,
  KanbanList,
  KanbanCard,
  KanbanLabel,
  KanbanActivityLog,
} from '../../types/kanban';
import { KanbanService, KanbanSnapshot } from '../../lib/kanban/kanbanService';
import { StorageService } from '../../data/storage';
import { calculateInsertPosition, normalizePositions } from '../../lib/kanban/ranking';
import { BoardView } from './BoardView';
import { CardModal } from './CardModal';
import { ActivityDrawer } from './ActivityDrawer';
import { KanbanBoardPicker } from './KanbanBoardPicker';
import {
  Kanban,
  Plus,
  Search,
  Filter,
  Activity,
  Archive,
  Keyboard,
  CheckCircle2,
  AlertCircle,
  X,
  ChevronDown,
  Trash2,
  ArrowLeft,
  Maximize2,
  Minimize2,
} from 'lucide-react';

interface KanbanTabProps {
  isDark: boolean;
  onBoardSelectChange?: (hasActiveBoard: boolean) => void;
}

export const KanbanTab: React.FC<KanbanTabProps> = ({ isDark, onBoardSelectChange }) => {
  // Boards state
  const [boards, setBoards] = useState<KanbanBoard[]>([]);
  const [selectedBoardId, setSelectedBoardId] = useState<string>(() => {
    return localStorage.getItem('noteflow_selected_kanban_board_id') || '';
  });

  // Native fullscreen state
  const [isNativeFullscreen, setIsNativeFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsNativeFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleNativeFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  // Lists & Cards state
  const [lists, setLists] = useState<KanbanList[]>([]);
  const [cards, setCards] = useState<KanbanCard[]>([]);
  const [labels, setLabels] = useState<KanbanLabel[]>([]);
  const [activities, setActivities] = useState<KanbanActivityLog[]>([]);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLabelId, setSelectedLabelId] = useState<string>('all');
  const [selectedDueFilter, setSelectedDueFilter] = useState<'all' | 'overdue' | 'due-soon' | 'done'>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'all' | 'completed' | 'uncompleted'>('all');
  const [showArchived, setShowArchived] = useState(false);

  // Modals & Drawers
  const [activeModalCard, setActiveModalCard] = useState<KanbanCard | null>(null);
  const [isActivityOpen, setIsActivityOpen] = useState(false);
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);
  const [showNewBoardModal, setShowNewBoardModal] = useState(false);
  const [newBoardTitle, setNewBoardTitle] = useState('');
  const [newBoardDesc, setNewBoardDesc] = useState('');
  const [newBoardColor, setNewBoardColor] = useState('#0d9488');

  // Feedback Toast (for optimistic UI rollback or alerts)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // 1) Load initial data
  const refreshData = useCallback(() => {
    const loadedBoards = KanbanService.getBoards(true);
    setBoards(loadedBoards);

    const activeId =
      selectedBoardId && loadedBoards.some((b) => b.id === selectedBoardId)
        ? selectedBoardId
        : '';

    setSelectedBoardId(activeId);
    onBoardSelectChange?.(Boolean(activeId));

    if (activeId) {
      setLists(KanbanService.getLists(activeId, true));
      setCards(KanbanService.getCards(activeId, true));
      setActivities(KanbanService.getActivities(activeId));
    } else {
      setLists([]);
      setCards([]);
      setActivities([]);
    }

    setLabels(StorageService.getKanbanLabels());
  }, [selectedBoardId, onBoardSelectChange]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const activeBoard = useMemo(() => {
    if (!selectedBoardId) return null;
    return boards.find((b) => b.id === selectedBoardId) || null;
  }, [boards, selectedBoardId]);

  const handleSelectBoard = (boardId: string) => {
    setSelectedBoardId(boardId);
    localStorage.setItem('noteflow_selected_kanban_board_id', boardId);
    onBoardSelectChange?.(true);
  };

  const handleBackToBoardPicker = () => {
    setSelectedBoardId('');
    localStorage.removeItem('noteflow_selected_kanban_board_id');
    onBoardSelectChange?.(false);
  };

  const handleDeleteBoard = (boardId: string) => {
    try {
      KanbanService.deleteBoard(boardId);
      setBoards((prev) => prev.filter((b) => b.id !== boardId));
      if (selectedBoardId === boardId) {
        setSelectedBoardId('');
        localStorage.removeItem('noteflow_selected_kanban_board_id');
        onBoardSelectChange?.(false);
      }
      showToast('Pano silindi.', 'info');
    } catch (err) {
      showToast('Pano silinemedi.', 'error');
    }
  };

  // 2) Filter cards based on search & filters
  const filteredCards = useMemo(() => {
    return cards.filter((card) => {
      // Archive filter
      if (!showArchived && card.archived) return false;
      if (showArchived && !card.archived) return false;

      // Text query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = card.title.toLowerCase().includes(q);
        const matchesDesc = card.description?.toLowerCase().includes(q);
        if (!matchesTitle && !matchesDesc) return false;
      }

      // Label filter
      if (selectedLabelId !== 'all') {
        const hasLabel = card.labels?.some((l) => l.id === selectedLabelId);
        if (!hasLabel) return false;
      }

      // Status filter
      const total = card.checklist?.length || 0;
      const done = card.checklist?.filter((item) => item.is_done).length || 0;
      const isCompleted = Boolean(card.completed || (total > 0 && done === total));

      if (selectedStatusFilter === 'completed' && !isCompleted) return false;
      if (selectedStatusFilter === 'uncompleted' && isCompleted) return false;

      // Due date filter
      if (selectedDueFilter !== 'all') {
        if (selectedDueFilter === 'done') {
          if (!isCompleted) return false;
        } else if (card.due_date) {
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          const due = new Date(card.due_date);
          due.setHours(0, 0, 0, 0);
          const diffDays = Math.round((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

          if (selectedDueFilter === 'overdue' && (diffDays >= 0 || isCompleted)) return false;
          if (selectedDueFilter === 'due-soon' && (diffDays < 0 || diffDays > 1 || isCompleted))
            return false;
        } else {
          return false;
        }
      }

      return true;
    });
  }, [cards, showArchived, searchQuery, selectedLabelId, selectedDueFilter, selectedStatusFilter]);

  // Board completion progress stats
  const boardProgress = useMemo(() => {
    const activeCards = cards.filter((c) => !c.archived);
    const total = activeCards.length;
    if (total === 0) return { total: 0, completed: 0, percent: 0 };
    const completed = activeCards.filter((c) => {
      const checklistTotal = c.checklist?.length || 0;
      const checklistDone = c.checklist?.filter((item) => item.is_done).length || 0;
      return Boolean(c.completed || (checklistTotal > 0 && checklistDone === checklistTotal));
    }).length;
    return {
      total,
      completed,
      percent: Math.round((completed / total) * 100),
    };
  }, [cards]);

  // Active (non-archived or archived) lists
  const visibleLists = useMemo(() => {
    return showArchived ? lists : lists.filter((l) => !l.archived);
  }, [lists, showArchived]);

  // 3) Keyboard Shortcuts (n: new card, e: edit, Esc: close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input/textarea
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (e.key === 'Escape') {
        setActiveModalCard(null);
        setIsActivityOpen(false);
        setShowShortcutsModal(false);
        setShowNewBoardModal(false);
      } else if (e.key === '?' && !e.ctrlKey && !e.metaKey) {
        setShowShortcutsModal((prev) => !prev);
      } else if (e.key === 'n' && !e.ctrlKey && !e.metaKey) {
        // Quick add card to first list
        if (visibleLists.length > 0) {
          e.preventDefault();
          const firstList = visibleLists[0];
          const newCard = KanbanService.createCard(firstList.id, 'Yeni Görev', undefined, activeBoard?.id);
          setCards((prev) => [...prev, newCard]);
          setActiveModalCard(newCard);
          showToast('Yeni kart oluşturuldu. Detayları düzenleyebilirsiniz.');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [visibleLists, activeBoard]);

  // 4) Optimistic Actions with Rollback Support
  const handleCardMove = (
    cardId: string,
    targetListId: string,
    newPosition: number,
    targetListName?: string
  ) => {
    const snapshot: KanbanSnapshot = KanbanService.createSnapshot();

    // Optimistic UI update
    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, list_id: targetListId, position: newPosition } : c))
    );

    try {
      KanbanService.moveCard(cardId, targetListId, newPosition, activeBoard?.id, targetListName);
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
    } catch (err) {
      // Rollback on error
      KanbanService.restoreSnapshot(snapshot);
      refreshData();
      showToast('Kart taşınırken bir hata oluştu, geri alındı.', 'error');
    }
  };

  const handleMoveList = (listId: string, newPosition: number) => {
    const snapshot: KanbanSnapshot = KanbanService.createSnapshot();

    setLists((prev) =>
      prev.map((l) => (l.id === listId ? { ...l, position: newPosition } : l))
    );

    try {
      KanbanService.moveList(listId, newPosition);
    } catch (err) {
      KanbanService.restoreSnapshot(snapshot);
      refreshData();
      showToast('Liste sıralanırken hata oluştu.', 'error');
    }
  };

  const handleAddCard = (listId: string, title: string) => {
    try {
      const created = KanbanService.createCard(listId, title, undefined, activeBoard?.id);
      setCards((prev) => [...prev, created]);
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
      showToast(`"${title}" kartı eklendi.`);
    } catch (err) {
      showToast('Kart eklenemedi.', 'error');
    }
  };

  const handleUpdateCard = (updatedCard: KanbanCard) => {
    try {
      KanbanService.updateCard(updatedCard.id, updatedCard, activeBoard?.id);
      setCards((prev) => prev.map((c) => (c.id === updatedCard.id ? updatedCard : c)));
      setActiveModalCard(updatedCard);
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
    } catch (err) {
      showToast('Kart güncellenemedi.', 'error');
    }
  };

  const handleDeleteCard = (cardId: string) => {
    try {
      KanbanService.deleteCard(cardId, activeBoard?.id);
      setCards((prev) => prev.filter((c) => c.id !== cardId));
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
      showToast('Kart silindi.');
    } catch (err) {
      showToast('Kart silinemedi.', 'error');
    }
  };

  const handleArchiveCard = (cardId: string, archived = true) => {
    try {
      const updated = KanbanService.archiveCard(cardId, archived, activeBoard?.id);
      setCards((prev) => prev.map((c) => (c.id === cardId ? updated : c)));
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
      showToast(archived ? 'Kart arşivlendi.' : 'Kart arşivden çıkarıldı.');
    } catch (err) {
      showToast('İşlem tamamlanamadı.', 'error');
    }
  };

  const handleQuickEditCard = (cardId: string, newTitle: string) => {
    try {
      const updated = KanbanService.updateCard(cardId, { title: newTitle }, activeBoard?.id);
      setCards((prev) => prev.map((c) => (c.id === cardId ? updated : c)));
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
    } catch (err) {
      showToast('Başlık güncellenemedi.', 'error');
    }
  };

  const handleToggleCardComplete = (cardId: string) => {
    const targetCard = cards.find((c) => c.id === cardId);
    if (!targetCard) return;
    const isNowComplete = !targetCard.completed;
    try {
      const updated = KanbanService.updateCard(
        cardId,
        {
          completed: isNowComplete,
          updated_at: new Date().toISOString(),
        },
        activeBoard?.id
      );
      setCards((prev) => prev.map((c) => (c.id === cardId ? updated : c)));
      if (activeModalCard && activeModalCard.id === cardId) {
        setActiveModalCard(updated);
      }
      setActivities(KanbanService.getActivities(activeBoard?.id || ''));
      showToast(isNowComplete ? 'Konu tamamlandı olarak işaretlendi ✓' : 'Konu çalışma listesine geri alındı');
    } catch (err) {
      showToast('Durum güncellenemedi.', 'error');
    }
  };

  const handleAddList = (title: string) => {
    if (!activeBoard) return;
    try {
      const newList = KanbanService.createList(activeBoard.id, title);
      setLists((prev) => [...prev, newList]);
      setActivities(KanbanService.getActivities(activeBoard.id));
      showToast(`"${title}" sütunu eklendi.`);
    } catch (err) {
      showToast('Sütun eklenemedi.', 'error');
    }
  };

  const handleUpdateListTitle = (listId: string, title: string) => {
    try {
      const updated = KanbanService.updateList(listId, { title });
      setLists((prev) => prev.map((l) => (l.id === listId ? updated : l)));
    } catch (err) {
      showToast('Liste başlığı güncellenemedi.', 'error');
    }
  };

  const handleDeleteList = (listId: string) => {
    try {
      KanbanService.deleteList(listId);
      setLists((prev) => prev.filter((l) => l.id !== listId));
      setCards((prev) => prev.filter((c) => c.list_id !== listId));
      showToast('Sütun silindi.');
    } catch (err) {
      showToast('Sütun silinemedi.', 'error');
    }
  };

  const handleArchiveList = (listId: string, archived: boolean) => {
    try {
      const updated = KanbanService.archiveList(listId, archived);
      setLists((prev) => prev.map((l) => (l.id === listId ? updated : l)));
      showToast(archived ? 'Sütun arşivlendi.' : 'Sütun arşivden çıkarıldı.');
    } catch (err) {
      showToast('İşlem gerçekleştirilemedi.', 'error');
    }
  };

  const handleCreateBoard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBoardTitle.trim()) return;
    try {
      const created = KanbanService.createBoard(newBoardTitle, newBoardDesc, newBoardColor);
      setBoards((prev) => [created, ...prev]);
      setSelectedBoardId(created.id);
      setShowNewBoardModal(false);
      setNewBoardTitle('');
      setNewBoardDesc('');
      showToast(`"${created.title}" panosu oluşturuldu!`);
    } catch (err) {
      showToast('Pano oluşturulamadı.', 'error');
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0 w-full overflow-hidden">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold backdrop-blur-md transition-all ${
            toast.type === 'error'
              ? 'bg-rose-500/90 text-white'
              : 'bg-emerald-600/90 text-white'
          }`}
        >
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Main View: Board Picker or Full-Screen Cards Board */}
      {!activeBoard ? (
        <KanbanBoardPicker
          boards={boards}
          onSelectBoard={handleSelectBoard}
          onCreateBoardClick={() => setShowNewBoardModal(true)}
          onDeleteBoard={handleDeleteBoard}
          isDark={isDark}
        />
      ) : (
        <>
          {/* Top Header & Toolbar */}
          <header
            className={`px-3 sm:px-6 py-2.5 sm:py-3 border-b shrink-0 flex flex-wrap items-center justify-between gap-2.5 ${
              isDark
                ? 'bg-slate-900/95 border-slate-800 text-white'
                : 'bg-white/95 border-slate-200 text-slate-900'
            }`}
          >
            {/* Left: Return to Board Picker ("Pano Seçimi") + Active Board Selector */}
            <div className="flex items-center flex-wrap gap-2.5">
              <button
                onClick={handleBackToBoardPicker}
                title="Tüm panoları görüntüle ve pano değiştir"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-teal-500/30 bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold text-xs transition-all cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Pano Seçimi</span>
              </button>

              <div className="h-5 w-[1px] bg-slate-200 dark:bg-slate-800 hidden sm:block" />

              <div className="flex items-center gap-2">
                <span
                  className="w-3 h-3 rounded-full shrink-0 ring-2 ring-white/20"
                  style={{ backgroundColor: activeBoard.color || '#0d9488' }}
                />
                {/* Board Dropdown Switcher */}
                <select
                  value={selectedBoardId}
                  onChange={(e) => handleSelectBoard(e.target.value)}
                  className={`px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white'
                      : 'bg-slate-100 border-slate-300 text-slate-900'
                  }`}
                >
                  {boards.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.title}
                    </option>
                  ))}
                </select>
              </div>

              {/* New Board Button */}
              <button
                onClick={() => setShowNewBoardModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-teal-500 hover:bg-teal-600 text-white transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Yeni Pano</span>
              </button>
            </div>

            {/* Right: Search, Filter, Archive, Fullscreen, Activity */}
            <div className="flex items-center flex-wrap gap-2">
              {/* Search Box */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Kartlarda ara..."
                  className={`pl-8 pr-3 py-1 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 w-32 sm:w-44 ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                      : 'bg-slate-100 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Label Filter */}
              <select
                value={selectedLabelId}
                onChange={(e) => setSelectedLabelId(e.target.value)}
                className={`px-2.5 py-1 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-slate-200'
                    : 'bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <option value="all">Tüm Etiketler</option>
                {labels.map((lbl) => (
                  <option key={lbl.id} value={lbl.id}>
                    {lbl.name}
                  </option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value as any)}
                className={`px-2.5 py-1 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-slate-200'
                    : 'bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <option value="all">Tüm Durumlar</option>
                <option value="completed">✓ Tamamlananlar</option>
                <option value="uncompleted">○ Çalışılacaklar</option>
              </select>

              {/* Due Date Filter */}
              <select
                value={selectedDueFilter}
                onChange={(e) => setSelectedDueFilter(e.target.value as any)}
                className={`px-2.5 py-1 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-slate-200'
                    : 'bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <option value="all">Tüm Tarihler</option>
                <option value="overdue">Gecikenler</option>
                <option value="due-soon">Yaklaşanlar (24s)</option>
                <option value="done">Tamamlananlar</option>
              </select>

              {/* Archive View Toggle */}
              <button
                onClick={() => setShowArchived(!showArchived)}
                title="Arşivlenmiş kart ve sütunları göster"
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-xl border transition-colors ${
                  showArchived
                    ? 'bg-amber-500 text-white border-amber-600'
                    : isDark
                    ? 'border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Archive className="w-3.5 h-3.5" />
                <span className="hidden md:inline">{showArchived ? 'Arşiv Modu Açık' : 'Arşiv'}</span>
              </button>

              {/* Native Browser Fullscreen Toggle Button */}
              <button
                onClick={toggleNativeFullscreen}
                title={isNativeFullscreen ? 'Tam Ekrandan Çık (Esc)' : 'Tam Ekran Modu (F11)'}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-xl border transition-colors cursor-pointer ${
                  isNativeFullscreen
                    ? 'bg-teal-500 text-white border-teal-600 shadow-sm'
                    : isDark
                    ? 'border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {isNativeFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                <span className="hidden lg:inline">{isNativeFullscreen ? 'Normal Ekran' : 'Tam Ekran'}</span>
              </button>

              {/* Activity Drawer Trigger */}
              <button
                onClick={() => setIsActivityOpen(true)}
                title="Aktivite Geçmişini Aç"
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-xl border transition-colors ${
                  isDark
                    ? 'border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-teal-500" />
                <span className="hidden md:inline">Aktiviteler</span>
              </button>

              {/* Keyboard Shortcuts Trigger */}
              <button
                onClick={() => setShowShortcutsModal(true)}
                title="Klavye Kısayolları (?)"
                className="p-1.5 text-slate-400 hover:text-teal-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Keyboard className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Board Info & Progress Banner */}
          <div
            className={`px-4 sm:px-6 py-2 border-b flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 ${
              isDark
                ? 'bg-slate-900/60 border-slate-800/80 text-slate-300'
                : 'bg-slate-50/80 border-slate-200/80 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2 max-w-xl">
              {activeBoard.description && (
                <span className="truncate text-slate-500 dark:text-slate-400">
                  {activeBoard.description}
                </span>
              )}
            </div>
            <div className="flex items-center gap-3 ml-auto shrink-0">
              <span className="font-semibold">
                İlerleme:{' '}
                <strong className="text-teal-600 dark:text-teal-400 font-mono">
                  {boardProgress.completed}
                </strong>
                /{boardProgress.total} konu (%{boardProgress.percent})
              </span>
              <div className="w-24 sm:w-36 h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <div
                  className="h-full bg-teal-500 transition-all duration-300 rounded-full"
                  style={{ width: `${boardProgress.percent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Board View / Main Kanban Area - Full Screen Cards Container */}
          <div className="flex-1 h-full min-h-0 w-full overflow-hidden">
            <BoardView
              board={activeBoard}
              lists={visibleLists}
              cards={filteredCards}
              isDark={isDark}
              onUpdateListTitle={handleUpdateListTitle}
              onDeleteList={handleDeleteList}
              onArchiveList={handleArchiveList}
              onAddList={handleAddList}
              onAddCard={handleAddCard}
              onCardClick={(card) => setActiveModalCard(card)}
              onQuickEditCard={handleQuickEditCard}
              onArchiveCard={handleArchiveCard}
              onCardMove={handleCardMove}
              onMoveList={handleMoveList}
              onToggleCardComplete={handleToggleCardComplete}
              onNormalizeList={(listId) => {
                const destCards = cards.filter((c) => c.list_id === listId);
                const normalized = normalizePositions(destCards);
                setCards((prev) =>
                  prev.map((c) => {
                    const norm = normalized.find((n: any) => n.id === c.id);
                    return norm ? { ...c, position: norm.position } : c;
                  })
                );
                StorageService.saveKanbanCards(
                  StorageService.getKanbanCards().map((c) => {
                    const norm = normalized.find((n: any) => n.id === c.id);
                    return norm ? { ...c, position: norm.position } : c;
                  })
                );
                showToast('Kart pozisyonları 65536 katlarına normalize edildi.');
              }}
            />
          </div>

          {/* Card Detail Modal */}
          <CardModal
            card={activeModalCard}
            lists={visibleLists}
            availableLabels={labels}
            isOpen={Boolean(activeModalCard)}
            isDark={isDark}
            onClose={() => setActiveModalCard(null)}
            onUpdateCard={handleUpdateCard}
            onDeleteCard={handleDeleteCard}
            onArchiveCard={handleArchiveCard}
            onMoveCardToList={(cardId, targetListId) => {
              const destCards = cards.filter((c) => c.list_id === targetListId);
              const { position } = calculateInsertPosition(destCards, destCards.length);
              handleCardMove(cardId, targetListId, position);
              if (activeModalCard) {
                setActiveModalCard({ ...activeModalCard, list_id: targetListId, position });
              }
            }}
          />

          {/* Activity Drawer */}
          <ActivityDrawer
            isOpen={isActivityOpen}
            isDark={isDark}
            activities={activities}
            onClose={() => setIsActivityOpen(false)}
          />
        </>
      )}

      {/* New Board Modal */}
      {showNewBoardModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div
            className={`w-full max-w-md rounded-2xl border p-5 shadow-2xl ${
              isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold">Yeni Kanban Panosu Oluştur</h3>
              <button
                onClick={() => setShowNewBoardModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateBoard} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Pano Başlığı</label>
                <input
                  autoFocus
                  type="text"
                  value={newBoardTitle}
                  onChange={(e) => setNewBoardTitle(e.target.value)}
                  placeholder="örn. 2026 Ürün Yol Haritası"
                  className={`w-full px-3 py-2 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-300'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Açıklama (opsiyonel)</label>
                <textarea
                  rows={2}
                  value={newBoardDesc}
                  onChange={(e) => setNewBoardDesc(e.target.value)}
                  placeholder="Panonun amacı ve hedefleri..."
                  className={`w-full px-3 py-2 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-300'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1.5">Pano Tema Rengi</label>
                <div className="flex items-center gap-2">
                  {['#0d9488', '#3B82F6', '#6366f1', '#8B5CF6', '#EC4899', '#F59E0B', '#10B981'].map(
                    (color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setNewBoardColor(color)}
                        className={`w-7 h-7 rounded-xl border-2 transition-transform ${
                          newBoardColor === color
                            ? 'scale-110 border-white ring-2 ring-teal-500'
                            : 'border-transparent hover:scale-105'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    )
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewBoardModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={!newBoardTitle.trim()}
                  className="px-4 py-2 text-xs font-bold bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white rounded-xl cursor-pointer"
                >
                  Pano Oluştur
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Keyboard Shortcuts Cheat-sheet Modal */}
      {showShortcutsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div
            className={`w-full max-w-sm rounded-2xl border p-5 shadow-2xl ${
              isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Keyboard className="w-4 h-4 text-teal-500" />
                <h4 className="font-bold text-sm">Klavye Kısayolları</h4>
              </div>
              <button
                onClick={() => setShowShortcutsModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Hızlı Yeni Kart Ekle</span>
                <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono font-bold text-teal-500">
                  N
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Modal veya Menüyü Kapat</span>
                <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono font-bold text-teal-500">
                  Esc
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Kartı Yukarı / Aşağı Taşı</span>
                <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono font-bold text-teal-500">
                  Alt + ↑ / ↓
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Kartı Başka Sütuna Taşı</span>
                <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono font-bold text-teal-500">
                  Alt + ← / →
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-500">Kısayol Penceresini Aç</span>
                <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono font-bold text-teal-500">
                  ?
                </kbd>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
