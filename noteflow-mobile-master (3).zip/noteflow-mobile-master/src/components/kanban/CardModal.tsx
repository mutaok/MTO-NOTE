import React, { useState } from 'react';
import {
  KanbanCard,
  KanbanList,
  KanbanLabel,
  KanbanChecklistItem,
  KanbanComment,
} from '../../types/kanban';
import {
  X,
  Calendar,
  Tag,
  CheckSquare,
  MessageSquare,
  AlignLeft,
  Archive,
  Trash2,
  Plus,
  ArrowRight,
  Clock,
  User,
  Sparkles,
  CheckCircle2,
  Circle,
} from 'lucide-react';
import { newId } from '../../data/sync/ids';

interface CardModalProps {
  card: KanbanCard | null;
  lists: KanbanList[];
  availableLabels: KanbanLabel[];
  isOpen: boolean;
  isDark: boolean;
  onClose: () => void;
  onUpdateCard: (updatedCard: KanbanCard) => void;
  onDeleteCard: (cardId: string) => void;
  onArchiveCard: (cardId: string, archived: boolean) => void;
  onMoveCardToList: (cardId: string, targetListId: string) => void;
}

export const CardModal: React.FC<CardModalProps> = ({
  card,
  lists,
  availableLabels,
  isOpen,
  isDark,
  onClose,
  onUpdateCard,
  onDeleteCard,
  onArchiveCard,
  onMoveCardToList,
}) => {
  if (!isOpen || !card) return null;

  const currentList = lists.find((l) => l.id === card.list_id);

  // Local state for editing
  const [title, setTitle] = useState(card.title);
  const [description, setDescription] = useState(card.description || '');
  const [isEditingDesc, setIsEditingDesc] = useState(!card.description);
  const [dueDate, setDueDate] = useState(card.due_date || '');

  // Checklist state
  const [newChecklistText, setNewChecklistText] = useState('');
  const [showAddChecklist, setShowAddChecklist] = useState(false);

  // Comment state
  const [commentText, setCommentText] = useState('');
  const [commentAuthor, setCommentAuthor] = useState('Kullanıcı');

  // Label popup
  const [showLabelPicker, setShowLabelPicker] = useState(false);
  const [customLabelName, setCustomLabelName] = useState('');
  const [customLabelColor, setCustomLabelColor] = useState('#3B82F6');

  // Checklist statistics
  const totalChecklist = card.checklist?.length || 0;
  const doneChecklist = card.checklist?.filter((item) => item.is_done).length || 0;
  const checklistPercent = totalChecklist > 0 ? Math.round((doneChecklist / totalChecklist) * 100) : 0;

  // Title save
  const handleTitleBlur = () => {
    if (title.trim() && title.trim() !== card.title) {
      onUpdateCard({ ...card, title: title.trim(), updated_at: new Date().toISOString() });
    }
  };

  // Description save
  const handleSaveDescription = () => {
    onUpdateCard({ ...card, description, updated_at: new Date().toISOString() });
    setIsEditingDesc(false);
  };

  // Due Date save
  const handleDueDateChange = (newDate: string) => {
    setDueDate(newDate);
    onUpdateCard({
      ...card,
      due_date: newDate ? newDate : null,
      updated_at: new Date().toISOString(),
    });
  };

  // Toggle label on card
  const handleToggleLabel = (label: KanbanLabel) => {
    const existing = card.labels || [];
    const hasLabel = existing.some((l) => l.id === label.id);
    let nextLabels: KanbanLabel[];
    if (hasLabel) {
      nextLabels = existing.filter((l) => l.id !== label.id);
    } else {
      nextLabels = [...existing, label];
    }
    onUpdateCard({ ...card, labels: nextLabels, updated_at: new Date().toISOString() });
  };

  // Add custom label
  const handleAddCustomLabel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customLabelName.trim()) return;
    const newLbl: KanbanLabel = {
      id: newId(),
      name: customLabelName.trim(),
      color: customLabelColor,
    };
    handleToggleLabel(newLbl);
    setCustomLabelName('');
  };

  // Checklist handlers
  const handleToggleChecklistItem = (itemId: string) => {
    const nextChecklist = (card.checklist || []).map((item) =>
      item.id === itemId ? { ...item, is_done: !item.is_done } : item
    );
    onUpdateCard({ ...card, checklist: nextChecklist, updated_at: new Date().toISOString() });
  };

  const handleAddChecklistItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistText.trim()) return;
    const newItem: KanbanChecklistItem = {
      id: newId(),
      card_id: card.id,
      text: newChecklistText.trim(),
      is_done: false,
    };
    const nextChecklist = [...(card.checklist || []), newItem];
    onUpdateCard({ ...card, checklist: nextChecklist, updated_at: new Date().toISOString() });
    setNewChecklistText('');
  };

  const handleDeleteChecklistItem = (itemId: string) => {
    const nextChecklist = (card.checklist || []).filter((item) => item.id !== itemId);
    onUpdateCard({ ...card, checklist: nextChecklist, updated_at: new Date().toISOString() });
  };

  // Comments handler
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    const newComm: KanbanComment = {
      id: newId(),
      card_id: card.id,
      author_name: commentAuthor.trim() || 'Kullanıcı',
      text: commentText.trim(),
      created_at: new Date().toISOString(),
    };
    const nextComments = [newComm, ...(card.comments || [])];
    onUpdateCard({ ...card, comments: nextComments, updated_at: new Date().toISOString() });
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="card-modal-title"
        className={`relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl shadow-2xl border overflow-hidden z-10 transition-all ${
          isDark
            ? 'bg-slate-900 text-slate-100 border-slate-700/80'
            : 'bg-white text-slate-900 border-slate-200'
        }`}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 pb-3 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <input
              id="card-modal-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={handleTitleBlur}
              className={`w-full text-lg sm:text-xl font-bold bg-transparent border-b border-transparent hover:border-slate-300 dark:hover:border-slate-700 focus:border-teal-500 focus:outline-none rounded px-1 py-0.5 transition-colors ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            />
            <div className="flex items-center flex-wrap gap-2 mt-2 px-1 text-xs text-slate-500 dark:text-slate-400">
              <button
                type="button"
                onClick={() =>
                  onUpdateCard({
                    ...card,
                    completed: !card.completed,
                    updated_at: new Date().toISOString(),
                  })
                }
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                  card.completed
                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/25'
                    : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-teal-500/50'
                }`}
              >
                {card.completed ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Tamamlandı</span>
                  </>
                ) : (
                  <>
                    <Circle className="w-3.5 h-3.5 text-slate-400" />
                    <span>Tamamlandı Olarak İşaretle</span>
                  </>
                )}
              </button>
              <span>•</span>
              <span>Şu listede:</span>
              <span className="font-semibold text-teal-600 dark:text-teal-400">
                {currentList?.title || 'Bilinmiyor'}
              </span>
              {card.archived && (
                <span className="px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500 font-bold uppercase text-[10px]">
                  Arşivlenmiş
                </span>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Kapat"
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: 2 Columns */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Column (2/3) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Active Labels */}
            {card.labels && card.labels.length > 0 && (
              <div>
                <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Etiketler
                </h5>
                <div className="flex flex-wrap gap-2">
                  {card.labels.map((lbl) => (
                    <span
                      key={lbl.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold text-white shadow-xs"
                      style={{ backgroundColor: lbl.color }}
                    >
                      {lbl.name}
                      <button
                        onClick={() => handleToggleLabel(lbl)}
                        className="hover:bg-black/20 rounded-full p-0.5 transition-colors"
                        title="Etiketi Kaldır"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Description Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-300">
                  <AlignLeft className="w-4 h-4 text-teal-500" />
                  <span>Açıklama</span>
                </div>
                {!isEditingDesc && card.description && (
                  <button
                    onClick={() => setIsEditingDesc(true)}
                    className="text-xs font-medium text-teal-600 dark:text-teal-400 hover:underline"
                  >
                    Düzenle
                  </button>
                )}
              </div>

              {isEditingDesc ? (
                <div className="space-y-2">
                  <textarea
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Bu karta daha ayrıntılı bir açıklama ekleyin..."
                    className={`w-full p-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all ${
                      isDark
                        ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                        : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                    }`}
                  />
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSaveDescription}
                      className="px-4 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      Kaydet
                    </button>
                    <button
                      onClick={() => {
                        setDescription(card.description || '');
                        setIsEditingDesc(false);
                      }}
                      className="px-3 py-1.5 rounded-xl text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      İptal
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  onClick={() => setIsEditingDesc(true)}
                  className={`p-3 rounded-xl text-sm leading-relaxed cursor-pointer transition-colors ${
                    card.description
                      ? isDark
                        ? 'bg-slate-800/60 hover:bg-slate-800 text-slate-200'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                      : isDark
                      ? 'bg-slate-800/40 text-slate-500 hover:text-slate-400'
                      : 'bg-slate-50 text-slate-400 hover:text-slate-600'
                  }`}
                >
                  {card.description || 'Ayrıntılı açıklama eklemek için tıklayın...'}
                </div>
              )}
            </div>

            {/* Checklist Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-300">
                  <CheckSquare className="w-4 h-4 text-teal-500" />
                  <span>Kontrol Listesi (Checklist)</span>
                </div>
                <span className="text-xs font-mono text-slate-400 font-medium">
                  {doneChecklist}/{totalChecklist} (%{checklistPercent})
                </span>
              </div>

              {/* Progress Bar */}
              {totalChecklist > 0 && (
                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mb-3">
                  <div
                    className={`h-full transition-all duration-300 rounded-full ${
                      doneChecklist === totalChecklist ? 'bg-emerald-500' : 'bg-teal-500'
                    }`}
                    style={{ width: `${checklistPercent}%` }}
                  />
                </div>
              )}

              {/* Checklist Items */}
              <div className="space-y-1.5 mb-3">
                {(card.checklist || []).map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/60 group transition-colors"
                  >
                    <label className="flex items-center gap-2.5 flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={item.is_done}
                        onChange={() => handleToggleChecklistItem(item.id)}
                        className="w-4 h-4 text-teal-500 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                      />
                      <span
                        className={`text-sm ${
                          item.is_done
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        {item.text}
                      </span>
                    </label>
                    <button
                      onClick={() => handleDeleteChecklistItem(item.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-500 rounded transition-all"
                      title="Maddeyi Sil"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Checklist Item Form */}
              <form onSubmit={handleAddChecklistItem} className="flex items-center gap-2">
                <input
                  type="text"
                  value={newChecklistText}
                  onChange={(e) => setNewChecklistText(e.target.value)}
                  placeholder="Bir madde ekle..."
                  className={`flex-1 px-3 py-2 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
                <button
                  type="submit"
                  disabled={!newChecklistText.trim()}
                  className="px-3.5 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                >
                  Ekle
                </button>
              </form>
            </div>

            {/* Comments Section */}
            <div>
              <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-300 mb-3">
                <MessageSquare className="w-4 h-4 text-teal-500" />
                <span>Yorumlar & Tartışma</span>
              </div>

              {/* New Comment Box */}
              <form onSubmit={handleAddComment} className="mb-4 space-y-2">
                <textarea
                  rows={2}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Yorumunuzu yazın..."
                  className={`w-full p-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <User className="w-3.5 h-3.5" />
                    <span>Yazan: {commentAuthor}</span>
                  </div>
                  <button
                    type="submit"
                    disabled={!commentText.trim()}
                    className="px-4 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Yorum Yap
                  </button>
                </div>
              </form>

              {/* Comments Stream */}
              <div className="space-y-2.5">
                {(card.comments || []).map((comm) => (
                  <div
                    key={comm.id}
                    className={`p-3 rounded-xl border text-xs ${
                      isDark
                        ? 'bg-slate-800/60 border-slate-700/60 text-slate-200'
                        : 'bg-slate-50 border-slate-200/80 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold mb-1">
                      <span className="text-teal-600 dark:text-teal-400">{comm.author_name}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {new Date(comm.created_at).toLocaleDateString('tr-TR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed">{comm.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Actions Column (1/3) */}
          <div className="space-y-4">
            {/* Due Date Card */}
            <div
              className={`p-3.5 rounded-xl border ${
                isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Bitiş Tarihi
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => handleDueDateChange(e.target.value)}
                  className={`w-full px-2.5 py-1.5 text-xs rounded-lg border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white'
                      : 'bg-white border-slate-300 text-slate-800'
                  }`}
                />
                {dueDate && (
                  <button
                    onClick={() => handleDueDateChange('')}
                    className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700"
                    title="Tarihi Temizle"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Status & Completion Toggle */}
            <div
              className={`p-3.5 rounded-xl border ${
                isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Çalışma Durumu
              </label>
              <button
                type="button"
                onClick={() =>
                  onUpdateCard({
                    ...card,
                    completed: !card.completed,
                    updated_at: new Date().toISOString(),
                  })
                }
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  card.completed
                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-teal-500'
                }`}
              >
                <span className="flex items-center gap-2">
                  {card.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-400" />
                  )}
                  <span>{card.completed ? 'Tamamlandı' : 'Tamamlanmadı'}</span>
                </span>
                <span className="text-[10px] opacity-70 underline">Değiştir</span>
              </button>
            </div>

            {/* Change List Selector */}
            <div
              className={`p-3.5 rounded-xl border ${
                isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Listeyi Değiştir
              </label>
              <select
                value={card.list_id}
                onChange={(e) => onMoveCardToList(card.id, e.target.value)}
                className={`w-full px-2.5 py-1.5 text-xs rounded-lg border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white'
                    : 'bg-white border-slate-300 text-slate-800'
                }`}
              >
                {lists.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.title}
                  </option>
                ))}
              </select>
            </div>

            {/* Label Manager Button & Drawer */}
            <div
              className={`p-3.5 rounded-xl border ${
                isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Etiket Yönetimi
                </span>
                <button
                  onClick={() => setShowLabelPicker(!showLabelPicker)}
                  className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline"
                >
                  {showLabelPicker ? 'Kapat' : '+ Etiket'}
                </button>
              </div>

              {/* Label Badges Selection */}
              <div className="flex flex-col gap-1.5">
                {availableLabels.map((lbl) => {
                  const isSelected = (card.labels || []).some((l) => l.id === lbl.id);
                  return (
                    <button
                      key={lbl.id}
                      onClick={() => handleToggleLabel(lbl)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        isSelected
                          ? 'ring-2 ring-teal-500 shadow-xs'
                          : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: lbl.color, color: '#fff' }}
                    >
                      <span>{lbl.name}</span>
                      {isSelected && <span className="text-xs">✓</span>}
                    </button>
                  );
                })}
              </div>

              {/* Custom Label Creator Form */}
              {showLabelPicker && (
                <form onSubmit={handleAddCustomLabel} className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2">
                  <span className="text-[11px] font-semibold text-slate-500">Yeni Etiket Ekle</span>
                  <input
                    type="text"
                    value={customLabelName}
                    onChange={(e) => setCustomLabelName(e.target.value)}
                    placeholder="Etiket Adı"
                    className={`w-full px-2 py-1 text-xs rounded border ${
                      isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-300'
                    }`}
                  />
                  <div className="flex items-center gap-1.5">
                    {['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899', '#06B6D4'].map(
                      (c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => setCustomLabelColor(c)}
                          className={`w-5 h-5 rounded-full border-2 ${
                            customLabelColor === c ? 'border-white ring-2 ring-teal-500' : 'border-transparent'
                          }`}
                          style={{ backgroundColor: c }}
                        />
                      )
                    )}
                  </div>
                  <button
                    type="submit"
                    disabled={!customLabelName.trim()}
                    className="w-full py-1 rounded-lg bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white text-xs font-bold"
                  >
                    Oluştur ve Ekle
                  </button>
                </form>
              )}
            </div>

            {/* Actions (Archive & Delete) */}
            <div className="pt-2 space-y-2">
              <button
                onClick={() => {
                  onArchiveCard(card.id, !card.archived);
                  onClose();
                }}
                className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                  card.archived
                    ? 'border-teal-500 text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/20'
                    : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Archive className="w-3.5 h-3.5" />
                <span>{card.archived ? 'Arşivden Çıkar' : 'Kartı Arşivle'}</span>
              </button>

              <button
                onClick={() => {
                  if (window.confirm('Bu kartı kalıcı olarak silmek istediğinizden emin misiniz?')) {
                    onDeleteCard(card.id);
                    onClose();
                  }
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Kartı Kalıcı Olarak Sil</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
