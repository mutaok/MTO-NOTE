import React from 'react';
import { KanbanActivityLog } from '../../types/kanban';
import { X, Clock, Activity, ArrowRight, PlusCircle, Edit3, Archive } from 'lucide-react';

interface ActivityDrawerProps {
  isOpen: boolean;
  isDark: boolean;
  activities: KanbanActivityLog[];
  onClose: () => void;
}

export const ActivityDrawer: React.FC<ActivityDrawerProps> = ({
  isOpen,
  isDark,
  activities,
  onClose,
}) => {
  if (!isOpen) return null;

  const getActionIcon = (action: KanbanActivityLog['action']) => {
    switch (action) {
      case 'move_card':
        return <ArrowRight className="w-3.5 h-3.5 text-teal-500" />;
      case 'create_card':
      case 'create_list':
        return <PlusCircle className="w-3.5 h-3.5 text-emerald-500" />;
      case 'edit_card':
        return <Edit3 className="w-3.5 h-3.5 text-blue-500" />;
      case 'archive_card':
        return <Archive className="w-3.5 h-3.5 text-amber-500" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString('tr-TR', {
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div
        className={`relative w-full max-w-md h-full shadow-2xl border-l flex flex-col z-10 transition-all ${
          isDark
            ? 'bg-slate-900 text-slate-100 border-slate-800'
            : 'bg-white text-slate-900 border-slate-200'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-500" />
            <h3 className="font-bold text-sm">Pano Aktivite Geçmişi</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stream List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {activities.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-400">
              Henüz bir aktivite kaydı bulunmuyor.
            </div>
          ) : (
            activities.map((act) => (
              <div
                key={act.id}
                className={`p-3 rounded-xl border text-xs transition-colors ${
                  isDark
                    ? 'bg-slate-800/50 border-slate-800 hover:border-slate-700'
                    : 'bg-slate-50 border-slate-200/80 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0 mt-0.5">
                    {getActionIcon(act.action)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-semibold text-teal-600 dark:text-teal-400 truncate">
                        {act.user_name}
                      </span>
                      <span className="text-[10px] text-slate-400 shrink-0 flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {formatTime(act.created_at)}
                      </span>
                    </div>

                    <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300">
                      {act.details}
                    </p>

                    {act.card_title && (
                      <div className="mt-1 text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
                        🏷️ {act.card_title}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
