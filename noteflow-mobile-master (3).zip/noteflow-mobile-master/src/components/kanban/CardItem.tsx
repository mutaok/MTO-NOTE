import React, { useState } from 'react';
import { KanbanCard, KanbanList } from '../../types/kanban';
import {
  Calendar,
  CheckSquare,
  MessageSquare,
  AlignLeft,
  MoreHorizontal,
  ChevronUp,
  ChevronDown,
  ArrowRight,
  ArrowLeft,
  Edit2,
  Archive,
  CheckCircle2,
  Circle,
} from 'lucide-react';

interface CardItemProps {
  card: KanbanCard;
  lists: KanbanList[];
  isDark: boolean;
  onClick: () => void;
  onQuickEdit: (newTitle: string) => void;
  onArchive: () => void;
  onMoveKeyboard?: (direction: 'up' | 'down' | 'prev_list' | 'next_list') => void;
  onToggleComplete?: (cardId: string) => void;
}

export const CardItem: React.FC<CardItemProps> = ({
  card,
  lists = [],
  isDark,
  onClick,
  onQuickEdit,
  onArchive,
  onMoveKeyboard,
  onToggleComplete,
}) => {
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitle, setEditTitle] = useState(card.title);
  const [showQuickMenu, setShowQuickMenu] = useState(false);

  // Checklist calculations
  const totalChecklist = card.checklist?.length || 0;
  const doneChecklist = card.checklist?.filter((item) => item.is_done).length || 0;
  const checklistPercent = totalChecklist > 0 ? Math.round((doneChecklist / totalChecklist) * 100) : 0;
  const isCardCompleted = Boolean(
    card.completed || (totalChecklist > 0 && doneChecklist === totalChecklist)
  );

  // Due date status calculation
  let dueDateStatus: 'overdue' | 'due-soon' | 'future' | 'done' | null = null;
  if (card.due_date) {
    if (totalChecklist > 0 && doneChecklist === totalChecklist) {
      dueDateStatus = 'done';
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const due = new Date(card.due_date);
      due.setHours(0, 0, 0, 0);
      const diffDays = Math.round((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      if (diffDays < 0) {
        dueDateStatus = 'overdue';
      } else if (diffDays <= 1) {
        dueDateStatus = 'due-soon';
      } else {
        dueDateStatus = 'future';
      }
    }
  }

  const handleTitleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (editTitle.trim() && editTitle.trim() !== card.title) {
      onQuickEdit(editTitle.trim());
    }
    setIsEditingTitle(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setIsEditingTitle(false);
      setEditTitle(card.title);
    } else if (e.altKey && onMoveKeyboard) {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        onMoveKeyboard('up');
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        onMoveKeyboard('down');
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onMoveKeyboard('prev_list');
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onMoveKeyboard('next_list');
      }
    }
  };

  // Calculate adjacent lists for quick navigation and movement (especially on mobile)
  const sortedLists = [...lists].sort((a, b) => a.position - b.position);
  const currentListIndex = sortedLists.findIndex((l) => l.id === card.list_id);
  const prevList = currentListIndex > 0 ? sortedLists[currentListIndex - 1] : null;
  const nextList =
    currentListIndex >= 0 && currentListIndex < sortedLists.length - 1
      ? sortedLists[currentListIndex + 1]
      : null;

  return (
    <div
      data-card-id={card.id}
      tabIndex={0}
      onClick={onClick}
      onKeyDown={handleKeyDown}
      className={`kanban-card-item group relative rounded-xl p-3 border transition-all select-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-teal-500/50 touch-pan-y ${
        isDark
          ? 'bg-slate-800/95 border-slate-700/80 hover:border-slate-600 hover:shadow-md hover:shadow-black/20 text-slate-100'
          : 'bg-white border-slate-200/90 hover:border-slate-300 hover:shadow-md hover:shadow-slate-200/50 text-slate-800'
      } ${card.archived ? 'opacity-60 grayscale-[40%]' : ''}`}
    >
      {/* Label Strips */}
      {card.labels && card.labels.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          {card.labels.map((lbl) => (
            <span
              key={lbl.id}
              className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold text-white tracking-wide shadow-2xs"
              style={{ backgroundColor: lbl.color }}
              title={lbl.name}
            >
              {lbl.name}
            </span>
          ))}
        </div>
      )}

      {/* Card Title & Quick Edit */}
      {isEditingTitle ? (
        <form onSubmit={handleTitleSubmit} onClick={(e) => e.stopPropagation()} className="mb-2">
          <input
            autoFocus
            type="text"
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            onBlur={handleTitleSubmit}
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                setIsEditingTitle(false);
                setEditTitle(card.title);
              }
            }}
            className={`w-full px-2 py-1 text-sm font-medium rounded-md border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
              isDark
                ? 'bg-slate-900 border-teal-500 text-white'
                : 'bg-slate-50 border-teal-500 text-slate-900'
            }`}
          />
        </form>
      ) : (
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-start gap-2 flex-1 min-w-0">
            {onToggleComplete && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleComplete(card.id);
                }}
                className={`p-0.5 mt-0.5 rounded-full transition-all shrink-0 hover:scale-110 ${
                  isCardCompleted
                    ? 'text-emerald-500 hover:text-emerald-600 dark:text-emerald-400'
                    : 'text-slate-300 dark:text-slate-600 hover:text-teal-500 dark:hover:text-teal-400'
                }`}
                title={
                  isCardCompleted
                    ? 'Tamamlandı (Tamamlanmadı olarak değiştirmek için tıklayın)'
                    : 'Tamamlandı olarak işaretle'
                }
              >
                {isCardCompleted ? (
                  <CheckCircle2 className="w-4 h-4 fill-emerald-500/20 text-emerald-500" />
                ) : (
                  <Circle className="w-4 h-4" />
                )}
              </button>
            )}
            <h4
              className={`text-sm font-medium leading-snug line-clamp-3 transition-colors ${
                isCardCompleted
                  ? 'line-through text-slate-400 dark:text-slate-500'
                  : 'group-hover:text-teal-600 dark:group-hover:text-teal-400'
              }`}
            >
              {card.title}
            </h4>
          </div>

          {/* Quick Menu Button (Visible on mobile/touch, hover on desktop) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowQuickMenu(!showQuickMenu);
            }}
            aria-label="Kart İşlemleri"
            className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 p-1.5 sm:p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-all shrink-0 cursor-pointer"
          >
            <MoreHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Quick Menu Popover */}
      {showQuickMenu && (
        <div
          onClick={(e) => e.stopPropagation()}
          className={`absolute right-2 top-8 z-30 w-48 rounded-xl border p-1 shadow-xl text-xs backdrop-blur-md ${
            isDark
              ? 'bg-slate-800/95 border-slate-700 text-slate-200'
              : 'bg-white/95 border-slate-200 text-slate-700'
          }`}
        >
          {onToggleComplete && (
            <button
              onClick={() => {
                setShowQuickMenu(false);
                onToggleComplete(card.id);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-emerald-500/10 hover:text-emerald-500 transition-colors text-left cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isCardCompleted ? 'Tamamlanmadı Yap' : 'Tamamlandı Olarak İşaretle'}</span>
            </button>
          )}

          <button
            onClick={() => {
              setShowQuickMenu(false);
              setIsEditingTitle(true);
            }}
            className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-teal-500/10 hover:text-teal-500 transition-colors text-left cursor-pointer"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Başlığı Düzenle</span>
          </button>

          {onMoveKeyboard && (
            <>
              <div className="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Sırala & Taşı (Alt+)
              </div>
              <div className="grid grid-cols-2 gap-1 px-1 mb-1">
                <button
                  onClick={() => {
                    setShowQuickMenu(false);
                    onMoveKeyboard('up');
                  }}
                  className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-700 hover:bg-teal-500 hover:text-white transition-colors cursor-pointer"
                >
                  <ChevronUp className="w-3 h-3" />
                  <span>Yukarı</span>
                </button>
                <button
                  onClick={() => {
                    setShowQuickMenu(false);
                    onMoveKeyboard('down');
                  }}
                  className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-700 hover:bg-teal-500 hover:text-white transition-colors cursor-pointer"
                >
                  <ChevronDown className="w-3 h-3" />
                  <span>Aşağı</span>
                </button>
                <button
                  disabled={!prevList}
                  onClick={() => {
                    setShowQuickMenu(false);
                    onMoveKeyboard('prev_list');
                  }}
                  className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-700 hover:bg-teal-500 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
                  title={prevList ? `"${prevList.title}" listesine taşı` : undefined}
                >
                  <ArrowLeft className="w-3 h-3 shrink-0" />
                  <span className="truncate">{prevList ? prevList.title : 'Önceki'}</span>
                </button>
                <button
                  disabled={!nextList}
                  onClick={() => {
                    setShowQuickMenu(false);
                    onMoveKeyboard('next_list');
                  }}
                  className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-700 hover:bg-teal-500 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
                  title={nextList ? `"${nextList.title}" listesine taşı` : undefined}
                >
                  <span className="truncate">{nextList ? nextList.title : 'Sonraki'}</span>
                  <ArrowRight className="w-3 h-3 shrink-0" />
                </button>
              </div>
            </>
          )}

          <div className="h-px bg-slate-200 dark:bg-slate-700 my-1" />
          <button
            onClick={() => {
              setShowQuickMenu(false);
              onArchive();
            }}
            className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/10 hover:text-rose-500 transition-colors text-left cursor-pointer"
          >
            <Archive className="w-3.5 h-3.5" />
            <span>{card.archived ? 'Arşivden Çıkar' : 'Kartı Arşivle'}</span>
          </button>
        </div>
      )}

      {/* Checklist Progress Bar */}
      {totalChecklist > 0 && (
        <div className="mb-2.5">
          <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
            <span className="flex items-center gap-1">
              <CheckSquare className="w-3.5 h-3.5 text-teal-500" />
              <span>
                {doneChecklist}/{totalChecklist}
              </span>
            </span>
            <span className="font-mono text-[10px]">{checklistPercent}%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-700/80 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                doneChecklist === totalChecklist ? 'bg-emerald-500' : 'bg-teal-500'
              }`}
              style={{ width: `${checklistPercent}%` }}
            />
          </div>
        </div>
      )}

      {/* Badges Footer (Due Date, Description, Comments, and Mobile Move Arrows) */}
      <div className="flex items-center flex-wrap gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-1">
        {/* Status Badge */}
        <span
          className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md font-medium text-[10.5px] border transition-colors ${
            isCardCompleted
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/60 font-semibold'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200/80 dark:border-slate-700/80'
          }`}
        >
          {isCardCompleted ? (
            <>
              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
              <span>Tamamlandı</span>
            </>
          ) : (
            <>
              <Circle className="w-3 h-3 text-slate-400" />
              <span>Çalışılacak</span>
            </>
          )}
        </span>

        {/* Due Date Badge */}
        {card.due_date && (
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-medium border text-[10.5px] ${
              dueDateStatus === 'overdue'
                ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60 font-semibold'
                : dueDateStatus === 'due-soon'
                ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-900/60 font-semibold'
                : dueDateStatus === 'done'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/60'
                : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 border-transparent'
            }`}
            title={`Bitiş Tarihi: ${card.due_date} (${dueDateStatus || ''})`}
          >
            <Calendar className="w-3 h-3" />
            <span>{card.due_date.slice(5)}</span>
          </span>
        )}

        {/* Has Description Icon */}
        {card.description && card.description.trim().length > 0 && (
          <span title="Açıklama mevcut" className="flex items-center text-slate-400">
            <AlignLeft className="w-3.5 h-3.5" />
          </span>
        )}

        {/* Comments Count */}
        {card.comments && card.comments.length > 0 && (
          <span className="flex items-center gap-1 text-slate-400" title="Yorumlar">
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="text-[10px] font-mono">{card.comments.length}</span>
          </span>
        )}

        {/* Quick List Transfer Arrows (One-Tap Movement for Mobile & Desktop) */}
        {(prevList || nextList) && onMoveKeyboard && (
          <div
            className="flex items-center gap-1 ml-auto shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            {prevList && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onMoveKeyboard('prev_list');
                }}
                title={`"${prevList.title}" listesine taşı`}
                className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-semibold text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 bg-slate-100/90 dark:bg-slate-800/90 hover:bg-teal-50 dark:hover:bg-teal-950/40 border border-slate-200/80 dark:border-slate-700/80 transition-all cursor-pointer shadow-2xs"
              >
                <ArrowLeft className="w-3 h-3 text-teal-500" />
                <span className="hidden sm:hidden lg:inline max-w-[50px] truncate">{prevList.title}</span>
              </button>
            )}
            {nextList && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onMoveKeyboard('next_list');
                }}
                title={`"${nextList.title}" listesine taşı`}
                className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-semibold text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 bg-slate-100/90 dark:bg-slate-800/90 hover:bg-teal-50 dark:hover:bg-teal-950/40 border border-slate-200/80 dark:border-slate-700/80 transition-all cursor-pointer shadow-2xs"
              >
                <span className="hidden sm:hidden lg:inline max-w-[50px] truncate">{nextList.title}</span>
                <ArrowRight className="w-3 h-3 text-teal-500" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
