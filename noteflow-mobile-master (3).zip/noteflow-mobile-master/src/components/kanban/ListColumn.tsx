import React, { useState, useEffect, useRef } from 'react';
import Sortable from 'sortablejs';
import { KanbanList, KanbanCard, KanbanLabel } from '../../types/kanban';
import { CardItem } from './CardItem';
import {
  Plus,
  MoreVertical,
  X,
  Edit2,
  Archive,
  Trash2,
  SlidersHorizontal,
  ArrowUpDown,
  GripVertical,
} from 'lucide-react';
import { calculateInsertPosition, normalizePositions } from '../../lib/kanban/ranking';

interface ListColumnProps {
  list: KanbanList;
  lists: KanbanList[];
  cards: KanbanCard[];
  allCards?: KanbanCard[];
  isDark: boolean;
  onUpdateListTitle: (listId: string, title: string) => void;
  onDeleteList: (listId: string) => void;
  onArchiveList: (listId: string, archived: boolean) => void;
  onAddCard: (listId: string, title: string) => void;
  onCardClick: (card: KanbanCard) => void;
  onQuickEditCard: (cardId: string, newTitle: string) => void;
  onArchiveCard: (cardId: string) => void;
  onCardMove: (cardId: string, targetListId: string, newPosition: number, targetListName?: string) => void;
  onNormalizeList?: (listId: string) => void;
  onToggleCardComplete?: (cardId: string) => void;
}

export const ListColumn: React.FC<ListColumnProps> = ({
  list,
  lists,
  cards,
  allCards,
  isDark,
  onUpdateListTitle,
  onDeleteList,
  onArchiveList,
  onAddCard,
  onCardClick,
  onQuickEditCard,
  onArchiveCard,
  onCardMove,
  onNormalizeList,
  onToggleCardComplete,
}) => {
  // Sort cards in this list by position
  const sortedCards = [...cards].sort((a, b) => a.position - b.position);

  const completedCount = sortedCards.filter((c) => {
    const total = c.checklist?.length || 0;
    const done = c.checklist?.filter((item) => item.is_done).length || 0;
    return Boolean(c.completed || (total > 0 && done === total));
  }).length;

  // Column title inline editing
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(list.title);

  // New card composer
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [newCardTitle, setNewCardTitle] = useState('');

  // Column dropdown menu
  const [showMenu, setShowMenu] = useState(false);

  // SortableJS container ref
  const cardsContainerRef = useRef<HTMLDivElement>(null);
  const sortableRef = useRef<Sortable | null>(null);

  // Handle title save
  const handleTitleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (titleInput.trim() && titleInput.trim() !== list.title) {
      onUpdateListTitle(list.id, titleInput.trim());
    }
    setIsEditingTitle(false);
  };

  // Handle new card submit
  const handleAddCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCardTitle.trim()) {
      onAddCard(list.id, newCardTitle.trim());
      setNewCardTitle('');
      setIsAddingCard(false);
    }
  };

  // SortableJS initialization for Drag & Drop
  useEffect(() => {
    if (!cardsContainerRef.current) return;

    sortableRef.current = new Sortable(cardsContainerRef.current, {
      group: 'kanban-cards-group',
      animation: 200,
      ghostClass: 'kanban-sortable-ghost',
      chosenClass: 'kanban-sortable-chosen',
      dragClass: 'kanban-sortable-drag',
      filter: '.no-drag',
      preventOnFilter: false,
      delay: 180,
      delayOnTouchOnly: true,
      touchStartThreshold: 8,
      onEnd: (evt) => {
        const { item, to, newIndex } = evt;
        if (newIndex === undefined || newIndex === null) return;

        const cardId = item.getAttribute('data-card-id');
        const targetListId = to.getAttribute('data-list-id');
        if (!cardId || !targetListId) return;

        // Hedef listedeki kartları belirle (taşınan kart hariç sıralı)
        const targetListObj = lists.find((l) => l.id === targetListId);
        const targetListName = targetListObj?.title;

        // DOM'dan hedef listedeki kart ID'lerini sırayla topla
        const cardElements = Array.from(to.querySelectorAll('[data-card-id]'));
        const siblingCards: { position: number }[] = [];

        cardElements.forEach((el, index) => {
          if (index === newIndex) return; // taşınan öğenin kendisini atla
          const cId = el.getAttribute('data-card-id');
          const found = (allCards || cards).find((c) => c.id === cId);
          if (found) {
            siblingCards.push({ position: found.position });
          }
        });

        // calculateInsertPosition ile kesirli float pozisyonu hesapla
        const { position } = calculateInsertPosition(siblingCards, newIndex);
        onCardMove(cardId, targetListId, position, targetListName);
      },
    });

    return () => {
      sortableRef.current?.destroy();
      sortableRef.current = null;
    };
  }, [cards, allCards, lists, onCardMove]);

  // Keyboard navigation for card items
  const handleMoveKeyboard = (
    card: KanbanCard,
    direction: 'up' | 'down' | 'prev_list' | 'next_list'
  ) => {
    const currentIndex = sortedCards.findIndex((c) => c.id === card.id);
    if (currentIndex === -1) return;

    if (direction === 'up' && currentIndex > 0) {
      const targetIndex = currentIndex - 1;
      const siblings = sortedCards.filter((c) => c.id !== card.id);
      const { position } = calculateInsertPosition(siblings, targetIndex);
      onCardMove(card.id, list.id, position, list.title);
    } else if (direction === 'down' && currentIndex < sortedCards.length - 1) {
      const targetIndex = currentIndex + 1;
      const siblings = sortedCards.filter((c) => c.id !== card.id);
      const { position } = calculateInsertPosition(siblings, targetIndex);
      onCardMove(card.id, list.id, position, list.title);
    } else if (direction === 'prev_list' || direction === 'next_list') {
      const sortedLists = [...lists].sort((a, b) => a.position - b.position);
      const currentListIndex = sortedLists.findIndex((l) => l.id === list.id);
      const targetListIndex =
        direction === 'prev_list' ? currentListIndex - 1 : currentListIndex + 1;

      if (targetListIndex >= 0 && targetListIndex < sortedLists.length) {
        const destList = sortedLists[targetListIndex];
        const destCards = (allCards || cards)
          .filter((c) => c.list_id === destList.id)
          .sort((a, b) => a.position - b.position);
        const { position } = calculateInsertPosition(destCards, destCards.length);
        onCardMove(card.id, destList.id, position, destList.title);
      }
    }
  };

  return (
    <div
      data-list-id={list.id}
      className={`kanban-column flex flex-col w-[86vw] max-w-[340px] sm:w-80 shrink-0 snap-center sm:snap-align-none max-h-full rounded-2xl border transition-all duration-200 ${
        isDark
          ? 'bg-slate-900/90 border-slate-800 shadow-xl shadow-black/20'
          : 'bg-slate-100/95 border-slate-200 shadow-md shadow-slate-200/50'
      }`}
    >
      {/* List Header */}
      <div className="flex items-center justify-between p-3 pb-2 select-none">
        {/* Drag Handle & Title */}
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <span
            className="kanban-list-drag-handle p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-grab active:cursor-grabbing rounded"
            title="Sütunu Taşımak İçin Sürükle"
          >
            <GripVertical className="w-4 h-4" />
          </span>

          {isEditingTitle ? (
            <form onSubmit={handleTitleSubmit} className="flex-1 min-w-0">
              <input
                autoFocus
                type="text"
                value={titleInput}
                onChange={(e) => setTitleInput(e.target.value)}
                onBlur={() => handleTitleSubmit()}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setIsEditingTitle(false);
                    setTitleInput(list.title);
                  }
                }}
                className={`w-full px-2 py-0.5 text-sm font-bold rounded-lg border focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  isDark
                    ? 'bg-slate-800 border-teal-500 text-white'
                    : 'bg-white border-teal-500 text-slate-900'
                }`}
              />
            </form>
          ) : (
            <h3
              onClick={() => setIsEditingTitle(true)}
              title="Başlığı düzenlemek için tıklayın"
              className="text-sm font-bold truncate cursor-pointer hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
            >
              {list.title}
            </h3>
          )}

          {/* Card Count & Completion Progress Pill */}
          <div className="flex items-center gap-1 shrink-0">
            {completedCount > 0 ? (
              <span
                className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"
                title={`${completedCount} / ${sortedCards.length} tamamlandı`}
              >
                {completedCount}/{sortedCards.length}
              </span>
            ) : (
              <span
                className={`px-2 py-0.5 rounded-full text-xs font-mono font-semibold ${
                  isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-200/80 text-slate-600'
                }`}
              >
                {sortedCards.length}
              </span>
            )}
          </div>
        </div>

        {/* List Menu Trigger */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            aria-label="Sütun Menüsü"
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {/* List Options Dropdown */}
          {showMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className={`absolute right-0 top-7 z-40 w-52 rounded-xl border p-1 shadow-2xl backdrop-blur-md text-xs ${
                isDark
                  ? 'bg-slate-800/95 border-slate-700 text-slate-200'
                  : 'bg-white/95 border-slate-200 text-slate-700'
              }`}
            >
              <button
                onClick={() => {
                  setShowMenu(false);
                  setIsAddingCard(true);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-teal-500/10 hover:text-teal-500 transition-colors text-left"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Kart Ekle</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  setIsEditingTitle(true);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-teal-500/10 hover:text-teal-500 transition-colors text-left"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Sütun Başlığını Değiştir</span>
              </button>

              {onNormalizeList && (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onNormalizeList(list.id);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-teal-500/10 hover:text-teal-500 transition-colors text-left"
                  title="Kart pozisyonlarını 65536 katlarına sıfırlar"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Pozisyonları Düzelt (Normalize)</span>
                </button>
              )}

              <div className="h-px bg-slate-200 dark:bg-slate-700 my-1" />

              <button
                onClick={() => {
                  setShowMenu(false);
                  onArchiveList(list.id, !list.archived);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-amber-500/10 hover:text-amber-500 transition-colors text-left"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>{list.archived ? 'Arşivden Çıkar' : 'Sütunu Arşivle'}</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  if (
                    window.confirm(
                      `"${list.title}" sütununu ve içindeki tüm kartları kalıcı olarak silmek istiyor musunuz?`
                    )
                  ) {
                    onDeleteList(list.id);
                  }
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition-colors text-left"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sütunu Sil</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Cards Scrollable Drop Area */}
      <div
        ref={cardsContainerRef}
        data-list-id={list.id}
        className="flex-1 min-h-[80px] overflow-y-auto overscroll-contain px-2 py-1.5 pb-8 space-y-2.5 max-h-[50vh] sm:max-h-[calc(100vh-280px)] custom-scrollbar touch-pan-y"
      >
        {sortedCards.map((card) => (
          <CardItem
            key={card.id}
            card={card}
            lists={lists}
            isDark={isDark}
            onClick={() => onCardClick(card)}
            onQuickEdit={(newTitle) => onQuickEditCard(card.id, newTitle)}
            onArchive={() => onArchiveCard(card.id)}
            onMoveKeyboard={(dir) => handleMoveKeyboard(card, dir)}
            onToggleComplete={onToggleCardComplete}
          />
        ))}

        {sortedCards.length === 0 && !isAddingCard && (
          <div
            onClick={() => setIsAddingCard(true)}
            className="h-16 rounded-xl border-2 border-dashed border-slate-300/60 dark:border-slate-700/60 flex items-center justify-center text-xs text-slate-400 hover:text-teal-600 hover:border-teal-500/50 cursor-pointer transition-colors"
          >
            + Kart Bırak veya Ekle
          </div>
        )}
      </div>

      {/* List Footer: Add Card Composer */}
      <div className="p-2 pt-1">
        {isAddingCard ? (
          <form onSubmit={handleAddCardSubmit} className="space-y-2 p-1">
            <textarea
              autoFocus
              rows={2}
              value={newCardTitle}
              onChange={(e) => setNewCardTitle(e.target.value)}
              placeholder="Bu kart için bir başlık girin..."
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleAddCardSubmit(e);
                } else if (e.key === 'Escape') {
                  setIsAddingCard(false);
                  setNewCardTitle('');
                }
              }}
              className={`w-full p-2.5 text-xs font-medium rounded-xl border resize-none focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-sm ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                  : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
              }`}
            />
            <div className="flex items-center gap-1.5">
              <button
                type="submit"
                disabled={!newCardTitle.trim()}
                className="px-3.5 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
              >
                Kart Ekle
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsAddingCard(false);
                  setNewCardTitle('');
                }}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                title="İptal (Esc)"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => setIsAddingCard(true)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-200/60 dark:hover:bg-slate-800/80 transition-all text-left group`}
          >
            <Plus className="w-4 h-4 group-hover:scale-110 transition-transform text-teal-500" />
            <span>Kart Ekle</span>
          </button>
        )}
      </div>
    </div>
  );
};
