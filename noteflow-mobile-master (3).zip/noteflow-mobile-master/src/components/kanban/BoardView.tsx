import React, { useState, useEffect, useRef, useCallback } from 'react';
import Sortable from 'sortablejs';
import { KanbanBoard, KanbanList, KanbanCard } from '../../types/kanban';
import { ListColumn } from './ListColumn';
import { Plus, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { calculateInsertPosition } from '../../lib/kanban/ranking';

interface BoardViewProps {
  board: KanbanBoard;
  lists: KanbanList[];
  cards: KanbanCard[];
  isDark: boolean;
  onUpdateListTitle: (listId: string, title: string) => void;
  onDeleteList: (listId: string) => void;
  onArchiveList: (listId: string, archived: boolean) => void;
  onAddList: (title: string) => void;
  onAddCard: (listId: string, title: string) => void;
  onCardClick: (card: KanbanCard) => void;
  onQuickEditCard: (cardId: string, newTitle: string) => void;
  onArchiveCard: (cardId: string) => void;
  onCardMove: (cardId: string, targetListId: string, newPosition: number, targetListName?: string) => void;
  onMoveList: (listId: string, newPosition: number) => void;
  onNormalizeList?: (listId: string) => void;
  onToggleCardComplete?: (cardId: string) => void;
}

export const BoardView: React.FC<BoardViewProps> = ({
  board,
  lists,
  cards,
  isDark,
  onUpdateListTitle,
  onDeleteList,
  onArchiveList,
  onAddList,
  onAddCard,
  onCardClick,
  onQuickEditCard,
  onArchiveCard,
  onCardMove,
  onMoveList,
  onNormalizeList,
  onToggleCardComplete,
}) => {
  // Sort lists by position
  const sortedLists = [...lists].sort((a, b) => a.position - b.position);

  // New list composer state
  const [isAddingList, setIsAddingList] = useState(false);
  const [newListTitle, setNewListTitle] = useState('');

  // Active column tracking for mobile navigation
  const [activeListId, setActiveListId] = useState<string>(sortedLists[0]?.id || '');

  useEffect(() => {
    if (sortedLists.length > 0 && (!activeListId || !sortedLists.some((l) => l.id === activeListId))) {
      setActiveListId(sortedLists[0].id);
    }
  }, [sortedLists, activeListId]);

  // Horizontal Sortable for lists container
  const boardScrollRef = useRef<HTMLDivElement>(null);
  const listsContainerRef = useRef<HTMLDivElement>(null);
  const sortableRef = useRef<Sortable | null>(null);

  useEffect(() => {
    if (!listsContainerRef.current) return;

    sortableRef.current = new Sortable(listsContainerRef.current, {
      handle: '.kanban-list-drag-handle',
      animation: 250,
      direction: 'horizontal',
      ghostClass: 'kanban-list-ghost',
      chosenClass: 'kanban-list-chosen',
      filter: '.no-list-drag',
      delay: 180,
      delayOnTouchOnly: true,
      touchStartThreshold: 8,
      onEnd: (evt) => {
        const { item, newIndex } = evt;
        if (newIndex === undefined || newIndex === null) return;

        const listId = item.getAttribute('data-list-id');
        if (!listId) return;

        // Calculate new position among sibling lists
        const siblingLists = sortedLists.filter((l) => l.id !== listId);
        const { position } = calculateInsertPosition(siblingLists, newIndex);
        onMoveList(listId, position);
      },
    });

    return () => {
      sortableRef.current?.destroy();
      sortableRef.current = null;
    };
  }, [sortedLists, onMoveList]);

  // Smooth scroll to a target column (especially on mobile)
  const scrollToColumn = useCallback((listId: string) => {
    setActiveListId(listId);
    const el = listsContainerRef.current?.querySelector(`[data-list-id="${listId}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  }, []);

  // Sync active pill when user swipes between columns on mobile
  const handleScroll = () => {
    if (!boardScrollRef.current || !listsContainerRef.current) return;
    const container = boardScrollRef.current;
    const containerCenter = container.scrollLeft + container.clientWidth / 2;

    const columnEls = listsContainerRef.current.querySelectorAll('[data-list-id]');
    let closestId = activeListId;
    let minDiff = Infinity;

    columnEls.forEach((col) => {
      const htmlCol = col as HTMLElement;
      const colCenter = htmlCol.offsetLeft + htmlCol.offsetWidth / 2;
      const diff = Math.abs(colCenter - containerCenter);
      if (diff < minDiff) {
        minDiff = diff;
        const id = htmlCol.getAttribute('data-list-id');
        if (id) closestId = id;
      }
    });

    if (closestId && closestId !== activeListId) {
      setActiveListId(closestId);
    }
  };

  const currentIdx = sortedLists.findIndex((l) => l.id === activeListId);
  const canPrev = currentIdx > 0;
  const canNext = currentIdx >= 0 && currentIdx < sortedLists.length - 1;

  const handlePrevColumn = () => {
    if (canPrev) {
      scrollToColumn(sortedLists[currentIdx - 1].id);
    }
  };

  const handleNextColumn = () => {
    if (canNext) {
      scrollToColumn(sortedLists[currentIdx + 1].id);
    }
  };

  const handleAddListSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newListTitle.trim()) {
      onAddList(newListTitle.trim());
      setNewListTitle('');
      setIsAddingList(false);
    }
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
      {/* Mobile Column Quick Switcher Bar */}
      {sortedLists.length > 0 && (
        <div className="sm:hidden flex items-center justify-between gap-1.5 px-3 py-2 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md shrink-0">
          <button
            type="button"
            disabled={!canPrev}
            onClick={handlePrevColumn}
            className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 disabled:opacity-30 disabled:pointer-events-none hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Önceki Sütuna Git"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Column Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 px-1 flex-1">
            {sortedLists.map((list) => {
              const listCardCount = cards.filter((c) => c.list_id === list.id).length;
              const isActive = list.id === activeListId;

              return (
                <button
                  key={list.id}
                  type="button"
                  onClick={() => scrollToColumn(list.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-teal-500 text-white shadow-xs scale-102 ring-2 ring-teal-500/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <span className="truncate max-w-[120px]">{list.title}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isActive
                        ? 'bg-white/25 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {listCardCount}
                  </span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            disabled={!canNext}
            onClick={handleNextColumn}
            className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 disabled:opacity-30 disabled:pointer-events-none hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Sonraki Sütuna Git"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Board Scroll Container */}
      <div
        ref={boardScrollRef}
        onScroll={handleScroll}
        className="flex-1 min-h-0 overflow-x-auto overflow-y-auto sm:overflow-y-hidden p-2 sm:p-6 custom-scrollbar snap-x snap-mandatory sm:snap-none select-none scroll-smooth touch-pan-x"
      >
        <div className="flex items-start gap-3 sm:gap-4 h-full min-w-max pb-4">
          {/* Horizontal Sortable Lists Container */}
          <div ref={listsContainerRef} className="flex items-start gap-3 sm:gap-4 h-full">
            {sortedLists.map((list) => {
              const listCards = cards.filter((c) => c.list_id === list.id);
              return (
                <ListColumn
                  key={list.id}
                  list={list}
                  lists={lists}
                  cards={listCards}
                  allCards={cards}
                  isDark={isDark}
                  onUpdateListTitle={onUpdateListTitle}
                  onDeleteList={onDeleteList}
                  onArchiveList={onArchiveList}
                  onAddCard={onAddCard}
                  onCardClick={onCardClick}
                  onQuickEditCard={onQuickEditCard}
                  onArchiveCard={onArchiveCard}
                  onCardMove={onCardMove}
                  onNormalizeList={onNormalizeList}
                  onToggleCardComplete={onToggleCardComplete}
                />
              );
            })}
          </div>

          {/* Add New List Composer Column */}
          <div className="w-[82vw] max-w-[320px] sm:w-80 shrink-0 snap-center sm:snap-align-none no-list-drag">
            {isAddingList ? (
              <form
                onSubmit={handleAddListSubmit}
                className={`p-3 rounded-2xl border shadow-lg ${
                  isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <input
                  autoFocus
                  type="text"
                  value={newListTitle}
                  onChange={(e) => setNewListTitle(e.target.value)}
                  placeholder="Liste başlığı girin..."
                  className={`w-full px-3 py-2 text-xs font-semibold rounded-xl border focus:outline-none focus:ring-2 focus:ring-teal-500 mb-2.5 ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                      : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                  }`}
                />
                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    disabled={!newListTitle.trim()}
                    className="px-4 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-600 disabled:opacity-40 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Liste Ekle
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingList(false);
                      setNewListTitle('');
                    }}
                    className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <button
                onClick={() => setIsAddingList(true)}
                className={`w-full flex items-center gap-2.5 px-4 py-3 rounded-2xl border-2 border-dashed font-semibold text-xs transition-all cursor-pointer ${
                  isDark
                    ? 'border-slate-800 text-slate-400 hover:text-teal-400 hover:border-teal-500/50 hover:bg-slate-900/60'
                    : 'border-slate-300 text-slate-500 hover:text-teal-600 hover:border-teal-500/50 hover:bg-white/80'
                }`}
              >
                <Plus className="w-4 h-4 text-teal-500" />
                <span>Başka bir liste ekle</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

