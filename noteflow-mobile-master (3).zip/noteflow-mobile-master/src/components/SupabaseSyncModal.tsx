import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import type { SyncEngine, SyncStatus } from '../data/sync/SyncEngine';

interface SupabaseSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail: string | null;
  userId: string | null;
  syncStatus: SyncStatus | null;
  engine: SyncEngine | null;
  onRefreshSession: () => void;
  onSignOut: () => void;
  isDark: boolean;
}

export const SupabaseSyncModal: React.FC<SupabaseSyncModalProps> = ({
  isOpen,
  onClose,
  userEmail,
  userId,
  syncStatus,
  engine,
  onRefreshSession,
  onSignOut,
  isDark,
}) => {
  const [email, setEmail] = useState(userEmail || 'tahaoktar@gmail.com');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ text: string; error: boolean } | null>(null);

  if (!isOpen) return null;

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setFeedback({ text: 'Lütfen e-posta ve şifre girin.', error: true });
      return;
    }
    setLoading(true);
    setFeedback(null);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (error) {
        setFeedback({ text: error.message, error: true });
      } else if (data.session) {
        setFeedback({ text: 'Başarıyla bağlandı! Verileriniz eşitleniyor…', error: false });
        onRefreshSession();
        setTimeout(() => onClose(), 1200);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Bağlantı sırasında bir hata oluştu.';
      setFeedback({ text: msg, error: true });
    } finally {
      setLoading(false);
    }
  };

  const handleManualSync = async () => {
    if (!engine) return;
    setLoading(true);
    try {
      await engine.syncNow();
      setFeedback({ text: 'Eşitleme tamamlandı.', error: false });
    } catch {
      setFeedback({ text: 'Eşitleme sırasında hata oluştu.', error: true });
    } finally {
      setLoading(false);
    }
  };

  const handleClaimLocal = async () => {
    if (!engine) return;
    setLoading(true);
    try {
      await engine.claimLocalData();
      await engine.syncNow();
      setFeedback({ text: 'Yerel not ve görevler Supabase hesabınıza aktarıldı!', error: false });
    } catch {
      setFeedback({ text: 'Aktarma sırasında bir hata oluştu.', error: true });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div
        className={`w-full max-w-lg rounded-3xl p-6 shadow-2xl border transition-all ${
          isDark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-teal-500 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-teal-500/20">
              ⚡
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">Supabase & Flutter Eşitlemesi</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Masaüstü Web ve Android Flutter uygulaması ortak veritabanı
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 font-bold transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Feedback Message */}
        {feedback && (
          <div
            className={`mt-4 p-3 rounded-2xl text-xs font-medium ${
              feedback.error
                ? 'bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20'
                : 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20'
            }`}
          >
            {feedback.text}
          </div>
        )}

        {/* Status Card */}
        <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Bağlantı Durumu
            </span>
            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                userId
                  ? 'bg-teal-500/15 text-teal-600 dark:text-teal-400'
                  : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
              {userId ? 'Supabase ile Senkronize' : 'Yerel Mod (Çevrimdışı)'}
            </span>
          </div>

          {userId ? (
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700/50">
                <span className="text-slate-500 dark:text-slate-400">Hesap:</span>
                <span className="font-semibold text-teal-500">{userEmail}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700/50">
                <span className="text-slate-500 dark:text-slate-400">Motor Durumu:</span>
                <span className="font-medium capitalize">
                  {syncStatus?.phase === 'idle'
                    ? 'Hazır / Güncel'
                    : syncStatus?.phase === 'syncing'
                    ? 'Senkronize Ediliyor…'
                    : syncStatus?.phase === 'offline'
                    ? 'Çevrimdışı'
                    : 'Bağlı'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700/50">
                <span className="text-slate-500 dark:text-slate-400">Kuyrukta Bekleyen:</span>
                <span className="font-medium">{syncStatus?.pending ?? 0} değişiklik</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 dark:text-slate-400">Son Senkronizasyon:</span>
                <span className="font-medium">
                  {syncStatus?.lastSyncedAt
                    ? new Date(syncStatus.lastSyncedAt).toLocaleTimeString('tr-TR')
                    : 'Henüz yapılmadı'}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Şu anda verileriniz bu tarayıcının yerel hafızasında saklanıyor. Flutter mobil uygulamanızla
              anlık eşitlemek için aşağıdan Supabase hesabınıza bağlanabilirsiniz.
            </p>
          )}
        </div>

        {/* Action Panel */}
        {userId ? (
          <div className="mt-4 space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleManualSync}
                disabled={loading}
                className="p-3 rounded-2xl bg-teal-500 text-white font-medium text-xs sm:text-sm hover:bg-teal-600 transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                <span>🔄</span>
                <span>Şimdi Eşitle</span>
              </button>
              <button
                type="button"
                onClick={handleClaimLocal}
                disabled={loading}
                className="p-3 rounded-2xl border border-teal-500/30 text-teal-600 dark:text-teal-400 font-medium text-xs sm:text-sm hover:bg-teal-500/10 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>📤</span>
                <span>Yerel Notları Aktar</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onSignOut}
              className="w-full p-2.5 rounded-2xl border border-slate-300 dark:border-slate-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors mt-2"
            >
              Senkron Motorunu Yeniden Başlat
            </button>
          </div>
        ) : (
          <form onSubmit={handleSignIn} className="mt-4 space-y-3">
            <div className="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-700 dark:text-teal-300">
              Uygulama otomatik olarak ortak Supabase ve Flutter bulut veri katmanına bağlıdır. Dilerseniz özel bir Supabase hesabına geçiş yapabilirsiniz.
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Özel Supabase E-Posta
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ornek@gmail.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Şifre
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-2xl bg-teal-500 text-white font-semibold text-sm hover:bg-teal-600 transition-all shadow-md shadow-teal-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Bağlanıyor…</span>
                </>
              ) : (
                <>
                  <span>⚡</span>
                  <span>Supabase'e Bağlan & Eşitle</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Flutter Sync Info Badge */}
        <div className="mt-5 p-3 rounded-2xl bg-teal-500/5 border border-teal-500/15 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
          <span className="text-base leading-none">📱</span>
          <div className="leading-relaxed">
            <span className="font-semibold text-teal-600 dark:text-teal-400">Flutter Uyumluluğu: </span>
            Bu web arayüzünde oluşturduğunuz veya düzenlediğiniz tüm notlar, 11 defter türü, görevler ve
            zihin haritaları, Android Flutter uygulamanızdaki tablolarla (<code>notes</code>,{' '}
            <code>notebooks</code>, <code>tasks</code>, <code>mind_maps</code>) %100 birebir senkronize çalışır.
          </div>
        </div>
      </div>
    </div>
  );
};
