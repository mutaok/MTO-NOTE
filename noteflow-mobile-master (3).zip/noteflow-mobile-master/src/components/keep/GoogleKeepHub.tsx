import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  KeepNote,
  KeepColor,
  KeepFilter,
  KeepChecklistItem,
} from '../../types/keep';
import { Note } from '../../types';
import {
  KEEP_COLORS,
  loadKeepNotes,
  saveKeepNotes,
  exportKeepNotesToJSON,
  importKeepNotesFromJSON,
} from '../../lib/googleKeepService';
import {
  Pin,
  CheckSquare,
  Square,
  Search,
  Plus,
  Trash2,
  Archive,
  ArchiveRestore,
  ExternalLink,
  Download,
  Upload,
  Palette,
  Tag,
  X,
  FileText,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Info,
  Layers,
  StickyNote,
  Kanban,
  Filter,
} from 'lucide-react';

interface GoogleKeepHubProps {
  isDark: boolean;
  onConvertToNoteFlow?: (note: { title: string; content: string; tags: string[] }) => void;
  onConvertToKanban?: (task: { title: string; description: string; priority: 'düşük' | 'orta' | 'yüksek' | 'kritik' }) => void;
}

export const GoogleKeepHub: React.FC<GoogleKeepHubProps> = ({
  isDark,
  onConvertToNoteFlow,
  onConvertToKanban,
}) => {
  const [notes, setNotes] = useState<KeepNote[]>(() => loadKeepNotes());
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<KeepFilter>('all');
  const [selectedLabel, setSelectedLabel] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<KeepColor | 'all'>('all');

  // Quick Composer State
  const [isComposing, setIsComposing] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newIsChecklist, setNewIsChecklist] = useState(false);
  const [newChecklistText, setNewChecklistText] = useState('');
  const [newChecklistItems, setNewChecklistItems] = useState<KeepChecklistItem[]>([]);
  const [newColor, setNewColor] = useState<KeepColor>('default');
  const [newIsPinned, setNewIsPinned] = useState(false);
  const [newLabels, setNewLabels] = useState<string[]>([]);
  const [newLabelInput, setNewLabelInput] = useState('');

  // Edit Note Modal State
  const [editingNote, setEditingNote] = useState<KeepNote | null>(null);
  const [editChecklistInput, setEditChecklistInput] = useState('');

  // UI Modals & Popovers
  const [showImportModal, setShowImportModal] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importFeedback, setImportFeedback] = useState<string | null>(null);
  const [colorPickerNoteId, setColorPickerNoteId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showInfoBanner, setShowInfoBanner] = useState(true);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchronize with LocalStorage
  useEffect(() => {
    saveKeepNotes(notes);
  }, [notes]);

  // Extract all unique labels
  const allLabels = useMemo(() => {
    const set = new Set<string>();
    notes.forEach((n) => {
      n.labels.forEach((l) => set.add(l));
    });
    return Array.from(set);
  }, [notes]);

  // Filtered Notes
  const filteredNotes = useMemo(() => {
    return notes.filter((note) => {
      // Trash filter
      if (activeFilter === 'trash') {
        if (!note.isTrashed) return false;
      } else if (note.isTrashed) {
        return false;
      }

      // Archive filter
      if (activeFilter === 'archived') {
        if (!note.isArchived) return false;
      } else if (note.isArchived && activeFilter !== 'all') {
        return false;
      }

      // Pinned filter
      if (activeFilter === 'pinned' && !note.isPinned) {
        return false;
      }

      // Label filter
      if (selectedLabel && !note.labels.includes(selectedLabel)) {
        return false;
      }

      // Color filter
      if (selectedColor !== 'all' && note.color !== selectedColor) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = note.title.toLowerCase().includes(q);
        const matchContent = note.content.toLowerCase().includes(q);
        const matchChecklist = note.checklistItems.some((item) =>
          item.text.toLowerCase().includes(q)
        );
        const matchLabels = note.labels.some((l) => l.toLowerCase().includes(q));
        if (!matchTitle && !matchContent && !matchChecklist && !matchLabels) {
          return false;
        }
      }

      return true;
    });
  }, [notes, activeFilter, selectedLabel, selectedColor, searchQuery]);

  // Separate pinned and unpinned notes
  const pinnedNotes = useMemo(
    () => filteredNotes.filter((n) => n.isPinned && !n.isArchived && !n.isTrashed),
    [filteredNotes]
  );
  const otherNotes = useMemo(
    () =>
      activeFilter === 'all'
        ? filteredNotes.filter((n) => (!n.isPinned && !n.isArchived && !n.isTrashed))
        : filteredNotes,
    [filteredNotes, activeFilter]
  );

  // Quick Composer Handlers
  const handleAddComposerChecklistItem = () => {
    if (!newChecklistText.trim()) return;
    setNewChecklistItems((prev) => [
      ...prev,
      { id: `cli-${Date.now()}-${Math.random()}`, text: newChecklistText.trim(), done: false },
    ]);
    setNewChecklistText('');
  };

  const handleAddComposerLabel = () => {
    if (!newLabelInput.trim()) return;
    if (!newLabels.includes(newLabelInput.trim())) {
      setNewLabels((prev) => [...prev, newLabelInput.trim()]);
    }
    setNewLabelInput('');
  };

  const handleSaveNewNote = () => {
    if (!newTitle.trim() && !newContent.trim() && newChecklistItems.length === 0) {
      setIsComposing(false);
      return;
    }

    const newNote: KeepNote = {
      id: `keep-user-${Date.now()}`,
      title: newTitle.trim(),
      content: newContent.trim(),
      isChecklist: newIsChecklist,
      checklistItems: newChecklistItems,
      color: newColor,
      isPinned: newIsPinned,
      isArchived: false,
      isTrashed: false,
      labels: newLabels,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncSource: 'manual',
    };

    setNotes((prev) => [newNote, ...prev]);

    // Reset Composer
    setNewTitle('');
    setNewContent('');
    setNewIsChecklist(false);
    setNewChecklistItems([]);
    setNewColor('default');
    setNewIsPinned(false);
    setNewLabels([]);
    setIsComposing(false);
  };

  // Toggle checklist item done
  const handleToggleChecklistItem = (noteId: string, itemId: string) => {
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id !== noteId) return n;
        return {
          ...n,
          checklistItems: n.checklistItems.map((ci) =>
            ci.id === itemId ? { ...ci, done: !ci.done } : ci
          ),
          updatedAt: new Date().toISOString(),
        };
      })
    );
  };

  // Note actions
  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const handleToggleArchive = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isArchived: !n.isArchived } : n))
    );
  };

  const handleTrashNote = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isTrashed: true } : n))
    );
  };

  const handleRestoreNote = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isTrashed: false } : n))
    );
  };

  const handlePermanentDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Bu Keep notunu kalıcı olarak silmek istediğinize emin misiniz?')) {
      setNotes((prev) => prev.filter((n) => n.id !== id));
    }
  };

  const handleChangeColor = (id: string, color: KeepColor, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, color } : n)));
    setColorPickerNoteId(null);
  };

  const handleCopyNoteText = (note: KeepNote, e: React.MouseEvent) => {
    e.stopPropagation();
    let text = note.title ? `${note.title}\n\n` : '';
    if (note.isChecklist) {
      text += note.checklistItems
        .map((ci) => `${ci.done ? '[x]' : '[ ]'} ${ci.text}`)
        .join('\n');
    } else {
      text += note.content;
    }
    navigator.clipboard.writeText(text);
    setCopiedId(note.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenInGoogleKeep = (note?: KeepNote) => {
    // If a note is provided, prefill or copy to clipboard and open Google Keep
    if (note) {
      const text = `${note.title}\n\n${
        note.isChecklist
          ? note.checklistItems.map((ci) => `- ${ci.text}`).join('\n')
          : note.content
      }`;
      navigator.clipboard.writeText(text);
    }
    window.open('https://keep.google.com/', '_blank', 'noopener,noreferrer');
  };

  const handleExportJSON = () => {
    const json = exportKeepNotesToJSON(notes);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `google-keep-noteflow-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = () => {
    if (!importJsonText.trim()) return;
    try {
      const result = importKeepNotesFromJSON(importJsonText, notes);
      setNotes(result.newNotes);
      setImportFeedback(`${result.importedCount} adet not başarıyla aktarıldı!`);
      setTimeout(() => {
        setShowImportModal(false);
        setImportJsonText('');
        setImportFeedback(null);
      }, 1500);
    } catch (err: any) {
      setImportFeedback(err.message || 'İçe aktarma hatası oluştu.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setImportJsonText(text);
    };
    reader.readAsText(file);
  };

  // Convert to NoteFlow Note
  const handleConvertToNoteFlowAction = (note: KeepNote, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onConvertToNoteFlow) {
      const content = note.isChecklist
        ? note.checklistItems.map((ci) => `- [${ci.done ? 'x' : ' '}] ${ci.text}`).join('\n')
        : note.content;
      onConvertToNoteFlow({
        title: note.title || 'Keep Notu',
        content,
        tags: [...note.labels, 'Google Keep'],
      });
    }
  };

  // Convert to Kanban Card
  const handleConvertToKanbanAction = (note: KeepNote, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onConvertToKanban) {
      const description = note.isChecklist
        ? note.checklistItems.map((ci) => `- ${ci.text} (${ci.done ? 'Tamamlandı' : 'Bekliyor'})`).join('\n')
        : note.content;
      onConvertToKanban({
        title: note.title || 'Keep Görevi',
        description,
        priority: 'orta',
      });
    }
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden relative">
      {/* Top Header */}
      <div
        className={`p-3 sm:px-5 border-b flex flex-wrap items-center justify-between gap-3 shrink-0 backdrop-blur-md ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'
        }`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowMobileSidebar(true)}
            className="md:hidden p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            title="Menü"
          >
            <Layers className="w-4 h-4 text-amber-500" />
          </button>

          <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-xs shrink-0">
            <StickyNote className="w-5 h-5 fill-amber-500/20" />
          </div>

          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Google Keep Çalışma Alanı</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                Keep Hub
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[280px]">
              Renkli kartlar, yapılacak listeleri ve hızlı not senkronizasyonu
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-md min-w-[180px] relative order-3 sm:order-2 w-full sm:w-auto">
          <input
            type="text"
            placeholder="Keep notlarında ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-9 pr-8 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all ${
              isDark
                ? 'bg-slate-800/80 border-slate-700 text-slate-100 placeholder-slate-500'
                : 'bg-slate-100 border-slate-200 text-slate-800 placeholder-slate-400'
            }`}
          />
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 order-2 sm:order-3">
          <button
            onClick={() => handleOpenInGoogleKeep()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-sm transition-all cursor-pointer"
            title="Google Keep Web uygulamasını yeni sekmede aç"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Keep'i Aç</span>
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            title="Google Takeout / JSON İçe Aktar"
            className={`p-2 rounded-xl border text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
              isDark ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
          </button>

          <button
            onClick={handleExportJSON}
            title="Notları JSON Olarak Yedekle"
            className={`p-2 rounded-xl border text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
              isDark ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Layout: Sidebar + Feed */}
      <div className="flex-1 flex overflow-hidden w-full h-full relative">
        {/* Mobile Sidebar Modal */}
        {showMobileSidebar && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
              onClick={() => setShowMobileSidebar(false)}
            />
            <div
              className={`relative w-4/5 max-w-xs h-full p-4 flex flex-col z-10 shadow-2xl transition-all ${
                isDark ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'
              }`}
            >
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <StickyNote className="w-4 h-4 text-amber-500" />
                  <span>Keep Kategorileri</span>
                </div>
                <button
                  onClick={() => setShowMobileSidebar(false)}
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-1">
                {[
                  { id: 'all' as KeepFilter, label: 'Tüm Notlar', icon: StickyNote },
                  { id: 'pinned' as KeepFilter, label: 'Sabitlenenler', icon: Pin },
                  { id: 'archived' as KeepFilter, label: 'Arşiv', icon: Archive },
                  { id: 'trash' as KeepFilter, label: 'Çöp Kutusu', icon: Trash2 },
                ].map((f) => {
                  const Icon = f.icon;
                  const isActive = activeFilter === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => {
                        setActiveFilter(f.id);
                        setShowMobileSidebar(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                        isActive
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold'
                          : isDark
                          ? 'text-slate-300 hover:bg-slate-800/60'
                          : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{f.label}</span>
                    </button>
                  );
                })}

                {allLabels.length > 0 && (
                  <>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mt-4 mb-1">
                      Etiketler
                    </div>
                    {allLabels.map((lbl) => (
                      <button
                        key={lbl}
                        onClick={() => {
                          setSelectedLabel(selectedLabel === lbl ? null : lbl);
                          setShowMobileSidebar(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors ${
                          selectedLabel === lbl
                            ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold'
                            : isDark
                            ? 'text-slate-400 hover:bg-slate-800'
                            : 'text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Tag className="w-3.5 h-3.5 text-amber-500" />
                          <span className="truncate">{lbl}</span>
                        </div>
                      </button>
                    ))}
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Desktop Sidebar */}
        <aside
          className={`hidden md:flex md:w-56 lg:w-64 border-r flex-col shrink-0 p-3 overflow-y-auto ${
            isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50/70 border-slate-200'
          }`}
        >
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2">
            Görünümler
          </div>
          <nav className="space-y-1 mb-6">
            {[
              { id: 'all' as KeepFilter, label: 'Tüm Notlar', icon: StickyNote },
              { id: 'pinned' as KeepFilter, label: 'Sabitlenenler', icon: Pin },
              { id: 'archived' as KeepFilter, label: 'Arşiv', icon: Archive },
              { id: 'trash' as KeepFilter, label: 'Çöp Kutusu', icon: Trash2 },
            ].map((f) => {
              const Icon = f.icon;
              const isActive = activeFilter === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setActiveFilter(f.id);
                    setSelectedLabel(null);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold'
                      : isDark
                      ? 'text-slate-300 hover:bg-slate-800/60'
                      : 'text-slate-700 hover:bg-slate-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{f.label}</span>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Color Filter */}
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2">
            Renge Göre Filtrele
          </div>
          <div className="grid grid-cols-6 gap-1.5 px-2 mb-6">
            <button
              onClick={() => setSelectedColor('all')}
              className={`w-6 h-6 rounded-full border flex items-center justify-center text-[10px] cursor-pointer ${
                selectedColor === 'all'
                  ? 'ring-2 ring-amber-500 border-transparent font-bold'
                  : 'border-slate-300 dark:border-slate-700'
              }`}
              title="Tüm Renkler"
            >
              *
            </button>
            {(Object.keys(KEEP_COLORS) as KeepColor[]).map((cKey) => {
              const c = KEEP_COLORS[cKey];
              return (
                <button
                  key={cKey}
                  onClick={() => setSelectedColor(selectedColor === cKey ? 'all' : cKey)}
                  className={`w-6 h-6 rounded-full border transition-transform cursor-pointer ${
                    selectedColor === cKey ? 'scale-115 ring-2 ring-amber-500' : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: c.dotColor, borderColor: isDark ? '#334155' : '#cbd5e1' }}
                  title={c.name}
                />
              );
            })}
          </div>

          {/* Labels Filter */}
          {allLabels.length > 0 && (
            <>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2 flex items-center justify-between">
                <span>Etiketler</span>
                {selectedLabel && (
                  <button
                    onClick={() => setSelectedLabel(null)}
                    className="text-[10px] text-amber-500 hover:underline cursor-pointer"
                  >
                    Temizle
                  </button>
                )}
              </div>
              <div className="space-y-1 overflow-y-auto max-h-48 mb-6">
                {allLabels.map((lbl) => (
                  <button
                    key={lbl}
                    onClick={() => setSelectedLabel(selectedLabel === lbl ? null : lbl)}
                    className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                      selectedLabel === lbl
                        ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold'
                        : isDark
                        ? 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                        : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
                    }`}
                  >
                    <Tag className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span className="truncate">{lbl}</span>
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Quick Integration Card */}
          <div className="mt-auto p-3 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs text-slate-600 dark:text-slate-300">
            <div className="font-bold flex items-center gap-1.5 text-amber-600 dark:text-amber-400 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Google Keep Senkronu</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Google Keep'teki notlarınızı içe aktarabilir veya buradaki notları Keep formatında indirebilirsiniz.
            </p>
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 flex flex-col overflow-y-auto p-3 sm:p-6 custom-scrollbar">
          {/* Info Banner on Google Keep API Restrictions */}
          {showInfoBanner && (
            <div
              className={`p-3.5 sm:p-4 rounded-2xl border mb-5 flex items-start justify-between gap-3 ${
                isDark ? 'bg-amber-950/20 border-amber-800/40 text-amber-200' : 'bg-amber-50/80 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-start gap-2.5 text-xs">
                <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-sm mb-0.5">Google Keep API ve NoteFlow Entegrasyonu</span>
                  <p className="opacity-90 leading-relaxed">
                    Google, Keep REST API'sini resmi olarak <strong>yalnızca kurumsal Google Workspace alan adı yöneticileri ve servis hesapları</strong> için sınırlandırmıştır. Bireysel (@gmail.com) kullanıcılar için doğrudan OAuth izni Google tarafından verilmemektedir.
                    NoteFlow, bu kısıtlamayı çözmek için <strong>Keep Tarzı Renkli Çalışma Alanı</strong>, <strong>Google Takeout İçe/Dışa Aktarma</strong> ve <strong>Tek Tıkla Keep'te Açma</strong> özelliklerini sunar.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowInfoBanner(false)}
                className="p-1 rounded-lg hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 shrink-0"
                title="Kapat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Quick Note Composer (Google Keep style) */}
          {activeFilter !== 'trash' && (
            <div className="max-w-xl mx-auto w-full mb-6">
              {!isComposing ? (
                <div
                  onClick={() => setIsComposing(true)}
                  className={`px-4 py-3 rounded-2xl border shadow-sm flex items-center justify-between gap-3 cursor-text transition-all ${
                    isDark ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <span className="text-xs sm:text-sm font-medium">Bir not alın...</span>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setNewIsChecklist(true);
                        setIsComposing(true);
                      }}
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-amber-500 transition-colors"
                      title="Yeni Kontrol Listesi"
                    >
                      <CheckSquare className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`p-4 rounded-2xl border shadow-md flex flex-col gap-3 transition-all ${
                    KEEP_COLORS[newColor][isDark ? 'darkBg' : 'lightBg']
                  } ${KEEP_COLORS[newColor][isDark ? 'borderDark' : 'borderLight']}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <input
                      type="text"
                      placeholder="Başlık"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full bg-transparent font-bold text-sm focus:outline-none placeholder-slate-400"
                    />
                    <button
                      onClick={() => setNewIsPinned(!newIsPinned)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        newIsPinned ? 'text-amber-500' : 'text-slate-400 hover:text-slate-600'
                      }`}
                      title={newIsPinned ? 'Sabitlemeyi Kaldır' : 'Başa Sabitle'}
                    >
                      <Pin className={`w-4 h-4 ${newIsPinned ? 'fill-amber-500' : ''}`} />
                    </button>
                  </div>

                  {newIsChecklist ? (
                    <div className="space-y-1.5 my-1">
                      {newChecklistItems.map((item, idx) => (
                        <div key={item.id} className="flex items-center gap-2 text-xs">
                          <Square className="w-3.5 h-3.5 text-slate-400" />
                          <span className="flex-1">{item.text}</span>
                          <button
                            onClick={() =>
                              setNewChecklistItems((prev) => prev.filter((_, i) => i !== idx))
                            }
                            className="text-slate-400 hover:text-rose-500"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                      <div className="flex items-center gap-2 mt-2">
                        <Plus className="w-3.5 h-3.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Madde ekle..."
                          value={newChecklistText}
                          onChange={(e) => setNewChecklistText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleAddComposerChecklistItem();
                          }}
                          className="flex-1 bg-transparent text-xs focus:outline-none placeholder-slate-400"
                        />
                        <button
                          onClick={handleAddComposerChecklistItem}
                          className="text-xs font-bold text-amber-500 hover:text-amber-600"
                        >
                          Ekle
                        </button>
                      </div>
                    </div>
                  ) : (
                    <textarea
                      placeholder="Bir not alın..."
                      rows={3}
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      className="w-full bg-transparent text-xs sm:text-sm focus:outline-none resize-none placeholder-slate-400"
                    />
                  )}

                  {/* Labels list */}
                  {newLabels.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {newLabels.map((lbl, idx) => (
                        <span
                          key={idx}
                          className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200/70 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                        >
                          <span>{lbl}</span>
                          <X
                            className="w-2.5 h-2.5 cursor-pointer hover:text-rose-500"
                            onClick={() =>
                              setNewLabels((prev) => prev.filter((_, i) => i !== idx))
                            }
                          />
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Composer Controls */}
                  <div className="pt-2 border-t border-slate-200/50 dark:border-slate-800/50 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      {/* Color dots */}
                      {(['default', 'sand', 'peach', 'mint', 'fog', 'dusk', 'blossom'] as KeepColor[]).map(
                        (cKey) => (
                          <button
                            key={cKey}
                            onClick={() => setNewColor(cKey)}
                            className={`w-5 h-5 rounded-full border transition-transform cursor-pointer ${
                              newColor === cKey ? 'scale-115 ring-2 ring-amber-500' : 'hover:scale-105'
                            }`}
                            style={{ backgroundColor: KEEP_COLORS[cKey].dotColor }}
                            title={KEEP_COLORS[cKey].name}
                          />
                        )
                      )}

                      <button
                        onClick={() => setNewIsChecklist(!newIsChecklist)}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          newIsChecklist ? 'text-amber-500' : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Kontrol Listesine Dönüştür"
                      >
                        <CheckSquare className="w-4 h-4" />
                      </button>

                      {/* Add Label inline */}
                      <div className="relative flex items-center">
                        <input
                          type="text"
                          placeholder="+ Etiket"
                          value={newLabelInput}
                          onChange={(e) => setNewLabelInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleAddComposerLabel();
                          }}
                          className="w-20 px-2 py-0.5 text-[11px] rounded-md bg-slate-200/50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsComposing(false)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        İptal
                      </button>
                      <button
                        onClick={handleSaveNewNote}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs transition-colors cursor-pointer"
                      >
                        Kaydet
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Pinned Notes Section */}
          {pinnedNotes.length > 0 && (
            <div className="mb-6">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-3 px-1 flex items-center gap-1.5">
                <Pin className="w-3 h-3 text-amber-500" />
                <span>Sabitlenenler ({pinnedNotes.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {pinnedNotes.map((note) => renderNoteCard(note))}
              </div>
            </div>
          )}

          {/* Other Notes Section */}
          <div>
            {pinnedNotes.length > 0 && otherNotes.length > 0 && (
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">
                <span>Diğer Notlar ({otherNotes.length})</span>
              </div>
            )}

            {otherNotes.length === 0 && pinnedNotes.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mx-auto mb-3">
                  <StickyNote className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Henüz Keep Notu Bulunmuyor
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4">
                  Yukarıdaki alandan hızlı bir not veya kontrol listesi ekleyebilir ya da Google Keep JSON yedeğinizi içe aktarabilirsiniz.
                </p>
                <button
                  onClick={() => setIsComposing(true)}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs inline-flex items-center gap-2 cursor-pointer shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Not Oluştur</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {otherNotes.map((note) => renderNoteCard(note))}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Edit Note Modal */}
      {editingNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setEditingNote(null)}
          />
          <div
            className={`relative w-full max-w-lg rounded-2xl border p-5 shadow-2xl z-10 transition-all ${
              KEEP_COLORS[editingNote.color][isDark ? 'darkBg' : 'lightBg']
            } ${KEEP_COLORS[editingNote.color][isDark ? 'borderDark' : 'borderLight']}`}
          >
            <div className="flex items-center justify-between gap-2 mb-3">
              <input
                type="text"
                placeholder="Başlık"
                value={editingNote.title}
                onChange={(e) =>
                  setEditingNote({ ...editingNote, title: e.target.value })
                }
                className="w-full bg-transparent font-bold text-base focus:outline-none placeholder-slate-400"
              />
              <button
                onClick={() =>
                  setEditingNote({ ...editingNote, isPinned: !editingNote.isPinned })
                }
                className={`p-1.5 rounded-lg cursor-pointer ${
                  editingNote.isPinned ? 'text-amber-500' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Pin className={`w-4 h-4 ${editingNote.isPinned ? 'fill-amber-500' : ''}`} />
              </button>
            </div>

            {editingNote.isChecklist ? (
              <div className="space-y-2 max-h-60 overflow-y-auto mb-3 pr-1">
                {editingNote.checklistItems.map((ci, idx) => (
                  <div key={ci.id} className="flex items-center gap-2 text-xs">
                    <button
                      onClick={() =>
                        setEditingNote({
                          ...editingNote,
                          checklistItems: editingNote.checklistItems.map((item, i) =>
                            i === idx ? { ...item, done: !item.done } : item
                          ),
                        })
                      }
                      className="text-amber-500"
                    >
                      {ci.done ? (
                        <CheckSquare className="w-4 h-4" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                    <input
                      type="text"
                      value={ci.text}
                      onChange={(e) =>
                        setEditingNote({
                          ...editingNote,
                          checklistItems: editingNote.checklistItems.map((item, i) =>
                            i === idx ? { ...item, text: e.target.value } : item
                          ),
                        })
                      }
                      className={`flex-1 bg-transparent focus:outline-none ${
                        ci.done ? 'line-through text-slate-400' : ''
                      }`}
                    />
                    <button
                      onClick={() =>
                        setEditingNote({
                          ...editingNote,
                          checklistItems: editingNote.checklistItems.filter(
                            (_, i) => i !== idx
                          ),
                        })
                      }
                      className="text-slate-400 hover:text-rose-500"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}

                <div className="flex items-center gap-2 pt-2">
                  <Plus className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Madde ekle..."
                    value={editChecklistInput}
                    onChange={(e) => setEditChecklistInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && editChecklistInput.trim()) {
                        setEditingNote({
                          ...editingNote,
                          checklistItems: [
                            ...editingNote.checklistItems,
                            {
                              id: `item-${Date.now()}`,
                              text: editChecklistInput.trim(),
                              done: false,
                            },
                          ],
                        });
                        setEditChecklistInput('');
                      }
                    }}
                    className="flex-1 bg-transparent text-xs focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      if (editChecklistInput.trim()) {
                        setEditingNote({
                          ...editingNote,
                          checklistItems: [
                            ...editingNote.checklistItems,
                            {
                              id: `item-${Date.now()}`,
                              text: editChecklistInput.trim(),
                              done: false,
                            },
                          ],
                        });
                        setEditChecklistInput('');
                      }
                    }}
                    className="text-xs font-bold text-amber-500"
                  >
                    Ekle
                  </button>
                </div>
              </div>
            ) : (
              <textarea
                rows={6}
                value={editingNote.content}
                onChange={(e) =>
                  setEditingNote({ ...editingNote, content: e.target.value })
                }
                className="w-full bg-transparent text-xs sm:text-sm focus:outline-none resize-none mb-3"
              />
            )}

            {/* Colors */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-200/50 dark:border-slate-800/50">
              <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                {(Object.keys(KEEP_COLORS) as KeepColor[]).map((cKey) => (
                  <button
                    key={cKey}
                    onClick={() => setEditingNote({ ...editingNote, color: cKey })}
                    className={`w-5 h-5 rounded-full border cursor-pointer ${
                      editingNote.color === cKey
                        ? 'scale-115 ring-2 ring-amber-500'
                        : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: KEEP_COLORS[cKey].dotColor }}
                  />
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setEditingNote(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800"
                >
                  İptal
                </button>
                <button
                  onClick={() => {
                    setNotes((prev) =>
                      prev.map((n) =>
                        n.id === editingNote.id
                          ? { ...editingNote, updatedAt: new Date().toISOString() }
                          : n
                      )
                    );
                    setEditingNote(null);
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs"
                >
                  Güncelle
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal (Google Takeout / JSON) */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setShowImportModal(false)}
          />
          <div
            className={`relative w-full max-w-md rounded-2xl border p-5 shadow-2xl z-10 ${
              isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Upload className="w-4 h-4 text-amber-500" />
                <span>Google Keep / JSON İçe Aktar</span>
              </div>
              <button
                onClick={() => setShowImportModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Google Takeout'tan indirdiğiniz Keep JSON dosyalarını veya önceden yedeklediğiniz NoteFlow Keep JSON dosyasını yükleyin:
            </p>

            <div className="mb-3">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 rounded-xl border border-dashed border-amber-500/40 hover:border-amber-500 bg-amber-500/5 hover:bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>Bilgisayardan JSON Dosyası Seç</span>
              </button>
            </div>

            <div className="mb-3">
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                Veya JSON Kodunu Buraya Yapıştırın:
              </label>
              <textarea
                rows={4}
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                placeholder='[{"title": "Örnek", "textContent": "İçerik", "color": "sand"}]'
                className={`w-full p-2.5 rounded-xl text-xs font-mono border focus:outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}
              />
            </div>

            {importFeedback && (
              <div
                className={`p-2.5 rounded-xl text-xs font-semibold mb-3 ${
                  importFeedback.includes('başarıyla')
                    ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                    : 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                }`}
              >
                {importFeedback}
              </div>
            )}

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Vazgeç
              </button>
              <button
                onClick={handleImportSubmit}
                disabled={!importJsonText.trim()}
                className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-xs"
              >
                İçe Aktar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // Helper renderer for individual note card
  function renderNoteCard(note: KeepNote) {
    const isTrash = activeFilter === 'trash';
    const colorStyle = KEEP_COLORS[note.color] || KEEP_COLORS.default;

    return (
      <div
        key={note.id}
        onClick={() => !isTrash && setEditingNote(note)}
        className={`group relative rounded-2xl border p-4 shadow-xs hover:shadow-md transition-all flex flex-col justify-between cursor-pointer ${
          colorStyle[isDark ? 'darkBg' : 'lightBg']
        } ${colorStyle[isDark ? 'borderDark' : 'borderLight']}`}
      >
        <div>
          {/* Header with Title & Pin */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-snug line-clamp-2">
              {note.title || '(Başlıksız)'}
            </h3>
            {!isTrash && (
              <button
                onClick={(e) => handleTogglePin(note.id, e)}
                className={`p-1 rounded-lg transition-colors opacity-80 group-hover:opacity-100 ${
                  note.isPinned ? 'text-amber-500' : 'text-slate-400 hover:text-slate-600'
                }`}
                title={note.isPinned ? 'Sabitlemeyi Kaldır' : 'Sabitle'}
              >
                <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-amber-500' : ''}`} />
              </button>
            )}
          </div>

          {/* Note Body (Checklist or Content) */}
          {note.isChecklist ? (
            <div className="space-y-1 my-2">
              {note.checklistItems.slice(0, 5).map((ci) => (
                <div
                  key={ci.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!isTrash) handleToggleChecklistItem(note.id, ci.id);
                  }}
                  className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 hover:opacity-80"
                >
                  {ci.done ? (
                    <CheckSquare className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  ) : (
                    <Square className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  )}
                  <span className={`truncate ${ci.done ? 'line-through text-slate-400' : ''}`}>
                    {ci.text}
                  </span>
                </div>
              ))}
              {note.checklistItems.length > 5 && (
                <span className="text-[10px] text-slate-400 block pt-1">
                  +{note.checklistItems.length - 5} daha fazla madde...
                </span>
              )}
            </div>
          ) : (
            <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line line-clamp-6 leading-relaxed mb-3">
              {note.content}
            </p>
          )}

          {/* Labels & Tags */}
          {note.labels.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2 mb-2">
              {note.labels.map((lbl, idx) => (
                <span
                  key={idx}
                  className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-black/5 dark:bg-white/5 text-slate-600 dark:text-slate-300"
                >
                  #{lbl}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Card Action Toolbar (appears on hover / mobile always visible) */}
        <div className="pt-2 mt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between text-slate-500 dark:text-slate-400">
          <span className="text-[10px] text-slate-400">
            {new Date(note.updatedAt).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })}
          </span>

          <div className="flex items-center gap-1 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
            {isTrash ? (
              <>
                <button
                  onClick={(e) => handleRestoreNote(note.id, e)}
                  title="Geri Yükle"
                  className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800 text-emerald-500"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={(e) => handlePermanentDelete(note.id, e)}
                  title="Kalıcı Olarak Sil"
                  className="p-1 rounded-md hover:bg-rose-100 dark:hover:bg-rose-900/30 text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <>
                {/* Color change popover toggle */}
                <div className="relative">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setColorPickerNoteId(colorPickerNoteId === note.id ? null : note.id);
                    }}
                    title="Renk Değiştir"
                    className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
                  >
                    <Palette className="w-3.5 h-3.5" />
                  </button>

                  {colorPickerNoteId === note.id && (
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="absolute bottom-full left-0 mb-1 p-1.5 rounded-xl bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 grid grid-cols-4 gap-1 z-30"
                    >
                      {(Object.keys(KEEP_COLORS) as KeepColor[]).map((cKey) => (
                        <button
                          key={cKey}
                          onClick={(e) => handleChangeColor(note.id, cKey, e)}
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: KEEP_COLORS[cKey].dotColor }}
                          title={KEEP_COLORS[cKey].name}
                        />
                      ))}
                    </div>
                  )}
                </div>

                <button
                  onClick={(e) => handleToggleArchive(note.id, e)}
                  title={note.isArchived ? 'Arşivden Çıkar' : 'Arşivle'}
                  className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
                >
                  {note.isArchived ? (
                    <ArchiveRestore className="w-3.5 h-3.5 text-amber-500" />
                  ) : (
                    <Archive className="w-3.5 h-3.5" />
                  )}
                </button>

                <button
                  onClick={(e) => handleConvertToNoteFlowAction(note, e)}
                  title="NoteFlow Notuna Dönüştür"
                  className="p-1 rounded-md hover:bg-teal-500/10 text-teal-600 dark:text-teal-400"
                >
                  <FileText className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={(e) => handleConvertToKanbanAction(note, e)}
                  title="Kanban Panosuna Kart Olarak Ekle"
                  className="p-1 rounded-md hover:bg-amber-500/10 text-amber-600 dark:text-amber-400"
                >
                  <Kanban className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={(e) => handleCopyNoteText(note, e)}
                  title="Metni Kopyala"
                  className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
                >
                  {copiedId === note.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>

                <button
                  onClick={(e) => handleTrashNote(note.id, e)}
                  title="Çöp Kutusuna Gönder"
                  className="p-1 rounded-md hover:bg-rose-500/10 text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }
};
