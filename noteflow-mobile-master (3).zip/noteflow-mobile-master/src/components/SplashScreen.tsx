import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onFinish?: () => void;
  isDark?: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish, isDark }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    // 1.4s görünür kal, sonra 400ms fade-out ile kapan
    const timer = setTimeout(() => {
      setIsFading(true);
      const finishTimer = setTimeout(() => {
        setIsVisible(false);
        if (onFinish) onFinish();
      }, 450);
      return () => clearTimeout(finishTimer);
    }, 1500);

    return () => clearTimeout(timer);
  }, [onFinish]);

  if (!isVisible) return null;

  return (
    <div
      id="noteflow-splash-screen"
      onClick={() => {
        setIsFading(true);
        setTimeout(() => {
          setIsVisible(false);
          if (onFinish) onFinish();
        }, 300);
      }}
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center cursor-pointer transition-opacity duration-500 select-none ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      } ${isDark ? 'bg-slate-950 text-white' : 'bg-[#faf8f5] text-slate-900'}`}
    >
      <div className="flex flex-col items-center max-w-sm px-6 text-center animate-fadeIn">
        {/* Kullanıcının Yüklediği Açılış Görseli */}
        <div className="relative mb-6">
          <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-full overflow-hidden shadow-2xl ring-4 ring-teal-500/20 shadow-teal-500/10 bg-white flex items-center justify-center p-2">
            <img
              src="/images/noteflow-splash.jpg"
              alt="NoteFlow Splash"
              className="w-full h-full object-contain transform hover:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Yedek resim kaynağı
                const target = e.target as HTMLImageElement;
                if (!target.src.includes('splash-icon.png')) {
                  target.src = '/images/splash-icon.png';
                }
              }}
            />
          </div>
          <span className="absolute -bottom-2 -right-2 px-2.5 py-1 rounded-full bg-teal-500 text-white text-[11px] font-bold shadow-md tracking-wider uppercase">
            v1.0
          </span>
        </div>

        {/* NoteFlow Başlığı */}
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent mb-2">
          NoteFlow
        </h1>

        <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 font-medium max-w-xs mb-8">
          Fikirlerinizi, Defterlerinizi ve Notlarınızı Özgürce Akıtın
        </p>

        {/* Yükleniyor / Açılıyor İlerleme Çubuğu */}
        <div className="w-36 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-teal-500 to-indigo-500 rounded-full animate-[pulse_1s_ease-in-out_infinite]" />
        </div>
        <span className="text-[11px] text-slate-400 dark:text-slate-500 mt-2 font-mono">
          Yükleniyor…
        </span>
      </div>
    </div>
  );
};
