import { newId } from '../data/sync/ids';
import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react';
import { MindMap, MindMapNode, MindMapTableDoc, MindMapTreeDoc, MindMapType } from '../types';
import {
  MIND_MAP_TEMPLATES,
  NODE_COLORS,
  isTableType,
  templateFor,
} from '../data/mindmapTemplates';
import { layoutMindMap, NODE_W, NODE_H } from '../lib/mindmap/layout';
import {
  addChildNode,
  recolorNode,
  removeNode,
  renameNode,
  countNodes,
  findNode,
} from '../lib/mindmap/tree';
import {
  addRow,
  addCol,
  removeRow,
  removeCol,
  renameRow,
  renameCol,
  setCell,
  getCell,
} from '../lib/mindmap/table';
import {
  Network,
  Plus,
  Trash2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  ArrowLeft,
  Edit2,
  Grid,
  FolderTree,
  GitFork,
  Milestone,
  Split,
  GitMerge,
  Users,
  Sparkles,
  Check,
  X,
  Target,
} from 'lucide-react';

interface MindMapTabProps {
  mindmaps: MindMap[];
  onSaveMindMap: (map: MindMap) => void;
  onDeleteMindMap: (id: string) => void;
  currentMap: MindMap | null;
  setCurrentMap: (map: MindMap | null) => void;
}

export const MindMapTab: React.FC<MindMapTabProps> = ({
  mindmaps,
  onSaveMindMap,
  onDeleteMindMap,
  currentMap,
  setCurrentMap,
}) => {
  // Canvas View Controls
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 200, y: 250 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [isEditingMapTitle, setIsEditingMapTitle] = useState(false);
  const [mapTitleInput, setMapTitleInput] = useState('');
  const [isNodeEditModalOpen, setIsNodeEditModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'canvas' | 'outline'>('canvas');

  const containerRef = useRef<HTMLDivElement>(null);

  // Node tree calculations
  const treeData = useMemo(() => {
    if (!currentMap || isTableType(currentMap.type)) return null;
    const doc = currentMap.data as MindMapTreeDoc;
    if (!doc.root) return null;
    return layoutMindMap(currentMap.type, doc.root);
  }, [currentMap]);

  // Dynamic Centering logic for both mobile and desktop using bounding box
  const centerView = useCallback(() => {
    const container = containerRef.current;
    const w = container ? container.clientWidth : (typeof window !== 'undefined' ? window.innerWidth : 360);
    const h = container ? container.clientHeight : 450;

    if (!treeData || treeData.nodes.length === 0) {
      const targetZoom = w < 640 ? 0.8 : 1;
      setZoom(targetZoom);
      setPan({
        x: Math.round(w / 2),
        y: Math.round(h / 2),
      });
      return;
    }

    // Accurate bounding box calculation of all nodes
    const bboxW = Math.max(160, treeData.maxX - treeData.minX + NODE_W);
    const bboxH = Math.max(100, treeData.maxY - treeData.minY + NODE_H);
    const midX = (treeData.minX + treeData.maxX) / 2;
    const midY = (treeData.minY + treeData.maxY) / 2;

    const pad = w < 640 ? 40 : 80;
    const scaleX = (w - pad) / bboxW;
    const scaleY = (h - pad) / bboxH;
    let targetZoom = Math.min(scaleX, scaleY);

    if (w < 640) {
      targetZoom = Math.min(0.95, Math.max(0.4, targetZoom));
    } else {
      targetZoom = Math.min(1.15, Math.max(0.45, targetZoom));
    }

    setZoom(targetZoom);
    setPan({
      x: Math.round(w / 2 - midX * targetZoom),
      y: Math.round(h / 2 - midY * targetZoom),
    });
  }, [treeData]);

  useEffect(() => {
    if (currentMap) {
      setMapTitleInput(currentMap.title);
      setSelectedNodeId(null);
      setEditingNodeId(null);
      setIsNodeEditModalOpen(false);

      // Center root node automatically after layout calculation
      const timer = setTimeout(() => {
        centerView();
      }, 60);
      return () => clearTimeout(timer);
    }
  }, [currentMap?.id, centerView]);

  const handleCreateFromTemplate = (type: MindMapType) => {
    const template = templateFor(type);
    const newDoc = template.createDoc();
    const newMap: MindMap = {
      id: newId(),
      title: `${template.label} Haritası`,
      type,
      data: newDoc,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onSaveMindMap(newMap);
    setCurrentMap(newMap);
  };

  const handleUpdateCurrentDoc = (newData: MindMap['data']) => {
    if (!currentMap) return;
    const updated: MindMap = {
      ...currentMap,
      data: newData,
      updatedAt: new Date().toISOString(),
    };
    onSaveMindMap(updated);
    setCurrentMap(updated);
  };

  const handleUpdateTitle = () => {
    if (!currentMap || !mapTitleInput.trim()) return;
    const updated: MindMap = {
      ...currentMap,
      title: mapTitleInput.trim(),
      updatedAt: new Date().toISOString(),
    };
    onSaveMindMap(updated);
    setCurrentMap(updated);
    setIsEditingMapTitle(false);
  };

  // Touch gesture state ref for smooth 1-finger pan, 2-finger pinch-zoom & tap detection
  const touchStateRef = useRef<{
    mode: 'none' | 'pan' | 'pinch';
    startX: number;
    startY: number;
    panStartX: number;
    panStartY: number;
    startDist: number;
    startZoom: number;
    movedDistance: number;
    startTime: number;
  }>({
    mode: 'none',
    startX: 0,
    startY: 0,
    panStartX: 0,
    panStartY: 0,
    startDist: 0,
    startZoom: 1,
    movedDistance: 0,
    startTime: 0,
  });

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      touchStateRef.current = {
        mode: 'pan',
        startX: t.clientX,
        startY: t.clientY,
        panStartX: pan.x,
        panStartY: pan.y,
        startDist: 0,
        startZoom: zoom,
        movedDistance: 0,
        startTime: Date.now(),
      };
    } else if (e.touches.length === 2) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      touchStateRef.current = {
        mode: 'pinch',
        startX: 0,
        startY: 0,
        panStartX: pan.x,
        panStartY: pan.y,
        startDist: dist,
        startZoom: zoom,
        movedDistance: 0,
        startTime: Date.now(),
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const ts = touchStateRef.current;
    if (ts.mode === 'pan' && e.touches.length === 1) {
      const t = e.touches[0];
      const dx = t.clientX - ts.startX;
      const dy = t.clientY - ts.startY;
      const dist = Math.hypot(dx, dy);
      ts.movedDistance = Math.max(ts.movedDistance, dist);

      // Only initiate panning if moved beyond 6px (protects mobile tap)
      if (dist >= 6) {
        setPan({
          x: ts.panStartX + dx,
          y: ts.panStartY + dy,
        });
      }
    } else if (ts.mode === 'pinch' && e.touches.length === 2) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      ts.movedDistance = 20;
      if (ts.startDist > 10) {
        const scaleFactor = dist / ts.startDist;
        const newZoom = Math.min(2.5, Math.max(0.35, ts.startZoom * scaleFactor));
        setZoom(newZoom);
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const ts = touchStateRef.current;
    // If user tapped on canvas background (distance < 6px), deselect
    if (ts.mode === 'pan' && ts.movedDistance < 6 && Date.now() - ts.startTime < 350) {
      const target = e.target as HTMLElement | null;
      if (target && !target.closest('[data-node-id]')) {
        setSelectedNodeId(null);
      }
    }
    touchStateRef.current.mode = 'none';
  };

  // Mouse pan handlers for desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target === containerRef.current || (e.target as HTMLElement).tagName === 'svg') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Node operations
  const handleAddChild = (parentId: string) => {
    if (!currentMap || isTableType(currentMap.type)) return;
    const doc = currentMap.data as MindMapTreeDoc;
    const { root, childId } = addChildNode(doc.root, parentId, 'Yeni Konu');
    handleUpdateCurrentDoc({ kind: 'tree', root });
    setSelectedNodeId(childId);
    setEditingNodeId(childId);
    setEditTitle('Yeni Konu');
  };

  const handleDeleteNode = (nodeId: string) => {
    if (!currentMap || isTableType(currentMap.type)) return;
    const doc = currentMap.data as MindMapTreeDoc;
    if (doc.root.id === nodeId) return; // Don't delete root
    const root = removeNode(doc.root, nodeId);
    handleUpdateCurrentDoc({ kind: 'tree', root });
    setSelectedNodeId(null);
  };

  const handleRecolorNode = (nodeId: string, color: string) => {
    if (!currentMap || isTableType(currentMap.type)) return;
    const doc = currentMap.data as MindMapTreeDoc;
    const root = recolorNode(doc.root, nodeId, color);
    handleUpdateCurrentDoc({ kind: 'tree', root });
  };

  const handleSaveNodeTitle = (nodeId: string) => {
    if (!currentMap || isTableType(currentMap.type) || !editTitle.trim()) {
      setEditingNodeId(null);
      return;
    }
    const doc = currentMap.data as MindMapTreeDoc;
    const root = renameNode(doc.root, nodeId, editTitle.trim());
    handleUpdateCurrentDoc({ kind: 'tree', root });
    setEditingNodeId(null);
  };

  const selectedNode = useMemo(() => {
    if (!currentMap || isTableType(currentMap.type) || !selectedNodeId) return null;
    const doc = currentMap.data as MindMapTreeDoc;
    return findNode(doc.root, selectedNodeId);
  }, [currentMap, selectedNodeId]);

  // Icon mapping
  const renderTemplateIcon = (type: MindMapType) => {
    switch (type) {
      case 'matrix':
      case 'grid':
        return <Grid className="w-5 h-5" />;
      case 'fishbone':
        return <GitFork className="w-5 h-5" />;
      case 'timeline':
        return <Milestone className="w-5 h-5" />;
      case 'brace':
        return <Split className="w-5 h-5" />;
      case 'logic':
        return <GitMerge className="w-5 h-5" />;
      case 'org':
        return <Users className="w-5 h-5" />;
      default:
        return <FolderTree className="w-5 h-5" />;
    }
  };

  // Mobile-friendly recursive Outline Tree Renderer
  const renderOutlineNode = (node: MindMapNode, depth: number = 0) => {
    const isRoot = depth === 0;
    const isSelected = selectedNodeId === node.id;
    const nodeColor = node.color || '#3B82F6';

    return (
      <div key={node.id} className="space-y-2">
        <div
          className={`flex items-center justify-between gap-2 p-3 rounded-2xl border transition-all ${
            isSelected
              ? 'bg-blue-500/10 border-blue-500 ring-2 ring-blue-500/30'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs'
          }`}
          style={{ marginLeft: `${Math.min(depth * 18, 90)}px` }}
        >
          <div
            onClick={() => {
              if (selectedNodeId === node.id) {
                setEditingNodeId(node.id);
                setEditTitle(node.title);
                setIsNodeEditModalOpen(true);
              } else {
                setSelectedNodeId(node.id);
              }
            }}
            className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer py-1"
          >
            <span
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: nodeColor }}
            />
            <span
              className={`text-xs sm:text-sm font-semibold truncate ${
                isRoot
                  ? 'font-bold text-slate-950 dark:text-white'
                  : 'text-slate-800 dark:text-slate-200'
              }`}
            >
              {node.title}
            </span>
            {isRoot && (
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400">
                Kök
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                setSelectedNodeId(node.id);
                setEditingNodeId(node.id);
                setEditTitle(node.title);
                setIsNodeEditModalOpen(true);
              }}
              className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Düzenle"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => handleAddChild(node.id)}
              className="flex items-center gap-1 px-2.5 py-2 min-h-[40px] rounded-xl bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/60 dark:hover:bg-blue-900/60 text-blue-600 dark:text-blue-400 text-xs font-bold transition-colors cursor-pointer"
              title="Alt Konu Ekle"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Alt Konu</span>
            </button>
            {!isRoot && (
              <button
                type="button"
                onClick={() => handleDeleteNode(node.id)}
                className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                title="Sil"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
        {node.children && node.children.map((child) => renderOutlineNode(child, depth + 1))}
      </div>
    );
  };

  // If a map is currently open, show Canvas Editor
  if (currentMap) {
    const isTable = isTableType(currentMap.type);
    const tableDoc = isTable ? (currentMap.data as MindMapTableDoc) : null;

    return (
      <div className="space-y-4 animate-fadeIn">
        {/* Editor Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentMap(null)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Haritalar</span>
            </button>

            {isEditingMapTitle ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={mapTitleInput}
                  onChange={(e) => setMapTitleInput(e.target.value)}
                  className="px-3 py-1 text-sm font-bold rounded-lg border border-blue-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
                  autoFocus
                  onKeyDown={(e) => e.key === 'Enter' && handleUpdateTitle()}
                />
                <button
                  onClick={handleUpdateTitle}
                  className="px-3 py-1 rounded-lg bg-blue-600 text-white text-xs font-semibold"
                >
                  Tamam
                </button>
              </div>
            ) : (
              <div
                onClick={() => setIsEditingMapTitle(true)}
                className="flex items-center gap-2 cursor-pointer group"
              >
                <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {currentMap.title}
                </h1>
                <Edit2 className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600" />
              </div>
            )}

            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-900">
              {templateFor(currentMap.type).label}
            </span>
          </div>

          {/* Controls: View Mode, Zoom & Actions */}
          <div className="flex items-center gap-2">
            {!isTable && (
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl p-1">
                <button
                  type="button"
                  onClick={() => setViewMode('canvas')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    viewMode === 'canvas'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                  title="Görsel Tuval Görünümü"
                >
                  Tuval
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('outline')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    viewMode === 'outline'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                  title="Mobil Uyumlu Ağaç Liste Görünümü"
                >
                  Liste
                </button>
              </div>
            )}

            {!isTable && viewMode === 'canvas' && (
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl p-1">
                <button
                  onClick={() => setZoom((z) => Math.max(0.35, z - 0.15))}
                  className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 transition-colors"
                  title="Uzaklaştır"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="text-xs font-mono font-semibold px-2 text-slate-700 dark:text-slate-300">
                  {Math.round(zoom * 100)}%
                </span>
                <button
                  onClick={() => setZoom((z) => Math.min(2.5, z + 0.15))}
                  className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 transition-colors"
                  title="Yakınlaştır"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={centerView}
                  className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 transition-colors ml-1 text-xs font-semibold"
                  title="Ortala ve Hizala"
                >
                  <Target className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span className="hidden sm:inline">Ortala</span>
                </button>
              </div>
            )}

            <button
              onClick={() => {
                if (confirm('Bu zihin haritasını silmek istediğinize emin misiniz?')) {
                  onDeleteMindMap(currentMap.id);
                  setCurrentMap(null);
                }
              }}
              className="p-2 rounded-xl text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
              title="Haritayı Sil"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Selected Node Action Toolbar (Desktop / Tablet top bar) */}
        {!isTable && selectedNode && (
          <div className="hidden sm:flex flex-wrap items-center justify-between gap-3 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900 rounded-2xl px-5 py-3 animate-fadeIn">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-blue-900 dark:text-blue-200">
                Seçili Düğüm: <span className="font-bold">"{selectedNode.title}"</span>
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => {
                  setEditingNodeId(selectedNode.id);
                  setEditTitle(selectedNode.title);
                  setIsNodeEditModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 shadow-xs cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" /> Düzenle
              </button>

              <button
                onClick={() => handleAddChild(selectedNode.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700 shadow-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Alt Düğüm Ekle
              </button>

              {/* Color swatches */}
              <div className="flex items-center gap-1.5 pl-2 border-l border-blue-200 dark:border-blue-900">
                {NODE_COLORS.slice(0, 5).map((color) => (
                  <button
                    key={color}
                    onClick={() => handleRecolorNode(selectedNode.id, color)}
                    className={`w-5 h-5 rounded-full border-2 transition-transform ${
                      selectedNode.color === color ? 'scale-125 border-slate-900 dark:border-white' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>

              {(currentMap.data as MindMapTreeDoc).root.id !== selectedNode.id && (
                <button
                  onClick={() => handleDeleteNode(selectedNode.id)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-100 dark:hover:bg-red-950/40 ml-2 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Sil
                </button>
              )}
            </div>
          </div>
        )}

        {/* Canvas or Table Area */}
        {isTable && tableDoc ? (
          /* Matrix / Table Editor */
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xs overflow-x-auto">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Tablo & Matris Düzenleyici
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Hücrelere tıklayarak doğrudan içerik düzenleyebilirsiniz.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleUpdateCurrentDoc(addRow(tableDoc))}
                  className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-semibold hover:bg-blue-100 transition-colors"
                >
                  + Satır Ekle
                </button>
                <button
                  onClick={() => handleUpdateCurrentDoc(addCol(tableDoc))}
                  className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-xs font-semibold hover:bg-indigo-100 transition-colors"
                >
                  + Sütun Ekle
                </button>
              </div>
            </div>

            <div className="min-w-[500px] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800">
                    <th className="p-3 w-40 text-xs font-bold text-slate-600 dark:text-slate-400 uppercase">
                      Satır / Sütun
                    </th>
                    {tableDoc.cols.map((col, colIdx) => (
                      <th key={colIdx} className="p-3 border-l border-slate-200 dark:border-slate-800">
                        <div className="flex items-center justify-between gap-1">
                          <input
                            type="text"
                            value={col}
                            onChange={(e) =>
                              handleUpdateCurrentDoc(renameCol(tableDoc, colIdx, e.target.value))
                            }
                            className="bg-transparent font-bold text-xs text-slate-900 dark:text-white focus:outline-hidden"
                          />
                          {tableDoc.cols.length > 1 && (
                            <button
                              onClick={() => handleUpdateCurrentDoc(removeCol(tableDoc, colIdx))}
                              className="text-slate-400 hover:text-red-500 p-0.5"
                              title="Sütunu Sil"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tableDoc.rows.map((row, rowIdx) => (
                    <tr
                      key={rowIdx}
                      className="border-b border-slate-200 dark:border-slate-800/80 hover:bg-slate-50/50 dark:hover:bg-slate-800/30"
                    >
                      <td className="p-3 bg-slate-50 dark:bg-slate-800/40">
                        <div className="flex items-center justify-between gap-1">
                          <input
                            type="text"
                            value={row}
                            onChange={(e) =>
                              handleUpdateCurrentDoc(renameRow(tableDoc, rowIdx, e.target.value))
                            }
                            className="bg-transparent font-semibold text-xs text-slate-900 dark:text-white focus:outline-hidden"
                          />
                          {tableDoc.rows.length > 1 && (
                            <button
                              onClick={() => handleUpdateCurrentDoc(removeRow(tableDoc, rowIdx))}
                              className="text-slate-400 hover:text-red-500 p-0.5"
                              title="Satırı Sil"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </td>
                      {tableDoc.cols.map((_, colIdx) => {
                        const val = getCell(tableDoc, rowIdx, colIdx);
                        return (
                          <td
                            key={colIdx}
                            className="p-3 border-l border-slate-200 dark:border-slate-800"
                          >
                            <input
                              type="text"
                              value={val}
                              placeholder="Metin..."
                              onChange={(e) =>
                                handleUpdateCurrentDoc(setCell(tableDoc, rowIdx, colIdx, e.target.value))
                              }
                              className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden placeholder-slate-400"
                            />
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : viewMode === 'outline' ? (
          /* Mobile-Friendly Hierarchical Outline View */
          <div className="w-full min-h-[360px] max-h-[70vh] overflow-y-auto bg-slate-50/80 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-3 sm:p-5 space-y-3 shadow-inner">
            <div className="flex items-center justify-between pb-3 mb-1 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-600 dark:text-slate-400">
                Ağaç Hiyerarşisi ({treeData?.nodes.length || 1} Konu)
              </span>
              <button
                type="button"
                onClick={() => {
                  const doc = currentMap.data as MindMapTreeDoc;
                  if (doc?.root) handleAddChild(doc.root.id);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Konu Ekle</span>
              </button>
            </div>
            {(currentMap.data as MindMapTreeDoc)?.root &&
              renderOutlineNode((currentMap.data as MindMapTreeDoc).root)}
          </div>
        ) : (
          /* Tree SVG Visual Interactive Canvas */
          <div
            ref={containerRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onTouchCancel={handleTouchEnd}
            style={{ touchAction: 'none' }}
            className="w-full h-[56vh] sm:h-[65vh] min-h-[340px] max-h-[750px] bg-slate-100/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden relative select-none cursor-grab active:cursor-grabbing shadow-inner"
          >
            {/* Background Grid Dots */}
            <div
              className="absolute inset-0 pointer-events-none opacity-20 dark:opacity-30"
              style={{
                backgroundImage: 'radial-gradient(#64748b 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            />

            {/* Transform Layer */}
            <div
              className="absolute transform-gpu transition-transform duration-75"
              style={{
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: '0 0',
              }}
            >
              {treeData && (
                <svg
                  className="overflow-visible pointer-events-none"
                  style={{
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    width: '1px',
                    height: '1px',
                  }}
                >
                  {/* Connecting Edges */}
                  {treeData.edges.map((edge) => {
                    const isDirectFishbone = currentMap.type === 'fishbone';
                    let path = '';
                    if (isDirectFishbone) {
                      path = `M ${edge.from.x} ${edge.from.y} L ${edge.to.x} ${edge.to.y}`;
                    } else {
                      // Smooth bezier curve
                      const midX = (edge.from.x + edge.to.x) / 2;
                      path = `M ${edge.from.x} ${edge.from.y} C ${midX} ${edge.from.y}, ${midX} ${edge.to.y}, ${edge.to.x} ${edge.to.y}`;
                    }

                    return (
                      <path
                        key={edge.id}
                        d={path}
                        fill="none"
                        stroke={edge.id === 'spine' ? '#3B82F6' : '#94A3B8'}
                        strokeWidth={edge.id === 'spine' ? 4 : 2}
                        strokeLinecap="round"
                        className="dark:stroke-slate-700 transition-all"
                      />
                    );
                  })}
                </svg>
              )}

              {/* Render Nodes */}
              {treeData &&
                treeData.nodes.map((layoutNode) => {
                  const isSelected = selectedNodeId === layoutNode.id;
                  const isEditing = editingNodeId === layoutNode.id;
                  const nodeColor = layoutNode.node.color || '#3B82F6';
                  const isRoot = layoutNode.parentId === null;

                  return (
                    <div
                      key={layoutNode.id}
                      data-node-id={layoutNode.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (selectedNodeId === layoutNode.id) {
                          setEditingNodeId(layoutNode.id);
                          setEditTitle(layoutNode.node.title);
                          setIsNodeEditModalOpen(true);
                        } else {
                          setSelectedNodeId(layoutNode.id);
                        }
                      }}
                      onTouchEnd={(e) => {
                        const ts = touchStateRef.current;
                        if (ts.mode === 'pan' && ts.movedDistance < 6) {
                          e.stopPropagation();
                          if (selectedNodeId === layoutNode.id) {
                            setEditingNodeId(layoutNode.id);
                            setEditTitle(layoutNode.node.title);
                            setIsNodeEditModalOpen(true);
                          } else {
                            setSelectedNodeId(layoutNode.id);
                          }
                        }
                      }}
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        setSelectedNodeId(layoutNode.id);
                        setEditingNodeId(layoutNode.id);
                        setEditTitle(layoutNode.node.title);
                        setIsNodeEditModalOpen(true);
                      }}
                      style={{
                        position: 'absolute',
                        left: layoutNode.x - NODE_W / 2,
                        top: layoutNode.y - NODE_H / 2,
                        width: NODE_W,
                        height: NODE_H,
                      }}
                      className={`flex items-center px-3.5 rounded-2xl transition-all cursor-pointer shadow-md select-none ${
                        isSelected
                          ? 'ring-4 ring-blue-500 scale-105 z-20 shadow-blue-500/20'
                          : 'hover:scale-102 hover:shadow-lg z-10'
                      } ${
                        isRoot
                          ? 'bg-slate-900 text-white dark:bg-blue-600'
                          : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {/* Left accent color pip */}
                      {!isRoot && (
                        <div
                          className="w-2.5 h-2.5 rounded-full mr-2.5 shrink-0"
                          style={{ backgroundColor: nodeColor }}
                        />
                      )}

                      {/* Title or Inline Edit Input */}
                      {isEditing ? (
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          onBlur={() => handleSaveNodeTitle(layoutNode.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveNodeTitle(layoutNode.id);
                            if (e.key === 'Escape') setEditingNodeId(null);
                          }}
                          autoFocus
                          className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white focus:outline-hidden border-b border-blue-500"
                        />
                      ) : (
                        <div className="truncate flex-1 flex items-center justify-between">
                          <span className={`text-xs font-bold truncate block ${isRoot ? 'text-white' : ''}`}>
                            {layoutNode.node.title}
                          </span>
                          {isSelected && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingNodeId(layoutNode.id);
                                setEditTitle(layoutNode.node.title);
                                setIsNodeEditModalOpen(true);
                              }}
                              className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-blue-500 transition-colors ml-1 shrink-0"
                              title="Düzenle"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>

            {/* Floating Zoom & Center Controls inside canvas */}
            <div className="absolute top-3 right-3 flex items-center gap-1 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 rounded-xl p-1 shadow-md z-30">
              <button
                onClick={() => setZoom((z) => Math.max(0.35, z - 0.15))}
                className="p-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Uzaklaştır"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono font-bold px-1.5 text-slate-700 dark:text-slate-300 min-w-[38px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(2.5, z + 0.15))}
                className="p-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Yakınlaştır"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={centerView}
                className="p-2 rounded-lg text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition-colors border-l border-slate-200 dark:border-slate-800 ml-0.5"
                title="Ekrana Ortala"
              >
                <Target className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile / Compact Floating Toolbar when a Node is Selected */}
            {!isTable && selectedNode && (
              <div className="absolute bottom-3 left-3 right-3 sm:hidden bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-xl z-30 animate-fadeIn">
                <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    📍 {selectedNode.title}
                  </span>
                  <button
                    onClick={() => setSelectedNodeId(null)}
                    className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg min-h-[36px] min-w-[36px] flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setEditingNodeId(selectedNode.id);
                      setEditTitle(selectedNode.title);
                      setIsNodeEditModalOpen(true);
                    }}
                    className="flex-1 flex items-center justify-center gap-1.5 min-h-[44px] py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 active:scale-95 transition-all"
                  >
                    <Edit2 className="w-4 h-4 text-blue-500" />
                    <span>Düzenle</span>
                  </button>
                  <button
                    onClick={() => handleAddChild(selectedNode.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 min-h-[44px] py-2.5 px-3 rounded-xl bg-blue-600 text-xs font-bold text-white shadow-xs active:scale-95 transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Alt Düğüm</span>
                  </button>
                  {/* Colors quick cycle */}
                  <div className="flex items-center gap-1 px-1">
                    {NODE_COLORS.slice(0, 3).map((color) => (
                      <button
                        key={color}
                        onClick={() => handleRecolorNode(selectedNode.id, color)}
                        className={`w-7 h-7 rounded-full border-2 transition-transform ${
                          selectedNode.color === color ? 'ring-2 ring-blue-500 scale-110 border-white' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  {(currentMap.data as MindMapTreeDoc).root.id !== selectedNode.id && (
                    <button
                      onClick={() => handleDeleteNode(selectedNode.id)}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center p-2.5 rounded-xl text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 active:scale-95 transition-all"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Helper tip overlay (desktop) */}
            <div className="hidden sm:block absolute bottom-4 left-4 pointer-events-none bg-white/90 dark:bg-slate-900/90 backdrop-blur-xs border border-slate-200 dark:border-slate-800 px-3 py-1.5 rounded-xl text-[11px] text-slate-500 dark:text-slate-400">
              💡 Parmağınızla veya fareyle tuvali sürükleyin • İki parmakla yakınlaştırın • Düğüme tıklayarak alt düğüm ekleyin
            </div>
          </div>
        )}

        {/* Mobile-Friendly Node Edit Modal */}
        {isNodeEditModalOpen && selectedNode && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
            <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-blue-500" />
                  Düğüm Başlığını Düzenle
                </h3>
                <button
                  onClick={() => setIsNodeEditModalOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleSaveNodeTitle(selectedNode.id);
                    setIsNodeEditModalOpen(false);
                  }
                }}
                autoFocus
                placeholder="Düğüm başlığı..."
                className="w-full px-4 py-3 rounded-xl border border-blue-500/50 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 mb-4"
              />

              {/* Color choices */}
              <div className="mb-5">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 block">
                  Düğüm Rengi
                </span>
                <div className="flex items-center gap-2">
                  {NODE_COLORS.map((color) => (
                    <button
                      key={color}
                      onClick={() => handleRecolorNode(selectedNode.id, color)}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        selectedNode.color === color
                          ? 'scale-110 border-slate-900 dark:border-white shadow-sm'
                          : 'border-transparent'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={() => setIsNodeEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  İptal
                </button>
                <button
                  onClick={() => {
                    handleSaveNodeTitle(selectedNode.id);
                    setIsNodeEditModalOpen(false);
                  }}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Otherwise, show Templates Catalog and Haritaların List
  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Header */}
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
          Görselleştirme
        </span>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          Mind Map & Şemalar
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
          Fikirlerinizi, iş süreçlerinizi ve hiyerarşilerinizi 10 farklı şablon ile yapılandırın.
        </p>
      </div>

      {/* Templates Carousel / Grid */}
      <div>
        <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-600" />
          Yeni Şablon Seç
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {MIND_MAP_TEMPLATES.map((tpl) => (
            <div
              key={tpl.type}
              onClick={() => handleCreateFromTemplate(tpl.type)}
              className="flex flex-col justify-between p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-500 hover:shadow-md transition-all cursor-pointer group"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  {renderTemplateIcon(tpl.type)}
                </div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors line-clamp-1">
                  {tpl.label}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {tpl.description}
                </p>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center text-[11px] font-semibold text-purple-600 dark:text-purple-400">
                <span>Şablonu Başlat</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* User's Existing Mind Maps */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Network className="w-4 h-4 text-blue-600" />
          Kayıtlı Haritaların ({mindmaps.length})
        </h2>

        {mindmaps.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mx-auto mb-3">
              <Network className="w-6 h-6" />
            </div>
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Henüz bir zihin haritası yok
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
              Yukarıdaki şablonlardan birine tıklayarak ilk zihin haritanızı oluşturabilirsiniz.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mindmaps.map((map) => {
              const tpl = templateFor(map.type);
              const nodeCount = !isTableType(map.type)
                ? countNodes((map.data as MindMapTreeDoc).root)
                : (map.data as MindMapTableDoc).rows.length * (map.data as MindMapTableDoc).cols.length;

              return (
                <div
                  key={map.id}
                  onClick={() => setCurrentMap(map)}
                  className="flex flex-col justify-between p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-500 hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                        {renderTemplateIcon(map.type)}
                      </div>
                      <div className="truncate">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors truncate">
                          {map.title}
                        </h3>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400 capitalize">
                          {tpl.label}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`"${map.title}" haritasını silmek istediğinize emin misiniz?`)) {
                          onDeleteMindMap(map.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors opacity-0 group-hover:opacity-100"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                    <span>
                      {isTableType(map.type) ? `${nodeCount} hücre` : `${nodeCount} düğüm`}
                    </span>
                    <span>
                      {new Date(map.updatedAt).toLocaleDateString('tr-TR', {
                        day: 'numeric',
                        month: 'short',
                      })}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
