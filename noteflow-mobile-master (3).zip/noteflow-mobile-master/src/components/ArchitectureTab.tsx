import React, { useState } from 'react';
import {
  Cpu,
  Database,
  Smartphone,
  Laptop,
  ShieldCheck,
  Zap,
  CheckCircle2,
  RefreshCw,
  Server,
  Layers,
  Code2,
  HardDrive,
  Lock,
  Wifi,
  WifiOff,
} from 'lucide-react';

export const ArchitectureTab: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'overview' | 'schema' | 'drift' | 'ui' | 'sync'>('overview');
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [syncQueueCount, setSyncQueueCount] = useState(0);
  const [lastSyncTime, setLastSyncTime] = useState(new Date().toLocaleTimeString());
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success'>('idle');

  const triggerManualSync = () => {
    setSyncStatus('syncing');
    setTimeout(() => {
      setSyncStatus('success');
      setSyncQueueCount(0);
      setLastSyncTime(new Date().toLocaleTimeString());
      setTimeout(() => setSyncStatus('idle'), 2000);
    }, 1200);
  };

  const simulateOfflineMutation = () => {
    setIsOfflineMode(true);
    setSyncQueueCount((prev) => prev + 1);
  };

  const restoreOnline = () => {
    setIsOfflineMode(false);
    triggerManualSync();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
            <Cpu className="w-3.5 h-3.5 animate-pulse" />
            Flutter + Supabase + Drift (Offline-First Clean Architecture)
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Yüksek Performanslı ve Çökmeyen Çapraz Platform Mimarisi
          </h1>
          <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
            NoteFlow, iOS, Android, Windows ve macOS platformlarında tek kod tabanıyla çalışan, Impeller motoruyla 60+ FPS pürüzsüz çizim sağlayan ve Drift (SQLite) ile Supabase (PostgreSQL) entegre edilmiş offline-first mimariyle yeniden yapılandırılmıştır.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl text-sm font-medium backdrop-blur-sm">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span>iOS & Android</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl text-sm font-medium backdrop-blur-sm">
              <Laptop className="w-4 h-4 text-indigo-400" />
              <span>Windows & macOS (PC)</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl text-sm font-medium backdrop-blur-sm">
              <Database className="w-4 h-4 text-emerald-400" />
              <span>Supabase PostgreSQL + RLS</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl text-sm font-medium backdrop-blur-sm">
              <HardDrive className="w-4 h-4 text-amber-400" />
              <span>Drift SQLite (Offline-First)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex overflow-x-auto gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {[
          { id: 'overview', label: '1. Mimari & Katmanlar', icon: Layers },
          { id: 'schema', label: '2. Supabase SQL & RLS', icon: ShieldCheck },
          { id: 'drift', label: '3. Drift Yerel DB & Senkronizasyon', icon: Database },
          { id: 'ui', label: '4. Responsive UI & Impeller', icon: Cpu },
          { id: 'sync', label: '5. Canlı Offline Simülasyonu', icon: RefreshCw },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSection === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'bg-slate-100 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Section 1: Overview & Clean Architecture */}
      {activeSection === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 flex items-center justify-center text-blue-600 dark:text-blue-400">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Presentation Layer</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Flutter widget&apos;ları ve Riverpod state yönetimi. Impeller grafik motoru ile jank-free, 60+ FPS pürüzsüz animasyonlar ve const constructor optimizasyonları.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                <Code2 className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Domain Layer</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                İş mantığı (Use Cases, Entities, Repositories) UI katmanından tamamen izole edilmiştir. Katı tip güvenliği ve AOT derleme standartlarına tam uyum.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                <Database className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Data Layer (Offline-First)</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Okuma/yazma öncelikle yerel Drift SQLite veritabanına yapılır. Arka planda Supabase PostgreSQL ile otomatik çift yönlü senkronizasyon ve conflict resolution.
              </p>
            </div>
          </div>

          {/* Architecture Stack Details */}
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 space-y-4">
            <h4 className="font-semibold text-slate-900 dark:text-white text-base">Seçilen Teknolojiler ve Gerekçeleri</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Flutter (Dart AOT):</strong>
                  <p className="text-slate-600 dark:text-slate-400">Mobil ve masaüstü işletim sistemlerinde yerel makine koduna derlenerek maksimum bellek ve CPU verimliliği sağlar.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Supabase (PostgreSQL + RLS):</strong>
                  <p className="text-slate-600 dark:text-slate-400">Güçlü SQL altyapısı, GoTrue kimlik doğrulama ve kullanıcı bazlı Satır Düzeyinde Güvenlik (Row-Level Security) politikaları.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Drift ORM (SQLite):</strong>
                  <p className="text-slate-600 dark:text-slate-400">Tür güvenli sorgular, reaktif akışlar (Streams) ve çevrimdışı çalışma sırasında sıfır veri kaybı garantisi.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Riverpod State Management:</strong>
                  <p className="text-slate-600 dark:text-slate-400">Compile-safe, test edilebilir ve global hata yönetimli modern durum yönetim kütüphanesi.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section 2: Supabase SQL & RLS */}
      {activeSection === 'schema' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Supabase PostgreSQL Veritabanı Şeması & RLS</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">Aşağıdaki SQL şeması Supabase konsolunda çalıştırılmak üzere hazırlanmıştır.</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> RLS Aktif
              </span>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-slate-950 text-slate-200 p-4 font-mono text-xs overflow-x-auto border border-slate-800">
              <pre>{`-- 1. UUID & Extensions
create extension if not exists "uuid-ossp";

-- 2. Profiles Table
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  full_name text,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Notebooks Table (11 Types)
create table public.notebooks (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  description text,
  type text not null, -- academic, project, journal, finance, etc.
  color text,
  icon text,
  is_locked boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. Notes Table
create table public.notes (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users on delete cascade not null,
  notebook_id uuid references public.notebooks on delete cascade,
  title text not null,
  body text,
  tag text,
  custom_fields jsonb default '{}'::jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 5. Row Level Security (RLS) Policies
alter table public.notebooks enable row level security;
alter table public.notes enable row level security;

create policy "Kullanıcılar sadece kendi defterlerini görebilir"
  on public.notebooks for all
  using (auth.uid() = user_id);

create policy "Kullanıcılar sadece kendi notlarını görebilir"
  on public.notes for all
  using (auth.uid() = user_id);`}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Section 3: Drift Local DB */}
      {activeSection === 'drift' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Drift SQLite Model Tanımları & Senkronizasyon Servisi</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">Çevrimdışı öncelikli (offline-first) mimari için yerel SQLite tabloları ve Supabase sync kuyruğu.</p>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-slate-950 text-slate-200 p-4 font-mono text-xs overflow-x-auto border border-slate-800">
              <pre>{`import 'package:drift/drift.dart';

class LocalNotebooks extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get title => text()();
  TextColumn get description => text().nullable()();
  TextColumn get type => text()();
  TextColumn get color => text().nullable()();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class SyncQueue extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get tableName => text()();
  TextColumn get recordId => text()();
  TextColumn get operation => text(); // INSERT, UPDATE, DELETE
  TextColumn get payload => text()(); // JSON
  DateTimeColumn get createdAt => dateTime()();
}`}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Section 4: UI & Impeller */}
      {activeSection === 'ui' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 flex items-center justify-center text-blue-600">
                <Laptop className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">PC Masaüstü (Multi-Pane Layout)</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Windows ve macOS ekranlarında sol kenar çubuğu, orta liste paneli ve sağ detay düzenleyici olmak üzere 3 bölmeli esnek ve responsive masaüstü yerleşimi.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600">
                <Smartphone className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Mobil (Tabbed & Adaptive)</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                iOS ve Android cihazlarda alt sekme çubuğu, tek sütunlu akışlar ve dokunmatik optimize edilmiş 44px+ hedef alanları.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Section 5: Live Offline Simulation & Sync Status */}
      {activeSection === 'sync' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Canlı Çevrimdışı ve Bulut Senkronizasyon Konsolu</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">İnternet kesintisini simüle edin ve Drift kuyruk yönetimini test edin.</p>
              </div>

              <div className="flex items-center gap-3">
                {isOfflineMode ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400 text-xs font-bold border border-rose-200 dark:border-rose-900">
                    <WifiOff className="w-3.5 h-3.5 animate-pulse" /> Çevrimdışı (Offline)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs font-bold border border-emerald-200 dark:border-emerald-900">
                    <Wifi className="w-3.5 h-3.5" /> Bağlı (Online)
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="text-xs text-slate-500 font-medium">Drift Bekleyen Kuyruk</span>
                <div className="text-2xl font-bold text-slate-900 dark:text-white">{syncQueueCount} Kayıt</div>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="text-xs text-slate-500 font-medium">Son Başarılı Senkron</span>
                <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{lastSyncTime}</div>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="text-xs text-slate-500 font-medium">Senkronizasyon Durumu</span>
                <div className="text-lg font-bold text-blue-600 dark:text-blue-400 capitalize">
                  {syncStatus === 'syncing' ? 'Senkronize Ediliyor...' : syncStatus === 'success' ? 'Senkronizasyon Tamamlandı' : 'Hazır'}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
              {isOfflineMode ? (
                <button
                  onClick={restoreOnline}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-sm shadow-md transition-colors"
                >
                  <Wifi className="w-4 h-4" /> İnterneti Bağla ve Senkronize Et
                </button>
              ) : (
                <button
                  onClick={simulateOfflineMutation}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-medium text-sm shadow-md transition-colors"
                >
                  <WifiOff className="w-4 h-4" /> Bağlantıyı Kes (Çevrimdışı Simülasyonu)
                </button>
              )}

              <button
                onClick={triggerManualSync}
                disabled={syncStatus === 'syncing'}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-md transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${syncStatus === 'syncing' ? 'animate-spin' : ''}`} />
                Supabase Senkronizasyonunu Tetikle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
