import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Mail,
  Inbox,
  Send,
  Star,
  Trash2,
  Archive,
  Reply,
  Forward,
  Plus,
  RefreshCw,
  Search,
  Paperclip,
  Download,
  LogIn,
  LogOut,
  CheckCircle,
  FileText,
  CheckSquare,
  Kanban,
  X,
  ChevronRight,
  ChevronLeft,
  Clock,
  User as UserIcon,
  Tag,
  AlertCircle,
  Folder,
  ChevronDown,
  SlidersHorizontal,
  ExternalLink,
} from 'lucide-react';
import {
  GmailFolder,
  GmailLabel,
  GmailMessageDetail,
  GmailMessageSummary,
  GmailProfile,
  GmailSendPayload,
} from '../../types/gmail';
import { Note, Task, Notebook } from '../../types';
import {
  gmailSignIn,
  gmailSignOut,
  getGmailAccessToken,
  initGmailAuth,
} from '../../lib/gmailAuth';
import {
  listGmailMessages,
  getGmailMessage,
  sendGmailMessage,
  createGmailDraft,
  modifyGmailMessageLabels,
  trashGmailMessage,
  untrashGmailMessage,
  getGmailLabels,
  getGmailProfile,
  getGmailAttachment,
} from '../../lib/gmailService';
import { KanbanService } from '../../lib/kanban/kanbanService';
import { newId } from '../../data/sync/ids';

interface GmailHubProps {
  notebooks: Notebook[];
  notes: Note[];
  tasks: Task[];
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onSaveTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  isDark: boolean;
  showToast?: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const GmailHub: React.FC<GmailHubProps> = ({
  notebooks,
  notes,
  tasks,
  onSaveNote,
  onSaveTask,
  isDark,
  showToast = (msg) => console.log(msg),
}) => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [userProfile, setUserProfile] = useState<GmailProfile | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Folder and labels state
  const [currentFolder, setCurrentFolder] = useState<GmailFolder>('INBOX');
  const [showMobileFolders, setShowMobileFolders] = useState<boolean>(false);
  const [labels, setLabels] = useState<GmailLabel[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeQuery, setActiveQuery] = useState<string>('');
  const [quickFilter, setQuickFilter] = useState<'all' | 'unread' | 'starred'>('all');

  // Messages state
  const [messages, setMessages] = useState<GmailMessageSummary[]>([]);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>(undefined);
  const [isLoadingMessages, setIsLoadingMessages] = useState<boolean>(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());

  // Message detail state
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [activeMessageDetail, setActiveMessageDetail] = useState<GmailMessageDetail | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'html' | 'text'>('html');

  // Composer state
  const [isComposerOpen, setIsComposerOpen] = useState<boolean>(false);
  const [composerTo, setComposerTo] = useState<string>('');
  const [composerCc, setComposerCc] = useState<string>('');
  const [composerBcc, setComposerBcc] = useState<string>('');
  const [composerSubject, setComposerSubject] = useState<string>('');
  const [composerBody, setComposerBody] = useState<string>('');
  const [showCc, setShowCc] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [replyParent, setReplyParent] = useState<{ id: string; threadId: string } | null>(null);

  // NoteFlow Convert Modals
  const [saveNoteModalOpen, setSaveNoteModalOpen] = useState<boolean>(false);
  const [noteTitle, setNoteTitle] = useState<string>('');
  const [selectedNotebookId, setSelectedNotebookId] = useState<string>('');
  const [saveTaskModalOpen, setSaveTaskModalOpen] = useState<boolean>(false);
  const [taskTitle, setTaskTitle] = useState<string>('');
  const [taskDueDate, setTaskDueDate] = useState<string>('');
  const [taskPriority, setTaskPriority] = useState<'düşük' | 'orta' | 'yüksek' | 'kritik'>('orta');
  const [notePickerOpen, setNotePickerOpen] = useState<boolean>(false);

  // Initialize Auth
  useEffect(() => {
    const unsub = initGmailAuth(
      (user, token) => {
        setAuthToken(token);
        setIsAuthenticated(true);
        setAuthLoading(false);
        loadProfileAndLabels(token);
      },
      () => {
        const cached = getGmailAccessToken();
        if (cached) {
          setAuthToken(cached);
          setIsAuthenticated(true);
          setAuthLoading(false);
          loadProfileAndLabels(cached);
        } else {
          setIsAuthenticated(false);
          setAuthLoading(false);
        }
      }
    );
    return () => unsub();
  }, []);

  const loadProfileAndLabels = async (token: string) => {
    try {
      const [profileData, labelsData] = await Promise.all([
        getGmailProfile(token).catch(() => null),
        getGmailLabels(token).catch(() => []),
      ]);
      if (profileData) setUserProfile(profileData);
      setLabels(labelsData);
    } catch (err) {
      console.error('Error loading initial profile or labels', err);
    }
  };

  const handleSignIn = async () => {
    try {
      setAuthLoading(true);
      const res = await gmailSignIn();
      if (res && res.accessToken) {
        setAuthToken(res.accessToken);
        setIsAuthenticated(true);
        showToast('Gmail ile bağlantı başarıyla kuruldu!', 'success');
        await loadProfileAndLabels(res.accessToken);
        fetchMessages(res.accessToken, currentFolder, activeQuery, true);
      }
    } catch (error: any) {
      console.error('Sign in failed:', error);
      showToast(error.message || 'Gmail girişi yapılamadı.', 'error');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    await gmailSignOut();
    setIsAuthenticated(false);
    setAuthToken(null);
    setUserProfile(null);
    setMessages([]);
    setActiveMessageDetail(null);
    setActiveMessageId(null);
    showToast('Gmail oturumu kapatıldı.', 'info');
  };

  // Fetch Messages for current Folder / Query
  const fetchMessages = useCallback(
    async (token: string, folder: GmailFolder, query: string, reset = false) => {
      try {
        setIsLoadingMessages(true);
        if (reset) {
          setMessages([]);
          setNextPageToken(undefined);
          setSelectedMessageIds(new Set());
        }

        const labelIds: string[] = [];
        let combinedQuery = query.trim();

        if (folder === 'INBOX') labelIds.push('INBOX');
        else if (folder === 'STARRED') labelIds.push('STARRED');
        else if (folder === 'IMPORTANT') labelIds.push('IMPORTANT');
        else if (folder === 'SENT') labelIds.push('SENT');
        else if (folder === 'DRAFT') labelIds.push('DRAFT');
        else if (folder === 'TRASH') labelIds.push('TRASH');
        else if (folder === 'SPAM') labelIds.push('SPAM');
        else if (folder) {
          // Custom label
          labelIds.push(folder);
        }

        if (quickFilter === 'unread') {
          combinedQuery = combinedQuery ? `${combinedQuery} is:unread` : 'is:unread';
        } else if (quickFilter === 'starred') {
          combinedQuery = combinedQuery ? `${combinedQuery} is:starred` : 'is:starred';
        }

        const res = await listGmailMessages(token, {
          labelIds: labelIds.length > 0 ? labelIds : undefined,
          query: combinedQuery || undefined,
          pageToken: reset ? undefined : nextPageToken,
          maxResults: 20,
        });

        if (reset) {
          setMessages(res.messages);
        } else {
          setMessages((prev) => [...prev, ...res.messages]);
        }
        setNextPageToken(res.nextPageToken);
      } catch (err: any) {
        console.error('Error fetching messages:', err);
        showToast(err.message || 'E-postalar yüklenirken hata oluştu', 'error');
      } finally {
        setIsLoadingMessages(false);
      }
    },
    [nextPageToken, quickFilter, showToast]
  );

  // Trigger fetch when folder, filter or activeQuery changes
  useEffect(() => {
    if (authToken && isAuthenticated) {
      fetchMessages(authToken, currentFolder, activeQuery, true);
    }
  }, [authToken, isAuthenticated, currentFolder, activeQuery, quickFilter]);

  // Load message detail
  const handleSelectMessage = async (msgId: string) => {
    if (!authToken) return;
    setActiveMessageId(msgId);
    setIsLoadingDetail(true);
    try {
      const detail = await getGmailMessage(authToken, msgId);
      setActiveMessageDetail(detail);

      // Auto mark as read in local state
      if (detail.isUnread) {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === msgId
              ? { ...m, isUnread: false, labelIds: m.labelIds.filter((l) => l !== 'UNREAD') }
              : m
          )
        );
        // Sync mark as read to Gmail
        modifyGmailMessageLabels(authToken, msgId, [], ['UNREAD']).catch(console.warn);
      }
    } catch (err: any) {
      console.error('Error getting message detail:', err);
      showToast('E-posta detayı yüklenemedi.', 'error');
    } finally {
      setIsLoadingDetail(false);
    }
  };

  // Toggle star
  const handleToggleStar = async (msgId: string, currentStarred: boolean, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!authToken) return;

    // Optimistic update
    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, isStarred: !currentStarred } : m))
    );
    if (activeMessageDetail && activeMessageDetail.id === msgId) {
      setActiveMessageDetail({ ...activeMessageDetail, isStarred: !currentStarred });
    }

    try {
      if (currentStarred) {
        await modifyGmailMessageLabels(authToken, msgId, [], ['STARRED']);
      } else {
        await modifyGmailMessageLabels(authToken, msgId, ['STARRED'], []);
      }
    } catch (err) {
      console.error('Failed to toggle star', err);
      showToast('Yıldız durumu güncellenemedi', 'error');
    }
  };

  // Mark Read / Unread
  const handleToggleRead = async (msgId: string, isUnread: boolean) => {
    if (!authToken) return;
    const newUnreadState = !isUnread;

    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, isUnread: newUnreadState } : m))
    );
    if (activeMessageDetail && activeMessageDetail.id === msgId) {
      setActiveMessageDetail({ ...activeMessageDetail, isUnread: newUnreadState });
    }

    try {
      if (newUnreadState) {
        await modifyGmailMessageLabels(authToken, msgId, ['UNREAD'], []);
        showToast('Okunmadı olarak işaretlendi', 'info');
      } else {
        await modifyGmailMessageLabels(authToken, msgId, [], ['UNREAD']);
        showToast('Okundu olarak işaretlendi', 'info');
      }
    } catch (err) {
      console.error('Failed to change read status', err);
    }
  };

  // Move to Trash
  const handleTrashMessage = async (msgId: string) => {
    if (!authToken) return;
    try {
      await trashGmailMessage(authToken, msgId);
      setMessages((prev) => prev.filter((m) => m.id !== msgId));
      if (activeMessageId === msgId) {
        setActiveMessageId(null);
        setActiveMessageDetail(null);
      }
      showToast('E-posta çöp kutusuna taşındı', 'info');
    } catch (err: any) {
      showToast(err.message || 'Silinemedi', 'error');
    }
  };

  // Archive (remove INBOX label)
  const handleArchiveMessage = async (msgId: string) => {
    if (!authToken) return;
    try {
      await modifyGmailMessageLabels(authToken, msgId, [], ['INBOX']);
      setMessages((prev) => prev.filter((m) => m.id !== msgId));
      if (activeMessageId === msgId) {
        setActiveMessageId(null);
        setActiveMessageDetail(null);
      }
      showToast('E-posta arşivlendi', 'success');
    } catch (err: any) {
      showToast(err.message || 'Arşivlenemedi', 'error');
    }
  };

  // Bulk actions
  const toggleSelectAll = () => {
    if (selectedMessageIds.size === messages.length) {
      setSelectedMessageIds(new Set());
    } else {
      setSelectedMessageIds(new Set(messages.map((m) => m.id)));
    }
  };

  const toggleSelectMessage = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = new Set(selectedMessageIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedMessageIds(next);
  };

  const handleBulkTrash = async () => {
    if (!authToken || selectedMessageIds.size === 0) return;
    const ids = Array.from(selectedMessageIds);
    try {
      await Promise.all(ids.map((id) => trashGmailMessage(authToken, id)));
      setMessages((prev) => prev.filter((m) => !selectedMessageIds.has(m.id)));
      if (activeMessageId && selectedMessageIds.has(activeMessageId)) {
        setActiveMessageId(null);
        setActiveMessageDetail(null);
      }
      setSelectedMessageIds(new Set());
      showToast(`${ids.length} e-posta çöp kutusuna taşındı`, 'info');
    } catch (err) {
      showToast('Toplu silme sırasında hata oluştu', 'error');
    }
  };

  const handleBulkMarkRead = async () => {
    if (!authToken || selectedMessageIds.size === 0) return;
    const ids = Array.from(selectedMessageIds);
    try {
      await Promise.all(
        ids.map((id) => modifyGmailMessageLabels(authToken, id, [], ['UNREAD']))
      );
      setMessages((prev) =>
        prev.map((m) => (selectedMessageIds.has(m.id) ? { ...m, isUnread: false } : m))
      );
      setSelectedMessageIds(new Set());
      showToast(`${ids.length} e-posta okundu yapıldı`, 'success');
    } catch (err) {
      showToast('İşlem başarısız', 'error');
    }
  };

  // Download Attachment
  const handleDownloadAttachment = async (
    attachmentId: string,
    filename: string,
    mimeType: string
  ) => {
    if (!authToken || !activeMessageDetail) return;
    try {
      showToast(`${filename} indiriliyor...`, 'info');
      const dataObj = await getGmailAttachment(authToken, activeMessageDetail.id, attachmentId);
      if (!dataObj?.data) throw new Error('Ek verisi bulunamadı');

      // Convert base64url to blob
      let base64 = dataObj.data.replace(/-/g, '+').replace(/_/g, '/');
      while (base64.length % 4) base64 += '=';
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const blobUrl = URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);

      showToast(`${filename} başarıyla indirildi!`, 'success');
    } catch (err: any) {
      console.error('Attachment download failed:', err);
      showToast('Ek indirilemedi: ' + err.message, 'error');
    }
  };

  // Reply / Forward / Compose Handlers
  const handleOpenCompose = (initialData?: {
    to?: string;
    subject?: string;
    body?: string;
    replyParent?: { id: string; threadId: string };
  }) => {
    setComposerTo(initialData?.to || '');
    setComposerCc('');
    setComposerBcc('');
    setComposerSubject(initialData?.subject || '');
    setComposerBody(initialData?.body || '');
    setReplyParent(initialData?.replyParent || null);
    setShowCc(false);
    setIsComposerOpen(true);
  };

  const handleReply = () => {
    if (!activeMessageDetail) return;
    const reSubject = activeMessageDetail.subject.toLowerCase().startsWith('re:')
      ? activeMessageDetail.subject
      : `Re: ${activeMessageDetail.subject}`;
    const quoted = `\n\n--- ${activeMessageDetail.from} kişisinden ${activeMessageDetail.date} tarihinde yazılan ileti ---\n${activeMessageDetail.bodyText}`;
    handleOpenCompose({
      to: activeMessageDetail.fromEmail || activeMessageDetail.from,
      subject: reSubject,
      body: quoted,
      replyParent: { id: activeMessageDetail.id, threadId: activeMessageDetail.threadId },
    });
  };

  const handleForward = () => {
    if (!activeMessageDetail) return;
    const fwdSubject = activeMessageDetail.subject.toLowerCase().startsWith('fwd:')
      ? activeMessageDetail.subject
      : `Fwd: ${activeMessageDetail.subject}`;
    const quoted = `\n\n---------- İletilen İleti ----------\nKimden: ${activeMessageDetail.from}\nTarih: ${activeMessageDetail.date}\nKonu: ${activeMessageDetail.subject}\nKime: ${activeMessageDetail.to}\n\n${activeMessageDetail.bodyText}`;
    handleOpenCompose({
      to: '',
      subject: fwdSubject,
      body: quoted,
    });
  };

  const handleSendEmail = async () => {
    if (!authToken) return;
    if (!composerTo.trim()) {
      showToast('Lütfen alıcı (Kime) adresini girin', 'error');
      return;
    }

    try {
      setIsSending(true);
      const payload: GmailSendPayload = {
        to: composerTo.trim(),
        cc: composerCc.trim() || undefined,
        bcc: composerBcc.trim() || undefined,
        subject: composerSubject.trim() || '(Konusuz)',
        bodyText: composerBody,
        bodyHtml: composerBody.replace(/\n/g, '<br />'),
        inReplyTo: replyParent?.id,
        threadId: replyParent?.threadId,
      };

      await sendGmailMessage(authToken, payload);
      showToast('E-posta başarıyla gönderildi!', 'success');
      setIsComposerOpen(false);
      // Refresh current mailbox
      fetchMessages(authToken, currentFolder, activeQuery, true);
    } catch (err: any) {
      console.error('Failed to send email:', err);
      showToast(err.message || 'E-posta gönderilemedi', 'error');
    } finally {
      setIsSending(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!authToken) return;
    try {
      setIsSending(true);
      await createGmailDraft(authToken, {
        to: composerTo.trim(),
        cc: composerCc.trim() || undefined,
        subject: composerSubject.trim() || '(Taslak)',
        bodyText: composerBody,
      });
      showToast('Taslak kaydedildi!', 'info');
      setIsComposerOpen(false);
    } catch (err: any) {
      showToast('Taslak kaydedilemedi: ' + err.message, 'error');
    } finally {
      setIsSending(false);
    }
  };

  // Convert to NoteFlow Note
  const handleOpenSaveNote = () => {
    if (!activeMessageDetail) return;
    setNoteTitle(activeMessageDetail.subject || 'Gmail E-postası');
    setSelectedNotebookId(notebooks[0]?.id || '');
    setSaveNoteModalOpen(true);
  };

  const handleConfirmSaveNote = () => {
    if (!activeMessageDetail) return;
    const bodyContent = `## ✉️ ${activeMessageDetail.subject}\n\n**Kimden:** ${activeMessageDetail.from}\n**Tarih:** ${activeMessageDetail.date}\n**Kime:** ${activeMessageDetail.to}\n\n---\n\n${activeMessageDetail.bodyText || activeMessageDetail.snippet}`;

    onSaveNote({
      id: newId(),
      title: noteTitle.trim() || activeMessageDetail.subject,
      notebookId: selectedNotebookId || null,
      body: bodyContent,
      tag: 'gmail',
    });

    setSaveNoteModalOpen(false);
    showToast('E-posta başarıyla not olarak kaydedildi!', 'success');
  };

  // Convert to NoteFlow Task
  const handleOpenSaveTask = () => {
    if (!activeMessageDetail) return;
    setTaskTitle(activeMessageDetail.subject || 'E-postaya yanıt ver');
    const today = new Date().toISOString().slice(0, 10);
    setTaskDueDate(today);
    setSaveTaskModalOpen(true);
  };

  const handleConfirmSaveTask = () => {
    if (!activeMessageDetail) return;
    onSaveTask({
      id: newId(),
      title: taskTitle.trim(),
      list: 'Gmail Görevleri',
      dueDate: taskDueDate || null,
      dueTime: '12:00',
      done: false,
      color: '#ef4444',
      priority: taskPriority,
    });
    setSaveTaskModalOpen(false);
    showToast('Görev listenize eklendi!', 'success');
  };

  // Convert to Kanban Card
  const handleConvertToKanban = () => {
    if (!activeMessageDetail) return;
    try {
      const boards = KanbanService.getBoards();
      if (boards.length === 0) {
        showToast('Önce bir Kanban panosu oluşturulmalı', 'error');
        return;
      }
      const board = boards[0];
      const lists = KanbanService.getLists(board.id);
      if (lists.length === 0) {
        showToast('Panoda liste bulunamadı', 'error');
        return;
      }
      const firstList = lists[0];
      KanbanService.createCard(
        firstList.id,
        `✉️ ${activeMessageDetail.subject}`,
        `Gönderen: ${activeMessageDetail.from}\nTarih: ${activeMessageDetail.date}\n\n${activeMessageDetail.snippet}`,
        board.id
      );
      showToast(`"${board.title}" panosuna kart olarak eklendi!`, 'success');
    } catch (err: any) {
      console.error('Kanban conversion error:', err);
      showToast('Kanban kartı eklenemedi', 'error');
    }
  };

  // Insert Note into Composer
  const handleInsertNote = (note: Note) => {
    const noteText = `\n\n--- ${note.title} ---\n${note.body}\n`;
    setComposerBody((prev) => prev + noteText);
    setNotePickerOpen(false);
    showToast(`"${note.title}" notu eklendi`, 'info');
  };

  // 1. Loading State
  if (authLoading) {
    return (
      <div className="w-full h-full min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <RefreshCw className="w-8 h-8 text-teal-500 animate-spin" />
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Gmail oturum durumu kontrol ediliyor...
        </p>
      </div>
    );
  }

  // 2. Disconnected / Not Authenticated Screen
  if (!isAuthenticated) {
    return (
      <div className="w-full h-full min-h-[70vh] flex flex-col items-center justify-center p-4">
        <div
          className={`w-full max-w-lg p-8 rounded-3xl border text-center shadow-xl transition-all ${
            isDark
              ? 'bg-slate-900/90 border-slate-800 text-slate-100 shadow-black/40'
              : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-200/50'
          }`}
        >
          {/* Gmail Red Icon */}
          <div className="w-20 h-20 mx-auto rounded-3xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-500 mb-6 shadow-sm">
            <Mail className="w-10 h-10" />
          </div>

          <h2 className="text-2xl font-black tracking-tight mb-2">Gmail Bağlantısı</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
            Google hesabınızla güvenli bir şekilde bağlanarak gelen kutunuzu yönetin, e-postalarınızı
            NoteFlow notlarına, görevlere veya Kanban kartlarına tek dokunuşla dönüştürün.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left mb-6">
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs">
              <span className="font-bold text-teal-500 block mb-1">⚡ Doğrudan Erişim</span>
              <span>Gelen kutusu, yıldızlı iletiler ve özel etiketler.</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs">
              <span className="font-bold text-indigo-500 block mb-1">📝 NotFlow Entegrasyonu</span>
              <span>E-postaları defter notuna veya göreve bağlayın.</span>
            </div>
          </div>

          <button
            onClick={handleSignIn}
            className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm flex items-center justify-center gap-2.5 shadow-md shadow-red-500/20 active:scale-[0.99] transition-all cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            <span>Google ile Gmail'e Bağlan</span>
          </button>

          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-4">
            Erişim belirteçleri yalnızca bu oturum boyunca bellekte tutulur ve güvenli Google API
            çağrıları için kullanılır.
          </p>
        </div>
      </div>
    );
  }

  // Current Folder display name
  const currentFolderLabel =
    currentFolder === 'INBOX'
      ? 'Gelen Kutusu'
      : currentFolder === 'STARRED'
      ? 'Yıldızlı'
      : currentFolder === 'IMPORTANT'
      ? 'Önemli'
      : currentFolder === 'SENT'
      ? 'Gönderilenler'
      : currentFolder === 'DRAFT'
      ? 'Taslaklar'
      : currentFolder === 'TRASH'
      ? 'Çöp Kutusu'
      : labels.find((l) => l.id === currentFolder)?.name || currentFolder;

  // 3. Connected Gmail Client Workspace
  return (
    <div className="w-full h-full flex flex-col overflow-hidden relative">
      {/* Mobile Folders Drawer Modal */}
      {showMobileFolders && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setShowMobileFolders(false)}
          />
          <div
            className={`relative w-4/5 max-w-xs h-full p-4 flex flex-col z-10 shadow-2xl transition-all ${
              isDark ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Folder className="w-4 h-4 text-red-500" />
                <span>Klasörler & Etiketler</span>
              </div>
              <button
                onClick={() => setShowMobileFolders(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1">
                Klasörler
              </div>
              {[
                { id: 'INBOX', label: 'Gelen Kutusu', icon: Inbox },
                { id: 'STARRED', label: 'Yıldızlı', icon: Star },
                { id: 'IMPORTANT', label: 'Önemli', icon: Tag },
                { id: 'SENT', label: 'Gönderilenler', icon: Send },
                { id: 'DRAFT', label: 'Taslaklar', icon: FileText },
                { id: 'TRASH', label: 'Çöp Kutusu', icon: Trash2 },
              ].map((folder) => {
                const Icon = folder.icon;
                const isActive = currentFolder === folder.id;
                return (
                  <button
                    key={folder.id}
                    onClick={() => {
                      setCurrentFolder(folder.id);
                      setActiveMessageId(null);
                      setActiveMessageDetail(null);
                      setShowMobileFolders(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-red-500/15 text-red-600 dark:text-red-400 font-bold'
                        : isDark
                        ? 'text-slate-300 hover:bg-slate-800/60'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{folder.label}</span>
                    </div>
                  </button>
                );
              })}

              {labels.filter((l) => l.type === 'user').length > 0 && (
                <>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mt-4 mb-1">
                    Etiketler
                  </div>
                  {labels
                    .filter((l) => l.type === 'user')
                    .map((lbl) => {
                      const isActive = currentFolder === lbl.id;
                      return (
                        <button
                          key={lbl.id}
                          onClick={() => {
                            setCurrentFolder(lbl.id);
                            setActiveMessageId(null);
                            setActiveMessageDetail(null);
                            setShowMobileFolders(false);
                          }}
                          className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-colors ${
                            isActive
                              ? 'bg-red-500/15 text-red-600 dark:text-red-400 font-bold'
                              : isDark
                              ? 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                          }`}
                        >
                          <Tag className="w-3.5 h-3.5 text-red-500 shrink-0" />
                          <span className="truncate">{lbl.name}</span>
                        </button>
                      );
                    })}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Top Header Bar */}
      <div
        className={`p-2.5 sm:p-3 sm:px-4 border-b flex flex-wrap items-center justify-between gap-2 sm:gap-3 shrink-0 backdrop-blur-md ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'
        }`}
      >
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile Folder Drawer Button */}
          <button
            onClick={() => setShowMobileFolders(true)}
            className="md:hidden p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            title="Klasörler"
          >
            <Folder className="w-4 h-4 text-red-500" />
          </button>

          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-500 shrink-0">
            <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xs sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5 truncate">
              <span className="truncate">{currentFolderLabel}</span>
              <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/20 shrink-0">
                Bağlı
              </span>
            </h1>
            <p className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400 truncate max-w-[150px] sm:max-w-[240px]">
              {userProfile?.emailAddress || 'Google Hesabı'}
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md min-w-[150px] relative order-3 sm:order-2 w-full sm:w-auto">
          <input
            type="text"
            placeholder="E-postalarda ara (örn: fatura, from:google)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') setActiveQuery(searchQuery);
            }}
            className={`w-full pl-9 pr-8 py-1.5 sm:py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all ${
              isDark
                ? 'bg-slate-800/80 border-slate-700 text-slate-100 placeholder-slate-500'
                : 'bg-slate-100 border-slate-200 text-slate-800 placeholder-slate-400'
            }`}
          />
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 sm:top-3 text-slate-400" />
          {searchQuery && (
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveQuery('');
              }}
              className="absolute right-2.5 top-2 sm:top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 order-2 sm:order-3">
          <button
            onClick={() => handleOpenCompose()}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-sm active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden xs:inline sm:inline">Yeni</span>
          </button>

          <button
            onClick={() => {
              if (authToken) fetchMessages(authToken, currentFolder, activeQuery, true);
            }}
            disabled={isLoadingMessages}
            title="Yenile"
            className={`p-1.5 sm:p-2 rounded-xl border text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
              isDark ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isLoadingMessages ? 'animate-spin text-teal-500' : ''}`} />
          </button>

          <button
            onClick={handleSignOut}
            title="Gmail Bağlantısını Kes"
            className={`p-1.5 sm:p-2 rounded-xl border text-rose-500 hover:bg-rose-500/10 transition-colors ${
              isDark ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar + List + Detail View */}
      <div className="flex-1 flex overflow-hidden w-full h-full relative">
        {/* Left Folder / Label Navigation Sidebar (Desktop Only) */}
        <aside
          className={`hidden md:flex md:w-52 lg:w-60 border-r flex-col shrink-0 p-3 overflow-y-auto ${
            isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50/70 border-slate-200'
          }`}
        >
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2">
            Klasörler
          </div>
          <nav className="space-y-1 mb-6">
            {[
              { id: 'INBOX', label: 'Gelen Kutusu', icon: Inbox },
              { id: 'STARRED', label: 'Yıldızlı', icon: Star },
              { id: 'IMPORTANT', label: 'Önemli', icon: Tag },
              { id: 'SENT', label: 'Gönderilenler', icon: Send },
              { id: 'DRAFT', label: 'Taslaklar', icon: FileText },
              { id: 'TRASH', label: 'Çöp Kutusu', icon: Trash2 },
            ].map((folder) => {
              const Icon = folder.icon;
              const isActive = currentFolder === folder.id;
              return (
                <button
                  key={folder.id}
                  onClick={() => {
                    setCurrentFolder(folder.id);
                    setActiveMessageId(null);
                    setActiveMessageDetail(null);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-red-500/15 text-red-600 dark:text-red-400 font-bold'
                      : isDark
                      ? 'text-slate-300 hover:bg-slate-800/60'
                      : 'text-slate-700 hover:bg-slate-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{folder.label}</span>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* User Custom Labels */}
          {labels.filter((l) => l.type === 'user').length > 0 && (
            <>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2">
                Etiketler
              </div>
              <div className="space-y-1 overflow-y-auto">
                {labels
                  .filter((l) => l.type === 'user')
                  .map((lbl) => {
                    const isActive = currentFolder === lbl.id;
                    return (
                      <button
                        key={lbl.id}
                        onClick={() => {
                          setCurrentFolder(lbl.id);
                          setActiveMessageId(null);
                          setActiveMessageDetail(null);
                        }}
                        className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-red-500/15 text-red-600 dark:text-red-400 font-bold'
                            : isDark
                            ? 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                            : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
                        }`}
                      >
                        <Tag className="w-3 h-3 text-red-500 shrink-0" />
                        <span className="truncate">{lbl.name}</span>
                      </button>
                    );
                  })}
              </div>
            </>
          )}
        </aside>

        {/* Center / Left Pane: Email List (Full Width on Mobile when activeMessageId is null) */}
        <section
          className={`flex-col border-r overflow-hidden transition-all duration-200 ${
            activeMessageId ? 'hidden md:flex md:w-5/12 lg:w-4/12 md:max-w-md' : 'flex w-full flex-1'
          } ${isDark ? 'border-slate-800 bg-slate-950/40' : 'border-slate-200 bg-white/50'}`}
        >
          {/* List Controls & Filter Pills */}
          <div
            className={`p-2.5 border-b flex items-center justify-between gap-2 shrink-0 ${
              isDark ? 'border-slate-800 bg-slate-900/40' : 'border-slate-200 bg-slate-100/60'
            }`}
          >
            {/* Select All Checkbox & Bulk Actions & Mobile Folder Selector */}
            <div className="flex items-center gap-2 min-w-0">
              {/* Mobile Folder Selector Chip */}
              <button
                onClick={() => setShowMobileFolders(true)}
                className="md:hidden flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shrink-0"
              >
                <Folder className="w-3 h-3 text-red-500" />
                <span className="truncate max-w-[90px]">{currentFolderLabel}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              <input
                type="checkbox"
                aria-label="Tümünü Seç"
                checked={messages.length > 0 && selectedMessageIds.size === messages.length}
                onChange={toggleSelectAll}
                className="w-4 h-4 rounded text-red-600 focus:ring-red-500 cursor-pointer shrink-0"
              />

              {selectedMessageIds.size > 0 ? (
                <div className="flex items-center gap-1">
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700">
                    {selectedMessageIds.size} seçildi
                  </span>
                  <button
                    onClick={handleBulkMarkRead}
                    title="Okundu yap"
                    className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-xs text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={handleBulkTrash}
                    title="Sil"
                    className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-900/30 text-xs text-rose-500 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
                  {(['all', 'unread', 'starred'] as const).map((filterKey) => (
                    <button
                      key={filterKey}
                      onClick={() => setQuickFilter(filterKey)}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer shrink-0 ${
                        quickFilter === filterKey
                          ? 'bg-red-600 text-white font-bold'
                          : isDark
                          ? 'text-slate-400 hover:bg-slate-800'
                          : 'text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {filterKey === 'all'
                        ? 'Tümü'
                        : filterKey === 'unread'
                        ? 'Okunmamış'
                        : 'Yıldızlı'}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <span className="text-[11px] text-slate-400 shrink-0">
              {messages.length} ileti
            </span>
          </div>

          {/* Messages Scroll List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80 custom-scrollbar">
            {isLoadingMessages && messages.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center gap-2">
                <RefreshCw className="w-5 h-5 animate-spin text-red-500" />
                <span>E-postalar yükleniyor...</span>
              </div>
            ) : messages.length === 0 ? (
              <div className="p-10 text-center text-slate-400 text-xs">
                Bu klasörde e-posta bulunamadı.
              </div>
            ) : (
              messages.map((msg) => {
                const isSelected = selectedMessageIds.has(msg.id);
                const isActive = activeMessageId === msg.id;

                return (
                  <div
                    key={msg.id}
                    onClick={() => handleSelectMessage(msg.id)}
                    className={`p-3 transition-colors cursor-pointer flex items-start gap-2.5 relative group ${
                      isActive
                        ? isDark
                          ? 'bg-red-500/10 border-l-4 border-l-red-500'
                          : 'bg-red-50 border-l-4 border-l-red-500'
                        : msg.isUnread
                        ? isDark
                          ? 'bg-slate-800/40 hover:bg-slate-800/70 font-semibold text-white'
                          : 'bg-slate-50/80 hover:bg-slate-100 font-semibold text-slate-900'
                        : isDark
                        ? 'hover:bg-slate-900 text-slate-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    {/* Checkbox */}
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onClick={(e) => toggleSelectMessage(msg.id, e)}
                      onChange={() => {}}
                      className="mt-1 w-3.5 h-3.5 rounded text-red-600 focus:ring-red-500 cursor-pointer shrink-0"
                    />

                    {/* Star Toggle */}
                    <button
                      onClick={(e) => handleToggleStar(msg.id, msg.isStarred, e)}
                      title={msg.isStarred ? 'Yıldızı Kaldır' : 'Yıldızla'}
                      className="mt-0.5 text-slate-400 hover:text-amber-400 transition-colors shrink-0 cursor-pointer"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          msg.isStarred ? 'fill-amber-400 text-amber-400' : ''
                        }`}
                      />
                    </button>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span
                          className={`text-xs truncate ${
                            msg.isUnread ? 'font-bold text-slate-900 dark:text-white' : 'font-medium'
                          }`}
                        >
                          {msg.fromName || msg.fromEmail}
                        </span>
                        <span className="text-[10px] text-slate-400 shrink-0">
                          {msg.date.split(',')[0]}
                        </span>
                      </div>

                      <h4
                        className={`text-xs truncate ${
                          msg.isUnread ? 'font-bold text-slate-900 dark:text-white' : 'font-normal'
                        }`}
                      >
                        {msg.subject || '(Konusuz)'}
                      </h4>

                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5 font-normal">
                        {msg.snippet}
                      </p>
                    </div>

                    {/* Unread indicator dot */}
                    {msg.isUnread && (
                      <span className="w-2 h-2 rounded-full bg-red-500 shrink-0 mt-1.5" />
                    )}
                  </div>
                );
              })
            )}

            {/* Load More Button */}
            {nextPageToken && (
              <div className="p-3 text-center">
                <button
                  onClick={() => {
                    if (authToken) fetchMessages(authToken, currentFolder, activeQuery, false);
                  }}
                  disabled={isLoadingMessages}
                  className="px-4 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  {isLoadingMessages ? 'Yükleniyor...' : 'Daha Fazla E-posta Yükle'}
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Right Pane: Message Detail View (Full Width on Mobile when activeMessageId is set) */}
        <section
          className={`flex-col overflow-hidden transition-all duration-200 ${
            activeMessageId ? 'flex w-full flex-1' : 'hidden md:flex flex-1 items-center justify-center'
          } ${isDark ? 'bg-slate-900/30' : 'bg-slate-50/40'}`}
        >
          {isLoadingDetail ? (
            <div className="w-full h-full flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-6 h-6 animate-spin text-red-500" />
              <span className="text-xs text-slate-400">E-posta yükleniyor...</span>
            </div>
          ) : activeMessageDetail ? (
            <div className="w-full h-full flex flex-col overflow-hidden">
              {/* Detail Header & Action Toolbar */}
              <div
                className={`p-2.5 sm:p-3 sm:px-5 border-b flex flex-col gap-2 shrink-0 ${
                  isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                {/* Mobile Back Button & Subject */}
                <div className="flex items-center gap-2 min-w-0">
                  <button
                    onClick={() => {
                      setActiveMessageId(null);
                      setActiveMessageDetail(null);
                    }}
                    className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0"
                    title="Geri Dön"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate flex-1">
                    {activeMessageDetail.subject || '(Konusuz)'}
                  </h2>
                </div>

                {/* Actions: Reply, Forward, NoteFlow Convert, Trash */}
                <div className="flex items-center flex-wrap gap-1.5 overflow-x-auto py-0.5 no-scrollbar">
                  <button
                    onClick={handleReply}
                    title="Yanıtla"
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer shrink-0"
                  >
                    <Reply className="w-3.5 h-3.5" />
                    <span>Yanıtla</span>
                  </button>

                  <button
                    onClick={handleForward}
                    title="İlet"
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer shrink-0"
                  >
                    <Forward className="w-3.5 h-3.5" />
                    <span>İlet</span>
                  </button>

                  {/* NoteFlow Conversion Buttons */}
                  <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5 shrink-0" />

                  <button
                    onClick={handleOpenSaveNote}
                    title="Not Olarak Kaydet"
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-teal-500/10 text-teal-600 dark:text-teal-400 hover:bg-teal-500/20 transition-colors cursor-pointer shrink-0"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Not Yap</span>
                  </button>

                  <button
                    onClick={handleOpenSaveTask}
                    title="Görev Olarak Ekle"
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/20 transition-colors cursor-pointer shrink-0"
                  >
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>Görev Yap</span>
                  </button>

                  <button
                    onClick={handleConvertToKanban}
                    title="Kanban Panosuna Ekle"
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20 transition-colors cursor-pointer shrink-0"
                  >
                    <Kanban className="w-3.5 h-3.5" />
                    <span>Panoya Ekle</span>
                  </button>

                  <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5 shrink-0" />

                  <button
                    onClick={() =>
                      handleToggleRead(activeMessageDetail.id, activeMessageDetail.isUnread)
                    }
                    title="Okunmadı olarak işaretle"
                    className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer shrink-0"
                  >
                    <Mail className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleArchiveMessage(activeMessageDetail.id)}
                    title="Arşivle"
                    className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer shrink-0"
                  >
                    <Archive className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleTrashMessage(activeMessageDetail.id)}
                    title="Çöp Kutusuna At"
                    className="p-1.5 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/30 text-rose-500 cursor-pointer shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Message Header (Sender, To, Date, Labels) */}
              <div
                className={`p-4 sm:px-6 border-b shrink-0 ${
                  isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-white/60 border-slate-100'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr from-red-500 to-amber-500 flex items-center justify-center text-white font-bold text-xs sm:text-sm shadow-sm shrink-0">
                      {(activeMessageDetail.fromName || activeMessageDetail.fromEmail || 'U')[0].toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-1.5 truncate">
                        <span className="truncate">{activeMessageDetail.fromName || activeMessageDetail.fromEmail}</span>
                        {activeMessageDetail.fromName && (
                          <span className="text-[10px] sm:text-[11px] font-normal text-slate-400 truncate hidden xs:inline">
                            &lt;{activeMessageDetail.fromEmail}&gt;
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        Kime: {activeMessageDetail.to}
                        {activeMessageDetail.cc && <span> | Bilgi: {activeMessageDetail.cc}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] sm:text-xs text-slate-400 block">
                      {activeMessageDetail.date.split(',')[0]}
                    </span>
                    <button
                      onClick={() =>
                        setViewMode((prev) => (prev === 'html' ? 'text' : 'html'))
                      }
                      className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold hover:underline mt-0.5 block ml-auto"
                    >
                      {viewMode === 'html' ? 'Düz Metin' : 'HTML'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Message Body Content */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar bg-white dark:bg-slate-950">
                {viewMode === 'html' && activeMessageDetail.bodyHtml ? (
                  <div
                    className="gmail-rendered-html prose dark:prose-invert max-w-none text-xs sm:text-sm text-slate-800 dark:text-slate-200"
                    dangerouslySetInnerHTML={{ __html: activeMessageDetail.bodyHtml }}
                  />
                ) : (
                  <pre className="whitespace-pre-wrap font-sans text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                    {activeMessageDetail.bodyText || activeMessageDetail.snippet}
                  </pre>
                )}

                {/* Attachments Section */}
                {activeMessageDetail.attachments && activeMessageDetail.attachments.length > 0 && (
                  <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Paperclip className="w-3.5 h-3.5 text-slate-400" />
                      <span>Ekler ({activeMessageDetail.attachments.length})</span>
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {activeMessageDetail.attachments.map((att) => (
                        <div
                          key={att.attachmentId}
                          className={`p-3 rounded-xl border flex items-center justify-between gap-2 text-xs ${
                            isDark
                              ? 'bg-slate-900 border-slate-800 text-slate-200'
                              : 'bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <Paperclip className="w-4 h-4 text-red-500 shrink-0" />
                            <div className="min-w-0">
                              <p className="font-semibold truncate">{att.filename}</p>
                              <span className="text-[10px] text-slate-400">
                                {Math.round(att.size / 1024)} KB
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() =>
                              handleDownloadAttachment(
                                att.attachmentId,
                                att.filename,
                                att.mimeType
                              )
                            }
                            title="İndir"
                            className="p-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 shrink-0 transition-colors cursor-pointer"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center p-8 text-slate-400">
              <Mail className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm font-medium">Görüntülemek için soldan bir e-posta seçin</p>
            </div>
          )}
        </section>
      </div>

      {/* Floating or Modal Email Composer */}
      {isComposerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-2xl rounded-3xl border shadow-2xl flex flex-col overflow-hidden max-h-[90vh] transition-all ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            {/* Composer Header */}
            <div className="p-4 border-b flex items-center justify-between gap-2 shrink-0 bg-red-600 text-white">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Mail className="w-4 h-4" />
                <span>{replyParent ? 'E-postayı Yanıtla' : 'Yeni E-posta'}</span>
              </div>
              <button
                onClick={() => setIsComposerOpen(false)}
                className="w-7 h-7 rounded-full flex items-center justify-center hover:bg-white/20 text-white font-bold"
              >
                ✕
              </button>
            </div>

            {/* Composer Form */}
            <div className="p-4 space-y-3 overflow-y-auto flex-1">
              {/* To field */}
              <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                <label className="text-xs font-bold text-slate-400 w-12">Kime:</label>
                <input
                  type="email"
                  placeholder="alici@example.com"
                  value={composerTo}
                  onChange={(e) => setComposerTo(e.target.value)}
                  className="flex-1 bg-transparent text-xs focus:outline-none"
                />
                {!showCc && (
                  <button
                    onClick={() => setShowCc(true)}
                    className="text-[11px] text-teal-600 dark:text-teal-400 font-semibold"
                  >
                    CC / BCC
                  </button>
                )}
              </div>

              {/* CC / BCC fields */}
              {showCc && (
                <div className="space-y-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-bold text-slate-400 w-12">CC:</label>
                    <input
                      type="text"
                      placeholder="bilgi@example.com"
                      value={composerCc}
                      onChange={(e) => setComposerCc(e.target.value)}
                      className="flex-1 bg-transparent text-xs focus:outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-bold text-slate-400 w-12">BCC:</label>
                    <input
                      type="text"
                      placeholder="gizli@example.com"
                      value={composerBcc}
                      onChange={(e) => setComposerBcc(e.target.value)}
                      className="flex-1 bg-transparent text-xs focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Subject field */}
              <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                <label className="text-xs font-bold text-slate-400 w-12">Konu:</label>
                <input
                  type="text"
                  placeholder="E-posta konusu"
                  value={composerSubject}
                  onChange={(e) => setComposerSubject(e.target.value)}
                  className="flex-1 bg-transparent text-xs font-semibold focus:outline-none"
                />
              </div>

              {/* Quick NoteFlow Attachment Action */}
              <div className="flex items-center justify-between py-1">
                <button
                  type="button"
                  onClick={() => setNotePickerOpen(true)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-teal-500/10 text-teal-600 dark:text-teal-400 hover:bg-teal-500/20 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>NotFlow Notu Ekle</span>
                </button>
              </div>

              {/* Email Body */}
              <textarea
                rows={10}
                placeholder="Mesajınızı buraya yazın..."
                value={composerBody}
                onChange={(e) => setComposerBody(e.target.value)}
                className={`w-full p-3 rounded-2xl text-xs leading-relaxed border focus:outline-none focus:ring-2 focus:ring-red-500/40 resize-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}
              />
            </div>

            {/* Composer Footer Actions */}
            <div
              className={`p-4 border-t flex items-center justify-between gap-2 shrink-0 ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-100/70 border-slate-200'
              }`}
            >
              <button
                onClick={() => setIsComposerOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              >
                Vazgeç
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSaveDraft}
                  disabled={isSending}
                  className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                >
                  Taslak Kaydet
                </button>

                <button
                  onClick={handleSendEmail}
                  disabled={isSending}
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-500/20 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSending ? 'Gönderiliyor...' : 'Gönder'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Save Email As Note Modal */}
      {saveNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-md p-6 rounded-3xl border shadow-2xl space-y-4 ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-2.5 font-bold text-base text-teal-500">
              <FileText className="w-5 h-5" />
              <span>E-postayı Not Olarak Kaydet</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-400">Not Başlığı</label>
                <input
                  type="text"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-400">Hedef Defter</label>
                <select
                  value={selectedNotebookId}
                  onChange={(e) => setSelectedNotebookId(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <option value="">Deftersiz (Genel Notlar)</option>
                  {notebooks.map((nb) => (
                    <option key={nb.id} value={nb.id}>
                      {nb.title || nb.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSaveNoteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                onClick={handleConfirmSaveNote}
                className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs"
              >
                Notu Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Save Email As Task Modal */}
      {saveTaskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-md p-6 rounded-3xl border shadow-2xl space-y-4 ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-2.5 font-bold text-base text-indigo-500">
              <CheckSquare className="w-5 h-5" />
              <span>E-postayı Görev Olarak Ekle</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-400">Görev Başlığı</label>
                <input
                  type="text"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1 text-slate-400">Bitiş Tarihi</label>
                  <input
                    type="date"
                    value={taskDueDate}
                    onChange={(e) => setTaskDueDate(e.target.value)}
                    className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                      isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                    }`}
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-400">Öncelik</label>
                  <select
                    value={taskPriority}
                    onChange={(e: any) => setTaskPriority(e.target.value)}
                    className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                      isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <option value="düşük">Düşük</option>
                    <option value="orta">Orta</option>
                    <option value="yüksek">Yüksek</option>
                    <option value="kritik">Kritik</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSaveTaskModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                onClick={handleConfirmSaveTask}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
              >
                Görevi Ekle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Note Picker Modal for Email Composer */}
      {notePickerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-lg p-6 rounded-3xl border shadow-2xl space-y-4 max-h-[80vh] flex flex-col ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-teal-500" />
                <span>Eklenecek Notu Seçin</span>
              </h3>
              <button
                onClick={() => setNotePickerOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {notes.length === 0 ? (
                <p className="text-xs text-slate-400 p-4 text-center">Henüz kayıtlı not yok.</p>
              ) : (
                notes.map((n) => (
                  <button
                    key={n.id}
                    onClick={() => handleInsertNote(n)}
                    className={`w-full p-3 rounded-2xl border text-left transition-all ${
                      isDark
                        ? 'bg-slate-800/80 border-slate-700 hover:border-teal-500'
                        : 'bg-slate-50 border-slate-200 hover:border-teal-500'
                    }`}
                  >
                    <div className="font-bold text-xs">{n.title || 'Başlıksız Not'}</div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{n.body}</p>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
