import { useCallback, useEffect, useRef, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { App } from './App';
import { supabase, SHARED_DEFAULT_USER_ID, SHARED_DEFAULT_EMAIL } from './lib/supabase';
import { SyncEngine, clearSyncState } from './data/sync/SyncEngine';
import {
  attachSyncEngine,
  clearLocalData,
  getDataOwner,
  hasLocalData,
  localStore,
  setDataOwner,
  setSeedDefaults,
} from './data/storage';

/** Çevrimdışıyken uygulama ilk senkronu sonsuza kadar beklemesin. */
const INITIAL_SYNC_TIMEOUT_MS = 6_000;
const SIGN_OUT_FLUSH_TIMEOUT_MS = 3_000;

type GateState =
  | { kind: 'loading' }
  | { kind: 'account'; userId: string; email: string | null; engine: SyncEngine };

const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/**
 * Girişte e-posta ve şifre istemeden doğrudan NoteFlow'u ve Supabase-Flutter senkronizasyonunu başlatır.
 */
export function AuthGate() {
  const [state, setState] = useState<GateState>({ kind: 'loading' });
  const engineRef = useRef<SyncEngine | null>(null);
  const activeUserRef = useRef<string | null>(null);

  useEffect(() => {
    const dark =
      localStorage.getItem('noteflow_theme') === 'dark' || window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.classList.toggle('dark', dark);
  }, []);

  const stopEngine = useCallback(async () => {
    const engine = engineRef.current;
    engineRef.current = null;
    attachSyncEngine(null);
    if (engine) await engine.stop();
  }, []);

  const activate = useCallback(
    async (session: Session | null) => {
      // Gerçek bir kullanıcı oturumu varsa onu, yoksa paylaşımlı doğrudan Flutter/Supabase UUID'sini kullan
      const userId = session?.user.id || SHARED_DEFAULT_USER_ID;
      const userEmail = session?.user.email || SHARED_DEFAULT_EMAIL;

      if (userId === activeUserRef.current && engineRef.current) return;

      activeUserRef.current = userId;
      await stopEngine();

      const owner = getDataOwner();
      if (owner && owner !== 'local' && owner !== userId) {
        clearLocalData();
        clearSyncState(owner);
      }
      const claimLocalData = owner !== userId && hasLocalData();
      setDataOwner(userId);
      setSeedDefaults(false);

      const engine = new SyncEngine({ client: supabase, userId, store: localStore });
      engineRef.current = engine;
      attachSyncEngine(engine);
      if (claimLocalData) {
        try {
          await engine.claimLocalData();
        } catch {}
      }

      // Senkron motorunu başlat ve zaman aşımı koruması ile devam et
      try {
        await Promise.race([engine.start(), wait(INITIAL_SYNC_TIMEOUT_MS)]);
      } catch {}

      setState({ kind: 'account', userId, email: userEmail, engine });
    },
    [stopEngine],
  );

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      void activate(session);
    }).catch(() => {
      void activate(null);
    });

    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      setTimeout(() => void activate(session), 0);
    });

    return () => {
      data.subscription.unsubscribe();
      activeUserRef.current = null;
      void stopEngine();
    };
  }, [activate, stopEngine]);

  const handleSignOut = useCallback(async () => {
    const engine = engineRef.current;
    if (engine) {
      await Promise.race([engine.syncNow(), wait(SIGN_OUT_FLUSH_TIMEOUT_MS)]);
    }
    const userId = activeUserRef.current;
    activeUserRef.current = null;
    await stopEngine();
    clearLocalData();
    if (userId) clearSyncState(userId);
    setSeedDefaults(true);
    await supabase.auth.signOut({ scope: 'local' });
    // Çıkış yapılsa dahi hemen yeniden temiz paylaşımlı mod ile başlar
    void activate(null);
  }, [activate, stopEngine]);

  if (state.kind === 'loading') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 bg-slate-50 dark:bg-slate-950 text-slate-500">
        <div className="w-10 h-10 rounded-2xl bg-teal-500 flex items-center justify-center text-white font-bold animate-pulse">
          ✦
        </div>
        <span className="text-xs">NoteFlow ve Supabase bağlanıyor…</span>
      </div>
    );
  }

  return (
    <App
      key={state.userId}
      account={{ userId: state.userId, email: state.email }}
      engine={state.engine}
      onSignOut={() => void handleSignOut()}
    />
  );
}

