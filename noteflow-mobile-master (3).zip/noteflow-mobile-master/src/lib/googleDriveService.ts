export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  size?: string;
  webViewLink?: string;
  iconLink?: string;
  parents?: string[];
}

export interface DriveAbout {
  user?: {
    displayName?: string;
    emailAddress?: string;
    photoLink?: string;
  };
  storageQuota?: {
    limit?: string;
    usage?: string;
    usageInDrive?: string;
    usageInDriveTrash?: string;
  };
}

const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';
const DRIVE_UPLOAD_BASE = 'https://www.googleapis.com/upload/drive/v3';

export const GoogleDriveService = {
  // Get Drive User Info and Storage Quota
  async getAbout(accessToken: string): Promise<DriveAbout> {
    const res = await fetch(
      `${DRIVE_API_BASE}/about?fields=user(displayName,emailAddress,photoLink),storageQuota(limit,usage,usageInDrive,usageInDriveTrash)`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Google Drive hesap bilgisi alınamadı.');
    }

    return await res.json();
  },

  // List files or search in Google Drive
  async listFiles(accessToken: string, query?: string): Promise<DriveFile[]> {
    let url = `${DRIVE_API_BASE}/files?pageSize=40&fields=files(id,name,mimeType,modifiedTime,size,webViewLink,iconLink,parents)&orderBy=modifiedTime desc`;
    if (query) {
      url += `&q=${encodeURIComponent(query)}`;
    }

    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Google Drive dosyaları listelenemedi.');
    }

    const data = await res.json();
    return data.files || [];
  },

  // Read file text content
  async getFileContent(accessToken: string, fileId: string): Promise<string> {
    const res = await fetch(`${DRIVE_API_BASE}/files/${fileId}?alt=media`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!res.ok) {
      throw new Error('Dosya içeriği okunamadı.');
    }

    return await res.text();
  },

  // Create a dedicated folder in Drive (e.g. NoteFlow)
  async createFolder(accessToken: string, folderName: string, parentFolderId?: string): Promise<DriveFile> {
    const metadata: Record<string, any> = {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
    };
    if (parentFolderId) {
      metadata.parents = [parentFolderId];
    }

    const res = await fetch(`${DRIVE_API_BASE}/files?fields=id,name,mimeType,webViewLink`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: JSON.stringify(metadata),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Google Drive klasörü oluşturulamadı.');
    }

    return await res.json();
  },

  // Upload or export NoteFlow data as a file into Google Drive
  async uploadFile(
    accessToken: string,
    filename: string,
    content: string,
    mimeType = 'application/json',
    folderId?: string
  ): Promise<DriveFile> {
    const metadata: Record<string, any> = {
      name: filename,
      mimeType,
      description: 'NoteFlow Yedekleme ve Senkronizasyon Dosyası',
    };

    if (folderId) {
      metadata.parents = [folderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelim = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      `Content-Type: ${mimeType}\r\n\r\n` +
      content +
      closeDelim;

    const res = await fetch(
      `${DRIVE_UPLOAD_BASE}/files?uploadType=multipart&fields=id,name,mimeType,modifiedTime,webViewLink,size`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: multipartRequestBody,
      }
    );

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Google Drive dosyası yüklenemedi.');
    }

    return await res.json();
  },

  // Delete file with user confirmation
  async deleteFile(accessToken: string, fileId: string): Promise<void> {
    const res = await fetch(`${DRIVE_API_BASE}/files/${fileId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!res.ok && res.status !== 204) {
      throw new Error('Dosya silinemedi.');
    }
  },
};
