import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// Configured Gmail Scopes
export const GMAIL_SCOPES = [
  'https://mail.google.com/',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/gmail.labels',
];

const provider = new GoogleAuthProvider();
GMAIL_SCOPES.forEach((scope) => provider.addScope(scope));
// Force prompt to ensure consent and refresh of newly requested scopes
provider.setCustomParameters({
  prompt: 'consent',
  access_type: 'offline',
});

// In-memory token cache (strictly never in localStorage)
let cachedGmailToken: string | null = null;
let isSigningIn = false;

export const initGmailAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedGmailToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedGmailToken);
      } else if (!isSigningIn) {
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedGmailToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const gmailSignIn = async (): Promise<{
  user: User;
  accessToken: string;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Gmail erişim belirteci (Access Token) alınamadı.');
    }

    cachedGmailToken = credential.accessToken;
    return { user: result.user, accessToken: cachedGmailToken };
  } catch (error: any) {
    console.error('Gmail Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getGmailAccessToken = (): string | null => {
  return cachedGmailToken;
};

export const setGmailAccessToken = (token: string | null) => {
  cachedGmailToken = token;
};

export const gmailSignOut = async () => {
  try {
    cachedGmailToken = null;
    await auth.signOut();
  } catch (error) {
    console.error('Gmail sign out error:', error);
  }
};
