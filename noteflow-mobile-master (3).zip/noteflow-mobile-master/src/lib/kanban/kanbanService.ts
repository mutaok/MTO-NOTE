import {
  KanbanBoard,
  KanbanList,
  KanbanCard,
  KanbanActivityLog,
  KanbanLabel,
} from '../../types/kanban';
import { StorageService } from '../../data/storage';
import { newId } from '../../data/sync/ids';
import {
  calculateAppendPosition,
  normalizePositions,
  MIN_GAP,
  INITIAL_SPACING,
} from './ranking';
import { supabase, SHARED_DEFAULT_USER_ID } from '../supabase';

export interface KanbanSnapshot {
  boards: KanbanBoard[];
  lists: KanbanList[];
  cards: KanbanCard[];
  activities: KanbanActivityLog[];
}

class KanbanServiceImpl {
  // Snapshot for atomic rollback if an optimistic UI operation fails
  createSnapshot(): KanbanSnapshot {
    return {
      boards: StorageService.getKanbanBoards(),
      lists: StorageService.getKanbanLists(),
      cards: StorageService.getKanbanCards(),
      activities: StorageService.getKanbanActivities(),
    };
  }

  restoreSnapshot(snapshot: KanbanSnapshot): void {
    StorageService.saveKanbanBoards(snapshot.boards);
    StorageService.saveKanbanLists(snapshot.lists);
    StorageService.saveKanbanCards(snapshot.cards);
    StorageService.saveKanbanActivities(snapshot.activities);
  }

  // --------------------------------------------------------------------------
  // Board CRUD
  // --------------------------------------------------------------------------
  getBoards(includeArchived = false): KanbanBoard[] {
    const all = StorageService.getKanbanBoards();
    return includeArchived ? all : all.filter((b) => !b.archived);
  }

  createBoard(title: string, description?: string, color = '#0d9488'): KanbanBoard {
    const boards = StorageService.getKanbanBoards();
    const newBoard: KanbanBoard = {
      id: newId(),
      title: title.trim(),
      description: description?.trim() || '',
      color,
      owner_id: SHARED_DEFAULT_USER_ID,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      archived: false,
    };

    const updated = [newBoard, ...boards];
    StorageService.saveKanbanBoards(updated);

    // Otomatik varsayılan sütunlar ekle
    this.createList(newBoard.id, '📋 Yapılacaklar');
    this.createList(newBoard.id, '⚡ Devam Eden');
    this.createList(newBoard.id, '🎉 Tamamlandı');

    this.logActivity(newBoard.id, 'create_list', `"${title}" panosu oluşturuldu`);
    return newBoard;
  }

  updateBoard(id: string, updates: Partial<KanbanBoard>): KanbanBoard {
    const boards = StorageService.getKanbanBoards();
    const index = boards.findIndex((b) => b.id === id);
    if (index === -1) throw new Error(`Pano bulunamadı: ${id}`);

    const updated: KanbanBoard = {
      ...boards[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    boards[index] = updated;
    StorageService.saveKanbanBoards([...boards]);
    return updated;
  }

  deleteBoard(id: string): void {
    const boards = StorageService.getKanbanBoards().filter((b) => b.id !== id);
    StorageService.saveKanbanBoards(boards);

    // İlgili liste ve kartları da temizle
    const lists = StorageService.getKanbanLists().filter((l) => l.board_id !== id);
    StorageService.saveKanbanLists(lists);
  }

  archiveBoard(id: string, archived = true): KanbanBoard {
    return this.updateBoard(id, { archived });
  }

  // --------------------------------------------------------------------------
  // List CRUD & Move
  // --------------------------------------------------------------------------
  getLists(boardId: string, includeArchived = false): KanbanList[] {
    const all = StorageService.getKanbanLists().filter((l) => l.board_id === boardId);
    const filtered = includeArchived ? all : all.filter((l) => !l.archived);
    return filtered.sort((a, b) => a.position - b.position);
  }

  createList(boardId: string, title: string): KanbanList {
    const allLists = StorageService.getKanbanLists();
    const boardLists = allLists
      .filter((l) => l.board_id === boardId)
      .sort((a, b) => a.position - b.position);

    const lastPos = boardLists.length > 0 ? boardLists[boardLists.length - 1].position : undefined;
    const position = calculateAppendPosition(lastPos);

    const newList: KanbanList = {
      id: newId(),
      board_id: boardId,
      title: title.trim(),
      position,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      archived: false,
    };

    StorageService.saveKanbanLists([...allLists, newList]);
    this.logActivity(boardId, 'create_list', `"${title}" sütunu eklendi`);
    return newList;
  }

  updateList(id: string, updates: Partial<KanbanList>): KanbanList {
    const lists = StorageService.getKanbanLists();
    const index = lists.findIndex((l) => l.id === id);
    if (index === -1) throw new Error(`Liste bulunamadı: ${id}`);

    const updated: KanbanList = {
      ...lists[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    lists[index] = updated;
    StorageService.saveKanbanLists([...lists]);
    return updated;
  }

  deleteList(id: string): void {
    const lists = StorageService.getKanbanLists().filter((l) => l.id !== id);
    StorageService.saveKanbanLists(lists);

    // Kartları da temizle
    const cards = StorageService.getKanbanCards().filter((c) => c.list_id !== id);
    StorageService.saveKanbanCards(cards);
  }

  archiveList(id: string, archived = true): KanbanList {
    return this.updateList(id, { archived });
  }

  moveList(listId: string, newPosition: number): KanbanList {
    const lists = StorageService.getKanbanLists();
    const target = lists.find((l) => l.id === listId);
    if (!target) throw new Error(`Liste bulunamadı: ${listId}`);

    target.position = newPosition;
    target.updated_at = new Date().toISOString();

    // Normalizasyon kontrolü: Board'daki diğer listelerle aralık çok küçüldüyse
    const boardLists = lists
      .filter((l) => l.board_id === target.board_id)
      .sort((a, b) => a.position - b.position);

    let needsNormalization = false;
    for (let i = 1; i < boardLists.length; i++) {
      if (boardLists[i].position - boardLists[i - 1].position < MIN_GAP) {
        needsNormalization = true;
        break;
      }
    }

    if (needsNormalization) {
      const normalized = normalizePositions(boardLists);
      const normalizedMap = new Map(normalized.map((l) => [l.id, l.position]));
      lists.forEach((l) => {
        if (normalizedMap.has(l.id)) {
          l.position = normalizedMap.get(l.id)!;
        }
      });
    }

    StorageService.saveKanbanLists([...lists]);
    return target;
  }

  // --------------------------------------------------------------------------
  // Card CRUD & Move
  // --------------------------------------------------------------------------
  getCards(boardId?: string, includeArchived = false): KanbanCard[] {
    let allCards = StorageService.getKanbanCards();
    if (boardId) {
      const boardLists = new Set(
        StorageService.getKanbanLists()
          .filter((l) => l.board_id === boardId)
          .map((l) => l.id)
      );
      allCards = allCards.filter((c) => boardLists.has(c.list_id));
    }
    const filtered = includeArchived ? allCards : allCards.filter((c) => !c.archived);
    return filtered.sort((a, b) => a.position - b.position);
  }

  createCard(
    listId: string,
    title: string,
    description?: string,
    boardId?: string
  ): KanbanCard {
    const allCards = StorageService.getKanbanCards();
    const listCards = allCards
      .filter((c) => c.list_id === listId)
      .sort((a, b) => a.position - b.position);

    const lastPos = listCards.length > 0 ? listCards[listCards.length - 1].position : undefined;
    const position = calculateAppendPosition(lastPos);

    const newCard: KanbanCard = {
      id: newId(),
      list_id: listId,
      title: title.trim(),
      description: description?.trim() || '',
      position,
      labels: [],
      checklist: [],
      comments: [],
      attachments: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      archived: false,
    };

    StorageService.saveKanbanCards([...allCards, newCard]);

    if (boardId) {
      this.logActivity(boardId, 'create_card', `"${title}" kartı eklendi`, newCard.id, title);
    }

    return newCard;
  }

  updateCard(id: string, updates: Partial<KanbanCard>, boardId?: string): KanbanCard {
    const cards = StorageService.getKanbanCards();
    const index = cards.findIndex((c) => c.id === id);
    if (index === -1) throw new Error(`Kart bulunamadı: ${id}`);

    const updated: KanbanCard = {
      ...cards[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    cards[index] = updated;
    StorageService.saveKanbanCards([...cards]);

    if (boardId && updates.title) {
      this.logActivity(boardId, 'edit_card', `"${updated.title}" kartı güncellendi`, id, updated.title);
    }

    return updated;
  }

  deleteCard(id: string, boardId?: string): void {
    const cards = StorageService.getKanbanCards();
    const card = cards.find((c) => c.id === id);
    const updated = cards.filter((c) => c.id !== id);
    StorageService.saveKanbanCards(updated);

    if (boardId && card) {
      this.logActivity(boardId, 'archive_card', `"${card.title}" kartı silindi`, id, card.title);
    }
  }

  archiveCard(id: string, archived = true, boardId?: string): KanbanCard {
    const updated = this.updateCard(id, { archived }, boardId);
    if (boardId) {
      this.logActivity(
        boardId,
        'archive_card',
        `"${updated.title}" kartı ${archived ? 'arşivlendi' : 'arşivden çıkarıldı'}`,
        id,
        updated.title
      );
    }
    return updated;
  }

  /**
   * Atomic moveCard function satisfying:
   * - Updates ONLY (list_id, position) of the target card.
   * - If gap between adjacent cards < 0.00001, normalizes positions in that destination list.
   * - Never corrupts data.
   */
  moveCard(
    cardId: string,
    targetListId: string,
    newPosition: number,
    boardId?: string,
    targetListName?: string
  ): { updatedCard: KanbanCard; normalizedList?: KanbanCard[] } {
    const cards = StorageService.getKanbanCards();
    const cardIndex = cards.findIndex((c) => c.id === cardId);
    if (cardIndex === -1) throw new Error(`Kart bulunamadı: ${cardId}`);

    const oldListId = cards[cardIndex].list_id;

    // SADECE taşınan kartın list_id ve position alanları güncellenir
    const updatedCard: KanbanCard = {
      ...cards[cardIndex],
      list_id: targetListId,
      position: newPosition,
      updated_at: new Date().toISOString(),
    };
    cards[cardIndex] = updatedCard;

    // Hedef listedeki kartları kontrol et: boşluk çok daraldıysa (< 0.00001) normalize et
    const destCards = cards
      .filter((c) => c.list_id === targetListId && !c.archived)
      .sort((a, b) => a.position - b.position);

    let needsNormalization = false;
    for (let i = 1; i < destCards.length; i++) {
      if (destCards[i].position - destCards[i - 1].position < MIN_GAP) {
        needsNormalization = true;
        break;
      }
    }

    let normalizedCards: KanbanCard[] | undefined;
    if (needsNormalization) {
      const normalized = normalizePositions(destCards);
      const normalizedMap = new Map(normalized.map((c) => [c.id, c.position]));
      cards.forEach((c) => {
        if (normalizedMap.has(c.id)) {
          c.position = normalizedMap.get(c.id)!;
        }
      });
      normalizedCards = normalized;
    }

    StorageService.saveKanbanCards([...cards]);

    if (boardId) {
      const detail =
        oldListId === targetListId
          ? `"${updatedCard.title}" kartının sırası değiştirildi`
          : `"${updatedCard.title}" kartı "${targetListName || 'yeni sütuna'}" taşındı`;
      this.logActivity(boardId, 'move_card', detail, cardId, updatedCard.title);
    }

    return { updatedCard, normalizedList: normalizedCards };
  }

  // --------------------------------------------------------------------------
  // Activity Logging
  // --------------------------------------------------------------------------
  getActivities(boardId: string): KanbanActivityLog[] {
    return StorageService.getKanbanActivities()
      .filter((a) => a.board_id === boardId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  logActivity(
    boardId: string,
    action: KanbanActivityLog['action'],
    details: string,
    cardId?: string,
    cardTitle?: string
  ): KanbanActivityLog {
    const activities = StorageService.getKanbanActivities();
    const newLog: KanbanActivityLog = {
      id: newId(),
      board_id: boardId,
      card_id: cardId,
      card_title: cardTitle,
      action,
      details,
      user_name: 'Kullanıcı',
      created_at: new Date().toISOString(),
    };

    // Sadece son 200 kaydı tut
    const updated = [newLog, ...activities.slice(0, 199)];
    StorageService.saveKanbanActivities(updated);
    return newLog;
  }
}

export const KanbanService = new KanbanServiceImpl();
