/**
 * Trello-Style Fractional Positioning & Normalization Algorithm
 *
 * Requirements:
 * - Each List and Card has a float `position` field.
 * - When appending to the end: position = lastPosition + 65536 (or 65536 if empty)
 * - When prepending to the beginning: position = firstPosition / 2 (or 65536 if empty)
 * - When inserting between two items: position = (prevPosition + nextPosition) / 2
 * - When gap shrinks too much (diff < 0.00001), normalize all items in that list (65536, 131072, ...)
 * - When moving a card, ONLY that card's (list_id, position) changes; other cards remain untouched unless normalized.
 */

export const INITIAL_SPACING = 65536;
export const MIN_GAP = 0.00001;

export interface PositionCalculationResult {
  position: number;
  needsNormalization: boolean;
}

/**
 * Calculates position when adding an item to the end of a list.
 */
export function calculateAppendPosition(lastPosition?: number): number {
  if (lastPosition === undefined || lastPosition === null || isNaN(lastPosition) || lastPosition <= 0) {
    return INITIAL_SPACING;
  }
  return lastPosition + INITIAL_SPACING;
}

/**
 * Calculates position when adding or moving an item to the top/beginning of a list.
 */
export function calculatePrependPosition(firstPosition?: number): PositionCalculationResult {
  if (firstPosition === undefined || firstPosition === null || isNaN(firstPosition) || firstPosition <= 0) {
    return { position: INITIAL_SPACING, needsNormalization: false };
  }
  const position = firstPosition / 2;
  const needsNormalization = position < MIN_GAP;
  return { position, needsNormalization };
}

/**
 * Calculates position when placing an item strictly between two items.
 */
export function calculateBetweenPosition(prevPos: number, nextPos: number): PositionCalculationResult {
  if (prevPos >= nextPos) {
    // If indices are corrupted or inverted, trigger normalization
    return {
      position: (prevPos + nextPos) / 2,
      needsNormalization: true,
    };
  }

  const gap = nextPos - prevPos;
  const position = (prevPos + nextPos) / 2;
  const needsNormalization = gap < MIN_GAP;

  return { position, needsNormalization };
}

/**
 * Calculates the new position for an item moving to targetIndex inside an existing sorted array of items (excluding itself).
 *
 * @param sortedSiblings Existing items in the destination list, sorted by position ascending
 * @param targetIndex The 0-based index where the item should be placed
 */
export function calculateInsertPosition<T extends { position: number }>(
  sortedSiblings: T[],
  targetIndex: number
): PositionCalculationResult {
  const count = sortedSiblings.length;

  if (count === 0) {
    return { position: INITIAL_SPACING, needsNormalization: false };
  }

  // Prepend to top
  if (targetIndex <= 0) {
    return calculatePrependPosition(sortedSiblings[0].position);
  }

  // Append to end
  if (targetIndex >= count) {
    return {
      position: calculateAppendPosition(sortedSiblings[count - 1].position),
      needsNormalization: false,
    };
  }

  // Insert between targetIndex - 1 and targetIndex
  const prevPos = sortedSiblings[targetIndex - 1].position;
  const nextPos = sortedSiblings[targetIndex].position;
  return calculateBetweenPosition(prevPos, nextPos);
}

/**
 * Re-indexes all items in a list with healthy intervals (65536, 131072, 196608, ...).
 * Preserves the relative order of items.
 */
export function normalizePositions<T extends { position: number }>(items: T[]): T[] {
  // Sort by existing position first to guarantee stable ordering
  const sorted = [...items].sort((a, b) => a.position - b.position);
  return sorted.map((item, index) => ({
    ...item,
    position: (index + 1) * INITIAL_SPACING,
  }));
}
