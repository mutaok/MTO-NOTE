import {
  GmailHeader,
  GmailMessageDetail,
  GmailMessageSummary,
  GmailAttachmentInfo,
  GmailLabel,
  GmailProfile,
  GmailSendPayload,
} from '../types/gmail';

const BASE_URL = 'https://gmail.googleapis.com/gmail/v1/users/me';

/**
 * Base64URL decoder with robust UTF-8 support
 */
export function decodeBase64Url(str: string): string {
  if (!str) return '';
  try {
    let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder('utf-8').decode(bytes);
  } catch (e) {
    try {
      return atob(str.replace(/-/g, '+').replace(/_/g, '/'));
    } catch {
      return '';
    }
  }
}

/**
 * Base64URL encoder with robust UTF-8 support
 */
export function encodeBase64Url(str: string): string {
  const utf8Bytes = new TextEncoder().encode(str);
  let binary = '';
  const len = utf8Bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(utf8Bytes[i]);
  }
  const base64 = btoa(binary);
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * Encodes a header (like Subject) to RFC 2047 MIME encoded-word if it contains non-ASCII characters
 */
function encodeMimeHeader(text: string): string {
  // If text contains only printable ASCII (excluding special control chars), return as is
  if (/^[\x20-\x7E]*$/.test(text)) {
    return text;
  }
  const utf8Bytes = new TextEncoder().encode(text);
  let binary = '';
  for (let i = 0; i < utf8Bytes.length; i++) {
    binary += String.fromCharCode(utf8Bytes[i]);
  }
  const base64 = btoa(binary);
  return `=?UTF-8?B?${base64}?=`;
}

/**
 * Extracts sender display name and clean email from "Name <email@domain.com>"
 */
function parseFromHeader(fromStr: string): { name: string; email: string } {
  if (!fromStr) return { name: 'Bilinmeyen Gönderen', email: '' };
  const match = fromStr.match(/^(.*?)\s*<(.+?)>$/);
  if (match) {
    let name = match[1].trim();
    if ((name.startsWith('"') && name.endsWith('"')) || (name.startsWith("'") && name.endsWith("'"))) {
      name = name.slice(1, -1);
    }
    return { name: name || match[2].trim(), email: match[2].trim() };
  }
  return { name: fromStr.split('@')[0], email: fromStr };
}

/**
 * Parses raw Gmail API message into a structured GmailMessageDetail
 */
export function parseRawMessage(raw: any): GmailMessageDetail {
  const headersList: GmailHeader[] = raw.payload?.headers || [];
  const headersMap: Record<string, string> = {};
  for (const h of headersList) {
    headersMap[h.name.toLowerCase()] = h.value;
  }

  const subject = headersMap['subject'] || '(Konusuz E-posta)';
  const fromRaw = headersMap['from'] || '';
  const { name: fromName, email: fromEmail } = parseFromHeader(fromRaw);
  const to = headersMap['to'] || '';
  const cc = headersMap['cc'];
  const bcc = headersMap['bcc'];
  const dateStr = headersMap['date'] || new Date(parseInt(raw.internalDate || '0', 10)).toLocaleString('tr-TR');

  const labelIds: string[] = raw.labelIds || [];
  const isUnread = labelIds.includes('UNREAD');
  const isStarred = labelIds.includes('STARRED');

  let bodyHtml = '';
  let bodyText = '';
  const attachments: GmailAttachmentInfo[] = [];

  function extractParts(part: any) {
    if (!part) return;

    if (part.filename && part.body?.attachmentId) {
      attachments.push({
        attachmentId: part.body.attachmentId,
        filename: part.filename,
        mimeType: part.mimeType || 'application/octet-stream',
        size: part.body.size || 0,
      });
    }

    if (part.mimeType === 'text/html' && part.body?.data && !bodyHtml) {
      bodyHtml = decodeBase64Url(part.body.data);
    } else if (part.mimeType === 'text/plain' && part.body?.data && !bodyText) {
      bodyText = decodeBase64Url(part.body.data);
    }

    if (part.parts && Array.isArray(part.parts)) {
      for (const subPart of part.parts) {
        extractParts(subPart);
      }
    }
  }

  if (raw.payload) {
    extractParts(raw.payload);
    // If the top-level payload had direct body data
    if (!bodyHtml && !bodyText && raw.payload.body?.data) {
      const decoded = decodeBase64Url(raw.payload.body.data);
      if (raw.payload.mimeType === 'text/html') {
        bodyHtml = decoded;
      } else {
        bodyText = decoded;
      }
    }
  }

  // Fallback if only one format exists
  if (!bodyHtml && bodyText) {
    bodyHtml = bodyText
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br />');
  }

  return {
    id: raw.id,
    threadId: raw.threadId,
    snippet: raw.snippet || '',
    internalDate: raw.internalDate || '',
    from: fromRaw,
    fromName,
    fromEmail,
    to,
    cc,
    bcc,
    subject,
    date: dateStr,
    isUnread,
    isStarred,
    labelIds,
    hasAttachments: attachments.length > 0,
    bodyHtml,
    bodyText,
    attachments,
    rawHeaders: headersList,
  };
}

/**
 * Fetch Gmail user profile
 */
export async function getGmailProfile(token: string): Promise<GmailProfile> {
  const res = await fetch(`${BASE_URL}/profile`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Profil alınamadı (${res.status})`);
  }
  return res.json();
}

/**
 * Fetch list of labels
 */
export async function getGmailLabels(token: string): Promise<GmailLabel[]> {
  const res = await fetch(`${BASE_URL}/labels`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Etiketler alınamadı (${res.status})`);
  }
  const data = await res.json();
  return data.labels || [];
}

/**
 * List messages with query, label filtering, and pagination
 */
export async function listGmailMessages(
  token: string,
  options: {
    query?: string;
    labelIds?: string[];
    maxResults?: number;
    pageToken?: string;
  } = {}
): Promise<{
  messages: GmailMessageSummary[];
  nextPageToken?: string;
  resultSizeEstimate?: number;
}> {
  const params = new URLSearchParams();
  if (options.maxResults) params.set('maxResults', options.maxResults.toString());
  else params.set('maxResults', '25');

  if (options.pageToken) params.set('pageToken', options.pageToken);
  if (options.query) params.set('q', options.query);
  if (options.labelIds && options.labelIds.length > 0) {
    options.labelIds.forEach((lbl) => params.append('labelIds', lbl));
  }

  const res = await fetch(`${BASE_URL}/messages?${params.toString()}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Mesajlar listelenemedi (${res.status})`);
  }

  const data = await res.json();
  const rawList: Array<{ id: string; threadId: string }> = data.messages || [];

  if (rawList.length === 0) {
    return {
      messages: [],
      nextPageToken: data.nextPageToken,
      resultSizeEstimate: data.resultSizeEstimate,
    };
  }

  // Fetch metadata details for the listed messages concurrently
  const detailedMessages = await Promise.all(
    rawList.map(async (item) => {
      try {
        const msgRes = await fetch(
          `${BASE_URL}/messages/${item.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Date`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!msgRes.ok) return null;
        const msgData = await msgRes.json();
        const headers: Array<{ name: string; value: string }> = msgData.payload?.headers || [];
        const hMap: Record<string, string> = {};
        for (const h of headers) {
          hMap[h.name.toLowerCase()] = h.value;
        }

        const fromRaw = hMap['from'] || '';
        const { name: fromName, email: fromEmail } = parseFromHeader(fromRaw);
        const labelIds = msgData.labelIds || [];

        const summary: GmailMessageSummary = {
          id: msgData.id,
          threadId: msgData.threadId,
          snippet: msgData.snippet || '',
          internalDate: msgData.internalDate || '',
          from: fromRaw,
          fromName,
          fromEmail,
          to: hMap['to'] || '',
          subject: hMap['subject'] || '(Konusuz)',
          date: hMap['date'] || '',
          isUnread: labelIds.includes('UNREAD'),
          isStarred: labelIds.includes('STARRED'),
          labelIds,
          hasAttachments: false, // will be confirmed in full view
        };
        return summary;
      } catch (err) {
        console.warn('Mesaj özeti çekilemedi:', item.id, err);
        return null;
      }
    })
  );

  return {
    messages: detailedMessages.filter((m): m is GmailMessageSummary => m !== null),
    nextPageToken: data.nextPageToken,
    resultSizeEstimate: data.resultSizeEstimate,
  };
}

/**
 * Fetch full message details including HTML/plain-text body and attachments
 */
export async function getGmailMessage(token: string, messageId: string): Promise<GmailMessageDetail> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}?format=full`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `E-posta detayı alınamadı (${res.status})`);
  }

  const rawData = await res.json();
  return parseRawMessage(rawData);
}

/**
 * Send an email via RFC 2822 MIME format encoded in Base64URL
 */
export async function sendGmailMessage(token: string, payload: GmailSendPayload): Promise<any> {
  const lines: string[] = [];

  // Required headers
  lines.push(`To: ${payload.to}`);
  if (payload.cc) lines.push(`Cc: ${payload.cc}`);
  if (payload.bcc) lines.push(`Bcc: ${payload.bcc}`);
  lines.push(`Subject: ${encodeMimeHeader(payload.subject)}`);
  lines.push('MIME-Version: 1.0');

  if (payload.inReplyTo) {
    lines.push(`In-Reply-To: ${payload.inReplyTo}`);
    lines.push(`References: ${payload.references || payload.inReplyTo}`);
  }

  lines.push('Content-Type: text/html; charset=UTF-8');
  lines.push('Content-Transfer-Encoding: base64');
  lines.push(''); // blank line separating headers and body

  // Encode HTML body in base64
  const htmlContent = payload.bodyHtml || payload.bodyText?.replace(/\n/g, '<br />') || '';
  const utf8Bytes = new TextEncoder().encode(htmlContent);
  let binary = '';
  for (let i = 0; i < utf8Bytes.length; i++) {
    binary += String.fromCharCode(utf8Bytes[i]);
  }
  lines.push(btoa(binary));

  const rawMime = lines.join('\r\n');
  const encodedMessage = encodeBase64Url(rawMime);

  const bodyData: any = { raw: encodedMessage };
  if (payload.threadId) {
    bodyData.threadId = payload.threadId;
  }

  const res = await fetch(`${BASE_URL}/messages/send`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(bodyData),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `E-posta gönderilemedi (${res.status})`);
  }

  return res.json();
}

/**
 * Create a draft email
 */
export async function createGmailDraft(token: string, payload: GmailSendPayload): Promise<any> {
  const lines: string[] = [];
  if (payload.to) lines.push(`To: ${payload.to}`);
  if (payload.cc) lines.push(`Cc: ${payload.cc}`);
  lines.push(`Subject: ${encodeMimeHeader(payload.subject || '(Taslak)')}`);
  lines.push('MIME-Version: 1.0');
  lines.push('Content-Type: text/html; charset=UTF-8');
  lines.push('Content-Transfer-Encoding: base64');
  lines.push('');

  const htmlContent = payload.bodyHtml || payload.bodyText?.replace(/\n/g, '<br />') || '';
  const utf8Bytes = new TextEncoder().encode(htmlContent);
  let binary = '';
  for (let i = 0; i < utf8Bytes.length; i++) {
    binary += String.fromCharCode(utf8Bytes[i]);
  }
  lines.push(btoa(binary));

  const rawMime = lines.join('\r\n');
  const encodedMessage = encodeBase64Url(rawMime);

  const res = await fetch(`${BASE_URL}/drafts`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message: { raw: encodedMessage },
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Taslak kaydedilemedi (${res.status})`);
  }

  return res.json();
}

/**
 * Modify message labels (e.g. Star, Mark Read/Unread, Archive)
 */
export async function modifyGmailMessageLabels(
  token: string,
  messageId: string,
  addLabelIds: string[] = [],
  removeLabelIds: string[] = []
): Promise<any> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}/modify`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ addLabelIds, removeLabelIds }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Etiket değiştirilemedi (${res.status})`);
  }

  return res.json();
}

/**
 * Move message to Trash
 */
export async function trashGmailMessage(token: string, messageId: string): Promise<any> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}/trash`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Çöp kutusuna taşınamadı (${res.status})`);
  }

  return res.json();
}

/**
 * Untrash message
 */
export async function untrashGmailMessage(token: string, messageId: string): Promise<any> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}/untrash`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Geri yüklenemedi (${res.status})`);
  }

  return res.json();
}

/**
 * Delete message permanently
 */
export async function deleteGmailMessagePermanently(token: string, messageId: string): Promise<any> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Kalıcı olarak silinemedi (${res.status})`);
  }

  return true;
}

/**
 * Download attachment data
 */
export async function getGmailAttachment(
  token: string,
  messageId: string,
  attachmentId: string
): Promise<{ data: string; size: number }> {
  const res = await fetch(`${BASE_URL}/messages/${messageId}/attachments/${attachmentId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Ek indirilemedi (${res.status})`);
  }

  return res.json();
}
