import { KeepNote, KeepColor } from '../types/keep';
import { Note } from '../types';

const STORAGE_KEY = 'noteflow_keep_notes_v1';

export const KEEP_COLORS: Record<
  KeepColor,
  {
    name: string;
    lightBg: string;
    darkBg: string;
    borderLight: string;
    borderDark: string;
    dotColor: string;
  }
> = {
  default: {
    name: 'Varsayılan',
    lightBg: 'bg-white',
    darkBg: 'bg-slate-900',
    borderLight: 'border-slate-200',
    borderDark: 'border-slate-800',
    dotColor: '#94a3b8',
  },
  coral: {
    name: 'Mercan',
    lightBg: 'bg-red-50',
    darkBg: 'bg-red-950/40',
    borderLight: 'border-red-200',
    borderDark: 'border-red-900/60',
    dotColor: '#f87171',
  },
  peach: {
    name: 'Şeftali',
    lightBg: 'bg-amber-50',
    darkBg: 'bg-amber-950/40',
    borderLight: 'border-amber-200',
    borderDark: 'border-amber-900/60',
    dotColor: '#fbbf24',
  },
  sand: {
    name: 'Kum Sarısı',
    lightBg: 'bg-yellow-50',
    darkBg: 'bg-yellow-950/40',
    borderLight: 'border-yellow-200',
    borderDark: 'border-yellow-900/60',
    dotColor: '#facc15',
  },
  mint: {
    name: 'Nane Yeşili',
    lightBg: 'bg-teal-50',
    darkBg: 'bg-teal-950/40',
    borderLight: 'border-teal-200',
    borderDark: 'border-teal-900/60',
    dotColor: '#2dd4bf',
  },
  sage: {
    name: 'Adaçayı',
    lightBg: 'bg-emerald-50',
    darkBg: 'bg-emerald-950/40',
    borderLight: 'border-emerald-200',
    borderDark: 'border-emerald-900/60',
    dotColor: '#34d399',
  },
  fog: {
    name: 'Sis Mavisi',
    lightBg: 'bg-sky-50',
    darkBg: 'bg-sky-950/40',
    borderLight: 'border-sky-200',
    borderDark: 'border-sky-900/60',
    dotColor: '#38bdf8',
  },
  storm: {
    name: 'Fırtına',
    lightBg: 'bg-blue-50',
    darkBg: 'bg-blue-950/40',
    borderLight: 'border-blue-200',
    borderDark: 'border-blue-900/60',
    dotColor: '#60a5fa',
  },
  dusk: {
    name: 'Alacakaranlık',
    lightBg: 'bg-purple-50',
    darkBg: 'bg-purple-950/40',
    borderLight: 'border-purple-200',
    borderDark: 'border-purple-900/60',
    dotColor: '#c084fc',
  },
  blossom: {
    name: 'Pembe Çiçek',
    lightBg: 'bg-pink-50',
    darkBg: 'bg-pink-950/40',
    borderLight: 'border-pink-200',
    borderDark: 'border-pink-900/60',
    dotColor: '#f472b6',
  },
  clay: {
    name: 'Kil / Toprak',
    lightBg: 'bg-stone-100',
    darkBg: 'bg-stone-900/60',
    borderLight: 'border-stone-300',
    borderDark: 'border-stone-800',
    dotColor: '#a8a29e',
  },
  chalk: {
    name: 'Tebeşir Gri',
    lightBg: 'bg-slate-100',
    darkBg: 'bg-slate-800/60',
    borderLight: 'border-slate-300',
    borderDark: 'border-slate-700',
    dotColor: '#94a3b8',
  },
};

const INITIAL_KEEP_NOTES: KeepNote[] = [
  {
    id: 'keep-1',
    title: '💡 Google Keep & NoteFlow Entegrasyonu',
    content:
      'Google Keep tarzı renkli kartlar, kontrol listeleri ve hızlı notlar. Google API politikaları gereğince Keep REST API yalnızca Google Workspace kurumsal alan adı yöneticileri için aktiftir. NoteFlow üzerinden notlarınızı Keep ile senkronize edebilir, Takeout ile içe/dışa aktarabilirsiniz.',
    isChecklist: false,
    checklistItems: [],
    color: 'sand',
    isPinned: true,
    isArchived: false,
    isTrashed: false,
    labels: ['Google Workspace', 'İpuçları'],
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    syncSource: 'keep_import',
  },
  {
    id: 'keep-2',
    title: '🛒 Haftalık Alışveriş Listesi',
    content: '',
    isChecklist: true,
    checklistItems: [
      { id: 'item-1', text: 'Taze filtre kahve çekirdeği', done: true },
      { id: 'item-2', text: 'Yulaf sütü (2 kutu)', done: true },
      { id: 'item-3', text: 'Avokado ve taze roka', done: false },
      { id: 'item-4', text: 'Organik zeytinyağı', done: false },
      { id: 'item-5', text: 'Koyu bitter çikolata %85', done: false },
    ],
    color: 'mint',
    isPinned: true,
    isArchived: false,
    isTrashed: false,
    labels: ['Kişisel', 'Alışveriş'],
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    syncSource: 'manual',
  },
  {
    id: 'keep-3',
    title: '✈️ Gezi & Seyahat Notları: Roma & Floransa',
    content:
      'Gezilecek yerler:\n- Kolezyum & Roma Forumu (sabah 09:00 biletleri alındı)\n- Trastevere akşam yürüyüşü ve pizza\n- Vatikan Müzeleri ve Sistina Şapeli\n- Floransa tren bileti (Termini istasyonu saat 08:35)',
    isChecklist: false,
    checklistItems: [],
    color: 'fog',
    isPinned: false,
    isArchived: false,
    isTrashed: false,
    labels: ['Seyahat'],
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    syncSource: 'manual',
  },
  {
    id: 'keep-4',
    title: '📌 Proje Sprint Hedefleri',
    content: '',
    isChecklist: true,
    checklistItems: [
      { id: 'item-201', text: 'Mobil responsive Gmail arayüzü', done: true },
      { id: 'item-202', text: 'Google Keep çalışma alanı modülü', done: true },
      { id: 'item-203', text: 'Not dışa aktarma & JSON yedekleme', done: false },
    ],
    color: 'peach',
    isPinned: false,
    isArchived: false,
    isTrashed: false,
    labels: ['İş', 'NoteFlow'],
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    syncSource: 'manual',
  },
];

export const loadKeepNotes = (): KeepNote[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveKeepNotes(INITIAL_KEEP_NOTES);
      return INITIAL_KEEP_NOTES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_KEEP_NOTES;
  } catch (error) {
    console.warn('Failed to load Keep notes from localStorage, using defaults:', error);
    return INITIAL_KEEP_NOTES;
  }
};

export const saveKeepNotes = (notes: KeepNote[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  } catch (error) {
    console.error('Failed to save Keep notes to localStorage:', error);
  }
};

export const exportKeepNotesToJSON = (notes: KeepNote[]): string => {
  const exportData = {
    app: 'Google Keep & NoteFlow Export',
    version: '1.0',
    exportedAt: new Date().toISOString(),
    notes: notes.map((n) => ({
      title: n.title,
      textContent: n.content,
      isChecklist: n.isChecklist,
      listContent: n.checklistItems.map((item) => ({
        text: item.text,
        isChecked: item.done,
      })),
      color: n.color,
      isPinned: n.isPinned,
      isArchived: n.isArchived,
      labels: n.labels,
      createdAt: n.createdAt,
      updatedAt: n.updatedAt,
    })),
  };
  return JSON.stringify(exportData, null, 2);
};

export const importKeepNotesFromJSON = (
  jsonContent: string,
  existingNotes: KeepNote[]
): { importedCount: number; newNotes: KeepNote[] } => {
  try {
    const data = JSON.parse(jsonContent);
    const rawList: any[] = Array.isArray(data)
      ? data
      : Array.isArray(data.notes)
      ? data.notes
      : [data];

    let count = 0;
    const addedNotes: KeepNote[] = [];

    for (const item of rawList) {
      if (!item) continue;

      const title = item.title || item.name || 'İçe Aktarılan Not';
      const content =
        item.textContent || item.content || item.text || item.description || '';
      const isChecklist =
        item.isChecklist ||
        (Array.isArray(item.listContent) && item.listContent.length > 0) ||
        false;

      const checklistItems = Array.isArray(item.listContent)
        ? item.listContent.map((li: any, idx: number) => ({
            id: `imported-li-${Date.now()}-${idx}`,
            text: li.text || String(li),
            done: Boolean(li.isChecked || li.done),
          }))
        : [];

      const rawColor = String(item.color || 'default').toLowerCase();
      const validColor: KeepColor = (rawColor in KEEP_COLORS ? rawColor : 'default') as KeepColor;

      const labels = Array.isArray(item.labels)
        ? item.labels.map((l: any) => (typeof l === 'string' ? l : l.name || ''))
        : ['Keep İçe Aktarım'];

      const newNote: KeepNote = {
        id: `keep-imported-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        title,
        content,
        isChecklist,
        checklistItems,
        color: validColor,
        isPinned: Boolean(item.isPinned),
        isArchived: Boolean(item.isArchived),
        isTrashed: false,
        labels: labels.filter(Boolean),
        createdAt: item.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        syncSource: 'keep_import',
      };

      addedNotes.push(newNote);
      count++;
    }

    const updated = [...addedNotes, ...existingNotes];
    saveKeepNotes(updated);
    return { importedCount: count, newNotes: updated };
  } catch (error) {
    console.error('Failed to import Keep JSON:', error);
    throw new Error('Geçersiz JSON formatı. Lütfen geçerli bir Google Keep veya NoteFlow yedek dosyası seçin.');
  }
};

export const convertNoteFlowNoteToKeep = (note: Note): KeepNote => {
  return {
    id: `keep-from-note-${note.id}-${Date.now()}`,
    title: note.title || 'Başlıksız Not',
    content: note.content || '',
    isChecklist: false,
    checklistItems: [],
    color: 'sand',
    isPinned: note.isPinned || false,
    isArchived: false,
    isTrashed: false,
    labels: note.tags || ['NoteFlow'],
    createdAt: note.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    syncSource: 'noteflow_export',
  };
};
