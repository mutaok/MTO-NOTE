import { createClient } from '@supabase/supabase-js';

// Flutter uygulamasıyla aynı Supabase projesi. Publishable key tarayıcıda
// bulunmak üzere tasarlanmıştır; veri erişimini RLS sınırlar.
const FALLBACK_URL = 'https://etqffrlbmtowfqfgibbx.supabase.co';
const FALLBACK_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV0cWZmcmxibXRvd2ZxZmdpYmJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzNDU2NTUsImV4cCI6MjEwNDkyMTY1NX0.guM2xCToY1fOxmV_qAwv29cBpwJtvp0h-m6nQAswD6Q';

function sanitizeSupabaseUrl(raw?: string): string {
  if (!raw || typeof raw !== 'string') return FALLBACK_URL;
  let str = raw.trim();
  // Ortam değişkeni markdown linki [url](url) veya tırnak içinde geldiyse URL'yi ayıkla
  const match = str.match(/https?:\/\/[^\s"'\])]+/i);
  if (match) {
    str = match[0];
  } else if (!/^https?:\/\//i.test(str)) {
    str = `https://${str}`;
  }

  try {
    const url = new URL(str);
    if (url.protocol === 'http:' || url.protocol === 'https:') {
      return url.origin;
    }
  } catch {
    // URL geçersizse güvenli fallback kullan
  }
  return FALLBACK_URL;
}

function sanitizeSupabaseKey(raw?: string): string {
  if (!raw || typeof raw !== 'string') return FALLBACK_KEY;
  const str = raw.trim().replace(/^["']|["']$/g, '');
  return str.length > 10 ? str : FALLBACK_KEY;
}

const SUPABASE_URL = sanitizeSupabaseUrl(
  (typeof import.meta !== 'undefined' && import.meta.env ? import.meta.env.VITE_SUPABASE_URL : undefined) ||
  (typeof process !== 'undefined' && process.env ? process.env.VITE_SUPABASE_URL : undefined)
);
const SUPABASE_PUBLISHABLE_KEY = sanitizeSupabaseKey(
  (typeof import.meta !== 'undefined' && import.meta.env ? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY : undefined) ||
  (typeof process !== 'undefined' && process.env ? process.env.VITE_SUPABASE_PUBLISHABLE_KEY : undefined)
);

export const SHARED_DEFAULT_USER_ID = '00000000-0000-4000-8000-000000000001';
export const SHARED_DEFAULT_EMAIL = 'shared@noteflow.app';

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
