import { makeNode } from '../../data/mindmapTemplates';
import { MindMapNode } from '../../types';

export function cloneTree(root: MindMapNode): MindMapNode {
  return JSON.parse(JSON.stringify(root));
}

export function findNode(root: MindMapNode, id: string): MindMapNode | null {
  if (root.id === id) return root;
  for (const child of root.children || []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

export function findParent(root: MindMapNode, childId: string): MindMapNode | null {
  for (const child of root.children || []) {
    if (child.id === childId) return root;
    const found = findParent(child, childId);
    if (found) return found;
  }
  return null;
}

export function isDescendant(root: MindMapNode, ancestorId: string, maybeDescendantId: string): boolean {
  const ancestor = findNode(root, ancestorId);
  if (!ancestor) return false;
  return findNode(ancestor, maybeDescendantId) !== null;
}

export function renameNode(root: MindMapNode, id: string, title: string): MindMapNode {
  const next = cloneTree(root);
  const target = findNode(next, id);
  if (target) target.title = title;
  return next;
}

export function recolorNode(root: MindMapNode, id: string, color: string): MindMapNode {
  const next = cloneTree(root);
  const target = findNode(next, id);
  if (target) target.color = color;
  return next;
}

export function addChildNode(
  root: MindMapNode,
  parentId: string,
  title = 'Yeni Düğüm',
): { root: MindMapNode; childId: string } {
  const next = cloneTree(root);
  const parent = findNode(next, parentId);
  const child = makeNode(title);
  if (parent) {
    if (!parent.children) parent.children = [];
    parent.children.push(child);
  }
  return { root: next, childId: child.id };
}

export function removeNode(root: MindMapNode, id: string): MindMapNode {
  if (root.id === id) return root;
  const next = cloneTree(root);
  const parent = findParent(next, id);
  if (parent) {
    parent.children = (parent.children || []).filter((c) => c.id !== id);
  }
  return next;
}

export function reparentNode(root: MindMapNode, nodeId: string, newParentId: string): MindMapNode {
  if (nodeId === newParentId) return root;
  if (isDescendant(root, nodeId, newParentId)) return root;
  const currentParent = findParent(root, nodeId);
  if (currentParent?.id === newParentId) return root;

  const next = cloneTree(root);
  const parent = findParent(next, nodeId);
  const moving = findNode(next, nodeId);
  const newParent = findNode(next, newParentId);
  if (!parent || !moving || !newParent) return root;
  parent.children = (parent.children || []).filter((c) => c.id !== nodeId);
  if (!newParent.children) newParent.children = [];
  newParent.children.push(moving);
  return next;
}

export function countNodes(root: MindMapNode): number {
  return 1 + (root.children || []).reduce((sum, c) => sum + countNodes(c), 0);
}
