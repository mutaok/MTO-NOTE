import { MindMapTableDoc } from '../../types';

export function cellKey(row: number, col: number): string {
  return `${row}:${col}`;
}

export function getCell(doc: MindMapTableDoc, row: number, col: number): string {
  return doc.cells[cellKey(row, col)] ?? '';
}

export function setCell(doc: MindMapTableDoc, row: number, col: number, value: string): MindMapTableDoc {
  return { ...doc, cells: { ...doc.cells, [cellKey(row, col)]: value } };
}

export function renameRow(doc: MindMapTableDoc, row: number, label: string): MindMapTableDoc {
  const rows = [...doc.rows];
  rows[row] = label;
  return { ...doc, rows };
}

export function renameCol(doc: MindMapTableDoc, col: number, label: string): MindMapTableDoc {
  const cols = [...doc.cols];
  cols[col] = label;
  return { ...doc, cols };
}

export function addRow(doc: MindMapTableDoc): MindMapTableDoc {
  return { ...doc, rows: [...doc.rows, `Satır ${doc.rows.length + 1}`] };
}

export function addCol(doc: MindMapTableDoc): MindMapTableDoc {
  return { ...doc, cols: [...doc.cols, `Sütun ${doc.cols.length + 1}`] };
}

export function removeRow(doc: MindMapTableDoc, row: number): MindMapTableDoc {
  const rows = doc.rows.filter((_, i) => i !== row);
  const cells: Record<string, string> = {};
  for (const [key, value] of Object.entries(doc.cells)) {
    const [r, c] = key.split(':').map(Number);
    if (r === row) continue;
    cells[cellKey(r > row ? r - 1 : r, c)] = value;
  }
  return { ...doc, rows, cells };
}

export function removeCol(doc: MindMapTableDoc, col: number): MindMapTableDoc {
  const cols = doc.cols.filter((_, i) => i !== col);
  const cells: Record<string, string> = {};
  for (const [key, value] of Object.entries(doc.cells)) {
    const [r, c] = key.split(':').map(Number);
    if (c === col) continue;
    cells[cellKey(r, c > col ? c - 1 : c)] = value;
  }
  return { ...doc, cols, cells };
}
