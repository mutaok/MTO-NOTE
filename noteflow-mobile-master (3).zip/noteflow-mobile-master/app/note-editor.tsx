import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconButton, PrimaryButton } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

const commands = [{ icon: 'heading' as const, title: 'Başlık', subtitle: 'Büyük bir bölüm başlığı ekle' }, { icon: 'format.list.bulleted' as const, title: 'Liste', subtitle: 'Madde işaretli liste oluştur' }, { icon: 'table' as const, title: 'Tablo', subtitle: 'Yapılandırılmış veri ekle' }, { icon: 'code' as const, title: 'Kod', subtitle: 'Kod bloğu ile yaz' }];
const TAGS = ['Kişisel', 'İş', 'Fikir'] as const;

function dateLabel(key: string): string {
  const date = new Date(`${key}T00:00:00`);
  return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', weekday: 'long' });
}

export default function NoteEditor() {
  const colors = useColors();
  const params = useLocalSearchParams<{ id?: string; date?: string }>();
  const noteId = params.id ? Number(params.id) : undefined;
  const utils = trpc.useUtils();

  const noteQuery = trpc.notes.byId.useQuery({ id: noteId! }, { enabled: noteId !== undefined });
  const createNote = trpc.notes.create.useMutation({ onSuccess: () => utils.notes.list.invalidate() });
  const updateNote = trpc.notes.update.useMutation({ onSuccess: () => utils.notes.list.invalidate() });
  const deleteNote = trpc.notes.delete.useMutation({ onSuccess: () => utils.notes.list.invalidate() });

  const [title, setTitle] = useState('Yeni not');
  const [body, setBody] = useState('');
  const [tag, setTag] = useState<string>('Kişisel');
  const [date, setDate] = useState<string | null>(params.date ?? null);
  const [saved, setSaved] = useState(true);
  const hydrated = useRef(false);

  useEffect(() => {
    if (noteQuery.data && !hydrated.current) {
      setTitle(noteQuery.data.title);
      setBody(noteQuery.data.body);
      setTag(noteQuery.data.tag);
      setDate(noteQuery.data.date ?? null);
      hydrated.current = true;
    }
  }, [noteQuery.data]);

  const showCommands = body.endsWith('/') || body.endsWith('/ ');
  const isSaving = createNote.isPending || updateNote.isPending;

  const handleSave = () => {
    if (!title.trim()) return;
    if (noteId !== undefined) {
      updateNote.mutate({ id: noteId, title, body, tag, date }, { onSuccess: () => setSaved(true) });
    } else {
      createNote.mutate({ title, body, tag, date }, {
        onSuccess: (note) => {
          setSaved(true);
          if (note) router.replace({ pathname: '/note-editor', params: { id: String(note.id) } });
        },
      });
    }
  };

  const handleDelete = () => {
    if (noteId === undefined) return;
    Alert.alert('Notu sil', 'Bu not kalıcı olarak silinecek.', [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: () => deleteNote.mutate({ id: noteId }, { onSuccess: () => router.back() }) },
    ]);
  };

  if (noteId !== undefined && noteQuery.isLoading) {
    return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  }

  return <ScreenContainer edges={['top', 'left', 'right', 'bottom']} className="px-5"><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1"><View className="flex-row items-center justify-between py-3"><IconButton name="arrow.left" label="Geri" onPress={() => router.back()} /><View className="flex-row items-center gap-4"><Text className="text-[12px] text-muted">{isSaving ? 'Kaydediliyor...' : saved ? 'Kaydedildi' : 'Taslak'}</Text>{noteId !== undefined ? <IconButton name="delete" label="Sil" onPress={handleDelete} /> : null}</View></View><ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 28, paddingBottom: 150 }}><TextInput value={title} onChangeText={(value) => { setTitle(value); setSaved(false); }} placeholder="Not başlığı" placeholderTextColor={colors.muted} className="mb-4 text-[28px] font-semibold leading-9 text-foreground" /><TextInput autoFocus={noteId === undefined} value={body} onChangeText={(value) => { setBody(value); setSaved(false); }} multiline textAlignVertical="top" placeholder={'Düşüncelerini buraya yaz...\n\nSlash (/) ile hızlı komutları aç.'} placeholderTextColor={colors.muted} className="min-h-[380px] text-[16px] leading-7 text-foreground" /><View className="mt-5 flex-row items-center gap-2"><Pressable onPress={() => { setTag((current) => TAGS[(TAGS.indexOf(current as any) + 1) % TAGS.length]); setSaved(false); }} className="rounded-full bg-background px-3 py-1.5"><Text className="text-[11px] font-semibold text-muted">{tag}</Text></Pressable>{date ? <View className="flex-row items-center gap-1 rounded-full bg-background px-3 py-1.5"><IconSymbol name="calendar" size={12} color={colors.muted} /><Text className="text-[11px] font-semibold text-muted">{dateLabel(date)}</Text><Pressable onPress={() => { setDate(null); setSaved(false); }} hitSlop={6}><IconSymbol name="close" size={12} color={colors.muted} /></Pressable></View> : null}</View></ScrollView>{showCommands ? <View className="absolute bottom-[88px] left-5 right-5 rounded-2xl border border-border bg-surface p-2 shadow-lg"><Text className="px-3 pb-2 pt-1 text-[11px] font-semibold uppercase tracking-[1px] text-muted">Hızlı komutlar</Text>{commands.map((command) => <Pressable key={command.title} onPress={() => { setBody((current) => current.replace(/\/$/, '')); }} style={({ pressed }) => [{ opacity: pressed ? 0.65 : 1 }]} className="flex-row items-center rounded-xl px-3 py-2.5"><View className="mr-3 h-8 w-8 items-center justify-center rounded-lg bg-background"><IconSymbol name={command.icon} size={17} color={colors.primary} /></View><View><Text className="text-[14px] font-semibold text-foreground">{command.title}</Text><Text className="mt-0.5 text-[11px] text-muted">{command.subtitle}</Text></View></Pressable>)}</View> : <View className="absolute bottom-5 left-5 right-5 flex-row items-center justify-between rounded-2xl border border-border bg-surface px-4 py-3"><View className="flex-row items-center gap-5"><IconSymbol name="format.bold" size={20} color={colors.muted} /><IconSymbol name="format.italic" size={20} color={colors.muted} /><IconSymbol name="format.list.bulleted" size={20} color={colors.muted} /><IconSymbol name="link" size={20} color={colors.muted} /></View><PrimaryButton label="Kaydet" onPress={handleSave} /></View>}</KeyboardAvoidingView></ScreenContainer>;
}
