import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconButton } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';
import { addCol, addRow, getCell, removeCol, removeRow, renameCol, renameRow, setCell } from '@/lib/mindmap/table';
import type { MindMapTableDoc } from '@/shared/mindmap';

const CELL_W = 120;
const HEADER_W = 130;

export default function MindMapTableEditor() {
  const colors = useColors();
  const params = useLocalSearchParams<{ id: string }>();
  const mapId = Number(params.id);
  const utils = trpc.useUtils();
  const mapQuery = trpc.mindMaps.byId.useQuery({ id: mapId }, { enabled: Number.isFinite(mapId) });
  const updateMap = trpc.mindMaps.update.useMutation();
  const deleteMap = trpc.mindMaps.delete.useMutation({ onSuccess: () => utils.mindMaps.list.invalidate() });

  const [doc, setDoc] = useState<MindMapTableDoc | null>(null);
  const [title, setTitle] = useState('');
  const hydrated = useRef(false);
  const [saveState, setSaveState] = useState<'saving' | 'saved'>('saved');

  useEffect(() => {
    if (mapQuery.data && !hydrated.current && mapQuery.data.data.kind === 'table') {
      setDoc(mapQuery.data.data);
      setTitle(mapQuery.data.title);
      hydrated.current = true;
    }
  }, [mapQuery.data]);

  useEffect(() => {
    if (!doc || !hydrated.current) return;
    setSaveState('saving');
    const timeout = setTimeout(() => {
      updateMap.mutate({ id: mapId, data: doc }, { onSuccess: () => setSaveState('saved') });
    }, 700);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc]);

  const handleDeleteMap = () => {
    Alert.alert('Tabloyu sil', 'Bu tablo kalıcı olarak silinecek.', [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: () => deleteMap.mutate({ id: mapId }, { onSuccess: () => router.back() }) },
    ]);
  };

  const confirmRemoveRow = (row: number) => {
    if (!doc || doc.rows.length <= 1) return;
    Alert.alert('Satırı sil', `"${doc.rows[row]}" satırı silinecek.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: () => setDoc(removeRow(doc, row)) },
    ]);
  };

  const confirmRemoveCol = (col: number) => {
    if (!doc || doc.cols.length <= 1) return;
    Alert.alert('Sütunu sil', `"${doc.cols[col]}" sütunu silinecek.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: () => setDoc(removeCol(doc, col)) },
    ]);
  };

  if (mapQuery.isLoading || !doc) {
    return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  }

  return (
    <ScreenContainer edges={['top', 'left', 'right', 'bottom']}>
      <View className="flex-row items-center justify-between px-4 py-3">
        <IconButton name="arrow.left" label="Geri" onPress={() => router.back()} />
        <Text numberOfLines={1} className="mx-2 flex-1 text-center text-[15px] font-semibold text-foreground">{title}</Text>
        <IconButton name="delete" label="Tabloyu sil" onPress={handleDeleteMap} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View className="px-4 pb-6">
            <View className="flex-row">
              <View style={{ width: HEADER_W }} />
              {doc.cols.map((col, c) => (
                <View key={c} style={{ width: CELL_W }} className="mr-2 flex-row items-center">
                  <TextInput
                    value={col}
                    onChangeText={(value) => setDoc(renameCol(doc, c, value))}
                    placeholderTextColor={colors.muted}
                    style={{ borderColor: colors.border }}
                    className="flex-1 rounded-lg border px-2 py-2 text-center text-[12px] font-semibold text-foreground"
                  />
                  <Pressable onPress={() => confirmRemoveCol(c)} hitSlop={6} className="ml-1">
                    <IconSymbol name="close" size={14} color={colors.muted} />
                  </Pressable>
                </View>
              ))}
              <Pressable onPress={() => setDoc(addCol(doc))} style={{ borderColor: colors.border }} className="h-10 w-10 items-center justify-center rounded-lg border">
                <IconSymbol name="plus" size={16} color={colors.primary} />
              </Pressable>
            </View>

            {doc.rows.map((row, r) => (
              <View key={r} className="mt-2 flex-row">
                <View style={{ width: HEADER_W }} className="mr-0 flex-row items-center pr-2">
                  <TextInput
                    value={row}
                    onChangeText={(value) => setDoc(renameRow(doc, r, value))}
                    placeholderTextColor={colors.muted}
                    style={{ borderColor: colors.border }}
                    className="flex-1 rounded-lg border px-2 py-2.5 text-[12px] font-semibold text-foreground"
                  />
                  <Pressable onPress={() => confirmRemoveRow(r)} hitSlop={6} className="ml-1">
                    <IconSymbol name="close" size={14} color={colors.muted} />
                  </Pressable>
                </View>
                {doc.cols.map((_, c) => (
                  <View key={c} style={{ width: CELL_W }} className="mr-2">
                    <TextInput
                      value={getCell(doc, r, c)}
                      onChangeText={(value) => setDoc(setCell(doc, r, c, value))}
                      placeholder="—"
                      placeholderTextColor={colors.muted}
                      style={{ borderColor: colors.border, backgroundColor: colors.surface }}
                      className="rounded-lg border px-2 py-2.5 text-[13px] text-foreground"
                    />
                  </View>
                ))}
              </View>
            ))}

            <Pressable onPress={() => setDoc(addRow(doc))} style={{ borderColor: colors.border, width: HEADER_W }} className="mt-3 h-10 items-center justify-center rounded-lg border">
              <IconSymbol name="plus" size={16} color={colors.primary} />
            </Pressable>
          </View>
        </ScrollView>
      </ScrollView>

      <View style={{ borderColor: colors.border }} className="items-center border-t px-2 py-2">
        <Text className="text-[11px] text-muted">{saveState === 'saving' ? 'Kaydediliyor...' : 'Kaydedildi'}</Text>
      </View>
    </ScreenContainer>
  );
}
