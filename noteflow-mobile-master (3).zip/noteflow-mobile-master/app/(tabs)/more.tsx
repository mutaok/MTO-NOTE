import { Pressable, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { SurfaceCard } from '@/components/ui/nf-ui';
import { useColors } from '@/hooks/use-colors';
import { useAuth } from '@/hooks/use-auth';
import { useThemeContext } from '@/lib/theme-provider';
import { trpc } from '@/lib/trpc';

function initialsFor(name: string | null, email: string | null): string {
  const source = name?.trim() || email?.trim() || '?';
  const parts = source.split(/\s+/).filter(Boolean);
  const initials = parts.length > 1 ? `${parts[0][0]}${parts[1][0]}` : source.slice(0, 2);
  return initials.toUpperCase();
}

export default function MoreScreen() {
  const colors = useColors();
  const { colorScheme, setColorScheme } = useThemeContext();
  const router = useRouter();
  const { user } = useAuth();
  const notesQuery = trpc.notes.list.useQuery();
  const tasksQuery = trpc.tasks.list.useQuery();

  const folderCount = new Set((tasksQuery.data ?? []).map((task) => task.list)).size;
  const tagCount = new Set((notesQuery.data ?? []).map((note) => note.tag)).size;

  const items = [
    { icon: 'book' as const, title: 'Defterler (11 Tür)', subtitle: 'Akademik, Proje, Günlük, Finans ve tüm araçlar', value: '11', onPress: () => router.push('/(tabs)/notebooks'), disabled: false },
    { icon: 'folder' as const, title: 'Klasörler', subtitle: 'Görevlerin listelere göre gruplanması', value: String(folderCount), onPress: () => router.push('/(tabs)/tasks'), disabled: false },
    { icon: 'tag' as const, title: 'Etiketler', subtitle: 'Notlarını düzenle', value: String(tagCount), onPress: () => router.push('/(tabs)/notes'), disabled: false },
    { icon: 'dark.mode' as const, title: 'Görünüm', subtitle: 'Dokunarak temayı değiştir', value: colorScheme === 'dark' ? 'Koyu' : 'Açık', onPress: () => setColorScheme(colorScheme === 'dark' ? 'light' : 'dark'), disabled: false },
    { icon: 'document.scanner' as const, title: 'Tara', subtitle: 'Belge tarama — yakında', value: 'Yakında', onPress: () => {}, disabled: true },
  ];

  return <ScreenContainer className="px-5"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 18, paddingBottom: 34 }}><View className="mb-7"><Text className="text-[13px] font-semibold uppercase tracking-[1.4px] text-muted">Alanım</Text><Text className="mt-1 text-[28px] font-semibold text-foreground">Daha fazla</Text></View><SurfaceCard className="mb-6 flex-row items-center p-4"><View className="mr-3 h-12 w-12 items-center justify-center rounded-2xl bg-slate-900 dark:bg-blue-100"><Text className="text-[16px] font-bold text-white dark:text-slate-900">{initialsFor(user?.name ?? null, user?.email ?? null)}</Text></View><View className="flex-1"><Text className="text-[16px] font-semibold text-foreground">{user?.name || user?.email || 'Kullanıcı'}</Text><Text className="mt-1 text-[12px] text-muted">{user?.email ?? 'NoteFlow hesabı'}</Text></View></SurfaceCard><Text className="mb-3 text-[18px] font-semibold text-foreground">Kişiselleştir</Text><View className="gap-3">{items.map((item) => <Pressable key={item.title} disabled={item.disabled} onPress={item.onPress} style={({ pressed }) => [{ opacity: item.disabled ? 0.5 : pressed ? 0.7 : 1 }]}><SurfaceCard className="flex-row items-center p-4"><View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-background"><IconSymbol name={item.icon} size={20} color={item.disabled ? colors.muted : colors.primary} /></View><View className="flex-1"><Text className="text-[15px] font-semibold text-foreground">{item.title}</Text><Text className="mt-1 text-[12px] text-muted">{item.subtitle}</Text></View>{item.value ? <Text className="mr-2 text-[12px] font-semibold text-muted">{item.value}</Text> : null}{item.disabled ? null : <IconSymbol name="chevron.right" size={18} color={colors.muted} />}</SurfaceCard></Pressable>)}</View><View className="mt-8 items-center"><Text className="text-[12px] text-muted">NoteFlow 1.0.0</Text><Text className="mt-1 text-[11px] text-muted">Content first · No AI</Text></View></ScrollView></ScreenContainer>;
}
