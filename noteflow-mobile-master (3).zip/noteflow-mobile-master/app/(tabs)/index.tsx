import { ScrollView, Text, View, Pressable } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { SectionHeader } from '@/components/ui/nf-ui';
import { useColors } from '@/hooks/use-colors';

const quickActions = [
  { label: 'Defterler (11 Tür)', icon: 'book' as const, tone: '#EDE9FE', path: '/(tabs)/notebooks' },
  { label: 'Yeni Not', icon: 'plus' as const, tone: '#E7F3FE', path: '/note-editor' },
  { label: 'Yeni Görev', icon: 'checklist' as const, tone: '#EEF7F2', path: '/task-editor' },
];

export default function HomeScreen() {
  const colors = useColors();

  return (
    <ScreenContainer className="px-5" safeAreaClassName="flex-1">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 18, paddingBottom: 34 }}>
        <SectionHeader title="Hemen Başla" />
        <View className="flex-row gap-3">
          {quickActions.map((action) => (
            <Pressable
              key={action.label}
              onPress={() => router.push(action.path as any)}
              accessibilityLabel={action.label}
              style={({ pressed }) => [{ opacity: pressed ? 0.72 : 1 }]}
              className="h-28 flex-1 items-center justify-center rounded-2xl border border-border bg-surface"
            >
              <View style={{ backgroundColor: action.tone }} className="h-14 w-14 items-center justify-center rounded-2xl dark:bg-slate-800">
                <IconSymbol name={action.icon} size={26} color={colors.primary} />
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
