import { ActivityIndicator, ScrollView, Text, View, Pressable } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { EmptyState, SectionHeader, SurfaceCard } from '@/components/ui/nf-ui';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';
import { MIND_MAP_TEMPLATES, isTableType, templateFor, type MindMapType } from '@/shared/mindmap';

export default function MindMapScreen() {
  const colors = useColors();
  const mindMapsQuery = trpc.mindMaps.list.useQuery();
  const utils = trpc.useUtils();
  const createMindMap = trpc.mindMaps.create.useMutation({
    onSuccess: (map) => {
      utils.mindMaps.list.invalidate();
      if (!map) return;
      router.push(
        isTableType(map.type)
          ? { pathname: '/mind-map-table', params: { id: String(map.id) } }
          : { pathname: '/mind-map-editor', params: { id: String(map.id) } },
      );
    },
  });

  const maps = mindMapsQuery.data ?? [];

  const handleTemplatePress = (type: MindMapType) => {
    if (createMindMap.isPending) return;
    const template = templateFor(type);
    createMindMap.mutate({ title: template.label, type: template.type, data: template.createDoc() });
  };

  const openMindMap = (map: NonNullable<typeof mindMapsQuery.data>[number]) => {
    router.push(
      isTableType(map.type)
        ? { pathname: '/mind-map-table', params: { id: String(map.id) } }
        : { pathname: '/mind-map-editor', params: { id: String(map.id) } },
    );
  };

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 18, paddingBottom: 34 }}>
        <View className="mb-6">
          <Text className="text-[13px] font-semibold uppercase tracking-[1.4px] text-muted">Fikirler</Text>
          <Text className="mt-1 text-[28px] font-semibold text-foreground">Mind Map</Text>
        </View>

        <SectionHeader title="Yeni oluştur" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-1 mb-8">
          {MIND_MAP_TEMPLATES.map((template) => (
            <Pressable
              key={template.type}
              onPress={() => handleTemplatePress(template.type)}
              disabled={createMindMap.isPending}
              style={({ pressed }) => [{ opacity: pressed ? 0.72 : 1 }]}
              className="mr-3 w-[132px] rounded-2xl border border-border bg-surface p-3"
            >
              <View className="mb-3 h-9 w-9 items-center justify-center rounded-xl bg-background">
                <IconSymbol name={template.icon} size={19} color={colors.primary} />
              </View>
              <Text className="text-[13px] font-semibold text-foreground">{template.label}</Text>
              <Text numberOfLines={2} className="mt-1 text-[11px] leading-4 text-muted">{template.description}</Text>
            </Pressable>
          ))}
        </ScrollView>

        <SectionHeader title="Haritaların" />
        {mindMapsQuery.isLoading ? (
          <View className="items-center py-10"><ActivityIndicator color={colors.primary} /></View>
        ) : maps.length === 0 ? (
          <EmptyState icon="hub" title="Henüz mind map yok" description="Yukarıdaki şablonlardan birini seçerek başla." />
        ) : (
          <View className="gap-3">
            {maps.map((map) => (
              <SurfaceCard key={map.id} onPress={() => openMindMap(map)} className="flex-row items-center p-4">
                <View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-background">
                  <IconSymbol name={templateFor(map.type).icon} size={19} color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-[14px] font-semibold text-foreground" numberOfLines={1}>{map.title}</Text>
                  <Text className="mt-1 text-[12px] text-muted">{templateFor(map.type).label}</Text>
                </View>
                <IconSymbol name="chevron.right" size={18} color={colors.muted} />
              </SurfaceCard>
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
