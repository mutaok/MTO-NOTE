import { Tabs } from 'expo-router';
import { Platform, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { HapticTab } from '@/components/haptic-tab';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';

const tabs = [
  { name: 'index', title: 'Ana Sayfa', icon: 'house.fill' as const },
  { name: 'notebooks', title: 'Defterler', icon: 'book.closed' as const },
  { name: 'notes', title: 'Notlar', icon: 'note.text' as const },
  { name: 'tasks', title: 'Görevler', icon: 'checkmark.circle.fill' as const },
  { name: 'mind-map', title: 'Mind Map', icon: 'hub' as const },
  { name: 'more', title: 'Daha Fazla', icon: 'ellipsis.circle' as const },
];

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === 'web' ? 10 : Math.max(insets.bottom, 8);
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600', marginTop: 2 },
        tabBarStyle: { height: 66 + bottomPadding, paddingTop: 7, paddingBottom: bottomPadding, backgroundColor: colors.background, borderTopColor: colors.border, borderTopWidth: 0.5 },
      }}
    >
      {tabs.map((tab) => (
        <Tabs.Screen
          key={tab.name}
          name={tab.name}
          options={{
            title: tab.title,
            tabBarIcon: ({ color, focused }) => (
              <View style={focused ? { backgroundColor: colors.primary, borderRadius: 18, paddingHorizontal: 15, paddingVertical: 4 } : { paddingHorizontal: 15, paddingVertical: 4 }}>
                <IconSymbol name={tab.icon} size={21} color={focused ? '#0F172A' : color} />
              </View>
            ),
          }}
        />
      ))}
    </Tabs>
  );
}
