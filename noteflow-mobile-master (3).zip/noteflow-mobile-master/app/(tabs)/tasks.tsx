import { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { EmptyState, FilterChip, FloatingActionButton, IconButton, SectionHeader, SurfaceCard } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

const TABS = ['Bugün', 'Gelecek', 'Takvim', 'Tamamlanan'] as const;
type Tab = (typeof TABS)[number];

const WEEKDAYS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
const MONTH_NAMES = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function taskTimeLabel(dueDate: string | null, dueTime: string | null): string {
  if (!dueDate) return dueTime ?? 'Tarihsiz';
  const date = new Date(`${dueDate}T00:00:00`);
  const label = date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', weekday: 'short' });
  return dueTime ? `${label} · ${dueTime}` : label;
}

function toKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function startOffset(firstOfMonth: Date): number {
  // getDay(): 0=Sun..6=Sat. Grid starts Monday, so shift Sunday to the end.
  const day = firstOfMonth.getDay();
  return day === 0 ? 6 : day - 1;
}

export default function TasksScreen() {
  const colors = useColors();
  const [tab, setTab] = useState<Tab>('Bugün');
  const [listFilter, setListFilter] = useState<'Tümü' | string>('Tümü');
  const today = new Date();
  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState(today);
  const utils = trpc.useUtils();
  const tasksQuery = trpc.tasks.list.useQuery();
  const toggleDone = trpc.tasks.toggleDone.useMutation({
    onMutate: async ({ id, done }) => {
      await utils.tasks.list.cancel();
      const previous = utils.tasks.list.getData();
      utils.tasks.list.setData(undefined, (current) => current?.map((task) => (task.id === id ? { ...task, done } : task)));
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) utils.tasks.list.setData(undefined, context.previous);
    },
    onSettled: () => utils.tasks.list.invalidate(),
  });

  const allTasks = tasksQuery.data ?? [];
  const lists = useMemo(() => ['Tümü', ...Array.from(new Set(allTasks.map((task) => task.list)))], [allTasks]);
  const todayStr = todayKey();

  const grouped = useMemo(() => {
    const byList = listFilter === 'Tümü' ? allTasks : allTasks.filter((task) => task.list === listFilter);
    return {
      Bugün: byList.filter((task) => !task.done && task.dueDate === todayStr),
      Gelecek: byList.filter((task) => !task.done && task.dueDate !== todayStr),
      Tamamlanan: byList.filter((task) => task.done),
    };
  }, [allTasks, listFilter, todayStr]);

  const items = tab === 'Takvim' ? [] : grouped[tab];

  // Calendar view state, shown when tab === 'Takvim'.
  const daysInMonth = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0).getDate();
  const offset = startOffset(viewDate);
  const cells = useMemo(() => [...Array(offset).fill(null), ...Array.from({ length: daysInMonth }, (_, index) => index + 1)], [offset, daysInMonth]);
  const datesWithTasks = useMemo(() => new Set(allTasks.filter((task) => task.dueDate).map((task) => task.dueDate)), [allTasks]);
  const selectedKey = toKey(selected);
  const dayTasks = useMemo(() => allTasks.filter((task) => task.dueDate === selectedKey), [allTasks, selectedKey]);

  const changeMonth = (delta: number) => {
    const next = new Date(viewDate.getFullYear(), viewDate.getMonth() + delta, 1);
    setViewDate(next);
    setSelected(next);
  };

  const selectDay = (day: number) => setSelected(new Date(viewDate.getFullYear(), viewDate.getMonth(), day));

  const addNoteForSelectedDay = () => router.push({ pathname: '/note-editor', params: { date: selectedKey } });

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 18, paddingBottom: 100 }}>
        <View className="mb-6 flex-row items-center justify-between"><View><Text className="text-[13px] font-semibold uppercase tracking-[1.4px] text-muted">Üretkenlik</Text><Text className="mt-1 text-[28px] font-semibold text-foreground">Görevler</Text></View><IconButton name="magnifyingglass" label="Görevlerde ara" onPress={() => router.push('/search')} /></View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-1 mb-7">{TABS.map((item) => <FilterChip key={item} label={item} active={tab === item} onPress={() => setTab(item)} />)}</ScrollView>

        {tab === 'Takvim' ? (
          <>
            <SurfaceCard className="mb-6 p-4">
              <View className="mb-5 flex-row items-center justify-between">
                <Text className="text-[18px] font-semibold text-foreground">{MONTH_NAMES[viewDate.getMonth()]} {viewDate.getFullYear()}</Text>
                <View className="flex-row gap-4">
                  <Pressable onPress={() => changeMonth(-1)} hitSlop={8}><IconSymbol name="chevron.left" size={18} color={colors.muted} /></Pressable>
                  <Pressable onPress={() => changeMonth(1)} hitSlop={8}><IconSymbol name="chevron.right" size={18} color={colors.muted} /></Pressable>
                </View>
              </View>
              <View className="mb-3 flex-row">{WEEKDAYS.map((day) => <Text key={day} className="flex-1 text-center text-[11px] font-semibold text-muted">{day}</Text>)}</View>
              <View className="flex-row flex-wrap">
                {cells.map((day, index) => {
                  if (day === null) return <View key={`empty-${index}`} style={{ width: '14.285%' }} />;
                  const key = toKey(new Date(viewDate.getFullYear(), viewDate.getMonth(), day));
                  const isSelected = key === selectedKey;
                  return (
                    <Pressable key={key} onPress={() => selectDay(day)} style={({ pressed }) => [{ width: '14.285%', alignItems: 'center', marginBottom: 8, opacity: pressed ? 0.6 : 1 }]}>
                      <View style={isSelected ? { backgroundColor: colors.primary } : undefined} className="h-9 w-9 items-center justify-center rounded-full">
                        <Text className={`text-[13px] font-semibold ${isSelected ? 'text-slate-950' : 'text-foreground'}`}>{day}</Text>
                      </View>
                      {datesWithTasks.has(key) ? <View className="mt-1 h-1 w-1 rounded-full bg-blue-400" /> : <View className="mt-1 h-1 w-1" />}
                    </Pressable>
                  );
                })}
              </View>
            </SurfaceCard>

            <View className="mb-3 flex-row items-center justify-between">
              <Text className="text-[18px] font-semibold text-foreground">{selected.getDate()} {MONTH_NAMES[selected.getMonth()]} · {selected.toLocaleDateString('tr-TR', { weekday: 'long' })}</Text>
              <Pressable onPress={addNoteForSelectedDay} style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]} className="flex-row items-center gap-1 rounded-full bg-background px-3 py-1.5">
                <IconSymbol name="plus" size={14} color={colors.primary} />
                <Text style={{ color: colors.primary }} className="text-[12px] font-semibold">Not ekle</Text>
              </Pressable>
            </View>
            <View className="gap-3">
              {tasksQuery.isLoading ? (
                <View className="items-center py-10"><ActivityIndicator color={colors.primary} /></View>
              ) : dayTasks.length === 0 ? (
                <EmptyState icon="calendar" title="Bu günde görev yok" description="Sağ üstten bu güne bir not ekleyebilirsin." />
              ) : (
                dayTasks.map((taskItem) => (
                  <SurfaceCard key={taskItem.id} className="p-4">
                    <View className="flex-row items-center">
                      <View style={{ backgroundColor: taskItem.color }} className="mr-3 h-10 w-1 rounded-full" />
                      <View className="flex-1">
                        <Text className={`text-[15px] font-semibold ${taskItem.done ? 'text-muted line-through' : 'text-foreground'}`}>{taskItem.title}</Text>
                        <Text className="mt-1 text-[12px] text-muted">{taskItem.dueTime ?? 'Tüm gün'}</Text>
                      </View>
                      <View className="rounded-full bg-background px-2.5 py-1"><Text className="text-[11px] font-semibold text-muted">{taskItem.list}</Text></View>
                    </View>
                  </SurfaceCard>
                ))
              )}
            </View>
          </>
        ) : (
          <>
            <SectionHeader
              title={`${tab} · ${items.length} görev`}
              action={listFilter}
              onAction={() => setListFilter((current) => lists[(lists.indexOf(current) + 1) % lists.length])}
            />
            {tasksQuery.isLoading ? (
              <View className="items-center py-16"><ActivityIndicator color={colors.primary} /></View>
            ) : items.length === 0 ? (
              <EmptyState icon="checklist" title="Görev yok" description="Bu grupta gösterilecek bir görev bulunmuyor." />
            ) : (
              <View className="gap-3">
                {items.map((task) => (
                  <SurfaceCard key={task.id} className="p-4">
                    <View className="flex-row items-center">
                      <Pressable
                        onPress={() => toggleDone.mutate({ id: task.id, done: !task.done })}
                        style={({ pressed }) => [{ borderColor: task.done ? colors.primary : colors.border, backgroundColor: task.done ? colors.primary : 'transparent', opacity: pressed ? 0.7 : 1 }]}
                        className="mr-3 h-6 w-6 items-center justify-center rounded-full border-2"
                      >
                        {task.done ? <IconSymbol name="checkmark.circle.fill" size={22} color="#0F172A" /> : null}
                      </Pressable>
                      <View className="flex-1">
                        <Text className={`text-[15px] font-semibold ${task.done ? 'text-muted line-through' : 'text-foreground'}`}>{task.title}</Text>
                        <View className="mt-1 flex-row items-center">
                          <View style={{ backgroundColor: task.color }} className="mr-1.5 h-1.5 w-1.5 rounded-full" />
                          <Text className="text-[12px] text-muted">{taskTimeLabel(task.dueDate, task.dueTime)} · {task.list}</Text>
                        </View>
                      </View>
                      <IconSymbol name="more" size={18} color={colors.muted} />
                    </View>
                  </SurfaceCard>
                ))}
              </View>
            )}
          </>
        )}
      </ScrollView>
      <FloatingActionButton label="Yeni görev" onPress={() => router.push('/task-editor')} />
    </ScreenContainer>
  );
}
