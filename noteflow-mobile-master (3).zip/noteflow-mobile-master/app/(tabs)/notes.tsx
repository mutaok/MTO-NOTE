import { useMemo, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { EmptyState, FilterChip, FloatingActionButton, IconButton, SectionHeader, SurfaceCard } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

function formatDate(value: string | Date): string {
  const date = new Date(value);
  const today = new Date();
  const isToday = date.toDateString() === today.toDateString();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const isYesterday = date.toDateString() === yesterday.toDateString();
  const time = date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  if (isToday) return `Bugün · ${time}`;
  if (isYesterday) return `Dün · ${time}`;
  return `${date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })} · ${time}`;
}

const TAG_COLORS: Record<string, string> = { İş: '#64B5F6', Kişisel: '#F2B880', Fikir: '#A68BDB' };

export default function NotesScreen() {
  const colors = useColors();
  const [activeTag, setActiveTag] = useState('Tümü');
  const [sortAsc, setSortAsc] = useState(false);
  const notesQuery = trpc.notes.list.useQuery();

  const notes = notesQuery.data ?? [];
  const tags = useMemo(() => ['Tümü', ...Array.from(new Set(notes.map((note) => note.tag)))], [notes]);
  const visible = useMemo(() => {
    const filtered = activeTag === 'Tümü' ? notes : notes.filter((note) => note.tag === activeTag);
    return [...filtered].sort((a, b) => {
      const diff = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
      return sortAsc ? diff : -diff;
    });
  }, [notes, activeTag, sortAsc]);

  return (
    <ScreenContainer className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 18, paddingBottom: 100 }}>
        <View className="mb-6 flex-row items-center justify-between"><View><Text className="text-[13px] font-semibold uppercase tracking-[1.4px] text-muted">Kütüphanen</Text><Text className="mt-1 text-[28px] font-semibold text-foreground">Notlar</Text></View><IconButton name="magnifyingglass" label="Ara" onPress={() => router.push('/search')} /></View>
        <View className="mb-6 flex-row">
          {tags.map((tag) => <FilterChip key={tag} label={tag} active={activeTag === tag} onPress={() => setActiveTag(tag)} />)}
        </View>
        <SectionHeader title="Tüm notlar" action={sortAsc ? 'En yeni' : 'En eski'} onAction={() => setSortAsc((current) => !current)} />
        {notesQuery.isLoading ? (
          <View className="items-center py-16"><ActivityIndicator color={colors.primary} /></View>
        ) : visible.length === 0 ? (
          <EmptyState icon="note.text" title="Henüz not yok" description="Sağ alttaki butonla ilk notunu oluştur." />
        ) : (
          <View className="gap-3">
            {visible.map((note) => <SurfaceCard key={note.id} onPress={() => router.push({ pathname: '/note-editor', params: { id: String(note.id) } })} className="p-4"><View className="flex-row"><View style={{ backgroundColor: TAG_COLORS[note.tag] ?? colors.primary }} className="mr-3 mt-1 h-2.5 w-2.5 rounded-full" /><View className="flex-1"><View className="flex-row items-center justify-between"><Text className="flex-1 text-[16px] font-semibold text-foreground" numberOfLines={1}>{note.title}</Text><IconSymbol name="more" size={18} color={colors.muted} /></View><Text numberOfLines={2} className="mt-1 text-[13px] leading-5 text-muted">{note.body || 'Boş not'}</Text><View className="mt-3 flex-row items-center justify-between"><Text className="text-[11px] text-muted">{formatDate(note.updatedAt)}</Text><View className="rounded-full bg-background px-2.5 py-1"><Text className="text-[11px] font-semibold text-muted">{note.tag}</Text></View></View></View></View></SurfaceCard>)}
          </View>
        )}
      </ScrollView>
      <FloatingActionButton label="Yeni not" onPress={() => router.push('/note-editor')} />
    </ScreenContainer>
  );
}
