import React from 'react';
import { View, StyleSheet, ActivityIndicator, Platform, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import { ScreenContainer } from '@/components/screen-container';
import { getApiBaseUrl } from '@/constants/oauth';

export default function NotebooksScreen() {
  const baseUrl = getApiBaseUrl();
  // On web a relative URL resolves against the current origin; native needs an absolute one.
  const webAppUrl = baseUrl || (Platform.OS === 'web' ? '/' : '');

  if (!webAppUrl) {
    return (
      <ScreenContainer className="flex-1 p-0" safeAreaClassName="flex-1">
        <View style={[styles.container, styles.loadingContainer]}>
          <Text style={styles.errorTitle}>Defterler yüklenemedi</Text>
          <Text style={styles.errorBody}>
            Sunucu adresi tanımlı değil. EXPO_PUBLIC_API_BASE_URL ortam değişkenini ayarlayın.
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="flex-1 p-0" safeAreaClassName="flex-1">
      <View style={styles.container}>
        <WebView
          source={{ uri: webAppUrl }}
          style={styles.webview}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          startInLoadingState={true}
          renderLoading={() => (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#3B82F6" />
            </View>
          )}
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  webview: {
    flex: 1,
  },
  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F172A',
    marginBottom: 8,
  },
  errorBody: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    paddingHorizontal: 32,
  },
});
