import { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, LayoutChangeEvent, Pressable, Text, TextInput, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import { router, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconButton } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';
import { layoutMindMap, NODE_H, NODE_W, type LayoutEdge, type LayoutNode } from '@/lib/mindmap/layout';
import { addChildNode, cloneTree, countNodes, recolorNode, removeNode, renameNode, reparentNode } from '@/lib/mindmap/tree';
import { NODE_COLORS, type MindMapNode, type MindMapType } from '@/shared/mindmap';

const PADDING = 90;

function edgePath(type: MindMapType, edge: LayoutEdge): string {
  const { from: a, to: b } = edge;
  if (type === 'fishbone' || type === 'timeline') {
    return `M ${a.x} ${a.y} L ${b.x} ${b.y}`;
  }
  if (type === 'brace') {
    const midX = (a.x + b.x) / 2;
    return `M ${a.x} ${a.y} L ${midX} ${a.y} L ${midX} ${b.y} L ${b.x} ${b.y}`;
  }
  if (type === 'org' || type === 'treetable') {
    const midY = (a.y + b.y) / 2;
    return `M ${a.x} ${a.y} C ${a.x} ${midY}, ${b.x} ${midY}, ${b.x} ${b.y}`;
  }
  const midX = (a.x + b.x) / 2;
  return `M ${a.x} ${a.y} C ${midX} ${a.y}, ${midX} ${b.y}, ${b.x} ${b.y}`;
}

export default function MindMapEditor() {
  const colors = useColors();
  const params = useLocalSearchParams<{ id: string }>();
  const mapId = Number(params.id);
  const utils = trpc.useUtils();
  const mapQuery = trpc.mindMaps.byId.useQuery({ id: mapId }, { enabled: Number.isFinite(mapId) });
  const updateMap = trpc.mindMaps.update.useMutation();
  const deleteMap = trpc.mindMaps.delete.useMutation({ onSuccess: () => utils.mindMaps.list.invalidate() });

  const [root, setRoot] = useState<MindMapNode | null>(null);
  const [type, setType] = useState<MindMapType>('mindmap');
  const [title, setTitle] = useState('');
  const hydrated = useRef(false);
  const past = useRef<MindMapNode[]>([]);
  const future = useRef<MindMapNode[]>([]);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<{ id: string; value: string } | null>(null);
  const [moveMode, setMoveMode] = useState(false);
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'idle'>('idle');

  useEffect(() => {
    if (mapQuery.data && !hydrated.current && mapQuery.data.data.kind === 'tree') {
      setRoot(mapQuery.data.data.root);
      setType(mapQuery.data.type);
      setTitle(mapQuery.data.title);
      hydrated.current = true;
    }
  }, [mapQuery.data]);

  const commit = (next: MindMapNode, pushHistory = true) => {
    if (pushHistory && root) {
      past.current.push(cloneTree(root));
      if (past.current.length > 50) past.current.shift();
      future.current = [];
    }
    setRoot(next);
  };

  const undo = () => {
    if (!root || past.current.length === 0) return;
    future.current.push(cloneTree(root));
    const prev = past.current.pop()!;
    setRoot(prev);
  };

  const redo = () => {
    if (!root || future.current.length === 0) return;
    past.current.push(cloneTree(root));
    const next = future.current.pop()!;
    setRoot(next);
  };

  // Debounced autosave whenever the tree changes.
  useEffect(() => {
    if (!root || !hydrated.current) return;
    setSaveState('saving');
    const timeout = setTimeout(() => {
      updateMap.mutate({ id: mapId, data: { kind: 'tree', root } }, { onSuccess: () => setSaveState('saved') });
    }, 700);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [root]);

  const layout = useMemo(() => (root ? layoutMindMap(type, root) : null), [root, type]);

  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedTranslateX = useSharedValue(0);
  const savedTranslateY = useSharedValue(0);
  const centered = useRef(false);
  const [viewport, setViewport] = useState({ w: 0, h: 0 });

  const onViewportLayout = (e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    setViewport({ w: width, h: height });
  };

  const originX = layout ? -layout.minX + PADDING : 0;
  const originY = layout ? -layout.minY + PADDING : 0;
  const contentW = layout ? layout.maxX - layout.minX + PADDING * 2 : 0;
  const contentH = layout ? layout.maxY - layout.minY + PADDING * 2 : 0;

  useEffect(() => {
    if (!centered.current && viewport.w > 0 && layout) {
      translateX.value = viewport.w / 2 - originX;
      translateY.value = viewport.h / 2 - originY;
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
      centered.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewport.w, viewport.h, root === null]);

  const panGesture = Gesture.Pan()
    .minDistance(6)
    .onUpdate((e) => {
      'worklet';
      translateX.value = savedTranslateX.value + e.translationX;
      translateY.value = savedTranslateY.value + e.translationY;
    })
    .onEnd(() => {
      'worklet';
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
    });

  const pinchGesture = Gesture.Pinch()
    .onUpdate((e) => {
      'worklet';
      const next = savedScale.value * e.scale;
      scale.value = Math.min(2.5, Math.max(0.4, next));
    })
    .onEnd(() => {
      'worklet';
      savedScale.value = scale.value;
    });

  const composedGesture = Gesture.Simultaneous(panGesture, pinchGesture);

  const canvasStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }, { translateY: translateY.value }, { scale: scale.value }],
  }));

  const resetView = () => {
    scale.value = withTiming(1);
    savedScale.value = 1;
    translateX.value = withTiming(viewport.w / 2 - originX);
    translateY.value = withTiming(viewport.h / 2 - originY);
    savedTranslateX.value = viewport.w / 2 - originX;
    savedTranslateY.value = viewport.h / 2 - originY;
  };

  if (mapQuery.isLoading || !root || !layout) {
    return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  }

  const selectedNode: LayoutNode | undefined = layout.nodes.find((n) => n.id === selectedId);
  const isRootSelected = selectedId === root.id;

  const handleSelect = (node: LayoutNode) => {
    if (moveMode) {
      if (node.id === selectedId) {
        setMoveMode(false);
        return;
      }
      const next = reparentNode(root, selectedId!, node.id);
      commit(next);
      setMoveMode(false);
      return;
    }
    setSelectedId(node.id === selectedId ? null : node.id);
  };

  const startRename = (node: LayoutNode) => setRenaming({ id: node.id, value: node.node.title });

  const confirmRename = () => {
    if (!renaming) return;
    commit(renameNode(root, renaming.id, renaming.value.trim() || 'Adsız'));
    setRenaming(null);
  };

  const handleAddChild = () => {
    if (!selectedId) return;
    const { root: next, childId } = addChildNode(root, selectedId, 'Yeni düğüm');
    commit(next);
    setSelectedId(childId);
    setRenaming({ id: childId, value: 'Yeni düğüm' });
  };

  const handleDelete = () => {
    if (!selectedId || isRootSelected) return;
    Alert.alert('Düğümü sil', 'Bu düğüm ve alt düğümleri silinecek.', [
      { text: 'Vazgeç', style: 'cancel' },
      {
        text: 'Sil',
        style: 'destructive',
        onPress: () => {
          commit(removeNode(root, selectedId));
          setSelectedId(null);
        },
      },
    ]);
  };

  const handleRecolor = () => {
    if (!selectedId) return;
    const current = selectedNode?.node.color ?? NODE_COLORS[0];
    const idx = NODE_COLORS.indexOf(current as (typeof NODE_COLORS)[number]);
    const nextColor = NODE_COLORS[(idx + 1) % NODE_COLORS.length];
    commit(recolorNode(root, selectedId, nextColor), false);
  };

  const handleDeleteMap = () => {
    Alert.alert('Zihin haritasını sil', 'Bu harita kalıcı olarak silinecek.', [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: () => deleteMap.mutate({ id: mapId }, { onSuccess: () => router.back() }) },
    ]);
  };

  return (
    <ScreenContainer edges={['top', 'left', 'right', 'bottom']}>
      <View className="flex-row items-center justify-between px-4 py-3">
        <IconButton name="arrow.left" label="Geri" onPress={() => router.back()} />
        <Text numberOfLines={1} className="mx-2 flex-1 text-center text-[15px] font-semibold text-foreground">{title}</Text>
        <View className="flex-row items-center gap-3">
          <Pressable onPress={undo} disabled={past.current.length === 0} hitSlop={6}>
            <IconSymbol name="undo" size={20} color={past.current.length === 0 ? colors.border : colors.foreground} />
          </Pressable>
          <Pressable onPress={redo} disabled={future.current.length === 0} hitSlop={6}>
            <IconSymbol name="redo" size={20} color={future.current.length === 0 ? colors.border : colors.foreground} />
          </Pressable>
          <IconButton name="delete" label="Haritayı sil" onPress={handleDeleteMap} />
        </View>
      </View>

      {moveMode ? (
        <View className="mx-4 mb-2 flex-row items-center justify-between rounded-xl bg-background px-3 py-2">
          <Text className="flex-1 text-[12px] text-muted">Taşımak için hedef düğüme dokun.</Text>
          <Pressable onPress={() => setMoveMode(false)}><Text className="text-[12px] font-semibold" style={{ color: colors.primary }}>Vazgeç</Text></Pressable>
        </View>
      ) : null}

      <View className="flex-1 overflow-hidden" onLayout={onViewportLayout}>
        <GestureDetector gesture={composedGesture}>
          <Animated.View style={[{ width: contentW, height: contentH }, canvasStyle]}>
            <Svg width={contentW} height={contentH} style={{ position: 'absolute', left: 0, top: 0 }}>
              {layout.edges.map((edge) => (
                <Path
                  key={edge.id}
                  d={edgePath(type, {
                    id: edge.id,
                    from: { x: edge.from.x + originX, y: edge.from.y + originY },
                    to: { x: edge.to.x + originX, y: edge.to.y + originY },
                  })}
                  stroke={colors.border}
                  strokeWidth={2}
                  fill="none"
                />
              ))}
            </Svg>
            {layout.nodes.map((node) => {
              const isSelected = node.id === selectedId;
              const isRoot = node.id === root.id;
              return (
                <Pressable
                  key={node.id}
                  onPress={() => handleSelect(node)}
                  onLongPress={() => startRename(node)}
                  style={{
                    position: 'absolute',
                    left: originX + node.x - NODE_W / 2,
                    top: originY + node.y - NODE_H / 2,
                    width: NODE_W,
                    minHeight: NODE_H,
                  }}
                >
                  <View
                    style={{
                      borderColor: isSelected ? colors.primary : colors.border,
                      borderWidth: isSelected ? 2 : 1,
                      backgroundColor: colors.surface,
                    }}
                    className="flex-row items-center rounded-2xl px-3 py-2.5"
                  >
                    <View style={{ backgroundColor: node.node.color ?? colors.primary }} className="mr-2 h-2 w-2 rounded-full" />
                    <Text numberOfLines={2} className={`flex-1 text-[13px] ${isRoot ? 'font-bold' : 'font-semibold'} text-foreground`}>
                      {node.node.title}
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </Animated.View>
        </GestureDetector>
      </View>

      <View className="absolute bottom-24 right-4">
        <Pressable onPress={resetView} style={{ backgroundColor: colors.surface, borderColor: colors.border }} className="h-11 w-11 items-center justify-center rounded-full border">
          <IconSymbol name="zoom-in" size={18} color={colors.foreground} />
        </Pressable>
      </View>

      {selectedNode ? (
        <View style={{ borderColor: colors.border, backgroundColor: colors.surface }} className="flex-row items-center justify-around border-t px-2 py-3">
          <Pressable onPress={() => startRename(selectedNode)} className="items-center px-2"><IconSymbol name="edit" size={20} color={colors.foreground} /><Text className="mt-1 text-[10px] text-muted">Ad</Text></Pressable>
          <Pressable onPress={handleAddChild} className="items-center px-2"><IconSymbol name="add-circle" size={20} color={colors.foreground} /><Text className="mt-1 text-[10px] text-muted">Alt düğüm</Text></Pressable>
          <Pressable onPress={() => setMoveMode(true)} className="items-center px-2" disabled={isRootSelected}>
            <IconSymbol name="device-hub" size={20} color={isRootSelected ? colors.border : colors.foreground} />
            <Text className="mt-1 text-[10px] text-muted">Taşı</Text>
          </Pressable>
          <Pressable onPress={handleRecolor} className="items-center px-2"><IconSymbol name="palette" size={20} color={colors.foreground} /><Text className="mt-1 text-[10px] text-muted">Renk</Text></Pressable>
          <Pressable onPress={handleDelete} className="items-center px-2" disabled={isRootSelected}>
            <IconSymbol name="delete" size={20} color={isRootSelected ? colors.border : colors.error} />
            <Text className="mt-1 text-[10px]" style={{ color: isRootSelected ? colors.muted : colors.error }}>Sil</Text>
          </Pressable>
        </View>
      ) : (
        <View style={{ borderColor: colors.border }} className="items-center border-t px-2 py-2">
          <Text className="text-[11px] text-muted">{saveState === 'saving' ? 'Kaydediliyor...' : `${countNodes(root)} düğüm · Kaydedildi`}</Text>
        </View>
      )}

      {renaming ? (
        <View className="absolute inset-0 items-center justify-center bg-black/40 px-8">
          <View style={{ backgroundColor: colors.surface }} className="w-full rounded-2xl p-4">
            <Text className="mb-2 text-[12px] font-semibold text-muted">Düğüm adı</Text>
            <TextInput
              autoFocus
              value={renaming.value}
              onChangeText={(value) => setRenaming({ id: renaming.id, value })}
              onSubmitEditing={confirmRename}
              placeholderTextColor={colors.muted}
              className="mb-4 rounded-xl border border-border px-3 py-2.5 text-[15px] text-foreground"
            />
            <View className="flex-row justify-end gap-4">
              <Pressable onPress={() => setRenaming(null)}><Text className="text-[13px] text-muted">Vazgeç</Text></Pressable>
              <Pressable onPress={confirmRename}><Text className="text-[13px] font-semibold" style={{ color: colors.primary }}>Kaydet</Text></Pressable>
            </View>
          </View>
        </View>
      ) : null}
    </ScreenContainer>
  );
}
