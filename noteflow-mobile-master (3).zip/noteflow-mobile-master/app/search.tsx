import { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { FilterChip, IconButton, SurfaceCard } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

type ResultItem = { key: string; title: string; type: 'Not' | 'Görev'; detail: string; icon: 'note.text' | 'checkmark.circle.fill'; onPress: () => void };

export default function SearchScreen() {
  const colors = useColors();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('Tümü');
  const notesQuery = trpc.notes.list.useQuery();
  const tasksQuery = trpc.tasks.list.useQuery();
  const isLoading = notesQuery.isLoading || tasksQuery.isLoading;

  const results = useMemo<ResultItem[]>(() => {
    const noteItems: ResultItem[] = (notesQuery.data ?? []).map((note) => ({
      key: `note-${note.id}`,
      title: note.title,
      type: 'Not',
      detail: note.body || note.tag,
      icon: 'note.text',
      onPress: () => router.push({ pathname: '/note-editor', params: { id: String(note.id) } }),
    }));
    const taskItems: ResultItem[] = (tasksQuery.data ?? []).map((task) => ({
      key: `task-${task.id}`,
      title: task.title,
      type: 'Görev',
      detail: task.dueDate ? `${task.dueDate}${task.dueTime ? ` · ${task.dueTime}` : ''}` : task.list,
      icon: 'checkmark.circle.fill',
      onPress: () => router.push('/(tabs)/tasks'),
    }));
    return [...noteItems, ...taskItems];
  }, [notesQuery.data, tasksQuery.data]);

  const filtered = useMemo(
    () => results.filter((item) => (filter === 'Tümü' || item.type === filter) && (query.length === 0 || `${item.title} ${item.detail}`.toLocaleLowerCase('tr').includes(query.toLocaleLowerCase('tr')))),
    [results, query, filter],
  );

  return <ScreenContainer className="px-5"><View className="flex-row items-center py-3"><IconButton name="arrow.left" label="Geri" onPress={() => router.back()} /><Text className="ml-4 text-[17px] font-semibold text-foreground">Gelişmiş arama</Text></View><View className="mt-5 h-14 flex-row items-center rounded-2xl border border-border bg-surface px-4"><IconSymbol name="magnifyingglass" size={21} color={colors.muted} /><TextInput autoFocus value={query} onChangeText={setQuery} placeholder="Ara..." placeholderTextColor={colors.muted} className="ml-3 flex-1 text-[15px] text-foreground" /><Pressable onPress={() => setQuery('')} style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}><IconSymbol name="close" size={18} color={colors.muted} /></Pressable></View><ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-1 mt-5"><FilterChip label="Tümü" active={filter === 'Tümü'} onPress={() => setFilter('Tümü')} /><FilterChip label="Not" active={filter === 'Not'} onPress={() => setFilter('Not')} /><FilterChip label="Görev" active={filter === 'Görev'} onPress={() => setFilter('Görev')} /></ScrollView><Text className="mb-3 mt-8 text-[13px] font-semibold uppercase tracking-[1px] text-muted">{query ? 'Eşleşen sonuçlar' : 'Tümü'}</Text>{isLoading ? <View className="items-center py-16"><ActivityIndicator color={colors.primary} /></View> : <View className="gap-3">{filtered.map((item) => <SurfaceCard key={item.key} onPress={item.onPress} className="flex-row items-center p-4"><View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-background"><IconSymbol name={item.icon} size={19} color={colors.primary} /></View><View className="flex-1"><Text className="text-[14px] font-semibold text-foreground" numberOfLines={1}>{item.title}</Text><Text numberOfLines={1} className="mt-1 text-[12px] text-muted">{item.detail}</Text></View><IconSymbol name="chevron.right" size={18} color={colors.muted} /></SurfaceCard>)}</View>}{!isLoading && filtered.length === 0 ? <View className="items-center py-16"><IconSymbol name="magnifyingglass" size={30} color={colors.muted} /><Text className="mt-3 text-[15px] font-semibold text-foreground">Sonuç bulunamadı</Text><Text className="mt-1 text-[13px] text-muted">Farklı bir arama deneyin.</Text></View> : null}</ScreenContainer>;
}
