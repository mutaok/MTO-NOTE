import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconButton, PrimaryButton, SurfaceCard } from '@/components/ui/nf-ui';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

const LISTS = ['Kişisel', 'İş'] as const;
const LIST_COLORS: Record<string, string> = { Kişisel: '#7BC7A6', İş: '#64B5F6' };

function dueDateFor(option: 'Bugün' | 'Yarın'): string {
  const date = new Date();
  if (option === 'Yarın') date.setDate(date.getDate() + 1);
  return date.toISOString().slice(0, 10);
}

export default function TaskEditor() {
  const colors = useColors();
  const utils = trpc.useUtils();
  const createTask = trpc.tasks.create.useMutation({ onSuccess: () => utils.tasks.list.invalidate() });

  const [title, setTitle] = useState('');
  const [dateOption, setDateOption] = useState<'Bugün' | 'Yarın'>('Bugün');
  const [list, setList] = useState<(typeof LISTS)[number]>('Kişisel');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!title.trim()) return;
    createTask.mutate(
      { title, list, dueDate: dueDateFor(dateOption), dueTime: null, color: LIST_COLORS[list] },
      {
        onSuccess: () => {
          setSaved(true);
          router.back();
        },
      },
    );
  };

  return <ScreenContainer edges={['top', 'left', 'right', 'bottom']} className="px-5"><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1"><View className="flex-row items-center justify-between py-3"><IconButton name="arrow.left" label="Geri" onPress={() => router.back()} /><Text className="text-[15px] font-semibold text-foreground">Yeni görev</Text><IconButton name="close" label="Kapat" onPress={() => router.back()} /></View><View className="pt-12"><Text className="mb-3 text-[13px] font-semibold uppercase tracking-[1.2px] text-muted">Görev detayı</Text><TextInput autoFocus value={title} onChangeText={setTitle} placeholder="Ne yapılması gerekiyor?" placeholderTextColor={colors.muted} className="border-b border-border pb-4 text-[24px] font-semibold text-foreground" /><Text className="mb-3 mt-9 text-[15px] font-semibold text-foreground">Planlama</Text><View className="gap-3"><SurfaceCard className="flex-row items-center p-4"><View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-background"><IconSymbol name="calendar" size={20} color={colors.primary} /></View><View className="flex-1"><Text className="text-[14px] font-semibold text-foreground">Tarih</Text><Text className="mt-1 text-[12px] text-muted">Görevin zamanı</Text></View><View className="flex-row gap-2">{(['Bugün', 'Yarın'] as const).map((item) => <Pressable key={item} onPress={() => setDateOption(item)} style={({ pressed }) => [{ backgroundColor: dateOption === item ? colors.primary : colors.background, opacity: pressed ? 0.7 : 1 }]} className="rounded-full px-3 py-2"><Text className="text-[11px] font-semibold text-slate-950">{item}</Text></Pressable>)}</View></SurfaceCard><Pressable onPress={() => setList((current) => LISTS[(LISTS.indexOf(current) + 1) % LISTS.length])}><SurfaceCard className="flex-row items-center p-4"><View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-background"><IconSymbol name="tag" size={20} color={colors.primary} /></View><View className="flex-1"><Text className="text-[14px] font-semibold text-foreground">Liste</Text><Text className="mt-1 text-[12px] text-muted">{list}</Text></View><IconSymbol name="chevron.right" size={18} color={colors.muted} /></SurfaceCard></Pressable></View></View><View className="mt-auto pb-8"><Text className="mb-3 text-center text-[12px] text-muted">{saved ? 'Görev kaydedildi.' : createTask.isPending ? 'Kaydediliyor...' : 'Hazır olduğunda kaydet.'}</Text><PrimaryButton label="Görevi kaydet" icon="checkmark.circle.fill" onPress={handleSave} /></View></KeyboardAvoidingView></ScreenContainer>;
}
