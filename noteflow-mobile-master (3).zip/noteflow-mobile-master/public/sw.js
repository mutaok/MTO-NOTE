const CACHE_NAME = 'noteflow-v1';

self.addEventListener('install', (e) => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(clients.claim());
});

self.addEventListener('fetch', (e) => {
  // Let network handle by default, fallback to network
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request) as Promise<Response>)
  );
});
