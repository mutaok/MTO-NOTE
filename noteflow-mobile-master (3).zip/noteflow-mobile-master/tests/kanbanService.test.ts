import { describe, it, expect, beforeEach, beforeAll } from 'vitest';
import { KanbanService } from '../src/lib/kanban/kanbanService';
import { StorageService } from '../src/data/storage';

const memoryStore: Record<string, string> = {};

beforeAll(() => {
  if (typeof globalThis.localStorage === 'undefined') {
    globalThis.localStorage = {
      getItem: (key: string) => memoryStore[key] ?? null,
      setItem: (key: string, val: string) => {
        memoryStore[key] = String(val);
      },
      removeItem: (key: string) => {
        delete memoryStore[key];
      },
      clear: () => {
        for (const k in memoryStore) delete memoryStore[k];
      },
      key: (i: number) => Object.keys(memoryStore)[i] ?? null,
      length: 0,
    } as Storage;
  }
});

describe('KanbanService CRUD, Atomic Moves, and Rollback', () => {
  beforeEach(() => {
    // Reset local data to clean initial state
    globalThis.localStorage.clear();
  });

  it('creates board and auto-creates 3 default lists', () => {
    const board = KanbanService.createBoard('Test Proje Panosu', 'Açıklama');
    expect(board.title).toBe('Test Proje Panosu');
    expect(board.id).toBeDefined();

    const lists = KanbanService.getLists(board.id);
    expect(lists.length).toBe(3);
    expect(lists[0].position).toBe(65536);
    expect(lists[1].position).toBe(131072);
    expect(lists[2].position).toBe(196608);
  });

  it('creates cards with incremental 65536 positions', () => {
    const board = KanbanService.createBoard('Sprint Pano');
    const lists = KanbanService.getLists(board.id);
    const listId = lists[0].id;

    const card1 = KanbanService.createCard(listId, 'Kart 1', undefined, board.id);
    const card2 = KanbanService.createCard(listId, 'Kart 2', undefined, board.id);
    const card3 = KanbanService.createCard(listId, 'Kart 3', undefined, board.id);

    expect(card1.position).toBe(65536);
    expect(card2.position).toBe(131072);
    expect(card3.position).toBe(196608);
  });

  it('moveCard updates ONLY target card list_id and position', () => {
    const board = KanbanService.createBoard('Taşıma Testi');
    const lists = KanbanService.getLists(board.id);
    const listA = lists[0].id;
    const listB = lists[1].id;

    const c1 = KanbanService.createCard(listA, 'Kart A1');
    const c2 = KanbanService.createCard(listA, 'Kart A2');
    const cB1 = KanbanService.createCard(listB, 'Kart B1');

    // Move c1 to listB between 0 and cB1 (prepend)
    const newPos = cB1.position / 2; // 32768
    const { updatedCard } = KanbanService.moveCard(c1.id, listB, newPos, board.id);

    expect(updatedCard.list_id).toBe(listB);
    expect(updatedCard.position).toBe(32768);

    // c2 remains in listA with unchanged position!
    const cards = KanbanService.getCards(board.id);
    const c2Updated = cards.find((c) => c.id === c2.id);
    expect(c2Updated?.list_id).toBe(listA);
    expect(c2Updated?.position).toBe(131072);
  });

  it('supports snapshot creation and rollback', () => {
    const board = KanbanService.createBoard('Rollback Testi');
    const snapshot = KanbanService.createSnapshot();

    // Mutate state
    const lists = KanbanService.getLists(board.id);
    KanbanService.createCard(lists[0].id, 'Geçici Kart');
    expect(KanbanService.getCards(board.id).length).toBeGreaterThan(0);

    // Rollback
    KanbanService.restoreSnapshot(snapshot);
    expect(KanbanService.getCards(board.id).length).toBe(0);
  });
});
