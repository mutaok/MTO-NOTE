import { describe, it, expect } from 'vitest';
import {
  calculateAppendPosition,
  calculatePrependPosition,
  calculateBetweenPosition,
  calculateInsertPosition,
  normalizePositions,
  INITIAL_SPACING,
  MIN_GAP,
} from '../src/lib/kanban/ranking';

describe('Kanban Trello-Style Ranking Algorithm', () => {
  describe('calculateAppendPosition', () => {
    it('returns INITIAL_SPACING (65536) for empty or undefined last position', () => {
      expect(calculateAppendPosition(undefined)).toBe(INITIAL_SPACING);
      expect(calculateAppendPosition(0)).toBe(INITIAL_SPACING);
    });

    it('adds 65536 to the last position', () => {
      expect(calculateAppendPosition(65536)).toBe(131072);
      expect(calculateAppendPosition(131072)).toBe(196608);
      expect(calculateAppendPosition(200000)).toBe(200000 + 65536);
    });
  });

  describe('calculatePrependPosition', () => {
    it('returns INITIAL_SPACING for empty list', () => {
      const result = calculatePrependPosition(undefined);
      expect(result.position).toBe(INITIAL_SPACING);
      expect(result.needsNormalization).toBe(false);
    });

    it('divides first position by 2 when prepending', () => {
      const result = calculatePrependPosition(65536);
      expect(result.position).toBe(32768);
      expect(result.needsNormalization).toBe(false);
    });

    it('flags needsNormalization when position becomes smaller than MIN_GAP', () => {
      const result = calculatePrependPosition(0.000005);
      expect(result.position).toBeLessThan(MIN_GAP);
      expect(result.needsNormalization).toBe(true);
    });
  });

  describe('calculateBetweenPosition', () => {
    it('calculates average between two items', () => {
      const result = calculateBetweenPosition(65536, 131072);
      expect(result.position).toBe((65536 + 131072) / 2);
      expect(result.position).toBe(98304);
      expect(result.needsNormalization).toBe(false);
    });

    it('flags needsNormalization when difference between items is less than MIN_GAP (0.00001)', () => {
      const prev = 100.0;
      const next = 100.000008; // gap is 0.000008 < 0.00001
      const result = calculateBetweenPosition(prev, next);
      expect(result.needsNormalization).toBe(true);
      expect(result.position).toBeCloseTo((prev + next) / 2, 8);
    });

    it('flags needsNormalization if prev >= next (corrupted order)', () => {
      const result = calculateBetweenPosition(200, 100);
      expect(result.needsNormalization).toBe(true);
    });
  });

  describe('calculateInsertPosition', () => {
    const items = [
      { id: '1', position: 65536 },
      { id: '2', position: 131072 },
      { id: '3', position: 196608 },
    ];

    it('handles insert at index 0 (prepend)', () => {
      const result = calculateInsertPosition(items, 0);
      expect(result.position).toBe(32768);
      expect(result.needsNormalization).toBe(false);
    });

    it('handles insert at end (append)', () => {
      const result = calculateInsertPosition(items, 3);
      expect(result.position).toBe(196608 + 65536);
      expect(result.needsNormalization).toBe(false);
    });

    it('handles insert in middle between index 0 and index 1', () => {
      const result = calculateInsertPosition(items, 1);
      expect(result.position).toBe((65536 + 131072) / 2);
      expect(result.needsNormalization).toBe(false);
    });

    it('handles empty list', () => {
      const result = calculateInsertPosition([], 0);
      expect(result.position).toBe(INITIAL_SPACING);
      expect(result.needsNormalization).toBe(false);
    });
  });

  describe('normalizePositions', () => {
    it('renumbers items with clean 65536 multiples while preserving relative order', () => {
      const squishedItems = [
        { id: 'card-a', position: 100.000001 },
        { id: 'card-b', position: 100.000002 },
        { id: 'card-c', position: 100.000003 },
      ];

      const normalized = normalizePositions(squishedItems);
      expect(normalized).toEqual([
        { id: 'card-a', position: 65536 },
        { id: 'card-b', position: 131072 },
        { id: 'card-c', position: 196608 },
      ]);
    });

    it('sorts correctly even if input order was unsorted', () => {
      const unsorted = [
        { id: '3', position: 500 },
        { id: '1', position: 100 },
        { id: '2', position: 300 },
      ];
      const normalized = normalizePositions(unsorted);
      expect(normalized.map((x) => x.id)).toEqual(['1', '2', '3']);
      expect(normalized[0].position).toBe(65536);
      expect(normalized[1].position).toBe(131072);
      expect(normalized[2].position).toBe(196608);
    });
  });
});
