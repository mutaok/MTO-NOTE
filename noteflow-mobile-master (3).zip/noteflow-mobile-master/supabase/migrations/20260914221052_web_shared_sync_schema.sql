-- =============================================================================
-- NoteFlow · Web uygulaması (Vite) için paylaşılan şema eklentileri
--
-- Flutter uygulamasının (NOTEFLOW\noteflow) kullandığı sütunlara ve kurallara
-- dokunmaz; yalnızca ekler. Flutter push'u yalnızca kendi sütunlarını upsert
-- ettiği için yeni sütunlar onun yazmalarında korunur.
--
--   * notebooks.meta, notes.meta : web'e özgü alanlar (tür, ikon, Cornell vb.)
--   * notes.tag, notes.note_date : web'deki etiket ve takvim günü
--   * tasks, mind_maps           : Flutter'da karşılığı olmayan varlıklar
--   * app_documents              : web çalışma alanlarının anahtar-değer verileri
--
-- Yeni tablolar başlangıç şemasının kurallarını izler: RLS (yalnızca kendi
-- satırların), sync_row_guard (last-write-wins + server_updated_at),
-- yumuşak silme (deleted_at) ve Realtime.
-- =============================================================================

-- 1) Mevcut tablolara web alanları ---------------------------------------------

alter table public.notebooks
  add column meta jsonb not null default '{}'::jsonb;

alter table public.notes
  add column tag       text check (tag is null or char_length(tag) <= 64),
  add column note_date date,
  add column meta      jsonb not null default '{}'::jsonb;

-- 2) Yeni tablolar ------------------------------------------------------------------

create table public.tasks (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  notebook_id       uuid references public.notebooks (id) on delete set null,
  title             text not null check (char_length(title) between 1 and 500),
  list              text not null default 'Kişisel' check (char_length(list) <= 64),
  due_date          date,
  due_time          text check (due_time is null or due_time ~ '^[0-2][0-9]:[0-5][0-9]$'),
  done              boolean not null default false,
  color             text check (color is null or char_length(color) <= 32),
  meta              jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  deleted_at        timestamptz
);

create table public.mind_maps (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  notebook_id       uuid references public.notebooks (id) on delete set null,
  title             text not null default '' check (char_length(title) <= 300),
  type              text not null check (char_length(type) between 1 and 24),
  data              jsonb not null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  deleted_at        timestamptz
);

-- Anahtar örn. 'noteflow_flashcards'; değer o anahtarın tüm JSON içeriği.
create table public.app_documents (
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  key               text not null check (key ~ '^[a-z0-9_]{1,64}$'),
  data              jsonb not null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

create index tasks_user_sync_idx         on public.tasks (user_id, server_updated_at);
create index tasks_notebook_id_idx       on public.tasks (notebook_id);
create index mind_maps_user_sync_idx     on public.mind_maps (user_id, server_updated_at);
create index mind_maps_notebook_id_idx   on public.mind_maps (notebook_id);
create index app_documents_user_sync_idx on public.app_documents (user_id, server_updated_at);

-- 3) Tetikleyiciler (başlangıç şemasındaki sync_row_guard) -----------------------

create trigger tasks_sync_row_guard
  before insert or update on public.tasks
  for each row execute function public.sync_row_guard();

create trigger mind_maps_sync_row_guard
  before insert or update on public.mind_maps
  for each row execute function public.sync_row_guard();

create trigger app_documents_sync_row_guard
  before insert or update on public.app_documents
  for each row execute function public.sync_row_guard();

-- 4) Row Level Security ------------------------------------------------------------

alter table public.tasks         enable row level security;
alter table public.mind_maps     enable row level security;
alter table public.app_documents enable row level security;

-- tasks (bir görev yalnızca kullanıcının kendi defterine bağlanabilir)
create policy tasks_select_own on public.tasks
  for select to authenticated
  using ((select auth.uid()) = user_id);

create policy tasks_insert_own on public.tasks
  for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and (
      tasks.notebook_id is null
      or exists (
        select 1 from public.notebooks nb
        where nb.id = tasks.notebook_id and nb.user_id = (select auth.uid())
      )
    )
  );

create policy tasks_update_own on public.tasks
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check (
    (select auth.uid()) = user_id
    and (
      tasks.notebook_id is null
      or exists (
        select 1 from public.notebooks nb
        where nb.id = tasks.notebook_id and nb.user_id = (select auth.uid())
      )
    )
  );

create policy tasks_delete_own on public.tasks
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- mind_maps
create policy mind_maps_select_own on public.mind_maps
  for select to authenticated
  using ((select auth.uid()) = user_id);

create policy mind_maps_insert_own on public.mind_maps
  for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and (
      mind_maps.notebook_id is null
      or exists (
        select 1 from public.notebooks nb
        where nb.id = mind_maps.notebook_id and nb.user_id = (select auth.uid())
      )
    )
  );

create policy mind_maps_update_own on public.mind_maps
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check (
    (select auth.uid()) = user_id
    and (
      mind_maps.notebook_id is null
      or exists (
        select 1 from public.notebooks nb
        where nb.id = mind_maps.notebook_id and nb.user_id = (select auth.uid())
      )
    )
  );

create policy mind_maps_delete_own on public.mind_maps
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- app_documents
create policy app_documents_select_own on public.app_documents
  for select to authenticated
  using ((select auth.uid()) = user_id);

create policy app_documents_insert_own on public.app_documents
  for insert to authenticated
  with check ((select auth.uid()) = user_id);

create policy app_documents_update_own on public.app_documents
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy app_documents_delete_own on public.app_documents
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- 5) Yetkiler ----------------------------------------------------------------------

revoke all on public.tasks, public.mind_maps, public.app_documents from anon;
grant select, insert, update, delete on public.tasks, public.mind_maps, public.app_documents to authenticated;

-- 6) Realtime ----------------------------------------------------------------------

alter publication supabase_realtime add table public.tasks, public.mind_maps, public.app_documents;
