-- =============================================================================
-- NoteFlow · Trello Kanban Board Schema & Realtime Sync Migration
-- =============================================================================

-- 1) Tablolar -----------------------------------------------------------------

create table if not exists public.kanban_boards (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  title             text not null check (char_length(title) between 1 and 300),
  description       text,
  color             text check (color is null or char_length(color) <= 32),
  archived          boolean not null default false,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  deleted_at        timestamptz
);

create table if not exists public.kanban_lists (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  board_id          uuid not null references public.kanban_boards (id) on delete cascade,
  title             text not null check (char_length(title) between 1 and 300),
  position          double precision not null default 65536,
  archived          boolean not null default false,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  deleted_at        timestamptz
);

create table if not exists public.kanban_cards (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  list_id           uuid not null references public.kanban_lists (id) on delete cascade,
  title             text not null check (char_length(title) between 1 and 500),
  description       text,
  position          double precision not null default 65536,
  due_date          date,
  labels            jsonb not null default '[]'::jsonb,
  checklist         jsonb not null default '[]'::jsonb,
  comments          jsonb not null default '[]'::jsonb,
  attachments       jsonb not null default '[]'::jsonb,
  archived          boolean not null default false,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  server_updated_at timestamptz not null default now(),
  deleted_at        timestamptz
);

create table if not exists public.kanban_activities (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  board_id          uuid not null references public.kanban_boards (id) on delete cascade,
  card_id           uuid references public.kanban_cards (id) on delete set null,
  card_title        text,
  action            text not null,
  details           text not null,
  user_name         text not null default 'Kullanıcı',
  created_at        timestamptz not null default now()
);

-- 2) İndeksler ----------------------------------------------------------------

create index if not exists kanban_boards_user_sync_idx   on public.kanban_boards (user_id, server_updated_at);
create index if not exists kanban_lists_board_pos_idx    on public.kanban_lists (board_id, position);
create index if not exists kanban_cards_list_pos_idx     on public.kanban_cards (list_id, position);
create index if not exists kanban_activities_board_idx   on public.kanban_activities (board_id, created_at desc);

-- 3) Tetikleyiciler -----------------------------------------------------------

create trigger kanban_boards_sync_row_guard
  before insert or update on public.kanban_boards
  for each row execute function public.sync_row_guard();

create trigger kanban_lists_sync_row_guard
  before insert or update on public.kanban_lists
  for each row execute function public.sync_row_guard();

create trigger kanban_cards_sync_row_guard
  before insert or update on public.kanban_cards
  for each row execute function public.sync_row_guard();

-- 4) Row Level Security (RLS) -------------------------------------------------

alter table public.kanban_boards     enable row level security;
alter table public.kanban_lists      enable row level security;
alter table public.kanban_cards      enable row level security;
alter table public.kanban_activities enable row level security;

create policy kanban_boards_own on public.kanban_boards
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy kanban_lists_own on public.kanban_lists
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy kanban_cards_own on public.kanban_cards
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy kanban_activities_own on public.kanban_activities
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
