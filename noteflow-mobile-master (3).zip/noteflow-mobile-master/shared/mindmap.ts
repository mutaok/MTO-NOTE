/**
 * Domain model for the Mind Map feature. Based on the diagram-type inventory
 * in xmind-android-teknik-rapor.md: 10 structures split into two render
 * families — a tree/canvas family (n-ary tree, auto-laid-out) and a
 * table/grid family (2D rows x cols). Logic Chart's crossLinks (DAG) and
 * Tree Table's per-node attribute columns are intentionally not modeled —
 * both would need bespoke editor UI beyond what this pass covers, so those
 * two types render as plain trees / plain grids for now.
 */

export type MindMapType =
  | "mindmap"
  | "logic"
  | "brace"
  | "org"
  | "tree"
  | "timeline"
  | "fishbone"
  | "treetable"
  | "matrix"
  | "grid";

export type MindMapNode = {
  id: string;
  title: string;
  notes?: string;
  color?: string;
  children: MindMapNode[];
};

export type MindMapTreeDoc = {
  kind: "tree";
  root: MindMapNode;
};

export type MindMapTableDoc = {
  kind: "table";
  rows: string[];
  cols: string[];
  cells: Record<string, string>;
};

export type MindMapDoc = MindMapTreeDoc | MindMapTableDoc;

export const TABLE_TYPES: readonly MindMapType[] = ["matrix", "grid"];

export function isTableType(type: MindMapType): boolean {
  return TABLE_TYPES.includes(type);
}

export const NODE_COLORS = ["#64B5F6", "#7BC7A6", "#F2B880", "#A68BDB", "#F28B82"] as const;

let idCounter = 0;
export function makeNodeId(): string {
  idCounter += 1;
  return `n${Date.now().toString(36)}${idCounter}`;
}

export function makeNode(title: string, children: MindMapNode[] = [], color?: string): MindMapNode {
  return { id: makeNodeId(), title, children, color };
}

export type MindMapTemplateIcon =
  | "hub"
  | "account-tree"
  | "device-hub"
  | "schema"
  | "timeline"
  | "table"
  | "grid-on"
  | "call-split";

export type MindMapTemplate = {
  type: MindMapType;
  label: string;
  description: string;
  icon: MindMapTemplateIcon;
  createDoc: () => MindMapDoc;
};

function treeDoc(root: MindMapNode): MindMapTreeDoc {
  return { kind: "tree", root };
}

function tableDoc(rows: string[], cols: string[]): MindMapTableDoc {
  return { kind: "table", rows, cols, cells: {} };
}

export const MIND_MAP_TEMPLATES: MindMapTemplate[] = [
  {
    type: "mindmap",
    label: "Zihin Haritası",
    description: "Kök + çok çocuklu ağaç, iki yönlü dallanma",
    icon: "hub",
    createDoc: () =>
      treeDoc(
        makeNode("Ana Fikir", [
          makeNode("Dal 1", [], NODE_COLORS[0]),
          makeNode("Dal 2", [], NODE_COLORS[1]),
          makeNode("Dal 3", [], NODE_COLORS[2]),
        ]),
      ),
  },
  {
    type: "logic",
    label: "Mantık Şeması",
    description: "Soldan sağa katmanlı akış",
    icon: "device-hub",
    createDoc: () =>
      treeDoc(
        makeNode("Başlangıç", [makeNode("Adım 1", [makeNode("Adım 2", [])])]),
      ),
  },
  {
    type: "brace",
    label: "Parantez (Küme) Haritası",
    description: "Parça-bütün ağacı, iç içe gruplar",
    icon: "call-split",
    createDoc: () =>
      treeDoc(
        makeNode("Bütün", [makeNode("Parça 1", []), makeNode("Parça 2", []), makeNode("Parça 3", [])]),
      ),
  },
  {
    type: "org",
    label: "Organizasyon Şeması",
    description: "Katı hiyerarşik ağaç, dikey kutu-çizgi",
    icon: "account-tree",
    createDoc: () =>
      treeDoc(
        makeNode("Genel Müdür", [makeNode("Departman A", []), makeNode("Departman B", [])]),
      ),
  },
  {
    type: "tree",
    label: "Ağaç Şeması",
    description: "Klasik n-ary ağaç, üstten alta",
    icon: "account-tree",
    createDoc: () => treeDoc(makeNode("Kök", [makeNode("Çocuk 1", []), makeNode("Çocuk 2", [])])),
  },
  {
    type: "timeline",
    label: "Zaman Çizelgesi",
    description: "Kronolojik, tek eksende sıralı düğümler",
    icon: "timeline",
    createDoc: () =>
      treeDoc(
        makeNode("Zaman Çizelgesi", [makeNode("1. Aşama", []), makeNode("2. Aşama", []), makeNode("3. Aşama", [])]),
      ),
  },
  {
    type: "fishbone",
    label: "Kılçık Diyagramı",
    description: "Merkezi omurga + açılı kaburga dalları",
    icon: "schema",
    createDoc: () =>
      treeDoc(
        makeNode("Etki / Sonuç", [
          makeNode("Kategori 1", [makeNode("Neden", [])]),
          makeNode("Kategori 2", [makeNode("Neden", [])]),
          makeNode("Kategori 3", [makeNode("Neden", [])]),
          makeNode("Kategori 4", [makeNode("Neden", [])]),
        ]),
      ),
  },
  {
    type: "treetable",
    label: "Ağaç Tablosu",
    description: "Hiyerarşi + sütunlu veri (basitleştirilmiş: ağaç)",
    icon: "account-tree",
    createDoc: () => treeDoc(makeNode("Kök", [makeNode("Öğe 1", []), makeNode("Öğe 2", [])])),
  },
  {
    type: "matrix",
    label: "Matris",
    description: "Satır/sütun başlıklı 2 boyutlu tablo",
    icon: "table",
    createDoc: () => tableDoc(["Satır 1", "Satır 2"], ["Sütun 1", "Sütun 2"]),
  },
  {
    type: "grid",
    label: "Grid (Izgara)",
    description: "Serbest hücre grid'i",
    icon: "grid-on",
    createDoc: () => tableDoc(["1", "2"], ["A", "B", "C"]),
  },
];

export function templateFor(type: MindMapType): MindMapTemplate {
  const found = MIND_MAP_TEMPLATES.find((t) => t.type === type);
  if (!found) throw new Error(`Unknown mind map type: ${type}`);
  return found;
}
