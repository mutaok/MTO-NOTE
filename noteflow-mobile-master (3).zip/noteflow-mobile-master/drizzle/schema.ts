import { boolean, integer, jsonb, pgTable, serial, text, timestamp, varchar, pgEnum } from "drizzle-orm/pg-core";
import type { MindMapDoc, MindMapType } from "../shared/mindmap";

export const roleEnum = pgEnum("role", ["user", "admin"]);

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = pgTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: serial("id").primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: roleEnum("role").default("user").notNull(),
  createdAt: timestamp("createdAt", { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { mode: 'date' }).defaultNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn", { mode: 'date' }).defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User-authored notes. Free-form title/body pair with a single organizing tag.
 */
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  userId: integer("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  tag: varchar("tag", { length: 32 }).notNull().default("Kişisel"),
  /** Calendar day (YYYY-MM-DD) this note is pinned to, e.g. via "tap a day in Takvim → write a note". Null for ordinary notes. */
  date: varchar("date", { length: 10 }),
  createdAt: timestamp("createdAt", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { mode: "date" }).defaultNow().notNull(),
});

export type Note = typeof notes.$inferSelect;
export type InsertNote = typeof notes.$inferInsert;

/**
 * To-dos and calendar events share one table: an event is a task with a due
 * date/time. `dueDate` (YYYY-MM-DD) drives both the "Bugün/Gelecek" task
 * grouping and the calendar day view.
 */
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  list: varchar("list", { length: 32 }).notNull().default("Kişisel"),
  dueDate: varchar("dueDate", { length: 10 }),
  dueTime: varchar("dueTime", { length: 5 }),
  done: boolean("done").notNull().default(false),
  color: varchar("color", { length: 16 }).notNull().default("#64B5F6"),
  createdAt: timestamp("createdAt", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { mode: "date" }).defaultNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * A mind map / diagram document. `type` picks the template (see
 * shared/mindmap.ts); `data` holds the whole tree or table as JSON — a
 * single jsonb blob is far simpler than normalizing every node into its own
 * row, and diagrams are small enough that whole-document read/write is fine.
 */
export const mindMaps = pgTable("mind_maps", {
  id: serial("id").primaryKey(),
  userId: integer("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  type: varchar("type", { length: 24 }).notNull().$type<MindMapType>(),
  data: jsonb("data").notNull().$type<MindMapDoc>(),
  createdAt: timestamp("createdAt", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { mode: "date" }).defaultNow().notNull(),
});

export type MindMap = typeof mindMaps.$inferSelect;
export type InsertMindMap = typeof mindMaps.$inferInsert;

/**
 * Key-value synchronized store for NoteFlow data (notebooks, notes, tasks, mindmaps, etc.)
 * Stored in Neon PostgreSQL to synchronize instantly between PC, tablet, and mobile.
 */
export const syncStore = pgTable("sync_store", {
  id: serial("id").primaryKey(),
  userId: integer("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  storeKey: varchar("storeKey", { length: 64 }).notNull(),
  data: jsonb("data").notNull(),
  updatedAt: timestamp("updatedAt", { mode: "date" }).defaultNow().notNull(),
});

export type SyncStoreItem = typeof syncStore.$inferSelect;
export type InsertSyncStoreItem = typeof syncStore.$inferInsert;
