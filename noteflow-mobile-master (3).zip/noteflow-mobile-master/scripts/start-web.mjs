import { spawn } from "node:child_process";

// package.json used `${EXPO_PORT:-8081}`, which is bash-only syntax. On Windows,
// npm scripts run through cmd.exe by default, so the literal string was passed
// through unexpanded and expo tried to parse "NaN" as a port. This wrapper reads
// the env var in JS, which works the same on every shell.
const port = process.env.EXPO_PORT || "8081";

const child = spawn("npx", ["expo", "start", "--web", "--port", port, "--max-workers", "2"], {
  stdio: "inherit",
  shell: true,
  env: {
    ...process.env,
    // Metro's transform/render workers hit "Fatal process out of memory" on this
    // project's dependency graph with Node's default heap on low-RAM machines;
    // give workers more room and cap concurrency so peak usage stays bounded.
    NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ""} --max-old-space-size=4096`.trim(),
  },
});

child.on("exit", (code) => process.exit(code ?? 0));
